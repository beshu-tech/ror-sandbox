/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

// There's a bug in webpack that import doesn't work sometimes. So everything JS needs a require.
import "./less/main.less"
import "ui/autoload/modules"
const constants = require('../server/routes/lib/constants.js')

import "ui/autoload/styles"
import settingsTemplate from "./templates/settings.html"
import auditTemplate from "./templates/audit.html"
import { toastNotifications } from 'ui/notify'
import React from "react";
import { render } from 'react-dom';
import { AuditView } from "./components/auditView";

const uiModules = require("ui/modules")
const uiRoutes = require("ui/routes")
const chrome = require("ui/chrome")
const ace = require('brace')
require('brace/mode/yaml')
require('brace/theme/chrome')

// Some browsers don't have the console.log function, avoid crashing.
window.console = window.console || {
  log: function () {
  }
}

function toastMessage(message) {
  toastNotifications.addSuccess(message)
}

function toastError(message, err) {
  if (!message) {
    throw new Error("message can't be null")
  }
  if (!err) {
    err = new Error(message)
  }
  try {
    toastNotifications.addError(err, {})
  } catch (e) {
    toastNotifications.addDanger(message)
  }
}

eval(atob('aWYoZXZhbChhdG9iKCJNVFk1TURNd016RTVPVE13TkNBK0lEQWdKaVlnY0dGeWMyVkpiblFvWVhSdllpZ2lUVlJCZWsxNlFYbE5WRmt6VDFScmVFMUVSVDBpS1NrZ1BDQW9ibVYzSUVSaGRHVW9LU2t1WjJWMFZHbHRaU2dwIikpKXt0aHJvdyBuZXcgRXJyb3IoYXRvYigiVW1WaFpHOXViSGxTUlZOVUlHWnZjaUJMYVdKaGJtRWdhR0ZzZEdWa0lHSmxZMkYxYzJVZ2VXOTFjaUIwY21saGJDQm9ZWE1nWlhod2FYSmxaQ3dnYjNJZ2RHaHBjeUJpZFdsc1pDQnBjeUIzWVhrZ2RHOXZJRzlzWkM0Z1IyVjBJSFJvWlNCc1lYUmxjM1FnWW5WcGJHUXNJRzl5SUdkbGRDQmhjM05wYzNSaGJtTmxJR0YwSUdGMElHaDBkSEJ6T2k4dmNtVmhaRzl1YkhseVpYTjBMbU52YlE9PSIpKX0='))

uiRoutes.when('/', {
  template: settingsTemplate
})
  .when('/settings', {
    template: settingsTemplate
  })
  .when('/audit', {
    template: auditTemplate,
  })

uiRoutes.enable()

uiModules.get('app/readonlyrest_kbn', []).controller('AuditController', [function () {
    const el = document.getElementById('root');
    render(<AuditView toastNotifications={toastNotifications}
                      importUri={chrome.addBasePath(`/api/saved_objects/_import`)}
                      kibanaVersion={chrome.getInjected('kibana_version')}
    />, el);
  }]
);

uiModules.get('app/readonlyrest_kbn', []).controller('SettingsController', ['$scope', '$http', function ($scope, $http) {
  $scope.refreshSettings = () => refreshSettings('/api/readonlyrest_kbn/settings');
  $scope.refreshSettingsFromFile = () => refreshSettings('/api/readonlyrest_kbn/settings/file');

  /* SETTING UP ACE EDITOR */

  //{"selectionStyle":"line","highlightActiveLine":true,"highlightSelectedWord":true,"readOnly":false,"cursorStyle":"ace",
  // "mergeUndoDeltas":true,"behavioursEnabled":true,"wrapBehavioursEnabled":true,"hScrollBarAlwaysVisible":false,
  // "vScrollBarAlwaysVisible":false,"highlightGutterLine":true,"animatedScroll":true,"showInvisibles":true,"showPrintMargin":true,
  // "printMarginColumn":80,"printMargin":80,"fadeFoldWidgets":true,"showFoldWidgets":true,"showLineNumbers":true,"showGutter":true,
  // "displayIndentGuides":true,"fontSize":"14px","scrollPastEnd":1,"theme":"ace/theme/chrome","scrollSpeed":2,"dragDelay":150,
  // "dragEnabled":true,"focusTimout":0,"tooltipFollowsMouse":true,"firstLineNumber":1,"overwrite":false,"newLineMode":"auto",
  // "useWorker":true,"useSoftTabs":true,"tabSize":4,"wrap":"off","indentedSoftWrap":true,"mode":"ace/mode/yaml",
  // "enableMultiselect":true,"enableBlockSelect":true,"spellcheck":true,"loadDroppedFile":true,"useElasticTabstops":true,"useIncrementalSearch":false,"enableEmmet":true,"enableBasicAutocompletion":true,"enableLiveAutocompletion":false,"enableSnippets":true});
  var editor = ace.edit("editor")
  editor.getSession().setMode('ace/mode/yaml');
  //  editor.setTheme('ace/theme/chrome');
  editor.setShowPrintMargin(false);
  editor.getShowFoldWidgets(true);
  editor.session.setUseSoftTabs(true)
  editor.session.setTabSize(2)
  editor.getHighlightSelectedWord(true)
  editor.setShowInvisibles(true)
  editor.setAutoScrollEditorIntoView = true
  editor.$blockScrolling = Infinity

  // editor.setShowPrintMargin(true)
  // editor.showSettingsMenu(true)

  /* END SETUP ACE EDITOR */
  function refreshSettings(path) {
    $http.get(chrome.addBasePath(path)).then((response) => {
      if (response.data.status == 'empty') {
        try {
          if (path.indexOf('/file') < 0) {
            $scope.refreshSettingsFromFile()
          }
          toastMessage('No settings in index, loaded from readonlyrest.yml')
        } catch (e) {
        }
        editor.setValue(response.data.message, 1);
        return;
      }
      if (response.status == 401) {
        toastError("Credentials invalid for retrieving settings: " + response.data.message)
        return;
      }
      if (response.status >= 300 || response.data.status != 'ok') {
        toastError("Failed to get the security settings: " + response.data.message)
        if (path.indexOf('/file') < 0) {
          $scope.refreshSettingsFromFile()
        }
        return;
      }
      try { // 6.3.x seems not to have the .info method. This is not vital, so try to do it or ignore.
        toastMessage("Successfully fetched security settings.")
      } catch (e) {
      }
      try {
        editor.setValue(JSON.parse('{"a": ' + response.data.message + '}').a, 1)
      } catch (e) {
        editor.setValue(response.data.message, 1)
      }
    })
      .catch(function (e, r) {
        toastError("Elasticsearch error: " + JSON.stringify(e), e)
      })
      .finally(() => {
        markEditorClean()
      })
  }


  $scope.setupSearchBox = function () {
    var searchBox = $('#editorSearch')
    searchBox.bind("enterKey", function (e) {
      editor.find(searchBox.val(), {
        backwards: false,
        wrap: true,
        caseSensitive: false,
        wholeWord: false,
        regExp: false
      });
    });
    searchBox.keyup(function (e) {
      if (e.keyCode == 13) {
        $(this).trigger("enterKey");
      }
    });
  }

  // Utility function to fetch settings
  $scope.getEditorContent = function () {
    return editor.getValue()
  }

  // Saving to backend.
  $scope.tryToSaveSettings = function () {
    const payload = editor.getValue()

    let shouldNotifyUpgrade = true

    if (shouldNotifyUpgrade) {
      toastError("This feature is not enabled in ReadonlyREST Free. Please upgrade to PRO or Enterprise subscriptions. For more information, please visit https://readonlyrest.com or contact us at info@readonlyrest.com")
      return
    }
  };

  // First rendering = Load settings from backend
  $scope.refreshSettings();
  $scope.setupSearchBox();

  let editorDirty = false;

  editor.getSession().on('change', function (e) {
    editorDirty = true;
  });

  window.onbeforeunload = () => !editorDirty ? void (0) : true;

  function markEditorClean() {
    editorDirty = false;
  }

  $('#save').click(() => $scope.tryToSaveSettings())
  $('#discard').click(() => $scope.refreshSettings())
  $('#default').click(() => $scope.refreshSettingsFromFile())
}]);
