/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
import * as React from "react";
import { Card } from "./common/card";
import { Spacer } from "./common/spacer";
import { FlexGrid } from "./common/flexGrid";
import { FlexItem } from "./common/flexItem";
import { Button } from "./common/button";
import { FlexGroup } from "./common/flexGroup";
import { Title } from "./common/title";
import { Panel } from "./common/panel";
import { Text } from "./common/text";
import { IconAppManagement } from "./icons/gearWheelIcon";
import { HorizontalRule } from "./common/horizontalRule";
import { Code } from "./common/code";
import { RorPage } from "./rorPage";
import { importAuditLogDashboard } from './services/auditLogDashboardService';
import { HorizontalCard } from "./horizontalCard";
export class AuditView extends React.Component {
    constructor() {
        super(...arguments);
        this.onDashboardLoad = () => {
            if (this.props.kibanaVersion < "7.0.0") {
                this.props.toastNotifications.addDanger("Unsupported feature. Please upgrade to Kibana 7.0.0 or above");
                return;
            }
            const fileName = 'audit_dashboard.ndjson';
            importAuditLogDashboard(this.props.kibanaVersion, this.props.importUri, `../plugins/readonlyrest_kbn/${fileName}`, fileName)
                .then(response => this.handleNotifications(response))
                .catch(error => console.error(error));
        };
        this.handleNotifications = (response) => {
            if (response.successful === response.total) {
                this.props.toastNotifications.addSuccess("Successfully loaded audit dashboard");
                return;
            }
            this.props.toastNotifications.addDanger(`Loaded ${response.successful}/${response.total}`);
        };
    }
    render() {
        return (React.createElement(RorPage, { tabNumber: 3 },
            React.createElement(React.Fragment, null,
                React.createElement(FlexGrid, { columns: 3 },
                    React.createElement(FlexItem, null,
                        React.createElement(Card, { title: "Audit log dashboard", description: "Clearly express and visualise security events persisted in audit log within your cluster.", image: "../plugins/readonlyrest_kbn/audit_log_viz_example.png", layout: "vertical", textAlign: "left", footer: React.createElement(FlexGroup, { justifyContent: "flexEnd" },
                                React.createElement(FlexItem, { grow: false },
                                    React.createElement(Button, { onClick: this.onDashboardLoad }, "Load data"))) })),
                    React.createElement(FlexItem, { grow: 2 },
                        React.createElement(Panel, { grow: true, paddingSize: "m", className: "euiPageContent--horizontalCenter" },
                            React.createElement("div", { className: "eui-textCenter" },
                                React.createElement(IconAppManagement, null),
                                React.createElement(Title, { size: "l" },
                                    React.createElement("h3", null, "Audit log configuration")),
                                React.createElement(HorizontalRule, null)),
                            React.createElement("div", { className: "eui-textLeft" },
                                React.createElement(Text, null,
                                    React.createElement("p", null,
                                        "ReadonlyREST can be configured to store incoming HTTP requests events as JSON documents in a series of indices:",
                                        React.createElement(Code, null, "readonlyrest_audit-YYYY-MM-DD"))),
                                React.createElement(Spacer, { size: "m" }),
                                React.createElement(Text, null,
                                    React.createElement("p", null,
                                        "To enable audit logging just add the ",
                                        React.createElement(Code, null, "audit_collector: true"),
                                        " to your security settings."),
                                    React.createElement("pre", null,
                                        React.createElement("p", { style: { textAlign: "start", marginBottom: 0 } },
                                            React.createElement(Code, null,
                                                "readonlyrest:",
                                                React.createElement("br", null),
                                                React.createElement("br", null),
                                                "\u00A0\u00A0\u00A0\u00A0audit_collector: true",
                                                React.createElement("br", null),
                                                "\u00A0\u00A0\u00A0\u00A0...")))))))),
                React.createElement(HorizontalRule, { margin: "xl" }),
                React.createElement(Panel, null,
                    React.createElement(FlexGroup, null,
                        React.createElement(FlexItem, null,
                            React.createElement(Title, null,
                                React.createElement("h3", null, "ReadonlyREST Audit logs example visualizations")),
                            React.createElement(Text, { size: "s" },
                                React.createElement("p", null, "Here are some examples of what can be done - feel free to get inspired")))),
                    React.createElement(Spacer, { size: "xl" }),
                    React.createElement(HorizontalCard, { imagePath: "../plugins/readonlyrest_kbn/time_by_user_example.png", description: "This is an example of a time by user pie chart" }),
                    React.createElement(Spacer, { size: "m" }),
                    React.createElement(HorizontalCard, { imagePath: "../plugins/readonlyrest_kbn/avg_request_time_example.png", description: "This is an example of an average request time chart" }),
                    React.createElement(Spacer, { size: "m" }),
                    React.createElement(HorizontalCard, { imagePath: "../plugins/readonlyrest_kbn/indices_breakdown_example.png", description: "This is an example of an indices breakdown pie chart" }),
                    React.createElement(Spacer, { size: "m" }),
                    React.createElement(HorizontalCard, { imagePath: "../plugins/readonlyrest_kbn/response_time_vs_request_body_length_example.png", description: "This is an example of a chart showing cumulative response time vs cumulative request body length in KB" })),
                React.createElement(HorizontalRule, { margin: "xl" }),
                React.createElement(Panel, null,
                    React.createElement(Title, null,
                        React.createElement("h5", null, "Custom audit log serializer")),
                    React.createElement(Text, { size: "m" },
                        React.createElement("p", null, "You can write your own custom audit log serializer as a Java/Scala class, add it to the ROR plugin class path and configure it through the YAML settings.")),
                    React.createElement(Spacer, null),
                    React.createElement(Title, null,
                        React.createElement("h5", null, "More about this")),
                    React.createElement(Text, { size: "m" },
                        React.createElement("p", null,
                            "For more detailed explanation, see the ",
                            React.createElement("a", { href: "https://github.com/beshu-tech/readonlyrest-docs/blob/master/elasticsearch.md#audit-logs" }, "official documentation project on Github"),
                            "."))))));
    }
}
