/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
// This component is extracted from EUI, which is released under Apache License 2.0
/*
 * Licensed to Elasticsearch B.V. under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch B.V. licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
import React from 'react';
import classNames from 'classnames';
export const GROW_SIZES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
export const FlexItem = (_a) => {
    var { children, className, grow = true, component: Component = 'div' } = _a, rest = __rest(_a, ["children", "className", "grow", "component"]);
    validateGrowValue(grow);
    const classes = classNames('euiFlexItem', {
        'euiFlexItem--flexGrowZero': !grow,
        [`euiFlexItem--flexGrow${grow}`]: typeof grow === 'number' ? GROW_SIZES.indexOf(grow) >= 0 : undefined,
    }, className);
    return (
    // @ts-ignore
    React.createElement(Component, Object.assign({ className: classes }, rest), children));
};
function validateGrowValue(value) {
    const validValues = [null, undefined, true, false, ...GROW_SIZES];
    if (validValues.indexOf(value) === -1) {
        throw new Error(`Prop \`grow\` passed to \`FlexItem\` must be a boolean or an integer between 1 and 10, received \`${value}\``);
    }
}
