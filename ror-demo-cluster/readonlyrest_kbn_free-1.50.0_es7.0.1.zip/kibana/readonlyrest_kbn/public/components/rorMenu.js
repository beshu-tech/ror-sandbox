/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
import * as React from "react";
import { Popover } from "./common/popover";
import { HeaderSectionItemButton } from "./common/headerSectionItemButton";
import { Spacer } from "./common/spacer";
import { Button } from "./common/button";
import { Text } from "./common/text";
import { Select } from "./common/select";
import { FlexGroup } from "./common/flexGroup";
import { FlexItem } from "./common/flexItem";
export class RorMenu extends React.Component {
    constructor(props) {
        super(props);
        this.toggleRorMenu = () => {
            this.setState({
                showRorMenu: !this.state.showRorMenu,
            });
        };
        this.closeRorMenu = () => {
            this.setState({
                showRorMenu: false,
            });
        };
        this.onLogoutClick = () => {
            window.location.href = this.props.logoutRedirect;
        };
        this.onGoToSettingsPageClick = () => {
            window.location.href = this.props.settingsRedirect;
        };
        this.onGoToReportingPage = () => {
            window.location.href = this.props.reportingRedirect;
        };
        //TODO: figure out how to shut TS up about the "union mapping"
        this.getGroupOptions = () => {
            // @ts-ignore
            return this.props.availableGroups && this.props.availableGroups.map(group => ({
                value: group.groupName || group,
                label: group.alias || group
            }));
        };
        this.getBadgeLabel = () => {
            switch (this.props.kibanaAccess) {
                case 'ro':
                    return 'ro';
                case 'ro_strict':
                    return 'rs';
                case 'rw':
                    return 'rw';
                case 'admin':
                    return 'a';
                case 'unrestricted':
                    return 'u';
                default:
                    return '';
            }
        };
        this.isAccessUnrestricted = () => {
            return this.props.kibanaAccess === 'unrestricted' || this.props.kibanaAccess === 'admin';
        };
        this.showSettingsButton = () => {
            return this.props.kibanaAccess === undefined || this.isAccessUnrestricted();
        };
        this.renderAccessLevel = () => {
            return this.isAccessUnrestricted() ? this.props.kibanaAccess : this.props.kibanaAccess && this.props.kibanaAccess.toUpperCase();
        };
        this.state = {
            showRorMenu: false
        };
    }
    render() {
        const button = (React.createElement(HeaderSectionItemButton, { onClick: this.toggleRorMenu },
            React.createElement("img", { alt: "ReadonlyREST", height: "20", src: this.props.logoPath })));
        return (React.createElement(Popover, { id: 'rorMenuPopover', button: button, isOpen: this.state.showRorMenu, closePopover: this.closeRorMenu, anchorPosition: "leftDown", panelPaddingSize: "m", repositionOnScroll: true, withTitle: true, badgeLabel: this.getBadgeLabel(), badgeTitle: this.props.kibanaAccess },
            React.createElement("div", { className: 'euiPopoverTitle', style: { 'textTransform': 'none' } },
                React.createElement(FlexGroup, null,
                    React.createElement(FlexItem, null, "ReadonlyREST"),
                    React.createElement(FlexItem, { className: 'chrHeaderHelpMenu__version', style: {
                            fontWeight: 200,
                            fontSize: '65%',
                            whiteSpace: 'nowrap',
                        } }, this.props.rorVersion))),
            React.createElement("div", { style: { maxWidth: 240 } },
                React.createElement(Text, { size: "s" },
                    React.createElement("p", { style: { 'overflow': 'hidden', 'whiteSpace': 'nowrap' } },
                        "Logged in as: ",
                        React.createElement("span", { style: { 'fontWeight': 600 } }, this.props.username),
                        React.createElement("br", null),
                        this.props.kibanaAccess &&
                            React.createElement("span", null,
                                "Access",
                                React.createElement("span", { style: { marginLeft: '2px' } }),
                                " level: ",
                                React.createElement("span", { style: { 'fontWeight': 600 } }, this.renderAccessLevel())))),
                this.showSettingsButton() &&
                    React.createElement("span", null,
                        React.createElement(Spacer, null),
                        React.createElement(Button, { onClick: this.onGoToSettingsPageClick, fullWidth: true }, "Go to settings page")),
                this.props.showReportLink &&
                    React.createElement("span", null,
                        React.createElement(Spacer, null),
                        React.createElement(Button, { color: 'secondary', onClick: this.onGoToReportingPage, fullWidth: true }, "Go to CSV reports")),
                this.props.availableGroups &&
                    React.createElement("span", null,
                        React.createElement(Spacer, null),
                        React.createElement(Text, { size: "s" }, "Selected tenancy:"),
                        React.createElement(Select, { options: this.getGroupOptions(), onChange: this.props.onTenancyHop, value: typeof this.props.currentGroup === 'string' ? this.props.currentGroup : this.props.currentGroup && this.props.currentGroup.groupName })),
                React.createElement(Spacer, null),
                React.createElement(Button, { onClick: this.onLogoutClick, color: 'secondary', fullWidth: true }, "Logout"))));
    }
}
