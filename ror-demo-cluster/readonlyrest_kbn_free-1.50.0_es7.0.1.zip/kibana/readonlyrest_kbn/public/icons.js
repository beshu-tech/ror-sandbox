/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

import chrome from "ui/chrome"
import React from 'react';
import ReactDOM from 'react-dom';
import { chromeHeaderNavControlsRegistry } from 'ui/registry/chrome_header_nav_controls';
import { RorMenu } from "./components/rorMenu";

const constants = require('../server/routes/lib/constants.js')

let hasDrawnLogoutBar = false

const rorVersion = "free-1.50.0_es7.0.1"
const members = {
  I_LOGOUT: `<img width="400" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+PHN2ZyAgIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgICB4bWxuczpjYz0iaHR0cDovL2NyZWF0aXZlY29tbW9ucy5vcmcvbnMjIiAgIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIgICB4bWxuczpzdmc9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiAgIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgICB4bWxuczpzb2RpcG9kaT0iaHR0cDovL3NvZGlwb2RpLnNvdXJjZWZvcmdlLm5ldC9EVEQvc29kaXBvZGktMC5kdGQiICAgeG1sbnM6aW5rc2NhcGU9Imh0dHA6Ly93d3cuaW5rc2NhcGUub3JnL25hbWVzcGFjZXMvaW5rc2NhcGUiICAgdmVyc2lvbj0iMS4xIiAgIHg9IjBweCIgICB5PSIwcHgiICAgdmlld0JveD0iMCAwIDEwMDAgMTAwMCIgICBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCAxMDAwIDEwMDAiICAgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgICBpZD0ic3ZnMiIgICBpbmtzY2FwZTp2ZXJzaW9uPSIwLjkxIHIxMzcyNSIgICBzb2RpcG9kaTpkb2NuYW1lPSJpY29uLnN2ZyI+PGRlZnMgICAgIGlkPSJkZWZzMTQiIC8+PHNvZGlwb2RpOm5hbWVkdmlldyAgICAgcGFnZWNvbG9yPSIjZmZmZmZmIiAgICAgYm9yZGVyY29sb3I9IiM2NjY2NjYiICAgICBib3JkZXJvcGFjaXR5PSIxIiAgICAgb2JqZWN0dG9sZXJhbmNlPSIxMCIgICAgIGdyaWR0b2xlcmFuY2U9IjEwIiAgICAgZ3VpZGV0b2xlcmFuY2U9IjEwIiAgICAgaW5rc2NhcGU6cGFnZW9wYWNpdHk9IjAiICAgICBpbmtzY2FwZTpwYWdlc2hhZG93PSIyIiAgICAgaW5rc2NhcGU6d2luZG93LXdpZHRoPSI2NDAiICAgICBpbmtzY2FwZTp3aW5kb3ctaGVpZ2h0PSI0ODAiICAgICBpZD0ibmFtZWR2aWV3MTIiICAgICBzaG93Z3JpZD0iZmFsc2UiICAgICBpbmtzY2FwZTp6b29tPSIwLjIzNiIgICAgIGlua3NjYXBlOmN4PSI1MDAiICAgICBpbmtzY2FwZTpjeT0iNTAwIiAgICAgaW5rc2NhcGU6d2luZG93LXg9IjAiICAgICBpbmtzY2FwZTp3aW5kb3cteT0iMCIgICAgIGlua3NjYXBlOndpbmRvdy1tYXhpbWl6ZWQ9IjAiICAgICBpbmtzY2FwZTpjdXJyZW50LWxheWVyPSJnNiIgLz48bWV0YWRhdGEgICAgIGlkPSJtZXRhZGF0YTQiPiBTdmcgVmVjdG9yIEljb25zIDogaHR0cDovL3d3dy5vbmxpbmV3ZWJmb250cy5jb20vaWNvbiA8cmRmOlJERj48Y2M6V29yayAgICAgcmRmOmFib3V0PSIiPjxkYzpmb3JtYXQ+aW1hZ2Uvc3ZnK3htbDwvZGM6Zm9ybWF0PjxkYzp0eXBlICAgICAgIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiIC8+PC9jYzpXb3JrPjwvcmRmOlJERj48L21ldGFkYXRhPjxnICAgICBpZD0iZzYiPjxwYXRoICAgICAgIGQ9Ik05OTAsNDk5LjNjMC0xMS45LTQuMS0yMi44LTExLTMxLjVjLTIuMS0zLjQtNC42LTYuNy03LjUtOS42TDgxMC45LDI5Ny43Yy0xOS44LTE5LjgtNTEuOS0xOS44LTcxLjcsMGMtMTkuOCwxOS44LTE5LjgsNTEuOSwwLDcxLjdsNzkuMyw3OS4zbC0zODcuNCwwYy0yOCwwLTUwLjcsMjIuNy01MC43LDUwLjdjMCwyOCwyMi43LDUwLjcsNTAuNyw1MC43bDM4Ny4yLDBsLTc2LjUsNzYuNWMtMTkuOCwxOS44LTE5LjgsNTEuOSwwLDcxLjdjOS45LDkuOSwyMi45LDE0LjgsMzUuOCwxNC44YzEzLDAsMjUuOS00LjksMzUuOC0xNC44bDE2MC42LTE2MC42YzUtNSw4LjgtMTAuOSwxMS4zLTE3LjFDOTg4LjMsNTE0LDk5MCw1MDYuOSw5OTAsNDk5LjN6IiAgICAgICBpZD0icGF0aDgiICAgICAgIHN0eWxlPSJmaWxsOiNmZmZmZmYiIC8+PHBhdGggICAgICAgZD0iTTY0Ny45LDc1NS40Yy0yOCwwLTUwLjcsMjIuNy01MC43LDUwLjd2ODEuN0gxMTEuNFYxMTIuMmg0ODUuOHY5Ny42YzAsMjgsMjIuNyw1MC43LDUwLjcsNTAuN2MyOCwwLDUwLjctMjIuNyw1MC43LTUwLjdWOTEuM2MwLTQ0LjQtMzYuMS04MC41LTgwLjUtODAuNUg5MC41QzQ2LjEsMTAuOCwxMCw0Ni45LDEwLDkxLjN2ODE3LjNjMCw0NC40LDM2LjEsODAuNSw4MC41LDgwLjVINjE4YzQ0LjQsMCw4MC41LTM2LjEsODAuNS04MC41VjgwNi4xQzY5OC42LDc3OC4xLDY3NS45LDc1NS40LDY0Ny45LDc1NS40eiIgICAgICAgaWQ9InBhdGgxMCIgICAgICAgc3R5bGU9ImZpbGw6I2ZmZmZmZiIgLz48L2c+PC9zdmc+">`,
  I_EYE: '<img alt="Read-only" width=20 src="data:image/svg+xml,%3C%3Fxml%20version%3D%221.0%22%20encoding%3D%22utf-8%22%3F%3E%0A%3Csvg%20width%3D%221792%22%20height%3D%221792%22%20viewBox%3D%220%200%201792%201792%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cpath%20d%3D%22M1664%20960q-152-236-381-353%2061%20104%2061%20225%200%20185-131.5%20316.5t-316.5%20131.5-316.5-131.5-131.5-316.5q0-121%2061-225-229%20117-381%20353%20133%20205%20333.5%20326.5t434.5%20121.5%20434.5-121.5%20333.5-326.5zm-720-384q0-20-14-34t-34-14q-125%200-214.5%2089.5t-89.5%20214.5q0%2020%2014%2034t34%2014%2034-14%2014-34q0-86%2061-147t147-61q20%200%2034-14t14-34zm848%20384q0%2034-20%2069-140%20230-376.5%20368.5t-499.5%20138.5-499.5-139-376.5-368q-20-35-20-69t20-69q140-229%20376.5-368t499.5-139%20499.5%20139%20376.5%20368q20%2035%2020%2069z%22%20fill%3D%22%23fff%22/%3E%3C/svg%3E">',
  I_EYE_BARRED: '<img  alt="Read-only (Strict mode)" width=20 src="data:image/svg+xml,%3C%3Fxml%20version%3D%221.0%22%20encoding%3D%22utf-8%22%3F%3E%0A%3Csvg%20width%3D%221792%22%20height%3D%221792%22%20viewBox%3D%220%200%201792%201792%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cpath%20d%3D%22M555%201335l78-141q-87-63-136-159t-49-203q0-121%2061-225-229%20117-381%20353%20167%20258%20427%20375zm389-759q0-20-14-34t-34-14q-125%200-214.5%2089.5t-89.5%20214.5q0%2020%2014%2034t34%2014%2034-14%2014-34q0-86%2061-147t147-61q20%200%2034-14t14-34zm363-191q0%207-1%209-106%20189-316%20567t-315%20566l-49%2089q-10%2016-28%2016-12%200-134-70-16-10-16-28%200-12%2044-87-143-65-263.5-173t-208.5-245q-20-31-20-69t20-69q153-235%20380-371t496-136q89%200%20180%2017l54-97q10-16%2028-16%205%200%2018%206t31%2015.5%2033%2018.5%2031.5%2018.5%2019.5%2011.5q16%2010%2016%2027zm37%20447q0%20139-79%20253.5t-209%20164.5l280-502q8%2045%208%2084zm448%20128q0%2035-20%2069-39%2064-109%20145-150%20172-347.5%20267t-419.5%2095l74-132q212-18%20392.5-137t301.5-307q-115-179-282-294l63-112q95%2064%20182.5%20153t144.5%20184q20%2034%2020%2069z%22%20fill%3D%22%23fff%22/%3E%3C/svg%3E">',
  I_PENCIL: '<img  alt="Can make changes" width=20 src="data:image/svg+xml,%3C%3Fxml%20version%3D%221.0%22%20encoding%3D%22utf-8%22%3F%3E%0A%3Csvg%20width%3D%221792%22%20height%3D%221792%22%20viewBox%3D%220%200%201792%201792%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cpath%20d%3D%22M532%201108l152%20152-52%2052h-56v-96h-96v-56zm414-390q14%2013-3%2030l-291%20291q-17%2017-30%203-14-13%203-30l291-291q17-17%2030-3zm-274%20690l544-544-288-288-544%20544v288h288zm608-608l92-92q28-28%2028-68t-28-68l-152-152q-28-28-68-28t-68%2028l-92%2092zm384-384v960q0%20119-84.5%20203.5t-203.5%2084.5h-960q-119%200-203.5-84.5t-84.5-203.5v-960q0-119%2084.5-203.5t203.5-84.5h960q119%200%20203.5%2084.5t84.5%20203.5z%22%20fill%3D%22%23fff%22/%3E%3C/svg%3E">',
  I_BADGE: '<img  alt="ReadonlyREST Administrator" width=20 src="data:image/svg+xml,%3C%3Fxml%20version%3D%221.0%22%20encoding%3D%22utf-8%22%3F%3E%0A%3Csvg%20width%3D%222048%22%20height%3D%221792%22%20viewBox%3D%220%200%202048%201792%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cpath%20d%3D%22M1024%201131q0-64-9-117.5t-29.5-103-60.5-78-97-28.5q-6%204-30%2018t-37.5%2021.5-35.5%2017.5-43%2014.5-42%204.5-42-4.5-43-14.5-35.5-17.5-37.5-21.5-30-18q-57%200-97%2028.5t-60.5%2078-29.5%20103-9%20117.5%2037%20106.5%2091%2042.5h512q54%200%2091-42.5t37-106.5zm-157-520q0-94-66.5-160.5t-160.5-66.5-160.5%2066.5-66.5%20160.5%2066.5%20160.5%20160.5%2066.5%20160.5-66.5%2066.5-160.5zm925%20509v-64q0-14-9-23t-23-9h-576q-14%200-23%209t-9%2023v64q0%2014%209%2023t23%209h576q14%200%2023-9t9-23zm0-260v-56q0-15-10.5-25.5t-25.5-10.5h-568q-15%200-25.5%2010.5t-10.5%2025.5v56q0%2015%2010.5%2025.5t25.5%2010.5h568q15%200%2025.5-10.5t10.5-25.5zm0-252v-64q0-14-9-23t-23-9h-576q-14%200-23%209t-9%2023v64q0%2014%209%2023t23%209h576q14%200%2023-9t9-23zm256-320v1216q0%2066-47%20113t-113%2047h-352v-96q0-14-9-23t-23-9h-64q-14%200-23%209t-9%2023v96h-768v-96q0-14-9-23t-23-9h-64q-14%200-23%209t-9%2023v96h-352q-66%200-113-47t-47-113v-1216q0-66%2047-113t113-47h1728q66%200%20113%2047t47%20113z%22%20fill%3D%22%23fff%22/%3E%3C/svg%3E">',
  I_TENANCY_SELECTOR: `<img  alt="Tenancy Selector" width=20 src="data:image/svg+xml,%3C%3Fxml version='1.0' encoding='utf-8'%3F%3E%3C!-- Generator: Adobe Illustrator 15.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0) --%3E%3C!DOCTYPE svg PUBLIC '-//W3C//DTD SVG 1.1//EN' 'http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd'%3E%3Csvg version='1.1' id='Layer_1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' width='25.714px' height='24px' viewBox='1011.143 884 25.714 24' enable-background='new 1011.143 884 25.714 24' xml:space='preserve'%3E%3Cpath fill='%23FFFFFF' d='M1019.085,896c-1.446,0.044-2.629,0.616-3.549,1.714h-1.795c-0.732,0-1.348-0.18-1.848-0.542 c-0.5-0.362-0.75-0.891-0.75-1.587c0-3.151,0.553-4.727,1.661-4.727c0.054,0,0.248,0.094,0.583,0.281 c0.335,0.188,0.77,0.377,1.306,0.569c0.535,0.192,1.067,0.289,1.593,0.289c0.599,0,1.192-0.104,1.781-0.309 c-0.044,0.33-0.067,0.625-0.067,0.884C1018,893.812,1018.361,894.955,1019.085,896z M1033.428,904.531 c0,1.071-0.325,1.917-0.977,2.537c-0.652,0.621-1.519,0.932-2.598,0.932h-11.706c-1.08,0-1.946-0.311-2.599-0.932 c-0.651-0.62-0.977-1.466-0.977-2.537c0-0.474,0.016-0.936,0.046-1.386c0.032-0.451,0.094-0.938,0.188-1.46 c0.094-0.523,0.212-1.008,0.355-1.453c0.143-0.447,0.334-0.882,0.576-1.306c0.241-0.425,0.518-0.786,0.831-1.085 c0.312-0.3,0.694-0.538,1.145-0.717c0.451-0.179,0.948-0.268,1.493-0.268c0.09,0,0.282,0.096,0.576,0.287 c0.294,0.192,0.621,0.407,0.978,0.644c0.357,0.236,0.835,0.451,1.433,0.643c0.599,0.192,1.201,0.288,1.808,0.288 c0.606,0,1.209-0.096,1.808-0.288c0.599-0.191,1.076-0.406,1.434-0.643s0.683-0.451,0.978-0.644 c0.295-0.191,0.486-0.287,0.575-0.287c0.545,0,1.043,0.089,1.494,0.268c0.45,0.179,0.832,0.417,1.145,0.717 c0.313,0.299,0.589,0.66,0.831,1.085c0.24,0.424,0.434,0.858,0.575,1.306c0.143,0.445,0.262,0.93,0.354,1.453 c0.095,0.522,0.156,1.009,0.188,1.46C1033.412,903.596,1033.428,904.058,1033.428,904.531z M1019.714,887.429 c0,0.946-0.335,1.755-1.004,2.424c-0.67,0.669-1.478,1.004-2.424,1.004c-0.946,0-1.754-0.335-2.424-1.004s-1.004-1.478-1.004-2.424 s0.335-1.754,1.004-2.424c0.669-0.669,1.478-1.004,2.424-1.004c0.947,0,1.754,0.335,2.424,1.004 C1019.379,885.674,1019.714,886.482,1019.714,887.429z M1029.143,892.571c0,1.42-0.502,2.632-1.507,3.636 c-1.004,1.004-2.216,1.506-3.636,1.506s-2.631-0.502-3.636-1.506c-1.005-1.004-1.507-2.216-1.507-3.636 c0-1.419,0.502-2.631,1.507-3.636c1.004-1.004,2.216-1.507,3.636-1.507s2.632,0.502,3.636,1.507 C1028.641,889.94,1029.143,891.152,1029.143,892.571z M1036.857,895.584c0,0.697-0.251,1.225-0.751,1.587s-1.116,0.542-1.848,0.542 h-1.794c-0.92-1.098-2.104-1.669-3.549-1.714c0.723-1.045,1.084-2.188,1.084-3.429c0-0.258-0.022-0.554-0.067-0.884 c0.59,0.205,1.184,0.309,1.782,0.309c0.525,0,1.058-0.097,1.593-0.289c0.536-0.192,0.972-0.381,1.306-0.569 c0.335-0.188,0.529-0.281,0.583-0.281C1036.304,890.857,1036.857,892.433,1036.857,895.584z M1035.143,887.429 c0,0.946-0.334,1.755-1.004,2.424s-1.479,1.004-2.424,1.004c-0.947,0-1.755-0.335-2.425-1.004s-1.005-1.478-1.005-2.424 s0.335-1.754,1.005-2.424c0.67-0.669,1.478-1.004,2.425-1.004c0.945,0,1.754,0.335,2.424,1.004 C1034.809,885.674,1035.143,886.482,1035.143,887.429z'/%3E%3C/svg%3E%0A">`,
  THEME_COLOR: constants.isEnterprise() ? 'blue' : 'green'
};

const functions = {
  kibanaAccess2Icon: (kibanaAccess) => {
    switch (kibanaAccess) {
      case 'ro':
        return members.I_EYE
      case 'ro_strict':
        return members.I_EYE_BARRED
      case 'rw':
        return members.I_PENCIL
      case 'admin':
        return members.I_BADGE
      default:
        return '?'
    }
  },

  mkRorBar: () => {

    if (hasDrawnLogoutBar) {
      return
    }
    hasDrawnLogoutBar = true

    // Common data
    const identity = chrome.getInjected('identity')
    let redirectToLogout = chrome.addBasePath("/logout")

    if (!identity || !identity.username) {
      console.log("ROR frontend was handed invalid identity. Will abort the session to /logout", identity)
      window.location.href = redirectToLogout
      return
    }

    const origin = identity["x-ror-origin"] || constants.INTERNAL_ORIGIN
    redirectToLogout += '?x-ror-origin=' + origin

    const mkRorBarOld = () => {
      let icons = members
      if ($('#ror_bar').length === 0) {
        const classes = members.THEME_COLOR
        $('body')
          .append(`
      <div id="ror_bar_wrapper" class="${classes}">
        <div id="ror_bar_collapsible">
            <button id="ror_expander">&#187;</button>
        </div>
        <div id="ror_bar">
          <div id="ror_bar_content_wrapper">
            <span id="ror_user"></span>  <span id="ror_tenancy_sel"></span> <span id="ror_logout_span"></span>
          </div>
        </div>
      </div>
      `)

        function buttonHtml() {
          return `<a href="${redirectToLogout}" id="ror_logout">${icons.I_LOGOUT} <span id="ror_logout_username" title="Logout ${identity.username}"></span></a>`
        }

        let collapsed = false;
        let rorBarWidth = 0;

        $("#ror_user").text(identity.username);
        $('#ror_logout_span').append(buttonHtml());
        $('#ror_expander').on("click", function () {
          if (collapsed || $('#ror_bar').css("width").startsWith("0")) {
            $('#ror_bar').width(rorBarWidth);
            $('#ror_expander').html("&#187;");
            collapsed = false;
          } else {
            rorBarWidth = $('#ror_bar').width();
            $('#ror_bar').width(0);
            $('#ror_expander').html("&#171;");
            collapsed = true
          }
        })
      }
    }

    if (constants.isKibanaMoreAncientThan("7.0.0")) {
      return mkRorBarOld()
    }

    /// ---------- New React ROR BAR A.K.A ROR MENU -------------

    //TODO: this should actually be inside RorMenu component, but TS has problems with importing "chrome" - to be resolved
    const onTenancyHop = (event) => {
      if (!constants.isEnterprise()) {
        alert("please upgrade to ReadonlyREST Enterprise to use the multi-tenancy feature.")
        return false
      }
      const clearSessionOnEvents = chrome.getInjected('clearSessionOnEvents')

      if (clearSessionOnEvents && clearSessionOnEvents.includes('tenancyHop')) {
        window.localStorage && window.localStorage.clear()
        window.sessionStorage && window.sessionStorage.clear()
      }
      const redirect2Href = chrome.addBasePath('/switch-group?group=' + event.target.value + '&redirectTo=' + encodeURIComponent(location.href));
      console.log(">> Redirecting to switch group... ", redirect2Href)
      location.href = redirect2Href
    }

    const readableVersionString = (version) => {
      return version && version.replace("-", " ").charAt(0).toUpperCase() + version.slice(1)
    }

    const showReportLink = identity.hiddenApps && identity.hiddenApps.includes("kibana:stack_management")

    chromeHeaderNavControlsRegistry.register(() => ({
      name: 'ror-controls',
      order: 1000,
      side: 'right',
      render(el) {
        ReactDOM.render(
          <RorMenu
            onTenancyHop={onTenancyHop}
            currentGroup={identity.groupCurrent}
            availableGroups={identity.groupsAvailable}
            username={identity.username}
            rorVersion={readableVersionString(rorVersion)}
            kibanaAccess={identity.kibanaAccess}
            logoutRedirect={redirectToLogout}
            settingsRedirect={chrome.addBasePath("/app/readonlyrest_kbn")}
            reportingRedirect={chrome.addBasePath("/app/kibana#/management/kibana/reporting")}
            showReportLink={showReportLink}
            logoPath={chrome.addBasePath("/plugins/readonlyrest_kbn/img/rorSVG.svg")}
          />,
          el
        );
        return () => ReactDOM.unmountComponentAtNode(el);
      }
    }));
  }
};
module.exports = Object.freeze(Object.assign(members, functions))
