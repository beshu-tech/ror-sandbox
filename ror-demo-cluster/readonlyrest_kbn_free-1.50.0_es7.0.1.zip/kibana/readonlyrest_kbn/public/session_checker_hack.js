/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

import $ from "jquery"
import chrome from "ui/chrome"

const sessionProbeIntervalSeconds = Number.parseInt(chrome.getInjected('sessions_probe_interval_seconds'))
if (!sessionProbeIntervalSeconds) {
  throw new Error("Cannot get the session probe interval")
}
const IDEAL_POLLING_INTERVAL = sessionProbeIntervalSeconds * 1000
const ATTEMPT_TO_POLL_INTERVAL = Math.ceil(IDEAL_POLLING_INTERVAL / 2)

// Make sure we timeout the old connection before sending the new
const CONNECTION_TIMEOUT = Math.ceil(IDEAL_POLLING_INTERVAL * 0.9)

const MAX_TIMEOUTS_IN_A_ROW = 10
const LAST_CHECKED_DATE = "ror_session_checked_at"

function isItTimeToCheck() {
  const lastCheckedDate = new Date(localStorage.getItem(LAST_CHECKED_DATE))
  if (!lastCheckedDate) {
    return true
  }
  return new Date() - lastCheckedDate > IDEAL_POLLING_INTERVAL
}

let timeoutCtr = 0
$(function () {
  console.log("Session checker initialized: ", { MAX_TIMEOUTS_IN_A_ROW, CONNECTION_TIMEOUT, IDEAL_POLLING_INTERVAL, ATTEMPT_TO_POLL_INTERVAL })
  setInterval(checkSession, ATTEMPT_TO_POLL_INTERVAL)

  function checkSession() {

    if (window.location.href.indexOf(chrome.addBasePath("/login")) >= 0) {
      console.log("already in login, won't check session")
      return
    }
    if (!isItTimeToCheck()) {
      console.log("Too early to check for session validity")
      return
    }

    console.log('sending session validity check...')

    function onFailedCheck(err) {
      if (err == "timeout") {
        if (timeoutCtr < MAX_TIMEOUTS_IN_A_ROW) {
          timeoutCtr++
          console.log("Timeout recorded " + timeoutCtr + "/" + MAX_TIMEOUTS_IN_A_ROW)
          return true
        }
        console.log("Timeout attempts exceeded")
      }
      console.log('failed valid cookie check, redirecting to login: ', err)
      window.location.href = chrome.addBasePath("/logout") + "?nextUrl=/"
    }

    $.ajax({
      type: 'GET',
      timeout: CONNECTION_TIMEOUT,
      url: chrome.addBasePath('/session-continuity-check'),
      // data: {},
      // dataType: 'json',
      // encode: true,
      beforeSend: function (xhr) {
        xhr.setRequestHeader('kbn-version', chrome.getXsrfToken())
        xhr.setRequestHeader('kbn-xsrf', chrome.getXsrfToken())
      }
    })
      .always(() => {
        window.localStorage.setItem(LAST_CHECKED_DATE, new Date().toString())
      })
      .fail((jqXHR, textStatus, errorThrown) => {
        console.log("FAIL FUNCTION", textStatus, errorThrown);
        onFailedCheck(textStatus)
      })

      .done(function (data) {
        if (data == 'ok') {
          timeoutCtr = 0
          return
        }
        onFailedCheck(null)
      })
  }
})
