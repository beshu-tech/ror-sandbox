"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const jsx_runtime_1 = require("react/jsx-runtime");
const hiddenAppsChecker_1 = tslib_1.__importDefault(require("../../../proxy/preKibanaProxy/kibana_apps/hiddenAppsChecker"));
const group_1 = tslib_1.__importDefault(require("./group"));
const button_1 = require("../common/button");
const spacer_1 = require("../common/spacer");
const kibana_management_1 = tslib_1.__importDefault(require("../kibana-management"));
function ActionsGroups({ identity, closeRorMenu, isAccessUnrestricted, handleSettingsPageClick, kibanaVersion }) {
    const showKibanaManagementButton = () => {
        if (identity.kibanaHiddenApps?.includes('ROR Manage Kibana')) {
            return false;
        }
        return identity.kibanaHiddenApps?.some(hiddenApp => (0, hiddenAppsChecker_1.default)(hiddenApp, 'Management|Stack Management', console));
    };
    const showSettingsButton = () => {
        if (identity.kibanaHiddenApps?.includes('readonlyrest_kbn') ||
            identity.kibanaHiddenApps?.includes('ROR Security Settings')) {
            return false;
        }
        return identity.kibanaAccess === undefined || isAccessUnrestricted;
    };
    const showActionsGroup = showSettingsButton() || showKibanaManagementButton();
    return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: showActionsGroup && ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsxs)(group_1.default, { label: "Actions", children: [showSettingsButton() && ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(button_1.Button, { onClick: () => handleSettingsPageClick('settings'), fullWidth: true, children: "Edit security settings" }), (0, jsx_runtime_1.jsx)(spacer_1.Spacer, { size: "m" }), showKibanaManagementButton() && (0, jsx_runtime_1.jsx)(spacer_1.Spacer, { size: "m" })] })), showKibanaManagementButton() && ((0, jsx_runtime_1.jsx)(kibana_management_1.default, { kibanaVersion: kibanaVersion, closeMainMenu: closeRorMenu }))] }), (0, jsx_runtime_1.jsx)(spacer_1.Spacer, {})] })) }));
}
exports.default = ActionsGroups;
