"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const jsx_runtime_1 = require("react/jsx-runtime");
const fieldset_1 = tslib_1.__importDefault(require("../common/fieldset"));
function Group({ label, children }) {
    const theme = sessionStorage.getItem('rorTheme');
    const borderColor = theme === 'dark' ? '#4d4c4c' : '#d3dae6';
    return ((0, jsx_runtime_1.jsx)(fieldset_1.default, { legend: {
            children: label
        }, style: {
            border: `1px solid ${borderColor}`,
            margin: '2px 0',
            padding: '5.6px 12px 10px'
        }, children: children }));
}
exports.default = Group;
