"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RorPopover = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
const popover_1 = require("./common/popover");
function RorPopover({ id, closePopover, panelPaddingSize, badgeLabel, badgeTitle, anchorPosition, button, repositionOnScroll, isOpen, children }) {
    let optionalBadge;
    if (badgeLabel) {
        optionalBadge = ((0, jsx_runtime_1.jsx)(eui_1.EuiNotificationBadge, { style: { position: 'absolute', top: '9%', right: '9%', zIndex: 9000 }, title: badgeTitle, children: badgeLabel }));
    }
    return ((0, jsx_runtime_1.jsx)(popover_1.Popover, { closePopover: closePopover, anchorPosition: anchorPosition, isOpen: isOpen, id: id, panelPaddingSize: panelPaddingSize, repositionOnScroll: repositionOnScroll, hasArrow: true, button: (0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [optionalBadge, button] }), children: children }));
}
exports.RorPopover = RorPopover;
