"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseLogLevel = void 0;
const logLevel_1 = require("../../proxy/core/logging/logLevel");
const rorLoggerFactory_1 = require("../../proxy/core/logging/rorLoggerFactory");
function parseLogLevel(kibanaYmlConfig) {
    const rorConfig = kibanaYmlConfig?.readonlyrest_kbn;
    const rawLogLevel = rorConfig?.logLevel;
    if (rawLogLevel == null) {
        return rorLoggerFactory_1.RorLoggerFactory.DEFAULT_LOG_LEVEL;
    }
    const derivedLogLevel = logLevel_1.LogLevel[rawLogLevel.toString().toUpperCase()];
    if (derivedLogLevel == null) {
        // this will be caught by Kibana's own validation mechanism, no need to handle it here.
        return rorLoggerFactory_1.RorLoggerFactory.DEFAULT_LOG_LEVEL;
    }
    return derivedLogLevel;
}
exports.parseLogLevel = parseLogLevel;
