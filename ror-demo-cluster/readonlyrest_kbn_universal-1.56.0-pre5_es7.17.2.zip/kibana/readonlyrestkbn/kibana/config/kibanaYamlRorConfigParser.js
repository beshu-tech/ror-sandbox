"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseRorConfig = exports.parseLicenseConfig = exports.getCookieConfig = void 0;
const kibanaYamlAuthParser_1 = require("./kibanaYamlAuthParser");
const configGenerator_1 = require("./configGenerator");
const kibanaYamlWhitelistedPathsParser_1 = require("./kibanaYamlWhitelistedPathsParser");
const types_1 = require("../../proxy/core/common/types");
const kibanaYamlCustomUXCodeInjectionParser_1 = require("./kibanaYamlCustomUXCodeInjectionParser");
const kibanaYamlSessionManagerConfigParser_1 = require("./kibanaYamlSessionManagerConfigParser");
const kibanaYamlLoginPageCustomizationsParser_1 = require("./kibanaYamlLoginPageCustomizationsParser");
const kibanaYamlSessionConfigParser_1 = require("./kibanaYamlSessionConfigParser");
const defaultValues_1 = require("../../server/defaultValues");
function getCookieConfig({ cookieName, password, sslEnabled, secureCookies }) {
    const baseName = cookieName || defaultValues_1.DEFAULT_KIBANA_YAML_ROR_VALUES.cookieName;
    const withSecureSuffix = secureCookies || sslEnabled;
    if (withSecureSuffix) {
        return { name: `${baseName}_secure`, password, secure: true };
    }
    return { name: baseName, password, secure: false };
}
exports.getCookieConfig = getCookieConfig;
function parseLicenseConfig(rorObject) {
    function getRetrieval() {
        const retrievalMode = rorObject?.license?.activationKeyRetrievalMode;
        // Accept shortcut strings
        if (typeof retrievalMode === 'string') {
            if (retrievalMode === 'all' || retrievalMode === 'none' || retrievalMode === 'file' || retrievalMode === 'env') {
                return [retrievalMode];
            }
        }
        // Detect contradictions
        if (Array.isArray(retrievalMode)) {
            const hasAll = retrievalMode.includes('all');
            const hasNone = retrievalMode.includes('none');
            if (hasAll && hasNone) {
                throw new Error('Invalid activation key retrieval mode: "all" and "none" cannot be used together');
            }
            if (hasAll)
                return ['all'];
            if (hasNone)
                return ['none'];
        }
        return ['all'];
    }
    return {
        activationKeyRetrievalModes: getRetrieval(),
        activationKeyFilePath: rorObject?.license?.activationKeyFilePath
    };
}
exports.parseLicenseConfig = parseLicenseConfig;
function parseRorConfig(deepObject) {
    const { readonlyrest_kbn: rorObject, server, xpack } = deepObject;
    const cookiePass = rorObject?.cookiePass;
    const pkpKibanaToken = rorObject?.pkpKibanaToken || (0, configGenerator_1.generateRandomToken)();
    const authConfig = (0, kibanaYamlAuthParser_1.parseAuthConfiguration)(rorObject);
    const sessionConfig = (0, kibanaYamlSessionConfigParser_1.parseSessionConfig)(rorObject);
    const customUXCodeInjection = (0, kibanaYamlCustomUXCodeInjectionParser_1.parseCustomUxCodeInjection)(rorObject);
    const customLogoutLink = rorObject?.custom_logout_link;
    const customLoginLink = rorObject?.custom_login_link;
    const proxyAuth = {
        enabled: (rorObject?.proxy_auth_passthrough && !!rorObject.proxy_auth_passthrough) || false,
        forward_auth_header: rorObject?.forward_auth_header || types_1.X_FORWARDED_USER
    };
    const jwtQueryParam = { value: rorObject?.jwt_query_param || 'jwt' };
    const whitelistedPaths = (0, kibanaYamlWhitelistedPathsParser_1.getWhiteListedPaths)(rorObject);
    const loginPageCustomizations = (0, kibanaYamlLoginPageCustomizationsParser_1.parseLoginPageCustomizations)(rorObject);
    const cookieConfig = getCookieConfig({
        cookieName: rorObject?.cookieName,
        password: cookiePass,
        sslEnabled: server?.ssl?.enabled,
        secureCookies: xpack?.security?.secureCookies
    });
    const kibanaTemplateIndex = rorObject?.kibanaIndexTemplate;
    const resetKibanaIndexToTemplate = rorObject?.resetKibanaIndexToTemplate || false;
    const clearSessionOnEvents = rorObject?.clearSessionOnEvents ?? [];
    const spacesEnabled = xpack?.spaces?.enabled ?? true;
    const licenseConfiguration = parseLicenseConfig(rorObject);
    const multiTenancyEnabled = rorObject?.multiTenancyEnabled ?? true;
    const customMiddlewareInjectFile = rorObject?.custom_middleware_inject_file;
    const customMiddlewareInject = rorObject?.custom_middleware_inject;
    return {
        sessionManagerConfig: (0, kibanaYamlSessionManagerConfigParser_1.parseSessionManagerConfig)(rorObject),
        cookiePassword: cookiePass,
        pkpKibanaToken,
        authConfig,
        sessionConfig,
        customUXCodeInjection,
        customLogoutLink,
        customLoginLink,
        proxyAuthConfig: proxyAuth,
        jwtQueryParam,
        whitelistedPaths,
        loginPageCustomizations,
        cookieConfig,
        kibanaTemplateIndex,
        resetKibanaIndexToTemplate,
        clearSessionOnEvents,
        spacesEnabled,
        licenseConfiguration,
        multiTenancyEnabled,
        customMiddlewareInjectFile,
        customMiddlewareInject
    };
}
exports.parseRorConfig = parseRorConfig;
