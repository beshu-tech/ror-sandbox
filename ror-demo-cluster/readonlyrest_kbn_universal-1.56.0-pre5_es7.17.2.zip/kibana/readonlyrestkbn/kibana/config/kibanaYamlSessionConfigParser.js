"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseSessionConfig = void 0;
const defaultValues_1 = require("../../server/defaultValues");
function parseSessionConfig(rorObject) {
    const probeIntervalSeconds = rorObject?.sessions_probe_interval_seconds || defaultValues_1.DEFAULT_KIBANA_YAML_ROR_VALUES.sessions_probe_interval_seconds;
    return {
        timeoutMinutes: rorObject?.session_timeout_minutes || defaultValues_1.DEFAULT_KIBANA_YAML_ROR_VALUES.session_timeout_minutes,
        probeIntervalMillis: probeIntervalSeconds * 1000
    };
}
exports.parseSessionConfig = parseSessionConfig;
