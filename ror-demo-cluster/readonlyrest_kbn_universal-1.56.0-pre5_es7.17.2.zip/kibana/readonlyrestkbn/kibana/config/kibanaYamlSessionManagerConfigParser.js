"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseSessionManagerConfig = void 0;
const rorLoggerFactory_1 = require("../../proxy/core/logging/rorLoggerFactory");
const configUtils_1 = require("./configUtils");
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
function parseSessionManagerConfig(rorObject) {
    const config = {
        storeInIndex: rorObject?.store_sessions_in_index || false,
        indexName: rorObject?.sessions_index_name || '.readonlyrest_kbn_sessions',
        refreshAfter: rorObject?.sessions_refresh_after || 2000,
        sessionKey: rorObject?.cookiePass,
        cleanupInterval: rorObject?.sessions_cleanup_interval || '1d'
    };
    if (!config.storeInIndex) {
        logger.info(`"readonlyrest_kbn.store_sessions_in_index" is not enabled.
If you use more than one Kibana nodes (High availability configurations), you MUST enable both "readonlyrest_kbn.store_sessions_in_index" and share the same "readonlyrest.cookiePass" in ALL Kibana nodes.
See documentation: https://docs.readonlyrest.com/kibana#session-management-with-multiple-kibana-instances`);
    }
    if (config.storeInIndex && !rorObject?.cookiePass) {
        logger.error('Configuration error', new Error(`"readonlyrest_kbn.store_sessions_in_index" enabled, but "readonlyrest.cookiePass" string was not found.  
If you use more than one Kibana nodes (High availability configurations), you MUST enable both "readonlyrest_kbn.store_sessions_in_index" and share the same "readonlyrest.cookiePass" in ALL Kibana nodes.
See documentation: https://docs.readonlyrest.com/kibana#session-management-with-multiple-kibana-instances`));
        if (!rorObject?.cookiePass) {
            logger.error('Configuration error', new Error('Since ReadonlyREST 1.51.0 version readonlyrest.cookiePass is a required property. You need to configure a string of at least 32 characters length or more in your Kibana.yml file.'));
        }
        (0, configUtils_1.exitInOneSecond)();
    }
    return config;
}
exports.parseSessionManagerConfig = parseSessionManagerConfig;
