"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.onKibanaConfigParse = exports.parsedConfig = void 0;
const _ = __importStar(require("lodash"));
const kibanaYamlLogLevelParser_1 = require("./config/kibanaYamlLogLevelParser");
const rorLoggerFactory_1 = require("../proxy/core/logging/rorLoggerFactory");
const kibanaYamlElasticsearchConfigParser_1 = require("./config/kibanaYamlElasticsearchConfigParser");
const kibanaYamlKibanaConfigParser_1 = require("./config/kibanaYamlKibanaConfigParser");
const unsupportedFeaturesNotifier_1 = require("./config/unsupportedFeaturesNotifier");
const configUtils_1 = require("./configUtils");
const kibanaYamlRequestHeadersWhitelistParser_1 = require("./config/kibanaYamlRequestHeadersWhitelistParser");
const rorPort_1 = require("./config/rorPort");
const rorInitialization_1 = require("./config/rorInitialization");
const distributionInfoProvider_1 = require("./patchers/distributionInfoProvider");
exports.parsedConfig = (() => {
    let config;
    return {
        get: () => config,
        set: (newConfig) => {
            config = newConfig;
        }
    };
})();
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
function initLogsAndPrintDeepObject(deepObject) {
    rorLoggerFactory_1.RorLoggerFactory.initLogs((0, kibanaYamlLogLevelParser_1.parseLogLevel)(deepObject), deepObject.logging?.dest);
    logger.trace(`Found configuration object:\n ${JSON.stringify(deepObject, null, 2)}`);
}
function updateKibanaConfigDeepObject(deepObject, kibanaConfigForPkp, kibanaConfigForPep) {
    _.update(deepObject, 'server.ssl.enabled', (sslEnabled) => {
        logger.debug(`Overriding 'server.ssl.enabled' from ${sslEnabled} to false`);
        return false;
    });
    if (distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('8.0.0')) {
        _.update(deepObject, 'xpack.reporting.index', (reportingIndex) => {
            // eslint-disable-next-line @typescript-eslint/no-var-requires,global-require
            const { getTemporaryReportingIndex, setXpackReportingIndex } = require('../proxy/core/reportingIndex');
            setXpackReportingIndex(reportingIndex);
            const newReportingIndex = getTemporaryReportingIndex();
            logger.debug(`Overriding 'xpack.reporting.index' from ${reportingIndex} to ${newReportingIndex}`);
            return newReportingIndex;
        });
    }
    _.update(deepObject, 'server.port', (kibanaYamlServerPort) => {
        logger.debug(`Overriding 'server.port' from ${kibanaYamlServerPort} to ${kibanaConfigForPkp.newKibanaPort}`);
        return kibanaConfigForPkp.newKibanaPort;
    });
    _.update(deepObject, 'server.host', (kibanaYamlServerHost) => {
        logger.debug(`Overriding 'server.host' from ${kibanaYamlServerHost} to 127.0.0.1`);
        return '127.0.0.1';
    });
    if (distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('8.4.0')) {
        _.update(deepObject, 'telemetry.enabled', (_) => {
            logger.debug(`Overriding 'telemetry.enabled' from ${_} to false`);
            return false;
        });
    }
    else {
        _.update(deepObject, 'telemetry.optIn', (_) => {
            logger.debug(`Overriding 'telemetry.optIn' from ${_} to false`);
            return false;
        });
        _.update(deepObject, 'telemetry.allowChangingOptInStatus', (_) => {
            logger.debug(`Overriding 'telemetry.allowChangingOptInStatus' from ${_} to false`);
            return false;
        });
    }
    _.update(deepObject, 'elasticsearch.hosts', (kibanaYamlElasticsearchHosts) => {
        logger.debug(`Overriding 'elasticsearch.hosts' from ${kibanaYamlElasticsearchHosts} to [${kibanaConfigForPep.pepUrl}]`);
        return [kibanaConfigForPep.pepUrl];
    });
    _.update(deepObject, 'elasticsearch.requestHeadersWhitelist', (originalValue) => {
        const newValue = (0, kibanaYamlRequestHeadersWhitelistParser_1.normalizeWithDefaultsRequestHeadersWhiteList)(originalValue);
        logger.debug(`Overriding 'elasticsearch.requestHeadersWhitelist' from ${JSON.stringify(originalValue)} to ${JSON.stringify(newValue)}`);
        return newValue;
    });
    return deepObject;
}
function onKibanaConfigParse(deepObject) {
    if (exports.parsedConfig.get()) {
        return exports.parsedConfig.get();
    }
    initLogsAndPrintDeepObject(deepObject);
    if (!deepObject || _.isEmpty(deepObject)) {
        return deepObject;
    }
    (0, unsupportedFeaturesNotifier_1.verifyNoUnsupportedFeaturesConfigSupplied)(deepObject);
    try {
        const elasticsearchConfig = (0, kibanaYamlElasticsearchConfigParser_1.parseElasticsearchConfig)(deepObject.elasticsearch);
        const kibanaConfigForPkp = (0, kibanaYamlKibanaConfigParser_1.parseKibanaConfigForPkp)(deepObject);
        const kibanaConfigForPep = (0, kibanaYamlKibanaConfigParser_1.parseKibanaConfigForPep)(deepObject, elasticsearchConfig.kibanaTechUserEsAuthToken, elasticsearchConfig.requestHeadersWhitelist);
        (0, rorPort_1.checkIfPortsAreFree)(kibanaConfigForPkp.newKibanaPort, kibanaConfigForPep.pepPort)
            .then(verified => {
            const pkpPortVerified = verified[0];
            const pepPortVerified = verified[1];
            if (pkpPortVerified && pepPortVerified) {
                (0, rorInitialization_1.rorInitialization)(deepObject, elasticsearchConfig, kibanaConfigForPkp, kibanaConfigForPep);
            }
        })
            .catch(e => {
            logger.error(`ROR Cannot initialize Kibana: ${e.message}`);
            (0, configUtils_1.exitInOneSecond)();
        });
        const updatedConfig = updateKibanaConfigDeepObject(deepObject, kibanaConfigForPkp, kibanaConfigForPep);
        exports.parsedConfig.set(updatedConfig);
        return updatedConfig;
    }
    catch (e) {
        logger.error(`ROR Cannot initialize Kibana: ${e.message}`, e);
        (0, configUtils_1.exitInOneSecond)();
    }
}
exports.onKibanaConfigParse = onKibanaConfigParse;
