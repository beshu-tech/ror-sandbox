"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
module.exports = (() => {
    let pkpPort;
    let pkpKibanaToken;
    let pkpUrl;
    return {
        setOncePkpKibanaToken: (newPkpKibanaToken) => {
            if (pkpKibanaToken == null) {
                pkpKibanaToken = newPkpKibanaToken;
            }
        },
        setOncePkpUrl: (newPkpUrl) => {
            if (pkpUrl == null) {
                pkpUrl = newPkpUrl;
            }
        },
        setOncePkpPort: (newPkpPort) => {
            if (pkpPort == null) {
                pkpPort = newPkpPort;
            }
        },
        getPkpKibanaToken: () => pkpKibanaToken ?? undefined,
        getPkpPort: () => pkpPort ?? undefined,
        getPkpUrl: () => pkpUrl ?? undefined
    };
})();
