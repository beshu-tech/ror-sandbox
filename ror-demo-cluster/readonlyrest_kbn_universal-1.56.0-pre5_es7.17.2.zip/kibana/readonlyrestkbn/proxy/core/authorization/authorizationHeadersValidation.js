"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthorizationHeadersValidation = void 0;
const requestHeadersWhitelistApplier_1 = require("../common/requestHeadersWhitelistApplier");
const rorLoggerFactory_1 = require("../logging/rorLoggerFactory");
class AuthorizationHeadersValidation {
    authorizationHeadersCollector;
    requestHeadersWhitelist;
    esClient;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(authorizationHeadersCollector, requestHeadersWhitelist, esClient) {
        this.authorizationHeadersCollector = authorizationHeadersCollector;
        this.requestHeadersWhitelist = requestHeadersWhitelist;
        this.esClient = esClient;
    }
    async revalidate(request) {
        try {
            const rorRequest = request.rorRequest;
            const identitySession = rorRequest.getIdentitySession();
            if (!identitySession) {
                this.logger.debug('There is no identity session. Token revalidation aborted');
                return;
            }
            const credentialHeaders = this.authorizationHeadersCollector.collectCredentialHeaders(rorRequest);
            const allReqHeaders = rorRequest.getHeaders();
            requestHeadersWhitelistApplier_1.RequestHeadersWhitelistApplier.applyToMap(this.logger, this.requestHeadersWhitelist, allReqHeaders, credentialHeaders);
            const requestAuthorizationToken = credentialHeaders.get('authorization');
            const sessionAuthorizationToken = identitySession?.metadata.authorizationHeaders.get('authorization');
            if (!requestAuthorizationToken) {
                this.logger.debug('There is no authorization token in the request. Token revalidation aborted');
                return;
            }
            if (requestAuthorizationToken === sessionAuthorizationToken) {
                this.logger.debug('Request token is the same as session token. Token revalidation aborted');
                return;
            }
            await this.esClient.authorizeUser(credentialHeaders);
            rorRequest.setIdentitySession({
                ...identitySession,
                metadata: {
                    ...identitySession.metadata,
                    authorizationHeaders: credentialHeaders
                }
            });
            this.logger.info(`Current session successfully revalidated against ES`);
        }
        catch (e) {
            this.logger.info(`Could not revalidate the session against ES: + ${e.message}`);
        }
    }
}
exports.AuthorizationHeadersValidation = AuthorizationHeadersValidation;
