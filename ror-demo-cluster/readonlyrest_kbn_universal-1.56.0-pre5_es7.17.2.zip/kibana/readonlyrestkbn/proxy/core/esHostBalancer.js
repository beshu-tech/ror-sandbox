"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EsHostBalancer = void 0;
const node_fetch_1 = __importDefault(require("node-fetch"));
const http_errors_1 = __importDefault(require("http-errors"));
const node_abort_controller_1 = require("node-abort-controller");
const distributionInfoProvider_1 = require("../../kibana/patchers/distributionInfoProvider");
const esSecurityHeaderBuilder_1 = require("./common/esSecurityHeaderBuilder");
const rorLoggerFactory_1 = require("./logging/rorLoggerFactory");
class EsHostBalancer {
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    esHosts;
    networkParameters;
    kibanaTechUserEsAuthToken;
    esSSLConnectionProvider;
    mostRecentlyActiveHostIndex;
    constructor(esHosts, networkParameters, kibanaTechUserEsAuthToken, esSSLConnectionProvider) {
        this.esHosts = esHosts;
        this.networkParameters = networkParameters;
        this.kibanaTechUserEsAuthToken = kibanaTechUserEsAuthToken;
        this.esSSLConnectionProvider = esSSLConnectionProvider;
        this.mostRecentlyActiveHostIndex = 0;
        if (esHosts.length > 1 || distributionInfoProvider_1.DistributionInfoProvider.isEnvironmentDev()) {
            this.activateProbe();
        }
    }
    getElasticsearchUrl() {
        return this.esHosts[this.mostRecentlyActiveHostIndex];
    }
    activateProbe() {
        setInterval(() => this.probe().catch(error => this.logger.error(error)), this.networkParameters.pingTimeout);
    }
    probe() {
        const esUrl = this.getElasticsearchUrl();
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForGetRequestFrom(this.kibanaTechUserEsAuthToken);
        return this.fetchWithTimeout(esUrl, {
            headers: header,
            agent: this.esSSLConnectionProvider.getConnectionAgent()
        }).catch(error => {
            if (error.code === 'ECONNREFUSED' || error.code === 'ECONNRESET' || error.name === 'AbortError') {
                this.circularIncrementHostsArray();
                throw (0, http_errors_1.default)(503, `Elasticsearch host ${esUrl} is unavailable`);
            }
            this.logger.error(error);
        });
    }
    async fetchWithTimeout(resource, options = {}) {
        const timeout = this.networkParameters.pingTimeout;
        const controller = new node_abort_controller_1.AbortController();
        const id = setTimeout(() => {
            this.logger.warn(`Probe request timeout after ${timeout} milliseconds`);
            controller.abort();
        }, timeout);
        const response = await (0, node_fetch_1.default)(resource, {
            ...options,
            signal: controller.signal
        });
        clearTimeout(id);
        return response;
    }
    circularIncrementHostsArray() {
        this.mostRecentlyActiveHostIndex += 1;
        this.mostRecentlyActiveHostIndex %= this.esHosts.length;
    }
}
exports.EsHostBalancer = EsHostBalancer;
