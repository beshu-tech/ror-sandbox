"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EsSSLConnectionProvider = exports.SSLVerificationMode = exports.SSLCertificationType = void 0;
const fs_1 = __importDefault(require("fs"));
const https_1 = __importDefault(require("https"));
const http = __importStar(require("http"));
const distributionInfoProvider_1 = require("../../kibana/patchers/distributionInfoProvider");
var SSLCertificationType;
(function (SSLCertificationType) {
    SSLCertificationType[SSLCertificationType["PEM"] = 0] = "PEM";
    SSLCertificationType[SSLCertificationType["PKC12"] = 1] = "PKC12";
    SSLCertificationType[SSLCertificationType["NONE"] = 2] = "NONE";
})(SSLCertificationType = exports.SSLCertificationType || (exports.SSLCertificationType = {}));
var SSLVerificationMode;
(function (SSLVerificationMode) {
    SSLVerificationMode[SSLVerificationMode["FULL"] = 0] = "FULL";
    SSLVerificationMode[SSLVerificationMode["CERTIFICATE"] = 1] = "CERTIFICATE";
    SSLVerificationMode[SSLVerificationMode["NONE"] = 2] = "NONE";
})(SSLVerificationMode = exports.SSLVerificationMode || (exports.SSLVerificationMode = {}));
class EsSSLConnectionProvider {
    certificateAuthorities;
    truststore;
    truststorePassword;
    verificationMode;
    connectionAgent;
    certificationType;
    constructor(elasticsearchSSLConfig) {
        this.verificationMode = elasticsearchSSLConfig.verificationMode
            ? SSLVerificationMode[elasticsearchSSLConfig.verificationMode.toUpperCase()]
            : SSLVerificationMode.FULL;
        if (!elasticsearchSSLConfig.sslEnabled) {
            this.connectionAgent = http.globalAgent;
            this.certificationType = SSLCertificationType.NONE;
            this.verificationMode = SSLVerificationMode.NONE;
            return;
        }
        if (elasticsearchSSLConfig.certificateAuthorities) {
            this.setCertificationAuthorities(elasticsearchSSLConfig.certificateAuthorities);
            return;
        }
        if (elasticsearchSSLConfig.truststorePath) {
            this.setTruststore(elasticsearchSSLConfig.truststorePath, elasticsearchSSLConfig.truststorePassword);
            return;
        }
        this.setNoCertificationSSL();
    }
    getConnectionAgent() {
        return this.connectionAgent;
    }
    getCertificationType() {
        return this.certificationType;
    }
    getCertificateAuthorities() {
        return this.certificateAuthorities;
    }
    getTruststore() {
        return {
            truststore: this.truststore,
            password: this.truststorePassword
        };
    }
    isVerificationEnabled() {
        return !distributionInfoProvider_1.DistributionInfoProvider.isEnvironmentDev() && this.verificationMode !== SSLVerificationMode.NONE;
    }
    setCertificationAuthorities(caPaths) {
        this.certificateAuthorities = [];
        caPaths.forEach(path => this.certificateAuthorities?.push(fs_1.default.readFileSync(path)));
        const options = {
            ca: this.certificateAuthorities,
            rejectUnauthorized: this.isVerificationEnabled()
        };
        this.connectionAgent = new https_1.default.Agent(options);
        this.certificationType = SSLCertificationType.PEM;
    }
    setTruststore(truststorePath, truststorePassword) {
        this.truststore = fs_1.default.readFileSync(truststorePath);
        this.truststorePassword = truststorePassword;
        const options = {
            pfx: this.truststore,
            passphrase: this.truststorePassword,
            rejectUnauthorized: this.isVerificationEnabled()
        };
        this.connectionAgent = new https_1.default.Agent(options);
        this.certificationType = SSLCertificationType.PKC12;
    }
    setNoCertificationSSL() {
        this.certificationType = SSLCertificationType.NONE;
        const options = {
            rejectUnauthorized: this.isVerificationEnabled()
        };
        this.connectionAgent = new https_1.default.Agent(options);
    }
}
exports.EsSSLConnectionProvider = EsSSLConnectionProvider;
