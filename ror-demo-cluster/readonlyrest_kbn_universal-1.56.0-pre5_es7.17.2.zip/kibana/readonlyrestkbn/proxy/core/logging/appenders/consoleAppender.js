"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConsoleAppender = void 0;
const logAppender_1 = require("./logAppender");
// eslint-disable-next-line import/no-cycle
const rorLoggerFactory_1 = require("../rorLoggerFactory");
class ConsoleAppender extends logAppender_1.LogAppender {
    fileName;
    constructor(fileName) {
        super();
        this.fileName = fileName;
    }
    log(logLevel, message, impersonatedBy, ...optionalParams) {
        if (!rorLoggerFactory_1.RorLoggerFactory.isLoggingEnabled(logLevel)) {
            return;
        }
        console.log(this.logPattern(logLevel, this.fileName, message, impersonatedBy), ...optionalParams);
    }
}
exports.ConsoleAppender = ConsoleAppender;
