"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
// eslint-disable-next-line @typescript-eslint/no-namespace
var ReportingIndex;
(function (ReportingIndex) {
    const randomIndex = `.reporting-${Math.random().toString(36).slice(2)}`;
    const DEFAULT_REPORTING_INDEX = '.reporting';
    let xpackReportingIndex;
    function getTemporaryReportingIndex() {
        return randomIndex;
    }
    ReportingIndex.getTemporaryReportingIndex = getTemporaryReportingIndex;
    function getFinalReportingIndex() {
        return xpackReportingIndex || DEFAULT_REPORTING_INDEX;
    }
    ReportingIndex.getFinalReportingIndex = getFinalReportingIndex;
    function setXpackReportingIndex(reportingIndex) {
        xpackReportingIndex = reportingIndex;
    }
    ReportingIndex.setXpackReportingIndex = setXpackReportingIndex;
})(ReportingIndex || (ReportingIndex = {}));
module.exports = ReportingIndex;
