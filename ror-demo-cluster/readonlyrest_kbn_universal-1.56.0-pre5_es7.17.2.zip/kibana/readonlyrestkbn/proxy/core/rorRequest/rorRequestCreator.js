"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RorRequestCreator = void 0;
const rorRequest_1 = require("./rorRequest");
const types_1 = require("../common/types");
class RorRequestCreator {
    // TODO: typing the particular parts of RorRequest does not work
    static fromExpressRequest(request) {
        return new rorRequest_1.RorRequest(request.headers.cookie, types_1.Method[request.method], request.path, request.params, request.query, request.url, request.headers, request.socket.remoteAddress, request.body);
    }
}
exports.RorRequestCreator = RorRequestCreator;
