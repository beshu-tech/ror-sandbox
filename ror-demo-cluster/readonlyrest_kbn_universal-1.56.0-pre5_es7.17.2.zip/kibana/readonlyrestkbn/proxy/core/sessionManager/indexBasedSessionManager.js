"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.IndexBasedSessionManager = void 0;
const sessionManager_1 = require("./sessionManager");
const lazyUtils_1 = require("../lazyUtils");
const rorLoggerFactory_1 = require("../logging/rorLoggerFactory");
class IndexBasedSessionManager extends sessionManager_1.SessionManager {
    sessionTimeoutMillis;
    sessionManager;
    indexClient;
    refreshAfter;
    licenseService;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    sessionsFromIndex = new Map();
    constructor(sessionTimeoutMillis, sessionManager, indexClient, refreshAfter, licenseService) {
        super();
        this.sessionTimeoutMillis = sessionTimeoutMillis;
        this.sessionManager = sessionManager;
        this.indexClient = indexClient;
        this.refreshAfter = refreshAfter;
        this.licenseService = licenseService;
        this.init();
    }
    set = async (sid, session) => {
        await this.indexClient.saveInIndex(sid, session);
        await this.sessionManager.set(sid, session);
    };
    setShortLivedSessionInMemory = async (sid, session) => {
        await this.sessionManager.setShortLivedSessionInMemory(sid, session);
    };
    get = async (sid) => {
        let session = await this.getFromLocalStorage(sid);
        if (session) {
            session = this.cleanAfterGet(this.licenseService, session);
            this.mostRecentlyAccessed = session;
            return session || null;
        }
        session = await this.getFromIndex(sid);
        if (session) {
            this.logger.debug(`SID ${sid} found in in-index session storage.`);
            session = this.cleanAfterGet(this.licenseService, session);
            this.mostRecentlyAccessed = session;
            return session || null;
        }
        this.logger.debug(`SID ${sid} not found in in-index session storage either: giving up.`);
        return null;
    };
    delete = (sid) => {
        this.indexClient.deleteFromIndex(sid);
        this.sessionManager.delete(sid);
    };
    reloadSessionsFromIndex = async () => {
        this.sessionsFromIndex = await this.indexClient.getSessions();
    };
    checkIfSessionTimeout = async (sid) => {
        if (await this.isSessionTimeout(sid)) {
            this.delete(sid);
            return true;
        }
        return false;
    };
    getFromLocalStorage = async (sid) => (await this.sessionManager.get(sid)) || this.sessionsFromIndex.get(sid);
    getFromIndex = async (sid) => {
        const session = await this.indexClient.getFromIndex(sid);
        if (session != null) {
            await this.sessionManager.set(sid, session);
        }
        return session;
    };
    init = async () => {
        await this.indexClient.createSessionIndex();
        await (0, lazyUtils_1.executeWithInterval)(() => this.reloadSessionsFromIndex(), this.refreshAfter);
    };
    deleteAllSessions = async () => {
        await this.indexClient.deleteSessionIndex();
        await this.sessionManager.deleteAllSessions();
        this.mostRecentlyAccessed = undefined;
    };
}
exports.IndexBasedSessionManager = IndexBasedSessionManager;
