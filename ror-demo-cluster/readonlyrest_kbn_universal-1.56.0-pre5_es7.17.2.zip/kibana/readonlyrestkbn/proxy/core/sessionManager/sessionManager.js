"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionManager = void 0;
const ActivationKey_1 = require("../license/ActivationKey");
const accessLevel_1 = require("../common/accessLevel");
const EXCLUDED_SESSION_TIMEOUT_REFRESH_PATHS = ['/api/ui_counters/_report', '/api/licensing/info'];
class SessionManager {
    cleanAfterGet(licenseService, session) {
        const metadata = session;
        const license = licenseService.getActivationKey().license;
        const isEnt = (0, ActivationKey_1.isEnterpriseLicense)(license);
        const isFree = (0, ActivationKey_1.isFreeLicense)(license);
        const identity = {
            username: metadata.username,
            kibanaHiddenApps: isFree ? [] : metadata.kibanaHiddenApps,
            kibanaAccess: metadata.kibanaAccess || accessLevel_1.AccessLevel.UNRESTRICTED,
            currentGroup: isEnt ? metadata.currentGroup : undefined,
            availableGroups: isEnt ? metadata.availableGroups : [],
            authorizationHeaders: metadata.authorizationHeaders,
            expiresAt: metadata.expiresAt,
            lastSessionActivityDate: metadata.lastSessionActivityDate,
            origin: metadata.origin,
            impersonatedBy: isEnt ? metadata.impersonatedBy : undefined,
            correlationId: metadata.correlationId,
            kibanaIndex: metadata.kibanaIndex,
            kibanaTemplateIndex: metadata.kibanaTemplateIndex,
            customMetadata: metadata.customMetadata
        };
        return identity;
    }
    mostRecentlyAccessed = null;
    createNewSessionExpirationDate = () => new Date(Date.now() + this.sessionTimeoutMillis);
    getMostRecentlyAccessed = () => this.mostRecentlyAccessed;
    clearMostRecentlyAccessed = () => {
        this.mostRecentlyAccessed = undefined;
    };
    async exists(sid) {
        return (await this.get(sid)) != null;
    }
    async isSessionExpired(sid) {
        const session = await this.get(sid);
        if (!session?.expiresAt) {
            return true;
        }
        return session.expiresAt.getTime() < Date.now();
    }
    refreshSession = async (sid, currentUrl) => {
        const oldSession = await this.get(sid);
        if (!oldSession) {
            throw new Error('The previous session cannot be accessed.');
        }
        if (!oldSession.correlationId) {
            throw new Error('The previous correlationId cannot be retrieved.');
        }
        const lastSessionActivityDate = this.refreshLastSessionActivityDate(oldSession, sid, currentUrl);
        const newSession = {
            expiresAt: this.createNewSessionExpirationDate(),
            lastSessionActivityDate,
            authorizationHeaders: new Map([...Array.from(oldSession.authorizationHeaders.entries())]),
            username: oldSession.username,
            currentGroup: oldSession.currentGroup,
            availableGroups: oldSession.availableGroups ? [...oldSession.availableGroups] : [],
            kibanaHiddenApps: oldSession.kibanaHiddenApps ? [...oldSession.kibanaHiddenApps] : [],
            kibanaAccess: oldSession.kibanaAccess,
            kibanaIndex: oldSession.kibanaIndex,
            kibanaTemplateIndex: oldSession.kibanaTemplateIndex,
            origin: oldSession.origin,
            impersonatedBy: oldSession.impersonatedBy,
            allowedApiPaths: oldSession.allowedApiPaths,
            correlationId: oldSession.correlationId,
            customMetadata: oldSession.customMetadata
        };
        await this.set(sid, newSession);
        return newSession;
    };
    refreshLastSessionActivityDate(session, sid, currentUrl) {
        if (EXCLUDED_SESSION_TIMEOUT_REFRESH_PATHS.includes(currentUrl)) {
            return session.lastSessionActivityDate;
        }
        return new Date();
    }
    async lastSessionActivityDate(sid) {
        const session = await this.get(sid);
        if (!session) {
            return;
        }
        return session.lastSessionActivityDate;
    }
    async isSessionTimeout(sid) {
        const currentTimeInMillis = new Date().getTime();
        const lastSessionActivityDate = await this.lastSessionActivityDate(sid);
        if (!lastSessionActivityDate) {
            return true;
        }
        const lastSessionActivityTimeInMillis = currentTimeInMillis - lastSessionActivityDate.getTime();
        return this.sessionTimeoutMillis < lastSessionActivityTimeInMillis;
    }
}
exports.SessionManager = SessionManager;
