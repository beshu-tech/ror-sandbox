"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SpecialCaseDetector = void 0;
class SpecialCaseDetector {
    // Reporting and other features make use of saved_objects API
    // if we manage to patch/wrap savedObjectClient we can get rid of this fallible
    // time-locality based hack in favour of a deterministic solution (mostRecentlyAccessedSession)!
    static shouldAttachMostRecentSessionKibanaIndex(originalUrl, reportingIndex) {
        if (originalUrl.includes(reportingIndex)) {
            return 'isReportingRequest';
        }
        if (originalUrl.match(/\b\/alert\b/gi)) {
            return 'isAlertingRequest';
        }
        if (originalUrl.match(/\b\/action\b/gi)) {
            return 'isActionRequest';
        }
        return null;
    }
    // Since 7.11.x some Kibana -> ES requests lack the kibana tech user authorization headers
    // This set of rules pinpoints those requests, while limiting the chance of potential breaches to a minimum
    static shouldAttachTechUserCredentialsWhenMissing(proxyRequestOptions) {
        if (proxyRequestOptions.path.includes('/_search') && proxyRequestOptions.method === 'POST') {
            return 'search in indexes';
        }
        const userAgent = proxyRequestOptions.headers['user-agent']?.toString();
        if (userAgent?.includes('elasticsearch-js')) {
            return 'es client direct';
        }
        /**
         * Since version 8.0.0 kibana introduced the additional way to call http requests, node-fetch library.
         * In this case user-agent is like Kibana/{KIBANA_VERSION}
         */
        if (userAgent?.includes('Kibana')) {
            return 'kibana client direct';
        }
        return null;
    }
    static shouldChangeUserCredentialsToTechUserCredentials(proxyRequestOptions) {
        const userAgent = proxyRequestOptions.headers['user-agent']?.toString();
        // kibana ensuring existence and initialisation of the tenancy kibana index before login during the first time a tenant logs in.
        if (proxyRequestOptions?.method?.toLowerCase() === 'put' &&
            proxyRequestOptions?.path?.includes('/_create/config') &&
            userAgent?.includes('Kibana')) {
            return true;
        }
        return false;
    }
}
exports.SpecialCaseDetector = SpecialCaseDetector;
