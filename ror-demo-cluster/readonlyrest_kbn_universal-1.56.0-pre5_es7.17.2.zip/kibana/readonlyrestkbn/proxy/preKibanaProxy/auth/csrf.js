"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Csrf = void 0;
const uuid_1 = require("uuid");
const csrf_csrf_1 = require("csrf-csrf");
const rorLoggerFactory_1 = require("../../core/logging/rorLoggerFactory");
class Csrf {
    static logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    static CSRF_SECRET = 'X[%F`z@K#cIZ!\'P]L)v!_]&N#"NhxW';
    static CSRF_HEADER_NAME = 'x-csrf-token';
    static CSRF_COOKIE_PATTERN = `x-csrf-token-${(0, uuid_1.v4)()}`;
    static sslEnabled;
    static CSRF_COOKIE_NAME;
    static doubleCsrf;
    static invalidCsrfTokenError() {
        return Csrf.doubleCsrf.invalidCsrfTokenError;
    }
    static generateToken(res, req) {
        return Csrf.doubleCsrf.generateToken(req, res, false, true);
    }
    static doubleCsrfProtection(req, res, next) {
        return Csrf.doubleCsrf.doubleCsrfProtection(req, res, next);
    }
    static csrfErrorHandler(error, req, res, next) {
        if (error.code === Csrf.invalidCsrfTokenError()?.code) {
            Csrf.logger.error(error.message);
            res.status(401).json({
                message: 'Wrong credentials'
            });
        }
        else {
            next();
        }
    }
    static clearCookie(res) {
        res.clearCookie(Csrf.CSRF_COOKIE_NAME, {
            path: '/',
            sameSite: 'lax',
            secure: Csrf.sslEnabled
        });
    }
    static init(sslEnabled) {
        const expirationTime = 40 * 60 * 1000; // 40 minutes
        Csrf.sslEnabled = sslEnabled;
        Csrf.CSRF_COOKIE_NAME = Csrf.sslEnabled ? `__Host-ror.${Csrf.CSRF_COOKIE_PATTERN}` : Csrf.CSRF_COOKIE_PATTERN;
        Csrf.doubleCsrf = (0, csrf_csrf_1.doubleCsrf)({
            getSecret: () => Csrf.CSRF_SECRET,
            size: 64,
            cookieName: Csrf.CSRF_COOKIE_NAME,
            cookieOptions: {
                sameSite: 'lax',
                path: '/',
                secure: Csrf.sslEnabled,
                expires: new Date(Date.now() + expirationTime)
            },
            ignoredMethods: ['GET', 'HEAD', 'OPTIONS'],
            getTokenFromRequest: req => req.headers[Csrf.CSRF_HEADER_NAME]
        });
        setTimeout(() => {
            Csrf.init(sslEnabled);
        }, expirationTime);
    }
}
exports.Csrf = Csrf;
