"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OidcController = void 0;
const types_1 = require("../../../core/common/types");
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const csrf_1 = require("../csrf");
const ROUTES = {
    LOGOUT: '/logout'
};
class OidcController {
    config;
    jwtSigner;
    legacyRenderer;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(config, jwtSigner, legacyRenderer) {
        this.config = config;
        this.jwtSigner = jwtSigner;
        this.legacyRenderer = legacyRenderer;
    }
    onLoginCallback = (req, res) => {
        const profile = req.session.user;
        if (!profile) {
            this.logger.error('user is not defined');
            return;
        }
        const user = profile[this.config.usernameParameter];
        this.logger.debug(`Obtained user name from profile: ${user}`);
        const groups = this.getGroups(profile);
        this.logger.debug(`Obtained groups from profile: ${groups}`);
        const jwt = this.createJWT(user, groups, profile);
        const csrfToken = csrf_1.Csrf.generateToken(res, req);
        const headers = {
            [csrf_1.Csrf.CSRF_HEADER_NAME]: csrfToken
        };
        const redirectLoginBody = this.legacyRenderer.renderJwtRedirect(jwt, JSON.stringify(headers));
        res.send(redirectLoginBody);
    };
    onLogout = (req, res, next) => {
        const userInfo = JSON.stringify(req.session.user);
        this.logger.trace(`Logout called for user: ${userInfo}`);
        req.logout(err => {
            if (err) {
                this.logger.error(`${this.config.connectorName} error:`, err);
                return next(err);
            }
            const redirectUrl = `${this.config.oidcLogoutUrl}?redirect_uri=${this.config.logoutCallBackUrl}`;
            this.logger.trace(`Logout called for user: ${userInfo}. redirecting to ${redirectUrl}`);
            return res.redirect(redirectUrl);
        });
    };
    onLogoutCallback = (req, res, next) => {
        const userInfo = JSON.stringify(req.session.user);
        this.logger.trace(`Logout callback called for user: ${userInfo}`);
        req.logout(err => {
            if (err) {
                this.logger.error(`${this.config.connectorName} error:`, err);
                return next(err);
            }
            res.clearCookie(this.config.cookieConfig.name, { path: '/' });
            this.logger.trace(`Logout called for user: ${userInfo}. redirecting to ${ROUTES.LOGOUT}`);
            res.send(this.legacyRenderer.renderRedirect(ROUTES.LOGOUT));
        });
    };
    getGroups(user) {
        const groups = user[this.config.groupsParameter];
        if (!groups) {
            return [];
        }
        if (typeof groups === 'string') {
            return groups.split(',');
        }
        return Object.assign([], groups);
    }
    createJWT(user, groups, expressUser) {
        const assertion = { ...expressUser };
        // Don't duplicate the groups list: it can potentially be very large
        delete assertion[this.config.groupsParameter];
        const claims = {
            user,
            groups,
            assertion,
            [types_1.X_ROR_ORIGIN]: this.config.connectorName
        };
        this.logger.debug(`Created JWT for ROR with claims: ${JSON.stringify(claims)}`);
        return this.jwtSigner.sign(claims);
    }
}
exports.OidcController = OidcController;
