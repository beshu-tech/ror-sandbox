"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SamlController = void 0;
const types_1 = require("../../../core/common/types");
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const csrf_1 = require("../csrf");
class SamlController {
    config;
    samlStrategy;
    jwtSigner;
    legacyRenderer;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    HEADER_SIZE_MAX = 8192 - 'Bearer '.length;
    HEADER_SIZE_WATERMARK = this.HEADER_SIZE_MAX * 0.9;
    HEADER_SIZE_ADVICE = `Please set "readonlyrest_kbn.logLevel: debug", look for "Created JWT for ROR with claims" in Kibana logs, and inspect for any data duplication in the JSON Object. If no data is being duplicated, this user has too many groups, or the individual group strings length are too long.`;
    constructor(config, samlStrategy, jwtSigner, legacyRenderer) {
        this.config = config;
        this.samlStrategy = samlStrategy;
        this.jwtSigner = jwtSigner;
        this.legacyRenderer = legacyRenderer;
    }
    onLoginCallback = (req, res) => {
        const profile = req.session.user;
        if (!profile) {
            this.logger.error('user is not defined');
            return;
        }
        const assertion = profile.getAssertionXml?.();
        this.logger.debug(`Received SAML Assertion response`, JSON.stringify(assertion));
        const user = profile[this.config.usernameParameter];
        if (!user) {
            this.logger.error(`Obtained unusable user name from profile: ${user}`);
        }
        else {
            this.logger.debug(`Obtained user name from profile: ${user}`);
        }
        const groups = this.getGroups(profile);
        this.logger.debug(`Obtained groups from profile: ${groups}`);
        const jwt = this.createJWT(user, groups, profile);
        const csrfToken = csrf_1.Csrf.generateToken(res, req);
        const headers = {
            [csrf_1.Csrf.CSRF_HEADER_NAME]: csrfToken
        };
        const redirectLoginBody = this.legacyRenderer.renderJwtRedirect(jwt, JSON.stringify(headers));
        res.send(redirectLoginBody);
    };
    onLogout = (req, res, next) => {
        try {
            const profile = req.session.user;
            return this.samlStrategy.logout({ ...req, user: profile }, (err, uri) => {
                if (err) {
                    this.logger.error(`Something went wrong with ${this.config.connectorName} connector. `, err);
                }
                const userInfo = JSON.stringify(profile);
                req.logout(err => {
                    if (err) {
                        this.logger.error(`${this.config.connectorName} error:`, err);
                        return next(err);
                    }
                    this.logger.trace(`Logout called for user: ${userInfo}. redirecting to ${uri}`);
                    if (typeof uri === 'string') {
                        res.redirect(uri);
                    }
                });
            });
        }
        catch (e) {
            this.logger.error(`Something went wrong with ${this.config.connectorName} connector. `, e);
        }
    };
    onLogoutCallback = (req, res, next) => {
        const userInfo = JSON.stringify(req.session.user);
        this.logger.trace(`Logout callback called for user: ${userInfo}`);
        req.logout(err => {
            if (err) {
                this.logger.error(`${this.config.connectorName} error:`, err);
                return next(err);
            }
            res.clearCookie(this.config.cookieConfig.name, { path: '/' });
            this.logger.trace(`Logout called for user: ${userInfo}. redirecting to ${this.config.logoutPath}`);
            res.send(this.legacyRenderer.renderRedirect(this.config.logoutPath));
        });
    };
    onGetMetadata = (req, res) => {
        res.type('application/xml');
        res.send(this.samlStrategy.generateServiceProviderMetadata(null, null));
    };
    getGroups(user) {
        const groups = user[this.config.groupsParameter];
        if (!groups) {
            return [];
        }
        if (typeof groups === 'string') {
            return groups.split(',');
        }
        return Object.assign([], groups);
    }
    createJWT(user, groups, expressUser) {
        const assertion = { ...expressUser };
        try {
            // Don't duplicate the groups list: it can potentially be very large
            delete assertion[this.config.groupsParameter];
            // Attributes are already copied in the expressUser object once
            delete assertion.attributes;
        }
        catch (e) {
            this.logger.warn(`Could not remove groups from assertion: ${e}`);
        }
        const claims = {
            user,
            groups,
            assertion,
            [types_1.X_ROR_ORIGIN]: this.config.connectorName
        };
        const encodedJWT = this.jwtSigner.sign(claims);
        const jwtSize = Buffer.byteLength(encodedJWT, 'utf8');
        const jwtSizeInfo = `(size: ${jwtSize} of ${this.HEADER_SIZE_MAX} Bytes)`;
        if (jwtSize >= this.HEADER_SIZE_MAX) {
            this.logger.error(`Too large JWT token size ${jwtSizeInfo}! ${this.HEADER_SIZE_ADVICE}`);
        }
        else if (jwtSize >= this.HEADER_SIZE_WATERMARK) {
            this.logger.warn(`JWT token size is approaching the limit ${jwtSizeInfo}! ${this.HEADER_SIZE_ADVICE}`);
        }
        this.logger.debug(`Created JWT for ROR with claims: ${JSON.stringify(claims)}, ${jwtSizeInfo})`);
        return encodedJWT;
    }
}
exports.SamlController = SamlController;
