"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SamlRouterConfigFactory = exports.SamlRouterConfig = void 0;
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const SSO_PREFIX = 'ror_kbn_';
const ROUTES = {
    LOGIN: '/login',
    LOGOUT: '/logout',
    LOGIN_CALLBACK: '/assert',
    LOGOUT_CALLBACK: '/notifylogout'
};
class SamlRouterConfig {
    connectorName;
    protocol;
    entryPoint;
    issuer;
    usernameParameter;
    groupsParameter;
    buttonName;
    routerPath;
    callbackURL;
    logoutCallbackUrl;
    loginPath;
    logoutPath;
    loginCallbackPath;
    logoutCallbackPath;
    cert;
    privateCert;
    decryptionPvk;
    extraConfig;
    cookieConfig;
    constructor(basePath, config, cookieConfig) {
        this.connectorName = config.name;
        this.protocol = config.protocol;
        this.entryPoint = config.entryPoint;
        this.issuer = config.issuer;
        this.usernameParameter = config.usernameParameter;
        this.groupsParameter = config.groupsParameter;
        this.buttonName = config.buttonName;
        this.loginPath = ROUTES.LOGIN;
        this.logoutPath = ROUTES.LOGOUT;
        this.loginCallbackPath = ROUTES.LOGIN_CALLBACK;
        this.logoutCallbackPath = ROUTES.LOGOUT_CALLBACK;
        this.routerPath = `${basePath}/${SSO_PREFIX}${config.name}`;
        this.callbackURL = `${config.protocol}://${config.kibanaExternalHost + this.routerPath + ROUTES.LOGIN_CALLBACK}`;
        this.logoutCallbackUrl = `${config.protocol}://${config.kibanaExternalHost + this.routerPath + ROUTES.LOGOUT_CALLBACK}`;
        this.cert = config.cert;
        this.privateCert = config.privateCert;
        this.decryptionPvk = config.decryptionPvk;
        this.extraConfig = config.extraConfig;
        this.cookieConfig = {
            name: `${cookieConfig.name}_${this.connectorName}`,
            password: cookieConfig.password
        };
    }
    loginPathRelativeToRoot() {
        return `${this.routerPath}${this.loginPath}`;
    }
    logoutPathRelativeToRoot() {
        return `${this.routerPath}${this.logoutPath}`;
    }
    toLegacySsoButtonProps() {
        return {
            name: this.connectorName,
            type: 'saml',
            buttonName: this.buttonName,
            loginUrl: this.loginPathRelativeToRoot()
        };
    }
}
exports.SamlRouterConfig = SamlRouterConfig;
class SamlRouterConfigFactory {
    basePath;
    cookieConfig;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(basePath, cookieConfig) {
        this.basePath = basePath;
        this.cookieConfig = cookieConfig;
    }
    constructFrom(auth) {
        if (!auth) {
            return [];
        }
        if (!SamlRouterConfigFactory.signatureKeyExists(auth)) {
            this.logger.info('No auth.signature_key set');
            return [];
        }
        if (!SamlRouterConfigFactory.samlConfigurationsExist(auth)) {
            this.logger.info('No SAML configurations found');
            return [];
        }
        const configs = auth.samlConfigurations.filter(config => config.enabled);
        if (configs.length === 0) {
            this.logger.info('No enabled SAML configurations found');
            return [];
        }
        return configs.map(config => new SamlRouterConfig(this.basePath, config, this.cookieConfig));
    }
    static signatureKeyExists(auth) {
        return Boolean(auth.signatureKey);
    }
    static samlConfigurationsExist(auth) {
        return auth.samlConfigurations?.length !== 0;
    }
}
exports.SamlRouterConfigFactory = SamlRouterConfigFactory;
