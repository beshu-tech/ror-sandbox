"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.compile = void 0;
function compile(tpl, args) {
    function readModuleFile(path) {
        const filename = require.resolve(path);
        // eslint-disable-next-line @typescript-eslint/no-var-requires,global-require
        return require('fs').readFileSync(filename, 'utf8');
    }
    return readModuleFile(tpl).replace(/\${(\w+)}/g, (_, v) => (args[v] === '' || args[v] ? args[v] : `\${${v}}`));
}
exports.compile = compile;
