"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenancyController = void 0;
const cookieManager_1 = require("../../core/cookieManager");
class TenancyController {
    authenticationFacade;
    cookieConfig;
    constructor(authenticationFacade, cookieConfig) {
        this.authenticationFacade = authenticationFacade;
        this.cookieConfig = cookieConfig;
    }
    handleEncryptCookieOnSwitchGroup = async (req, res, next) => {
        const encryptedCookie = await this.authenticationFacade.switchGroups(req.rorRequest);
        if (!encryptedCookie) {
            throw new Error('Encrypted cookie is not available');
        }
        res.cookie(this.cookieConfig.name, encryptedCookie, cookieManager_1.CookieManager.getCookiesOptions({ secure: this.cookieConfig.secure }));
        next();
    };
}
exports.TenancyController = TenancyController;
