"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthenticationFacade = void 0;
const uuid_1 = require("uuid");
const rorRequest_1 = require("../core/rorRequest/rorRequest");
const esClient_1 = require("../core/esClient");
const defaultSpaceCreator_1 = require("./defaultSpaceCreator");
const cookieManager_1 = require("../core/cookieManager");
const accessLevel_1 = require("../core/common/accessLevel");
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
const rorLogger_1 = require("../core/logging/rorLogger");
const indexCreatorFactory_1 = require("./indexCreation/indexCreatorFactory");
const types_1 = require("../core/common/types");
const requestHeadersWhitelistApplier_1 = require("../core/common/requestHeadersWhitelistApplier");
const errors_1 = __importDefault(require("../constants/errors"));
const ActivationKey_1 = require("../core/license/ActivationKey");
class AuthenticationFacade {
    sessionManager;
    cookieManager;
    kibanaIndex;
    esClient;
    authorizationHeadersCollector;
    resetKibanaIndexToTemplate;
    requestHeadersWhitelist;
    licenseService;
    multiTenancyEnabled;
    kibanaTemplateIndex;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    defaultSpaceCreator;
    indexCreator;
    constructor(sessionManager, cookieManager, kibanaIndex, esClient, authorizationHeadersCollector, resetKibanaIndexToTemplate, requestHeadersWhitelist, licenseService, multiTenancyEnabled, kibanaTemplateIndex) {
        this.sessionManager = sessionManager;
        this.cookieManager = cookieManager;
        this.kibanaIndex = kibanaIndex;
        this.esClient = esClient;
        this.authorizationHeadersCollector = authorizationHeadersCollector;
        this.resetKibanaIndexToTemplate = resetKibanaIndexToTemplate;
        this.requestHeadersWhitelist = requestHeadersWhitelist;
        this.licenseService = licenseService;
        this.multiTenancyEnabled = multiTenancyEnabled;
        this.kibanaTemplateIndex = kibanaTemplateIndex;
        this.defaultSpaceCreator = new defaultSpaceCreator_1.DefaultSpaceCreator(this.kibanaIndex, this.esClient);
        this.indexCreator = indexCreatorFactory_1.IndexCreatorFactory.create(this.kibanaIndex, esClient, this.resetKibanaIndexToTemplate, this.kibanaTemplateIndex);
    }
    async authorizeRequest(request) {
        const credentialHeaders = this.authorizationHeadersCollector.collectCredentialHeaders(request);
        const allReqHeaders = request.getHeaders();
        requestHeadersWhitelistApplier_1.RequestHeadersWhitelistApplier.applyToMap(this.logger, this.requestHeadersWhitelist, allReqHeaders, credentialHeaders);
        const queries = request.getQueries();
        const defaultGroupAsString = (typeof queries.defaultGroup === 'string' ? queries.defaultGroup : undefined) ?? undefined;
        const response = await this.esClient.authorizeUser(credentialHeaders, defaultGroupAsString);
        const identitySession = await this.createIdentitySession(credentialHeaders, response, request.lastSessionActivityDate);
        await this.sessionManager.set(identitySession.sid, identitySession.metadata);
        await this.createIndexAndSpace(identitySession.metadata);
        this.appendCorrelationIdHeader(identitySession, identitySession.metadata.correlationId);
        const encryptedCookie = (await this.cookieManager.encryptRorCookie(identitySession.sid));
        return [encryptedCookie, identitySession];
    }
    async authorizeDirectRequestWithCredentials(request) {
        const credentialHeaders = this.authorizationHeadersCollector.collectCredentialHeaders(request);
        const allReqHeaders = request.getHeaders();
        requestHeadersWhitelistApplier_1.RequestHeadersWhitelistApplier.applyToMap(this.logger, this.requestHeadersWhitelist, allReqHeaders, credentialHeaders);
        const queries = request.getQueries();
        const defaultGroupAsString = (typeof queries.defaultGroup === 'string' ? queries.defaultGroup : undefined) ?? undefined;
        const response = await this.esClient.authorizeUser(credentialHeaders, defaultGroupAsString);
        const identitySession = await this.createIdentitySession(credentialHeaders, response, request.lastSessionActivityDate);
        await this.sessionManager.setShortLivedSessionInMemory(identitySession.sid, identitySession.metadata);
        await this.createIndexAndSpace(identitySession.metadata);
        this.appendCorrelationIdHeader(identitySession, identitySession.metadata.correlationId);
        const encryptedCookie = (await this.cookieManager.encryptRorCookie(identitySession.sid));
        return [encryptedCookie, identitySession];
    }
    async clearSession(request) {
        const sid = await this.cookieManager.decryptRorCookieFromHeader(request.getCookies());
        if (sid) {
            this.sessionManager.delete(sid);
            this.sessionManager.clearMostRecentlyAccessed();
        }
    }
    async refreshSession(request) {
        const identitySession = request.getIdentitySession();
        if (identitySession) {
            const refreshedSessionMetadata = await this.sessionManager.refreshSession(identitySession?.sid, request.getUrl());
            if (refreshedSessionMetadata) {
                identitySession.metadata = refreshedSessionMetadata;
            }
        }
    }
    async refreshSessionAgainstEs(identitySession) {
        const credentialHeaders = identitySession.metadata.authorizationHeaders;
        const currentGroup = identitySession.metadata.currentGroup;
        const response = await this.esClient.authorizeUser(credentialHeaders, currentGroup);
        const newMetadata = this.buildIdentitySessionMetadata({
            authorizationHeaders: credentialHeaders,
            response,
            lastSessionActivityDate: identitySession.metadata.lastSessionActivityDate,
            impersonatedBy: identitySession.metadata.impersonatedBy
        });
        await this.sessionManager.set(identitySession.sid, newMetadata);
        return {
            sid: identitySession.sid,
            metadata: newMetadata
        };
    }
    async switchGroups(request) {
        try {
            const identitySession = request.getIdentitySession();
            if (!identitySession) {
                this.logger.error('Identity session is not available');
                return null;
            }
            const newGroup = new URL(request.getUrl(), 'http://localhost:5601').searchParams.get('group');
            if (!newGroup) {
                this.logger.error('Groups are not defined in URL');
                return null;
            }
            const decodedNewGroup = decodeURIComponent(newGroup);
            const { authorizationHeaders } = identitySession.metadata;
            const newSid = await this.authorizeUserWithHeaders(authorizationHeaders, decodedNewGroup, request.lastSessionActivityDate, identitySession.metadata.impersonatedBy);
            if (!newSid) {
                this.logger.info('There is no sid defined in a authorized user headers');
                return null;
            }
            this.sessionManager.delete(identitySession.sid);
            const newIdentitySessionMetadata = await this.sessionManager.get(newSid);
            if (newIdentitySessionMetadata == null) {
                this.logger.info('Unsuccessful tenancy switch. Failed to retrieve IdentitySessionMetadata');
                return null;
            }
            await this.createIndexAndSpace(newIdentitySessionMetadata);
            request.setIdentitySession({ sid: newSid, metadata: newIdentitySessionMetadata });
            return this.cookieManager.encryptRorCookie(newSid);
        }
        catch (e) {
            return null;
        }
    }
    async checkImpersonationStatus(request, impersonateAs) {
        return this.esClient.checkImpersonatedUser(request.getAuthorizationHeaders(), impersonateAs);
    }
    async impersonateUser(request, res) {
        const handleImpersonate403UserState = (impersonateAs, due_to) => {
            if (due_to?.includes('NOT_SUFFICIENT_LICENSE')) {
                return res.status(403).json({
                    message: errors_1.default.notSufficientLicenseToUseImpersonateFeature
                });
            }
            if (due_to?.includes('IMPERSONATION_NOT_ALLOWED')) {
                return res.status(403).json({
                    message: `You are not allowed to impersonate ${impersonateAs} user`
                });
            }
            if (due_to?.includes('IMPERSONATION_NOT_SUPPORTED')) {
                return res.status(403).json({
                    message: `You have been using an rule that does not support impersonation feature`
                });
            }
            return res.status(403).json({
                message: `Operation not allowed`
            });
        };
        const appendImpersonateAsAuthorizationHeader = (identitySession, impersonateAs) => {
            const { authorizationHeaders } = identitySession.metadata;
            return authorizationHeaders.set(types_1.X_ROR_IMPERSONATING, impersonateAs);
        };
        const setNewImpersonateAsSession = async (authorizationHeaders, impersonatedUserResponse, currentUsername, sid) => {
            const newSid = (0, uuid_1.v4)();
            const newIdentitySessionMetadata = {
                ...this.buildIdentitySessionMetadata({
                    authorizationHeaders,
                    response: impersonatedUserResponse,
                    lastSessionActivityDate: request.lastSessionActivityDate,
                    impersonatedBy: currentUsername
                })
            };
            await this.createIndexAndSpace(newIdentitySessionMetadata);
            await this.sessionManager.set(newSid, newIdentitySessionMetadata);
            this.sessionManager.delete(sid);
            request.setIdentitySession({ sid: newSid, metadata: newIdentitySessionMetadata });
            const encryptedCookie = await this.cookieManager.encryptRorCookie(newSid);
            return { encryptedCookie, newIdentitySessionMetadata };
        };
        try {
            const body = request.getBody();
            const impersonateAs = (0, rorRequest_1.isLoginFormBody)(body) ? body.username : '';
            const checkImpersonateResponse = await this.checkImpersonationStatus(request, impersonateAs);
            if (checkImpersonateResponse.status === 403) {
                (0, esClient_1.checkEsAuthorizationResponseErrorStatus)(checkImpersonateResponse);
                this.logger.debug(`Error while impersonating user ${JSON.stringify(checkImpersonateResponse.body.error?.due_to)}`);
                return handleImpersonate403UserState(impersonateAs, Array.isArray(checkImpersonateResponse.body.error?.due_to)
                    ? checkImpersonateResponse.body.error?.due_to ?? []
                    : []);
            }
            const identitySession = request.getIdentitySession();
            if (!identitySession) {
                this.logger.error('Identity session is not available');
                return null;
            }
            const authorizationHeaders = appendImpersonateAsAuthorizationHeader(identitySession, impersonateAs);
            (0, esClient_1.checkEsAuthorizationResponseSuccessStatus)(checkImpersonateResponse);
            this.appendCorrelationIdHeader(identitySession, identitySession.metadata.correlationId);
            const { encryptedCookie, newIdentitySessionMetadata } = await setNewImpersonateAsSession(authorizationHeaders, checkImpersonateResponse.body, identitySession.metadata.username, identitySession.sid);
            res.cookie(this.cookieManager.cookieConfig.name, encryptedCookie, cookieManager_1.CookieManager.getCookiesOptions({ secure: this.cookieManager.cookieConfig.secure }));
            rorLogger_1.RorLogger.appendImpersonatingInfo(newIdentitySessionMetadata.username);
            return res.status(200).json({ status: 'ok' });
        }
        catch (e) {
            this.logger.error(e.message, e);
            res.status(500).json({ message: e.message });
        }
    }
    async finishImpersonation(request, res) {
        const deleteImpersonateAsHeader = (identitySession) => {
            const { authorizationHeaders } = identitySession.metadata;
            authorizationHeaders.delete(types_1.X_ROR_IMPERSONATING);
            return authorizationHeaders;
        };
        const setUserSession = async (authorizationHeaders, userResponse, currentSid, newSid) => {
            const newIdentitySessionMetadata = this.buildIdentitySessionMetadata({
                authorizationHeaders,
                response: userResponse,
                lastSessionActivityDate: request.lastSessionActivityDate
            });
            await this.sessionManager.set(newSid, newIdentitySessionMetadata);
            this.sessionManager.delete(currentSid);
            const identitySession = { sid: newSid, metadata: newIdentitySessionMetadata };
            request.setIdentitySession(identitySession);
            return identitySession;
        };
        try {
            const identitySession = request.getIdentitySession();
            if (!identitySession) {
                this.logger.error('Identity session is not available');
                return null;
            }
            const authorizationHeaders = deleteImpersonateAsHeader(identitySession);
            const response = await this.esClient.authorizeUser(authorizationHeaders);
            const newSid = (0, uuid_1.v4)();
            await setUserSession(authorizationHeaders, response, identitySession.sid, newSid);
            const encryptedCookie = await this.cookieManager.encryptRorCookie(newSid);
            res.cookie(this.cookieManager.cookieConfig.name, encryptedCookie, cookieManager_1.CookieManager.getCookiesOptions({ secure: this.cookieManager.cookieConfig.secure }));
            rorLogger_1.RorLogger.clearImpersonatingInfo();
        }
        catch (e) {
            this.logger.error(e.message, e);
            throw e;
        }
    }
    async verifySessionTimeout(request) {
        const sid = request.getIdentitySession()?.sid;
        if (!sid) {
            this.logger.info('Session is not defined');
            return;
        }
        return this.sessionManager.checkIfSessionTimeout(sid);
    }
    async verifyUserAccess(authorizationHeaders, kibanaIndex) {
        return this.esClient.verifyUserAccess(authorizationHeaders, kibanaIndex);
    }
    async createIndexAndSpace(metadata) {
        if (metadata.kibanaIndex) {
            await this.indexCreator.createIndexIfNecessary(metadata.kibanaIndex, metadata.kibanaTemplateIndex);
            await this.defaultSpaceCreator.createDefaultSpaceDocumentIfNeeded(metadata.kibanaIndex);
            await this.indexCreator.migrateIndexes(metadata.kibanaIndex);
        }
    }
    async authorizeUserWithHeaders(authorizationHeaders, newGroup, lastSessionActivityDate, impersonatedBy) {
        if (!authorizationHeaders) {
            return null;
        }
        const response = await this.esClient.authorizeUserAttachingMetadata(authorizationHeaders, newGroup);
        if (newGroup !== response['x-ror-current-group']) {
            this.logger.error('The group returned from es response does not match the selected group.');
            return null;
        }
        const identitySession = await this.createIdentitySession(authorizationHeaders, response, lastSessionActivityDate, impersonatedBy);
        await this.sessionManager.set(identitySession.sid, identitySession.metadata);
        return identitySession.sid;
    }
    async createIdentitySession(credentialHeaders, response, lastSessionActivityDate, impersonatedBy) {
        if (!this.multiTenancyEnabled && (response?.['x-ror-available-groups']?.length ?? 0) > 1) {
            console.log(`######################################################
#######    WARNING    ########
######################################################`);
            this.logger.warn('There is more than one group available, however, the multi-tenancy feature is disabled.');
        }
        const sid = (0, uuid_1.v4)();
        const identityMetadata = this.buildIdentitySessionMetadata({
            authorizationHeaders: credentialHeaders,
            response: response,
            lastSessionActivityDate,
            impersonatedBy
        });
        return {
            sid,
            metadata: identityMetadata
        };
    }
    buildIdentitySessionMetadata({ authorizationHeaders, response, lastSessionActivityDate, impersonatedBy }) {
        const license = this.licenseService.getActivationKey().license;
        const isEnt = (0, ActivationKey_1.isEnterpriseLicense)(license);
        const isFree = (0, ActivationKey_1.isFreeLicense)(license);
        return {
            expiresAt: this.sessionManager.createNewSessionExpirationDate(),
            lastSessionActivityDate,
            authorizationHeaders,
            username: response['x-ror-username'],
            availableGroups: isEnt && this.multiTenancyEnabled ? response['x-ror-available-groups'] || [] : [],
            kibanaHiddenApps: isFree ? [] : response['x-ror-kibana-hidden-apps'] || [],
            kibanaAccess: response['x-ror-kibana_access'] || accessLevel_1.AccessLevel.UNRESTRICTED,
            kibanaIndex: response['x-ror-kibana_index'],
            kibanaTemplateIndex: isEnt ? response['x-ror-kibana_template_index'] : '',
            origin: response['x-ror-origin'],
            correlationId: response['x-ror-correlation-id'],
            impersonatedBy: isEnt ? impersonatedBy : undefined,
            currentGroup: isEnt && this.multiTenancyEnabled ? response['x-ror-current-group'] || undefined : undefined,
            allowedApiPaths: response['x-ror-kibana-allowed-api-paths'] || undefined,
            customMetadata: response['x-ror-kibana-metadata']
        };
    }
    appendCorrelationIdHeader(identitySession, correlationId) {
        const authorizationHeaders = identitySession.metadata.authorizationHeaders;
        return authorizationHeaders.set(types_1.X_ROR_CORRELATION_ID, correlationId);
    }
    async verifyCurrentUser(request) {
        const rorRequest = request.rorRequest;
        const identitySession = rorRequest.getIdentitySession();
        if (!identitySession) {
            throw new Error('Identity session is not available');
        }
        await this.esClient.authorizeUserAttachingMetadata(identitySession.metadata.authorizationHeaders, identitySession.metadata.currentGroup ?? '');
    }
    // if you have no session, or null access level. Having a valid cookie, but invalid session is still possible, and should be handled.
    async getAccessLevel(req) {
        try {
            const accessLevel = await req.rorRequest.getIdentitySession()?.metadata?.kibanaAccess;
            if (accessLevel) {
                return accessLevel;
            }
        }
        catch (e) {
            this.logger.error('Failed to get access level from rorRequest', e);
        }
        // Try from cookie (when do we need this? do we need it?)
        const sid = await this.cookieManager.decryptRorCookieFromHeader(req.rorRequest.getCookies());
        if (sid == null) {
            return accessLevel_1.AccessLevel.RO_STRICT;
        }
        const metadata = await this.sessionManager.get(sid);
        if (metadata == null) {
            return accessLevel_1.AccessLevel.RO_STRICT;
        }
        return metadata.kibanaAccess || accessLevel_1.AccessLevel.RO;
    }
    async deleteAllSessions() {
        await this.sessionManager.deleteAllSessions();
    }
}
exports.AuthenticationFacade = AuthenticationFacade;
