"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.IndexCreator = void 0;
const abstractIndexCreator_1 = require("./abstractIndexCreator");
const distributionInfoProvider_1 = require("../../../kibana/patchers/distributionInfoProvider");
class IndexCreator extends abstractIndexCreator_1.AbstractIndexCreator {
    defaultKibanaIndex;
    esClient;
    static POST_7_12_KIBANA_INDEX_SUFFIX = /_[0-9][0-9][0-9]$/;
    constructor(defaultKibanaIndex, esClient, resetKibanaIndexToTemplate, kibanaTemplateIndex) {
        super(esClient, defaultKibanaIndex, __filename, resetKibanaIndexToTemplate, kibanaTemplateIndex);
        this.defaultKibanaIndex = defaultKibanaIndex;
        this.esClient = esClient;
    }
    async createKibanaIndex(kibanaIndexFromSession, baseIndex) {
        const mapping = await this.getDefaultIndexMapping(baseIndex);
        const realDefaultKibanaIndexPotentiallyBehindAlias = Object.keys(mapping)[0];
        const mappingWithAliasHandled = mapping[realDefaultKibanaIndexPotentiallyBehindAlias].mappings;
        const putPayload = {
            settings: { 'index.mapping.total_fields.limit': 2000, number_of_shards: 1, number_of_replicas: 1 },
            mappings: { properties: mappingWithAliasHandled.properties }
        };
        const kibanaIndexToCreate = realDefaultKibanaIndexPotentiallyBehindAlias
            .split(this.defaultKibanaIndex)
            .join(kibanaIndexFromSession);
        const shortFormAlias = IndexCreator.getShortFormAlias(kibanaIndexToCreate);
        const kibanaIndexToCreateWithoutAlias = kibanaIndexToCreate.split(/_\d./)[0];
        this.logger.debug(`Discovered Kibana >= 7.12.0 index migration algorithm in use. Will create the index ${kibanaIndexToCreate} with aliases: ${shortFormAlias}`);
        if (shortFormAlias && kibanaIndexToCreateWithoutAlias) {
            putPayload.aliases = {
                [kibanaIndexToCreateWithoutAlias]: {},
                [shortFormAlias]: {}
            };
        }
        this.logger.debug(`kibana_index resolution: default=${baseIndex}, fromSession=${kibanaIndexFromSession}, willBeCreated=${kibanaIndexToCreate}`);
        this.logger.debug(`Creating kibana index ${kibanaIndexFromSession} with mappings from ${baseIndex}: PUT ${JSON.stringify(putPayload).substring(0, 50)}...`);
        await this.esClient.putAsKibana(kibanaIndexToCreate, putPayload);
    }
    async isMigrationNeeded(kibanaIndex) {
        try {
            const response = await this.esClient.getAsKibana(`${kibanaIndex}/_alias`);
            if (!response.ok) {
                return false;
            }
            const data = await response.json();
            const kibanaIndexVersion = IndexCreator.getShortFormAlias(Object.keys(data)[0])?.split(`${kibanaIndex}_`)[1];
            const kibanaVersion = distributionInfoProvider_1.DistributionInfoProvider.getInstance().kibanaVersion;
            return kibanaIndexVersion !== kibanaVersion;
        }
        catch (e) {
            this.logger.error('Failed is migration needed check:', e.message);
            return false;
        }
    }
    static getShortFormAlias(kibanaIndexToCreate) {
        // Handle Kibana 7.12+ index handling (i.e. index=.kibana_7.12.0_00 => aliases=[.kibana, .kibana_7.12.0])
        const post712suffix = IndexCreator.getPost712KibanaIndexSuffix(kibanaIndexToCreate);
        if (!post712suffix) {
            return null;
        }
        return kibanaIndexToCreate.substring(0, kibanaIndexToCreate.length - post712suffix.length);
    }
    static getPost712KibanaIndexSuffix(defaultKibanaIndex) {
        const match = defaultKibanaIndex.match(IndexCreator.POST_7_12_KIBANA_INDEX_SUFFIX);
        return match ? match[0] : null;
    }
}
exports.IndexCreator = IndexCreator;
