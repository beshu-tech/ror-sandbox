"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CapabilitiesApiFilter = void 0;
const lodash_1 = __importDefault(require("lodash"));
const json_stable_stringify_1 = __importDefault(require("json-stable-stringify"));
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const _1 = require(".");
class CapabilitiesApiFilter {
    static logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    static shouldInterceptResponseBody(req) {
        return req.path.includes('/api/core/capabilities');
    }
    static interceptResponseBody(req, respBody) {
        // @ts-ignore
        const metadata = req.rorRequest.getIdentitySession()?.metadata;
        if (!metadata) {
            return respBody;
        }
        const capResponse = this.fromResponseBuffer(respBody);
        const modifiedResponse = (0, _1.transform)(capResponse ?? {}, metadata);
        CapabilitiesApiFilter.logger.trace('Modified intercepted body to: ', modifiedResponse);
        return Buffer.from((0, json_stable_stringify_1.default)(modifiedResponse, { space: '  ' }));
    }
    static fromResponseBuffer(respBody) {
        let parsed;
        try {
            parsed = JSON.parse(respBody.toString());
        }
        catch (e) {
            CapabilitiesApiFilter.logger.warn(`Problem with parsing JSON ${respBody.toString().substr(0, 30)}...`);
        }
        if (!parsed || lodash_1.default.isEmpty(parsed.navLinks) || lodash_1.default.isEmpty(parsed.catalogue)) {
            CapabilitiesApiFilter.logger.error(`Bad object parsed!! ${JSON.stringify(parsed)}`);
        }
        return parsed;
    }
}
exports.CapabilitiesApiFilter = CapabilitiesApiFilter;
