"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.HtmlInjector = void 0;
const rorLoggerFactory_1 = require("../../core/logging/rorLoggerFactory");
const distributionInfoProvider_1 = require("../../../kibana/patchers/distributionInfoProvider");
const HTML_HEAD_CLOSING_TAG = '</head>';
const HTML_BODY_CLOSING_TAG = '</body>';
class HtmlInjector {
    customUserCss;
    customUserCssFileContent;
    kibanaBasePath;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(kibanaBasePath, customUserCss, customUserCssFileContent) {
        this.kibanaBasePath = kibanaBasePath;
        this.customUserCss = customUserCss;
        this.customUserCssFileContent = customUserCssFileContent;
    }
    injectCssAndJsScriptsIntoHtml(interceptedHtmlResponse) {
        const isCustomUserCssDefined = this.customUserCss != null;
        const isCustomUserCssFileContentDefined = this.customUserCssFileContent != null;
        this.logger.trace(`Injecting custom user css: ${isCustomUserCssDefined}. ` +
            `Injecting custom user css file content: ${isCustomUserCssFileContentDefined}`);
        const htmlSplitAtHeadTag = interceptedHtmlResponse.toString().split(HTML_HEAD_CLOSING_TAG);
        const htmlSplitAtBodyTag = htmlSplitAtHeadTag[1] && htmlSplitAtHeadTag[1].split(HTML_BODY_CLOSING_TAG);
        const htmlHeadInjections = this.buildHtmlHeadInjections(isCustomUserCssDefined, isCustomUserCssFileContentDefined);
        const htmlBodyInjections = this.buildHtmlBodyInjections();
        const htmlSectionsBuffers = [
            htmlSplitAtHeadTag[0],
            htmlHeadInjections,
            HTML_HEAD_CLOSING_TAG,
            htmlSplitAtBodyTag[0],
            htmlBodyInjections,
            HTML_BODY_CLOSING_TAG,
            htmlSplitAtBodyTag[1]
        ].map(htmlSection => Buffer.from(htmlSection));
        return Buffer.concat(htmlSectionsBuffers);
    }
    buildHtmlHeadInjections(shouldInjectCustomUserCss, shouldInjectCustomUserCssFileContent) {
        let injectedHtml = distributionInfoProvider_1.DistributionInfoProvider.isEnvironmentDev()
            ? this.getLessNotCompiledToCssInjection()
            : this.getLessCompiledToCssInjection();
        if (shouldInjectCustomUserCss) {
            injectedHtml += `<style>${this.customUserCss}</style>`;
        }
        if (shouldInjectCustomUserCssFileContent) {
            injectedHtml += `<style>${this.customUserCssFileContent}</style>`;
        }
        return injectedHtml;
    }
    getLessNotCompiledToCssInjection() {
        return (`<link rel="stylesheet/less" type="text/css" href="${this.kibanaBasePath}/pkp/legacy/web/assets/less/main.less"/>` +
            `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/autodeps?file=less/dist/less.min.js"></script>`);
    }
    getLessCompiledToCssInjection() {
        return `<link rel="stylesheet" type="text/css" href="${this.kibanaBasePath}/pkp/legacy/web/assets/css/main.css"/>`;
    }
    buildHtmlBodyInjections() {
        let toInject = `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/legacy/web/assets/js/ie-alert.js"></script>` +
            `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/autodeps?file=jquery/dist/jquery.min.js"></script>` +
            `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/autodeps?file=xregexp/xregexp-all.js"></script>` +
            `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/injections/hidden-apps.js"></script>` +
            `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/injections/ror-css-classes.js"></script>` +
            `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/autodeps?file=js-cookie/dist/js.cookie.min.js"></script>` +
            `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/injections/session-probe.js"></script>` +
            `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/injections/activation-expiration-alert.js"></script>`;
        toInject += `<script type="application/javascript" defer src="${this.kibanaBasePath}/pkp/injections/custom.js"></script>`;
        return toInject;
    }
}
exports.HtmlInjector = HtmlInjector;
