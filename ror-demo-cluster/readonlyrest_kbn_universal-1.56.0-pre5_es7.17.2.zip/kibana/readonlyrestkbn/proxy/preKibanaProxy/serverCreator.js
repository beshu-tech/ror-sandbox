"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServerCreator = void 0;
const https_1 = __importDefault(require("https"));
const fs_1 = __importDefault(require("fs"));
const lodash_1 = __importDefault(require("lodash"));
const crypto_1 = require("crypto");
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
class ServerCreator {
    sslConfig;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    // TLSv1.0 is always disallowed
    secureOptionsBitmask = crypto_1.constants.SSL_OP_NO_TLSv1 || crypto_1.constants.SSL_OP_NO_SSLv2 || crypto_1.constants.SSL_OP_NO_SSLv3;
    constructor(sslConfig) {
        this.sslConfig = sslConfig;
        if (sslConfig) {
            this.initializeSupportedProtocols(sslConfig);
        }
    }
    createServer(app, hostAndPort) {
        app.disable('x-powered-by');
        if (!this.sslConfig) {
            return app.listen(hostAndPort.port, hostAndPort.host).on('error', err => {
                this.logger.error('listen error:', err);
            });
        }
        app.set('trust proxy', '127.0.0.1');
        return this.createHttpsServer(app, hostAndPort.host, hostAndPort.port);
    }
    initializeSupportedProtocols(sslConfig) {
        // TODO: To check, based on types there is no SSL_OP_NO_TLSv1_3 in types
        // @ts-ignore
        const { SSL_OP_NO_TLSv1_1, SSL_OP_NO_TLSv1_2, SSL_OP_NO_TLSv1_3 } = crypto_1.constants;
        const possibleValues = ['TLSv1.1', 'TLSv1.2', 'TLSv1.3'];
        if (!sslConfig.supportedProtocols) {
            this.logger.info(`ROR PKP SSL server will accept protocols: ${possibleValues} (bitmask: ${this.secureOptionsBitmask})`);
            return;
        }
        if (sslConfig.supportedProtocols.length === 0) {
            throw new Error('server.ssl.secureProtocols should be a non empty array or undefined');
        }
        const invalidValues = sslConfig.supportedProtocols.filter(x => !possibleValues.includes(x));
        if (invalidValues.length > 0) {
            throw new Error(`Unrecognised supportedProtocol values: ${invalidValues}, available values are: ${possibleValues}`);
        }
        if (!sslConfig.supportedProtocols.includes('TLSv1.1')) {
            this.logger.debug('Disallow TLSv1.1');
            this.secureOptionsBitmask = this.secureOptionsBitmask || SSL_OP_NO_TLSv1_1;
        }
        if (!sslConfig.supportedProtocols.includes('TLSv1.2')) {
            this.logger.debug('Disallow TLSv1.2');
            this.secureOptionsBitmask = this.secureOptionsBitmask || SSL_OP_NO_TLSv1_2;
        }
        if (!sslConfig.supportedProtocols.includes('TLSv1.3')) {
            this.logger.debug('Disallow TLSv1.3');
            this.secureOptionsBitmask = this.secureOptionsBitmask || SSL_OP_NO_TLSv1_3;
        }
        this.logger.info(`ROR PKP SSL server will accept protocols: ${sslConfig.supportedProtocols} (bitmask: ${this.secureOptionsBitmask})`);
    }
    createHttpsServer(app, host, port) {
        if (!this.sslConfig) {
            throw new Error('missing ssl config');
        }
        const options = {
            secureOptions: this.secureOptionsBitmask,
            ciphers: this.sslConfig.cipherSuites?.join(':'),
            honorCipherOrder: true
        };
        const keystoreOrCertOptions = this.sslConfig?.keystorePath
            ? {
                pfx: fs_1.default.readFileSync(this.sslConfig.keystorePath),
                passphrase: this.sslConfig.keystorePassword
            }
            : {
                key: fs_1.default.readFileSync(this.sslConfig.keyPath),
                passphrase: this.sslConfig.keyPassphrase,
                cert: fs_1.default.readFileSync(this.sslConfig.certificatePath)
            };
        Object.assign(options, keystoreOrCertOptions);
        if (Array.isArray(this.sslConfig.cipherSuites) && this.sslConfig.cipherSuites.length > 0) {
            options.ciphers = this.sslConfig.cipherSuites.join(':');
        }
        const ca = this.sslConfig.certificateAuthorities;
        if (!lodash_1.default.isEmpty(ca)) {
            options.ca = ca;
        }
        let server;
        try {
            this.logger.debug(`Creating TLS server on https://${host}:${port} with options: `, options);
            server = https_1.default.createServer(options, app).listen(port, host);
        }
        catch (error) {
            if (error.message.includes('mac verify failure')) {
                this.logger.error('The keystore password provided in kibana.yml does not match the password the PKCS#12 file is encrypted with. Please provide a valid password');
                process.exit(1);
            }
            else {
                this.logger.error('Error creating https server: ', error);
                console.error(error);
                process.exit(1);
            }
        }
        return server;
    }
}
exports.ServerCreator = ServerCreator;
