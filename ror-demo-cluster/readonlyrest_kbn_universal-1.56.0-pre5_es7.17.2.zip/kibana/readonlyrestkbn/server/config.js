"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.rorConfigSchema = void 0;
// @ts-nocheck
const config_schema_1 = require("@kbn/config-schema");
const types_1 = require("../proxy/core/common/types");
const logLevel_1 = require("../proxy/core/logging/logLevel");
const defaultValues_1 = require("./defaultValues");
exports.rorConfigSchema = config_schema_1.schema.object({
    identity: config_schema_1.schema.object({
        username: config_schema_1.schema.maybe(config_schema_1.schema.string()),
        currentlySelectedGroup: config_schema_1.schema.string({ defaultValue: 'groupA' }),
        availableGroups: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: ['groupA', 'groupB'] }),
        kibanaAccess: config_schema_1.schema.string({ defaultValue: 'ro' }),
        kibanaHiddenApps: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] })
    }),
    elasticsearch: config_schema_1.schema.object({
        username: config_schema_1.schema.maybe(config_schema_1.schema.string()),
        password: config_schema_1.schema.maybe(config_schema_1.schema.string())
    }),
    enabled: config_schema_1.schema.boolean({ defaultValue: true }),
    logLevel: config_schema_1.schema.string({
        defaultValue: 'info',
        validate(v) {
            const acceptedLogLevelValues = (0, logLevel_1.getAcceptedLogLevelValues)();
            if (acceptedLogLevelValues.includes(v)) {
                return false;
            }
            return `must be one of ${acceptedLogLevelValues.join(' ,')}`;
        }
    }),
    cookiePass: config_schema_1.schema.string({ minLength: 32 }),
    cookieName: config_schema_1.schema.string({
        minLength: 5,
        defaultValue: defaultValues_1.DEFAULT_KIBANA_YAML_ROR_VALUES.cookieName
    }),
    store_sessions_in_index: config_schema_1.schema.maybe(config_schema_1.schema.boolean({ defaultValue: false })),
    sessions_index_name: config_schema_1.schema.maybe(config_schema_1.schema.string({ defaultValue: '.readonlyrest_kbn_sessions' })),
    sessions_refresh_after: config_schema_1.schema.maybe(config_schema_1.schema.number({ minValue: 1, defaultValue: 2000 })),
    sessions_cleanup_interval: config_schema_1.schema.maybe(config_schema_1.schema.string({ defaultValue: '1d' })),
    sessions_probe_interval_seconds: config_schema_1.schema.maybe(config_schema_1.schema.number({
        minValue: 10,
        defaultValue: defaultValues_1.DEFAULT_KIBANA_YAML_ROR_VALUES.sessions_probe_interval_seconds
    })),
    // "login", "tenancyHop", "never"
    clearSessionOnEvents: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: ['login', 'tenancyHop'] }),
    session_timeout_minutes: config_schema_1.schema.number({
        defaultValue: defaultValues_1.DEFAULT_KIBANA_YAML_ROR_VALUES.session_timeout_minutes,
        minValue: 1
    }),
    proxy_auth_passthrough: config_schema_1.schema.boolean({ defaultValue: false }),
    custom_logout_link: config_schema_1.schema.maybe(config_schema_1.schema.string({ minLength: 6 })),
    custom_login_link: config_schema_1.schema.maybe(config_schema_1.schema.string({ minLength: 6 })),
    login_html_head_inject: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    login_custom_css_inject_file: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    login_custom_js_inject_file: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    custom_middleware_inject_file: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    custom_middleware_inject: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    login_custom_logo: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    login_subtitle: config_schema_1.schema.maybe(config_schema_1.schema.string({ unknowns: 'allowed', defaultValue: '' })),
    login_title: config_schema_1.schema.maybe(config_schema_1.schema.string({ unknowns: 'allowed', defaultValue: '' })),
    kibana_custom_css_inject: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    kibana_custom_css_inject_file: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    kibana_custom_js_inject: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    kibana_custom_js_inject_file: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    jwt_query_param: config_schema_1.schema.string({ defaultValue: 'jwt' }),
    whitelistedPaths: config_schema_1.schema.maybe(config_schema_1.schema.arrayOf(config_schema_1.schema.string())),
    forward_auth_header: config_schema_1.schema.string({ defaultValue: types_1.X_FORWARDED_USER }),
    kibanaIndexTemplate: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    groupsMapping: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    resetKibanaIndexToTemplate: config_schema_1.schema.boolean({ defaultValue: false }),
    // Kibana security token override (set it in dev mode)
    pkpKibanaToken: config_schema_1.schema.maybe(config_schema_1.schema.string()),
    license: config_schema_1.schema.maybe(config_schema_1.schema.any()),
    multiTenancyEnabled: config_schema_1.schema.maybe(config_schema_1.schema.boolean({ defaultValue: true })),
    // Legacy:
    //         auth: Joi.object({
    //           signature_key: Joi.string().optional(),
    //
    //           //removeIf(no_saml)
    //           saml: Joi.object({
    //             enabled: Joi.boolean().default(true),
    //             type: Joi.string().optional(),
    //             protocol: Joi.string().default('http'),
    //             usernameParameter: Joi.string().default('nameID'),
    //             groupsParameter: Joi.string().default('memberOf'),
    //             kibanaExternalHost: Joi.string(),
    //             buttonName: Joi.string().optional(),
    //             logoutUrl: Joi.string().optional(),
    //             decryptionCert: Joi.string().optional(),
    //             entryPoint: Joi.string(),
    //             decryptionPvk: Joi.string().optional(),
    //             cert: Joi.string().optional(),
    //             privateCert: Joi.string().optional(),
    //             issuer: Joi.string().optional().default('ror'),
    //             authnContext: Joi.string().optional(),
    //             identifierFormat: Joi.string().optional(),
    //             acceptedClockSkewMs: Joi.number().optional(),
    //             signatureAlgorithm: Joi.string().optional(),
    //             disableRequestedAuthnContext: Joi.string().optional(),
    //           }).optional()
    //           //endRemoveIf(no_saml)
    //
    //         }).pattern(/./, Joi.any()).optional(),
    //
    // This is a poor workaround for legacy backward compatibility.
    // It requires an addition of custom validator or rewrite of schema to proper yaml standards (configurations as an array)
    auth: config_schema_1.schema.maybe(config_schema_1.schema.any())
});
