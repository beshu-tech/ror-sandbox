"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReadonlyrestKbnPlugin = void 0;
const distributionInfoProvider_1 = require("../kibana/patchers/distributionInfoProvider");
const kibanaPatcher_1 = require("../kibana/patchers/kibanaPatcher");
const SessionCleanupTaskManager_1 = require("./SessionCleanupTaskManager");
class ReadonlyrestKbnPlugin {
    logger;
    sessionCleanupTaskManager;
    constructor(initializerContext) {
        this.logger = initializerContext.logger.get();
        this.sessionCleanupTaskManager = new SessionCleanupTaskManager_1.SessionCleanupTaskManager();
    }
    async setup(_, { taskManager }) {
        this.logger.info(`Setting up ReadonlyREST plugin - build info: ${distributionInfoProvider_1.DistributionInfoProvider.getInstance().toString()}`);
        this.logger.debug('readonlyrest_kbn: Setup');
        this.sessionCleanupTaskManager.setup(taskManager);
        return {};
    }
    start(core, { taskManager }) {
        this.sessionCleanupTaskManager.start(core.elasticsearch.client, taskManager);
        this.checkIfInstallationFinished();
        return {};
    }
    stop() {
        this.logger.debug('readonlyrest_kbn: Stopped');
    }
    checkIfInstallationFinished() {
        if ((0, kibanaPatcher_1.isPatchedAll)()) {
            this.logger.debug('readonlyrest_kbn: Started');
        }
        else {
            console.log(`######################################################
#######    READONLYREST INSTALLATION ERROR    ########
######################################################`);
            this.logger.error('ReadonlyREST plugin installation is not finished yet, an additional patching kibana step is required. Check documentation https://docs.readonlyrest.com/kibana#patching-kibana for more references');
            process.exit();
        }
    }
}
exports.ReadonlyrestKbnPlugin = ReadonlyrestKbnPlugin;
