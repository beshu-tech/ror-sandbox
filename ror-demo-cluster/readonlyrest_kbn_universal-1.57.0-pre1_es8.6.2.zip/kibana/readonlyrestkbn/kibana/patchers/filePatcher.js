"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.FilePatcher = void 0;
const diff = require('diff');
const fs = require('fs');
const { basename } = require('path');
class FilePatcher {
    patchFilePath;
    backup_suffix;
    targetPatchRoot;
    patchContent;
    sourceFile;
    destinationFile;
    constructor(patchFilePath, targetPatchRoot = `${__dirname}../../`, backup_suffix = '.orig') {
        this.patchFilePath = patchFilePath;
        this.backup_suffix = backup_suffix;
        // now we are in kibana/plugins/readonlyrest_kbn, so kibana sources are up two dirs.
        this.targetPatchRoot = targetPatchRoot;
        // Read the patch file
        this.patchContent = fs.readFileSync(patchFilePath, 'utf8');
        // Extract source file path
        const sourceFileMatch = /--- ([^ \n\r\t]+).*/.exec(this.patchContent);
        let sourceFile;
        if (sourceFileMatch && sourceFileMatch[1]) {
            sourceFile = sourceFileMatch[1];
        }
        else {
            throw Error(`Unable to find source file in '${this.patchFilePath}'`);
        }
        this.sourceFile = `${this.targetPatchRoot}/${sourceFile}`.replace('//', '/');
        // Extract destination file path
        const destinationFileMatch = /\+\+\+ ([^ \n\r\t]+).*/.exec(this.patchContent);
        let destinationFile;
        if (destinationFileMatch && destinationFileMatch[1]) {
            destinationFile = destinationFileMatch[1];
        }
        else {
            throw Error(`Unable to find destination file in '${patchFilePath}'`);
        }
        this.destinationFile = `${this.targetPatchRoot}/${destinationFile}`.replace('//', '/');
    }
    backup(pathAndFile = this.sourceFile) {
        fs.copyFileSync(pathAndFile, pathAndFile + this.backup_suffix);
        return this;
    }
    restore(pathAndFile = this.sourceFile) {
        if (!this.hasBackup(pathAndFile)) {
            throw new Error(`Cannot restore ${pathAndFile} as no backup was found`);
        }
        const backupFile = pathAndFile + this.backup_suffix;
        fs.copyFileSync(backupFile, pathAndFile);
        fs.unlinkSync(backupFile);
        console.log(`Restored ${pathAndFile}`);
        return this;
    }
    hasBackup(pathAndFile = this.sourceFile) {
        return fs.existsSync(pathAndFile + this.backup_suffix);
    }
    unpatch(pathAndFile = this.sourceFile) {
        return this.restore(pathAndFile);
    }
    isPatched() {
        console.log('Verifying patched state...');
        if (!this.hasBackup()) {
            console.log(`NO_BACKUP cannot verify patched status of ${this.sourceFile}, backup file not present.`);
            return false;
        }
        const backupFileContent = fs.readFileSync(this.sourceFile + this.backup_suffix, 'utf8').toString('utf-8');
        const patchedFileContent = fs.readFileSync(this.sourceFile, 'utf8').toString('utf-8');
        const repatchedContent = diff.applyPatch(backupFileContent, this.patchContent, { fuzzFactor: 2 });
        if (repatchedContent === false) {
            throw new Error('Cannot verify patched status, as the patch is not applicable to the original backed-up file');
        }
        const wasSuccess = patchedFileContent == repatchedContent;
        if (wasSuccess) {
            console.log(`${basename(this.sourceFile)} patched state: VERIFIED.`);
        }
        else {
            console.log(`${basename(this.sourceFile)} patched state is OUTDATED: it and needs to be reverted and patched again.`);
        }
        return wasSuccess;
    }
    patch() {
        if (this.hasBackup()) {
            console.log(`Backup file was present: '${this.sourceFile}${this.backup_suffix}'.  Already patched?`);
            return false;
        }
        this.backup();
        const originalFileContent = fs.readFileSync(this.sourceFile, 'utf8').toString('utf-8');
        const patchedFileContent = diff.applyPatch(originalFileContent, this.patchContent, { fuzzFactor: 2 });
        if (patchedFileContent === false) {
            throw Error(`Failed to apply patch '${basename(this.patchFilePath)}' to '${this.sourceFile}'`);
        }
        else if (this.sourceFile !== this.destinationFile) {
            console.log(`Applied '${basename(this.patchFilePath)}' to '${this.sourceFile}' and stored it as '${this.destinationFile}'`);
        }
        else {
            console.log(`Applied '${basename(this.patchFilePath)}' to '${this.sourceFile}'`);
        }
        fs.writeFileSync(this.destinationFile, patchedFileContent);
        return this;
    }
}
exports.FilePatcher = FilePatcher;
