"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EsClient = exports.checkEsAuthorizationResponseSuccessStatus = exports.checkEsAuthorizationResponseErrorStatus = void 0;
const node_fetch_1 = __importDefault(require("node-fetch"));
const lodash_1 = __importDefault(require("lodash"));
const authorizationHeaderBuilder_1 = require("./authorization/authorizationHeaderBuilder");
const types_1 = require("./common/types");
const esSecurityHeaderBuilder_1 = require("./common/esSecurityHeaderBuilder");
const rorLoggerFactory_1 = require("./logging/rorLoggerFactory");
const errors_1 = __importDefault(require("../constants/errors"));
function checkEsAuthorizationResponseErrorStatus(status) {
    if (status.status < 300) {
        throw new Error('Not an error status');
    }
}
exports.checkEsAuthorizationResponseErrorStatus = checkEsAuthorizationResponseErrorStatus;
function checkEsAuthorizationResponseSuccessStatus(status) {
    if (status.status >= 300) {
        throw new Error('Not an success status');
    }
}
exports.checkEsAuthorizationResponseSuccessStatus = checkEsAuthorizationResponseSuccessStatus;
class EsClient {
    static BATCH_DELETE_CHUNK_SIZE = 100;
    esAuthorizeUserUri = '_readonlyrest/metadata/current_user';
    configUri = '_readonlyrest/admin/config';
    testConfigUri = '_readonlyrest/admin/config/test';
    authMockUri = '_readonlyrest/admin/config/test/authmock';
    localUsersUri = '_readonlyrest/admin/config/test/localusers';
    configFileUri = '_readonlyrest/admin/config/file';
    auditLogEventUri = '_readonlyrest/admin/audit/event';
    getDefaultSpaceUrl = (kibanaIndex) => `${kibanaIndex}/_doc/space:default`;
    kibanaTechUserEsAuthToken;
    authorizationHeaderBuilder;
    esHostBalancer;
    esSSLConnectionProvider;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    customHeaders;
    constructor(kibanaTechUserEsAuthToken, esHostBalancer, esSSLConnectionProvider, multiTenancyEnabled, customHeaders, kibanaIndex) {
        this.kibanaTechUserEsAuthToken = kibanaTechUserEsAuthToken;
        this.authorizationHeaderBuilder = new authorizationHeaderBuilder_1.AuthorizationHeaderBuilder(multiTenancyEnabled, kibanaIndex);
        this.esHostBalancer = esHostBalancer;
        this.esSSLConnectionProvider = esSSLConnectionProvider;
        this.customHeaders = customHeaders;
    }
    async authorizeUser(credentialHeaders, group) {
        try {
            const requestInit = await this.prepareRequestInit(credentialHeaders, group);
            const authorizeUserResponse = await this.fetch(this.getElasticsearchUrl() + this.esAuthorizeUserUri, requestInit);
            const authorizeUserData = (await authorizeUserResponse.json());
            this.logger.trace('Authorization attempt returned: ', authorizeUserData);
            return this.validateSuccessfulAuthorizationResponse(authorizeUserResponse, authorizeUserData);
        }
        catch (e) {
            this.logger.error(e.message, e);
            throw new Error('WRONG_CREDENTIALS');
        }
    }
    async authorizeUserAttachingMetadata(authorizationHeaders, newGroup) {
        try {
            const headerValue = await this.authorizationHeaderBuilder.prepareAuthorizationHeaderFromMetadata(authorizationHeaders, newGroup);
            const header = { [types_1.AUTHORIZATION_HEADER]: headerValue };
            const authorizeUserResponse = await this.fetch(this.getElasticsearchUrl() + this.esAuthorizeUserUri, {
                headers: header
            });
            const authorizeUserData = (await authorizeUserResponse.json());
            this.logger.trace('Authorization attempt returned: ', authorizeUserData);
            return this.validateSuccessfulAuthorizationResponse(authorizeUserResponse, authorizeUserData);
        }
        catch (e) {
            this.logger.error(e.message, e);
            throw new Error('SERVER_ERROR');
        }
    }
    async getAsKibana(uri) {
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForGetRequestFrom(this.kibanaTechUserEsAuthToken);
        return this.fetch(this.getElasticsearchUrl() + uri, { headers: header });
    }
    async postAsKibana(uri, body) {
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForPostRequestFrom(this.kibanaTechUserEsAuthToken);
        return this.fetch(this.getElasticsearchUrl() + uri, {
            method: 'POST',
            headers: header,
            body
        });
    }
    async headAsKibana(uri) {
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForGetRequestFrom(this.kibanaTechUserEsAuthToken);
        return this.fetch(this.getElasticsearchUrl() + uri, { method: 'HEAD', headers: header });
    }
    async deleteAsKibana(uri) {
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForGetRequestFrom(this.kibanaTechUserEsAuthToken);
        return this.fetch(this.getElasticsearchUrl() + uri, {
            method: 'DELETE',
            headers: header
        });
    }
    async deleteBatchAsKibana(uri, documentIds) {
        const responses = [];
        let chunkId = 0;
        for (const chunk of lodash_1.default.chunk(documentIds, EsClient.BATCH_DELETE_CHUNK_SIZE)) {
            this.logger.debug(`Batch-${chunkId}: deleting ${chunk.length} ids: ${JSON.stringify(lodash_1.default.take(chunk, 3))}${chunk.length > 1 ? ' etc.' : ''}`);
            // eslint-disable-next-line no-await-in-loop
            const response = await this.postAsKibana(uri, JSON.stringify({ query: { ids: { values: chunk } } }));
            if (response.status >= 300) {
                // eslint-disable-next-line no-await-in-loop
                this.logger.warn(`Batch-${chunkId}: delete failed with response: ${JSON.stringify(await response.json())}`);
            }
            responses.push(response);
            chunkId += 1;
        }
        return responses;
    }
    async putAsKibana(uri, body) {
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForPostRequestFrom(this.kibanaTechUserEsAuthToken);
        const response = await this.fetch(this.getElasticsearchUrl() + uri, {
            method: 'PUT',
            headers: header,
            body: JSON.stringify(body)
        });
        return EsClient.toEsResponse(response);
    }
    async getConfiguration(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.configUri, {
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async getConfigurationFile(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.configFileUri, {
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async getTestConfiguration(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.testConfigUri, {
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async postTestConfiguration(authorizationHeaders, body) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.testConfigUri, {
            method: 'POST',
            headers: Array.from(authorizationHeaders.entries()).concat([['Content-Type', 'application/json']]),
            body: JSON.stringify({ settings: body.settings, ttl: body.ttl })
        });
        return EsClient.toEsResponse(response);
    }
    async getAuthMock(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.authMockUri, {
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async postAuthMock(authorizationHeaders, body) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.authMockUri, {
            method: 'POST',
            headers: Array.from(authorizationHeaders.entries()).concat([['Content-Type', 'application/json']]),
            body: JSON.stringify(body)
        });
        return EsClient.toEsResponse(response);
    }
    async getLocalUsers(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.localUsersUri, {
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async deleteTestConfiguration(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.testConfigUri, {
            method: 'DELETE',
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async postAuditEvent(authorizationHeaders, body) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.auditLogEventUri, {
            method: 'POST',
            headers: Array.from(authorizationHeaders.entries()).concat([['Content-Type', 'application/json']]),
            body: JSON.stringify(body)
        });
        return EsClient.toEsResponse(response);
    }
    async postConfiguration(authorizationHeaders, settings) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.configUri, {
            method: 'POST',
            headers: Array.from(authorizationHeaders.entries()).concat([['Content-Type', 'application/json']]),
            body: JSON.stringify(settings)
        });
        return EsClient.toEsResponse(response);
    }
    async checkImpersonatedUser(authorizationHeaders, impersonateAs) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.esAuthorizeUserUri, {
            headers: Array.from(authorizationHeaders.entries()).concat([[types_1.X_ROR_IMPERSONATING, impersonateAs]])
        });
        return EsClient.toEsResponse(response);
    }
    async verifyUserAccess(authorizationHeaders, kibanaIndex) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.getDefaultSpaceUrl(kibanaIndex), {
            method: 'GET',
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    getElasticsearchUrl() {
        return `${this.esHostBalancer.getElasticsearchUrl()}/`;
    }
    writeEsResponse(res, esResponse) {
        res.statusCode = esResponse.status;
        res.statusMessage = esResponse.statusMessage;
        res.send(esResponse.body);
    }
    async prepareRequestInit(credentialHeaders, group) {
        if (group) {
            return {
                headers: {
                    [types_1.AUTHORIZATION_HEADER]: await this.authorizationHeaderBuilder.prepareAuthorizationHeaderFromMetadata(credentialHeaders, group),
                    ...this.customHeaders
                }
            };
        }
        const customHeadersToArray = Object.entries(this.customHeaders).map(entry => entry);
        return {
            headers: Array.from(credentialHeaders.entries()).concat(customHeadersToArray)
        };
    }
    validateSuccessfulAuthorizationResponse(response, authorizeUserData) {
        if (response.status === 401 || response.status === 403) {
            throw new Error(`ES Authorization error: ${response.status}`);
        }
        return authorizeUserData;
    }
    static async toEsResponse(response) {
        const bodyString = await response.text();
        const body = bodyString ? JSON.parse(bodyString) : bodyString;
        return {
            status: response.status,
            statusMessage: response.statusText,
            body
        };
    }
    async fetch(url, init) {
        return (0, node_fetch_1.default)(url, {
            ...init,
            headers: init?.headers,
            agent: this.esSSLConnectionProvider.getConnectionAgent()
        });
    }
    verifyMediaType(req, res, next, acceptedMediaTypes) {
        if (req.is(acceptedMediaTypes)) {
            return next();
        }
        return res.status(415).send({
            status: 'UNSUPPORTED_MEDIA_TYPE',
            message: errors_1.default.unsupportedMediaType
        });
    }
}
exports.EsClient = EsClient;
