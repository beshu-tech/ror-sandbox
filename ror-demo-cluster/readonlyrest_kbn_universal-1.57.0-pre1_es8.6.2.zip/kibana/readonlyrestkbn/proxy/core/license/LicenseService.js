"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LicenseService = void 0;
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const jwt = __importStar(require("jsonwebtoken"));
const jwtLegacy = __importStar(require("jsonwebtoken-legacy"));
const crypto_js_1 = __importDefault(require("crypto-js"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const ms_1 = __importDefault(require("ms"));
const rorLoggerFactory_1 = require("../logging/rorLoggerFactory");
const ActivationKey_1 = require("./ActivationKey");
const ConfigurationCompliance_1 = require("./ConfigurationCompliance");
const errors_1 = __importDefault(require("../../constants/errors"));
const distributionInfoProvider_1 = require("../../../kibana/patchers/distributionInfoProvider");
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
class LicenseService {
    storeEncryptionKey;
    tokenPublicKey;
    licenseConfig;
    esClient = null;
    DEFAULT_ACTIVATION_KEY = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzUxMiJ9.eyJleHAiOjg4MDYxMjEyODAwLCJpc3MiOiJodHRwczovL2FwaS5iZXNodS50ZWNoIiwiaWF0IjoxNjYxMzU2MTAxLCJqdGkiOiJyb3JfbGljXzI1YjJhYWE4LTE0MDEtNGI4Zi04ZDBmLTZjMzE3ZjliYTY3MCIsImF1ZCI6InJlYWRvbmx5cmVzdF9rYm4iLCJzdWIiOiIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMSIsImxpY2Vuc29yIjp7Im5hbWUiOiJCZXNodSBMaW1pdGVkIHQvYSBSZWFkb25seVJFU1QgU2VjdXJpdHkiLCJjb250YWN0IjpbInN1cHBvcnRAcmVhZG9ubHlyZXN0LmNvbSIsImZpbmFuY2VAcmVhZG9ubHlyZXN0LmNvbSJdLCJpc3N1ZXIiOiJzdXBwb3J0QHJlYWRvbmx5cmVzdC5jb20ifSwibGljZW5zZWUiOnsibmFtZSI6IkFub255bW91cyBGcmVlIFVzZXIiLCJidXlpbmdfZm9yIjpudWxsLCJiaWxsaW5nX2VtYWlsIjoidW5rbm93bkByb3JmcmVlLmNvbSIsImFsdF9lbWFpbHMiOltdLCJhZGRyZXNzIjpbIlVua25vd24iXX0sImxpY2Vuc2UiOnsiY2x1c3Rlcl91dWlkIjoiKiIsImVkaXRpb24iOiJrYm5fZnJlZSIsImVkaXRpb25fbmFtZSI6IkZyZWUiLCJpc1RyaWFsIjpmYWxzZX19.AUpJKXec7Ed7z6v9SsK3ingQIN8WGZDEMXC5cDn2cLeWsPopwtcfXncptYUXfFUV6diJG-pFpVC41xKHBrZetVIlAcH5OJCEWIlxzMho-WrwDn8rjpTcVDE8tW_JCoE0uteTOLXy97V8vDdyW5pmJQjb7pUd2zvECxGjwFxVsrdsBDkg';
    LICENSE_INDEX_NAME = '.readonlyrest_license';
    CLUSTER_READY_POLL_INTERVAL = 4000;
    ACTIVATION_KEY_ENV_VAR = 'ROR_ACTIVATION_KEY';
    ACTIVATION_KEY_FILE_PATH;
    clusterUuid = '';
    activationKey = null;
    origin = null;
    jwt = distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('7.11.0') ? jwtLegacy : jwt;
    toString() {
        return '< LicenseService instance >';
    }
    static toLoggableActivationKey(info) {
        const clone = JSON.parse(JSON.stringify(info));
        delete clone.licensee?.billing_email;
        delete clone.licensee?.alt_emails;
        delete clone.licensee?.address;
        delete clone.licensor?.issuer;
        delete clone.licensor?.contact;
        delete clone.iss;
        delete clone.aud;
        return clone;
    }
    constructor(storeEncryptionKey, tokenPublicKey, licenseConfig) {
        this.storeEncryptionKey = storeEncryptionKey;
        this.tokenPublicKey = tokenPublicKey;
        this.licenseConfig = licenseConfig;
        logger.debug('Received licenseConfig: ', licenseConfig);
        this.ACTIVATION_KEY_FILE_PATH =
            licenseConfig.activationKeyFilePath ||
                path_1.default.resolve(path_1.default.join(__dirname, '..', '..', '..', '..', '..', 'ROR_ACTIVATION_KEY.txt'));
        if (this.canRetrieveFrom('index', false)) {
            setTimeout(async () => {
                logger.debug('Polling for new activation key in index...');
                await this.retrieveActivationKey();
            }, 5000);
        }
    }
    getCompliance() {
        return new ConfigurationCompliance_1.ConfigurationCompliance(this.getActivationKey());
    }
    isInitialisedOrDie() {
        if (!this.clusterUuid) {
            throw new Error('LicenseService is not initialised yet: empty clusterUuid');
        }
        if (!this.activationKey) {
            throw new Error('LicenseService is not initialised yet: empty ActivationKey');
        }
    }
    async init(esClient) {
        if (esClient) {
            this.esClient = esClient;
        }
        if (this.clusterUuid) {
            return;
        }
        const wait = function (ms = 1000) {
            return new Promise(resolve => {
                setTimeout(resolve, ms);
            });
        };
        const poll = async function (fn, fnCondition, ms) {
            let result = await fn();
            while (!fnCondition(result)) {
                // eslint-disable-next-line no-await-in-loop
                await wait(ms);
                // eslint-disable-next-line no-await-in-loop
                result = await fn();
            }
            return result;
        };
        const attempt = async () => {
            logger.debug('Trying to get cluster UUID');
            try {
                if (!this.esClient) {
                    throw new Error('Service not initialised');
                }
                const res = await this.esClient.getAsKibana('_cluster/stats');
                if (res.status !== 200) {
                    logger.info(`>> Cannot get the cluster stats. Got status: ${res.status}`);
                    return;
                }
                const body = await res.json();
                this.clusterUuid = body.cluster_uuid;
                return this.clusterUuid;
            }
            catch (e) {
                logger.error('Error ', e.message);
            }
        };
        await poll(attempt, () => !!this.clusterUuid, this.CLUSTER_READY_POLL_INTERVAL);
        this.activationKey = await this.retrieveActivationKey();
        logger.info(`Found ES cluster with UUID=${this.clusterUuid}`);
        logger.debug('Activation key retrieving:', JSON.stringify(this.activationKey));
    }
    getClusterUUID() {
        this.isInitialisedOrDie();
        return this.clusterUuid;
    }
    getActivationKeyOrigin() {
        this.isInitialisedOrDie();
        return this.origin;
    }
    getActivationKey() {
        this.isInitialisedOrDie();
        return this.activationKey;
    }
    intervalRefreshActivationKey(callback) {
        setInterval(async () => {
            const previousLicense = this.activationKey?.license.edition;
            this.activationKey = await this.retrieveActivationKey();
            const newLicense = this.activationKey.license.edition;
            logger.trace(`Activation key refreshed. Previous edition ${previousLicense}, new license ${newLicense}`);
            const isLicenseEditionChanged = previousLicense !== newLicense;
            await callback(isLicenseEditionChanged);
        }, (0, ms_1.default)(this.licenseConfig.activationKeyRefreshInterval));
    }
    async retrieveActivationKey() {
        try {
            // Try to read the activation key from index first
            let token = await this.getTokenFromIndex();
            let tokenValidationResult;
            if (token) {
                tokenValidationResult = this.validateToken(token);
                if (!tokenValidationResult.isValid) {
                    logger.error('The Activation Key found in index, but was not valid. Will delete it.');
                    await this.removeTokenFromIndex();
                }
                else {
                    logger.debug('Found valid activation key in index: ', LicenseService.toLoggableActivationKey(tokenValidationResult.token));
                    this.activationKey = tokenValidationResult.token;
                    this.origin = 'index';
                    return tokenValidationResult.token;
                }
            }
            // activation key was not found in the index, try to get it from the environment variable
            token = (this.canRetrieveFrom('env') && process.env[this.ACTIVATION_KEY_ENV_VAR]) || null;
            tokenValidationResult = this.validateToken(token);
            if (tokenValidationResult.isValid) {
                logger.info('Found valid activation key in env var: ', LicenseService.toLoggableActivationKey(tokenValidationResult.token));
                this.origin = 'env';
                this.activationKey = tokenValidationResult.token;
                return tokenValidationResult.token;
            }
            // Try from file
            token = (this.canRetrieveFrom('file') && this.readActivationKeyFromFilesystem()) || null;
            tokenValidationResult = this.validateToken(token);
            this.activationKey = tokenValidationResult.isValid ? tokenValidationResult.token : null;
            if (tokenValidationResult.isValid) {
                logger.info(`Found valid activation key in file ${this.ACTIVATION_KEY_FILE_PATH}: `, LicenseService.toLoggableActivationKey(tokenValidationResult.token));
                this.origin = 'filesystem';
                this.activationKey = tokenValidationResult.token;
                return tokenValidationResult.token;
            }
            // Last resort, default activation key rom hardcoded (Free)
            tokenValidationResult = this.validateToken(this.DEFAULT_ACTIVATION_KEY);
            if (!tokenValidationResult.isValid) {
                throw new Error('The default Activation key is not valid.');
            }
            logger.info(`No Activation Key found. That's OK. Defaulting to Free license.You can add your own Activation Key later.`);
            logger.info('Visit ReadonlyREST Customer Portal at https://readonlyrest.com to get a trial Activation Key.');
            this.origin = 'default_key';
            this.activationKey = tokenValidationResult.token;
            return tokenValidationResult.token;
        }
        catch (e) {
            logger.warn('Error retrieving license info: ', e);
            throw e;
        }
    }
    readActivationKeyFromFilesystem() {
        const path = this.ACTIVATION_KEY_FILE_PATH;
        logger.debug('Trying to read the activation key from file (activationKeyFilePath): ', path);
        if (fs_1.default.existsSync(path)) {
            const content = fs_1.default.readFileSync(path, 'utf8');
            if (content) {
                return content.trim();
            }
            logger.trace(`File was empty: ${path}`);
        }
        else {
            logger.trace(`File not found: ${path}`);
        }
        return null;
    }
    canRetrieveFrom(origin, enableLogging = true) {
        const modes = this.licenseConfig.activationKeyRetrievalModes;
        if (modes.includes(origin) || modes.includes('all')) {
            return true;
        }
        if (enableLogging) {
            logger.trace(`Will not try to retrieve from ${origin} because it is not in the list of allowed origins: ${modes}`);
        }
        return false;
    }
    async getTokenFromIndex() {
        await this.init();
        if (!this.canRetrieveFrom('index')) {
            return null;
        }
        if (!this.esClient) {
            throw new Error('Service not initialised');
        }
        const res = await this.esClient.getAsKibana(`${this.LICENSE_INDEX_NAME}/_doc/token`);
        if (res.status !== 200) {
            logger.info(`Cannot get the encrypted activation key from Kibana... Status code: ${res.status}`);
            if (res.status !== 404) {
                logger.trace(`Got response: ${res}`);
            }
            return null;
        }
        const body = await res.json();
        try {
            const decrypted = crypto_js_1.default.AES.decrypt(body._source.encrypted, this.storeEncryptionKey).toString(crypto_js_1.default.enc.Utf8);
            logger.trace(`Decrypted token: ${decrypted}`);
            return decrypted;
        }
        catch (e) {
            logger.error(`Cannot decrypt activation key ${JSON.stringify(body)}`);
        }
        return null;
    }
    async removeTokenFromIndex() {
        await this.init();
        if (!this.esClient) {
            throw new Error('Service not initialised');
        }
        const res = await this.esClient.deleteAsKibana(`${this.LICENSE_INDEX_NAME}/_doc/token?refresh=true`);
        if (res.status > 299) {
            throw new Error(`Cannot delete the encrypted activation key from Kibana... Got status: ${res.status} ${await res.text()}`);
        }
        const validateToken = this.validateToken(this.DEFAULT_ACTIVATION_KEY);
        if (!validateToken.isValid) {
            throw new Error(`Cannot delete the encrypted activation key from Kibana, default activation key is not available`);
        }
        this.activationKey = validateToken.token;
        this.origin = 'default_key';
        logger.debug(`deleted activation key from index, returned code ${res.status}`);
        return validateToken.token;
    }
    async saveTokenToIndex(token) {
        await this.init();
        const newActivationKey = this.validateToken(token);
        if (!newActivationKey.isValid) {
            const error = new Error(newActivationKey.message);
            error.name = newActivationKey.reason;
            throw error;
        }
        const encrypted = crypto_js_1.default.AES.encrypt(token, this.storeEncryptionKey).toString();
        if (!this.esClient) {
            throw new Error('Service not initialised');
        }
        const res = await this.esClient.postAsKibana(`${this.LICENSE_INDEX_NAME}/_doc/token?refresh=true`, JSON.stringify({ encrypted }));
        if (res.status > 299) {
            throw new Error(`Cannot write the encrypted activation key to Kibana... got status: ${res.status} ${await res.text()}`);
        }
        this.activationKey = newActivationKey.token;
        this.origin = 'index';
        return newActivationKey.token;
    }
    nonFreeLicenseRequired(res, next, message) {
        if ((0, ActivationKey_1.isFreeLicense)(this.getActivationKey().license)) {
            logger.warn(`FORBIDDEN: ${message}`);
            return res.status(403).send({ status: 'FORBIDDEN', message });
        }
        next();
    }
    enterpriseLicenseRequired(res, next, message) {
        if (!(0, ActivationKey_1.isEnterpriseLicense)(this.getActivationKey().license)) {
            logger.warn(`FORBIDDEN: ${message}`);
            return res.status(403).send({ status: 'FORBIDDEN', message });
        }
        next();
    }
    validateToken(token) {
        try {
            if (!token) {
                return { isValid: false, reason: 'CANNOT_BE_VERIFIED', message: errors_1.default.activationKey.cantBeVerified };
            }
            const decoded = this.jwt.verify(token, Buffer.from(this.tokenPublicKey), {
                algorithms: ['ES512']
            });
            if (!decoded) {
                logger.error(`❌ ${errors_1.default.activationKey.cantBeVerified} ${token}`);
                return { isValid: false, reason: 'CANNOT_BE_VERIFIED', message: errors_1.default.activationKey.cantBeVerified };
            }
            if (!this.clusterUuid) {
                throw Error(`${path_1.default.basename(__filename)} not properly initialised. Please run init()`);
            }
            const clusterUUidInToken = decoded.license.cluster_uuid;
            if (this.clusterUuid === clusterUUidInToken || clusterUUidInToken === '*') {
                logger.trace('✅ Checked ES cluster_uuid in license activation key matches');
                return { isValid: true, token: decoded };
            }
            logger.error(`Activation Key REJECTED: This ES cluster UUID (${this.clusterUuid}) differs from the ClusterUUID in the activation key (${clusterUUidInToken})`);
        }
        catch (e) {
            logger.trace(`❌ ${errors_1.default.activationKey.cantBeVerified} ${token}`);
            logger.error('❌ Invalid Activation key', e);
            const jsonWebTokenError = this.getJsonWebTokenErrorsMapping(e.message);
            if (jsonWebTokenError) {
                return jsonWebTokenError;
            }
        }
        return { isValid: false, reason: 'CANNOT_BE_VERIFIED', message: errors_1.default.activationKey.cantBeVerified };
    }
    getJsonWebTokenErrorsMapping(message) {
        if (message === 'jwt expired') {
            return { isValid: false, reason: 'LICENSE_KEY_EXPIRED', message: errors_1.default.activationKey.licenseKeyExpired };
        }
        if (message === 'invalid token') {
            return {
                isValid: false,
                reason: 'INVALID_JWT',
                message: errors_1.default.activationKey.invalidJwt
            };
        }
        if (message === 'jwt malformed') {
            return {
                isValid: false,
                reason: 'LICENSE_KEY_MALFORMED',
                message: errors_1.default.activationKey.licenseKeyMalformed
            };
        }
        if (message === 'invalid signature') {
            return {
                isValid: false,
                reason: 'INVALID_JWT_SIGNATURE',
                message: errors_1.default.activationKey.invalidJtwSignature
            };
        }
    }
}
exports.LicenseService = LicenseService;
