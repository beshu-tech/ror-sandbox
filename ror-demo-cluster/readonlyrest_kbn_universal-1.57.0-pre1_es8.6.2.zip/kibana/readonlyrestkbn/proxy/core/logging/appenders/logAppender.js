"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogAppender = void 0;
const logLevel_1 = require("../logLevel");
class LogAppender {
    logPattern(logLevel, fileName, message, impersonating) {
        const time = (0, logLevel_1.getLogFormattedTime)();
        const level = (0, logLevel_1.getLogLevelDescription)(logLevel);
        if (impersonating) {
            return `[${time}] [${level}][plugins][ReadonlyREST][${fileName}][impersonating ${impersonating}] ${message}`;
        }
        return `[${time}] [${level}][plugins][ReadonlyREST][${fileName}] ${message}`;
    }
}
exports.LogAppender = LogAppender;
