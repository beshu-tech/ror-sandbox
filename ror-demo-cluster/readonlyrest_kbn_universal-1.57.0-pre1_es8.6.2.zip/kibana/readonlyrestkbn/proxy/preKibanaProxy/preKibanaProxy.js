"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PreKibanaProxy = void 0;
const express_1 = __importDefault(require("express"));
const tcp_port_used_1 = __importDefault(require("tcp-port-used"));
const cors_1 = __importDefault(require("cors"));
const morgan_1 = __importDefault(require("morgan"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const authenticationFacade_1 = require("./authenticationFacade");
const pkpApiRouter_1 = require("./api/router/pkpApiRouter");
const jwtSigner_1 = require("./auth/jwtSigner");
const samlRouterConfigFactory_1 = require("./auth/saml/samlRouterConfigFactory");
const samlRouterFactory_1 = require("./auth/saml/samlRouterFactory");
const legacyRenderer_1 = require("./auth/legacyRenderer");
const distributionInfoProvider_1 = require("../../kibana/patchers/distributionInfoProvider");
const oidcRouterConfigFactory_1 = require("./auth/oidc/oidcRouterConfigFactory");
const oidcRouterFactory_1 = require("./auth/oidc/oidcRouterFactory");
const authController_1 = require("./auth/authController");
const tenancyController_1 = require("./auth/tenancyController");
const proxyBuilder_1 = require("./proxyBuilder");
const serverCreator_1 = require("./serverCreator");
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
const rorLogger_1 = require("../core/logging/rorLogger");
const htmlInjector_1 = require("./injection/htmlInjector");
const rorRequestAppender_1 = require("../core/rorRequestAppender");
const logoutLinkProvider_1 = require("./auth/logoutLinkProvider");
const auditLogEmitter_1 = require("./auditLogEmitter");
const whitelistedPathsController_1 = require("./auth/whitelistedPathsController");
const directAccessProxyBuilder_1 = require("./directAccessProxyBuilder");
const requestChecker_1 = require("./requestChecker");
const customMiddleware_1 = require("./customMiddleware");
const csrf_1 = require("./auth/csrf");
const rorApiRouter_1 = require("./api/router/rorApiRouter");
const ActivationKey_1 = require("../core/license/ActivationKey");
class PreKibanaProxy {
    app;
    server;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    serverCreator;
    params;
    samlRouterConfigs;
    oidcRouterConfigs;
    legacyRenderer;
    authController;
    tenantController;
    pkpApiRouter;
    rorApiRouter;
    rorRequestAppender;
    proxy;
    auditLogEmitter;
    whitelistedPathsController;
    isReservedPath;
    cookieManager;
    authorizationHeadersValidation;
    requestChecker;
    customMiddleware;
    constructor(sessionManager, cookieManager, rorRequestAppender, esClient, authorizationHeadersCollector, authorizationHeadersValidation, params) {
        this.app = (0, express_1.default)();
        this.params = params;
        this.serverCreator = new serverCreator_1.ServerCreator(this.params.kibanaSSLConfig);
        this.cookieManager = cookieManager;
        const authenticationFacade = new authenticationFacade_1.AuthenticationFacade(sessionManager, cookieManager, this.params.kibanaIndex, esClient, authorizationHeadersCollector, this.params.resetKibanaIndexToTemplate, this.params.requestHeadersWhitelist, this.params.licenseService, this.params.multiTenancyEnabled, this.params.kibanaTemplateIndex);
        this.auditLogEmitter = new auditLogEmitter_1.AuditLogEmitter(esClient);
        this.samlRouterConfigs = new samlRouterConfigFactory_1.SamlRouterConfigFactory(this.params.kibanaBasePath, this.params.cookieConfig).constructFrom(this.params.auth);
        this.oidcRouterConfigs = new oidcRouterConfigFactory_1.OidcRouterConfigFactory(this.params.kibanaBasePath, this.params.cookieConfig).constructFrom(this.params.auth);
        this.legacyRenderer = new legacyRenderer_1.LegacyRenderer(this.params.kibanaBasePath, this.params.sessionConfig.probeIntervalMillis, this.params.cookieConfig.name, PreKibanaProxy.buildSSOButtonProps(this.samlRouterConfigs, this.oidcRouterConfigs), this.params.licenseService, this.params.clearSessionOnEvents, this.params.loginPageCustomizations, this.params.customUXCodeInjection?.js, this.params.customUXCodeInjection?.jsFileContent);
        const logoutLinkProvider = new logoutLinkProvider_1.LogoutLinkProvider(this.params.kibanaBasePath, this.samlRouterConfigs, this.oidcRouterConfigs, this.params.customLogoutLink, this.params.proxyAuth);
        this.authController = new authController_1.AuthController(this.params.kibanaBasePath, this.params.proxyAuth, authenticationFacade, logoutLinkProvider, this.auditLogEmitter, this.params.cookieConfig, this.params.sessionConfig.probeIntervalMillis, this.withBasePath, this.getKibanaIndex, this.params.customLoginLink);
        this.tenantController = new tenancyController_1.TenancyController(authenticationFacade, this.params.cookieConfig);
        this.proxy = this.buildProxy();
        const directAccessProxy = new directAccessProxyBuilder_1.DirectAccessProxyBuilder(this.params.kibanaUrl, this.params.pkpKibanaToken, this.params.requestHeadersWhitelist).build();
        this.whitelistedPathsController = new whitelistedPathsController_1.WhitelistedPathsController(this.params.whitelistedPaths, directAccessProxy);
        this.pkpApiRouter = (0, pkpApiRouter_1.buildPkpApiRouter)(esClient, authenticationFacade, params.licenseService, this.authController);
        this.rorApiRouter = (0, rorApiRouter_1.buildRorApiRouter)(esClient, params.licenseService, this.authController, authenticationFacade);
        this.rorRequestAppender = rorRequestAppender;
        this.isReservedPath = new RegExp(`^${this.withBasePath('(/pkp.*|/log(in|out)|/switch-group|/api/ror)')}`);
        this.authorizationHeadersValidation = authorizationHeadersValidation;
        this.requestChecker = new requestChecker_1.RequestChecker(this.params.kibanaBasePath);
        this.customMiddleware = new customMiddleware_1.CustomMiddleware();
        csrf_1.Csrf.init(Boolean(params.kibanaSSLConfig));
        this.verifyLicenseChange(sessionManager);
        this.init();
    }
    static buildSSOButtonProps(samlRouterConfigs, oidcRouterConfigs) {
        return samlRouterConfigs
            .map(config => config.toLegacySsoButtonProps())
            .concat(oidcRouterConfigs.map(config => config.toLegacySsoButtonProps()));
    }
    close() {
        this.server?.close();
    }
    buildProxy() {
        let customUserCss;
        let customUserCssFileContent;
        // eslint-disable-next-line prefer-const
        customUserCss = this.params.customUXCodeInjection?.css;
        // eslint-disable-next-line prefer-const
        customUserCssFileContent = this.params.customUXCodeInjection?.cssFileContent;
        const htmlInjector = new htmlInjector_1.HtmlInjector(this.params.kibanaBasePath, customUserCss, customUserCssFileContent);
        return new proxyBuilder_1.ProxyBuilder(this.params.kibanaUrl, this.params.pkpKibanaToken, this.params.requestHeadersWhitelist, htmlInjector, this.params.kibanaBasePath, this.params.rewriteBasePath, this.authController, this.params.spacesEnabled, this.params.licenseService, this.cookieManager, this.params.multiTenancyEnabled, this.params.kibanaIndex).build();
    }
    init() {
        this.app.disable('x-powered-by');
        this.app.set('json spaces', 2);
        this.initDevInterceptors();
        this.app.use((req, res, next) => {
            if (!this.isReservedPath.test(req.path)) {
                // Proxy routes behave weird if you let the JSON body parser consume the request body
                return next();
            }
            if (req.header('content-type') === 'application/yaml') {
                return express_1.default.text({ type: ['application/yaml'] })(req, res, next);
            }
            return express_1.default.json({ limit: '500gb' })(req, res, next);
        });
        this.app.use((req, res, next) => {
            res.on('finish', async () => {
                if (res.statusCode === 401 || res.statusCode === 403) {
                    await this.authorizationHeadersValidation.revalidate(req);
                }
            });
            next();
        });
        this.app.use(this.whitelistedPathsController.handleWhitelistedPaths);
        this.app.use((0, cookie_parser_1.default)());
        this.app.use(rorRequestAppender_1.RorRequestAppender.appendRorRequest);
        // API calls can be allowed on the fly, if they carry good credentials
        this.app.use(this.authController.handleApiReqWithCredentialsOnboard);
        this.app.use(this.rorRequestAppender.appendIdentitySession);
        this.app.use(this.appendImpersonateInfoToLogs);
        this.app.use(this.requestChecker.ifApiOnlyAccessType);
        this.app.use(this.requestChecker.ifPathAllowed);
        this.app.use(async (req, res, next) => this.customMiddleware.inject(req, res, next, this.params.licenseService, this.params.customMiddlewareInjectFile, this.params.customMiddlewareInject));
        if (this.params.proxyAuth.enabled) {
            this.app.use(this.authController.handleProxyAuth);
        }
        this.initSSORouters();
        this.app.use(this.withBasePath('/pkp/legacy/web'), express_1.default.static(`${__dirname}/../../public`)); // TODO those files should probably be served wih web-app
        this.app.get(this.withBasePath('/pkp/autodeps'), this.legacyRenderer.serveDependenciesAutomaticallyFromNodeModules);
        this.app.get(this.withBasePath('/login'), this.authController.redirectAuthenticated);
        this.app.get(this.withBasePath('/login'), this.authController.handleCustomLoginRedirection);
        this.app.get(this.withBasePath('/login'), this.legacyRenderer.renderLoginPage);
        this.app.get(this.withBasePath('/pkp/legacy/web/assets/js/login_tpl_defer.js'), this.legacyRenderer.renderLoginDeferredScript);
        this.app.post(this.withBasePath('/login'), 
        // We need to call it this way to be able to mock csrfErrorHandler in our tests
        (req, res, next) => csrf_1.Csrf.doubleCsrfProtection(req, res, next), csrf_1.Csrf.csrfErrorHandler, this.authController.handleLoginPost);
        this.app.get(this.withBasePath('/logout'), this.authController.handleLogout);
        this.app.get(this.withBasePath('/pkp/session-probe'), this.authController.handleSessionProbe);
        this.app.use(this.authController.redirectUnauthenticated.bind(this.authController));
        this.app.use(this.authController.refreshSession.bind(this.authController));
        this.app.get(this.withBasePath('/switch-group'), this.handleSwitchGroup.bind(this));
        this.app.get(this.withBasePath('/pkp/legacy/web/assets/js/switch_group_tpl_defer.js'), this.legacyRenderer.renderSwitchGroupDeferredScript);
        this.app.use(this.withBasePath('/api/ror'), this.rorApiRouter);
        this.app.use(this.withBasePath('/pkp/api'), this.pkpApiRouter);
        this.app.use(this.withBasePath('/pkp/web/static'), express_1.default.static(`${__dirname}/../../web-app/build/web/static`));
        this.app.use(this.withBasePath('/pkp/web/vs'), express_1.default.static(`${__dirname}/../../web-app/build/web/vs`));
        this.app.use(this.withBasePath('/pkp/web/assets'), express_1.default.static(`${__dirname}/../../web-app/build/web/assets`));
        this.app.use(this.withBasePath('/pkp/web'), (req, res) => res.sendFile('index.html', { root: `${__dirname}/../../web-app/build` }));
        this.app.get(this.withBasePath('/pkp/injections/custom.js'), this.legacyRenderer.renderCustomUserJsInjection);
        this.app.get(this.withBasePath('/pkp/injections/hidden-apps.js'), this.legacyRenderer.renderHiddenAppsInjection);
        this.app.get(this.withBasePath('/pkp/injections/ror-css-classes.js'), this.legacyRenderer.renderRorCssClassesInjection);
        this.app.get(this.withBasePath('/pkp/injections/session-probe.js'), this.legacyRenderer.renderSessionProbeInjection);
        this.app.get(this.withBasePath('/pkp/injections/activation-expiration-alert.js'), this.legacyRenderer.renderActivationKeyExpirationAlert);
        this.app.use(this.proxy);
        this.launch();
    }
    async handleSwitchGroup(req, res, next) {
        try {
            await this.tenantController.handleEncryptCookieOnSwitchGroup(req, res, next);
            this.legacyRenderer.renderSwitchGroup(req, res);
        }
        catch (e) {
            this.logger.error(e.message);
            await this.authController.handleLogout(req, res);
        }
    }
    initDevInterceptors() {
        if (distributionInfoProvider_1.DistributionInfoProvider.isEnvironmentDev()) {
            // @ts-ignore
            this.app.use('/*', (0, cors_1.default)({ origin: true, credentials: true }));
            this.app.use((0, morgan_1.default)('PKP :method :url :status :response-time ms - :res[content-length]')); // http logging interceptor
        }
    }
    initSSORouters() {
        if (this.samlRouterConfigs.length === 0 && this.oidcRouterConfigs.length === 0) {
            return;
        }
        const jwtSigner = new jwtSigner_1.JwtSigner(this.params?.auth?.signatureKey ?? '', this.params.sessionConfig.timeoutMinutes);
        const samlRouterFactory = new samlRouterFactory_1.SamlRouterFactory(jwtSigner, this.legacyRenderer);
        const oidcRouterFactory = new oidcRouterFactory_1.OidcRouterFactory(jwtSigner, this.legacyRenderer);
        this.samlRouterConfigs.forEach(config => {
            this.logger.info(`Adding SAML SSO at "${config.routerPath}" path`);
            this.app.use(config.routerPath, samlRouterFactory.build(config));
        });
        this.oidcRouterConfigs.forEach(config => {
            this.logger.info(`Adding OIDC SSO at "${config.routerPath}" path`);
            this.app.use(config.routerPath, oidcRouterFactory.build(config));
        });
    }
    launch() {
        // for some reason kibana invokes this 3 times, so this is in order to avoid ERRADDRRINUSE
        // edit: in fact, there are probably 3 threads, let's see if we can do something about it
        const { host, port } = this.params.pkpHostAndPort;
        tcp_port_used_1.default.check(port, host).then(async (inUse) => {
            if (!inUse) {
                rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename).trace(`Pre-kibana-proxy will listen on http://${host}:${port}`);
                this.server = this.serverCreator.createServer(this.app, this.params.pkpHostAndPort);
            }
        });
    }
    withBasePath = path => {
        if (this.params.rewriteBasePath) {
            return this.params.kibanaBasePath + path;
        }
        return path;
    };
    appendImpersonateInfoToLogs = (req, res, next) => {
        const identitySession = req?.rorRequest?.getIdentitySession();
        const userImpersonated = identitySession?.metadata?.impersonatedBy;
        if (userImpersonated) {
            rorLogger_1.RorLogger.appendImpersonatingInfo(identitySession.metadata.username);
        }
        else {
            rorLogger_1.RorLogger.clearImpersonatingInfo();
        }
        next();
    };
    getKibanaIndex = (kibanaIndexFromSession) => {
        if (kibanaIndexFromSession &&
            this.params.multiTenancyEnabled &&
            (0, ActivationKey_1.isEnterpriseLicense)(this.params.licenseService.getActivationKey().license)) {
            return kibanaIndexFromSession;
        }
        return this.params.kibanaIndex;
    };
    verifyLicenseChange(sessionManager) {
        this.params.licenseService.intervalRefreshActivationKey(async (isLicenseEditionChanged) => {
            if (isLicenseEditionChanged) {
                await sessionManager.deleteAllSessions();
            }
        });
    }
}
exports.PreKibanaProxy = PreKibanaProxy;
