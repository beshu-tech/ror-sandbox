/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

const username = '${username}';
const currentGroupId = '${currentGroupId}';
const kibanaAccess = '${kibanaAccess}';
const hiddenAppsInRorCssClassesInjection = JSON.parse('[${hiddenApps}]');

function isKibanaManagementHidden() {
  return (
    Array.isArray(hiddenAppsInRorCssClassesInjection) &&
    hiddenAppsInRorCssClassesInjection.some(hiddenApp => 'Management|Stack Management'.startsWith(hiddenApp))
  );
}

function addRorBodyClasses() {
  const rorBodyClasses = [`ror-user_${username}`];

  if (currentGroupId !== '') {
    rorBodyClasses.push(`ror-group_${currentGroupId}`);
  }

  if (kibanaAccess.toLowerCase().match('^ro')) {
    rorBodyClasses.push('ror-ro');
  }

  if (isKibanaManagementHidden()) {
    rorBodyClasses.push('ror_stack_management');
  }

  rorBodyClasses.forEach(cssClass => $('body').addClass(cssClass));
}

function waitWithRorBodyClassesUntilKibanaHomeLoaded() {
  const kibanaSpinner = $('.kbnLoaderWrap');
  if (kibanaSpinner && kibanaSpinner.length) {
    setTimeout(waitWithRorBodyClassesUntilKibanaHomeLoaded, 300);
  } else {
    addRorBodyClasses();
  }
}
waitWithRorBodyClassesUntilKibanaHomeLoaded();
