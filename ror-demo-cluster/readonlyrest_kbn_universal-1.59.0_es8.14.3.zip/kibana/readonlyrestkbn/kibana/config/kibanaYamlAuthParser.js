"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseAuthConfiguration = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const rorLoggerFactory_1 = require("../../proxy/core/logging/rorLoggerFactory");
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
const AUTH_SIGNATURE_KEY = 'signature_key';
var SSO_TYPE;
(function (SSO_TYPE) {
    SSO_TYPE[SSO_TYPE["SAML"] = 0] = "SAML";
    SSO_TYPE[SSO_TYPE["OIDC"] = 1] = "OIDC";
})(SSO_TYPE || (SSO_TYPE = {}));
function hasUndefinedValues(pathToObject, objectToValidate) {
    let containsUndefinedKeyValues = false;
    Object.entries(objectToValidate).forEach(([key, value]) => {
        if (value == null) {
            logger.warn(`Missing value for ${pathToObject}.${key}: ${value}`);
            containsUndefinedKeyValues = true;
        }
    });
    return containsUndefinedKeyValues;
}
function readFileFromAbsolutePath(configKey, filePath) {
    if (!filePath) {
        const message = `${configKey} parameter is not configured`;
        logger.error(message);
        throw new Error(message);
    }
    if (!filePath.startsWith('/')) {
        const message = `${configKey} should be configured as an absolute path`;
        logger.error(message);
        throw new Error(message);
    }
    if (!fs_1.default.existsSync(filePath)) {
        const message = `File not found ${filePath} for configuration parameter ${configKey}`;
        logger.error(message);
        throw new Error(message);
    }
    let content;
    try {
        content = fs_1.default.readFileSync(filePath).toString();
    }
    catch (e) {
        logger.error(`Error reading from file: ${filePath}`, e);
        throw e;
    }
    return content;
}
function stringBasedCertType(cert) {
    if (cert && !path_1.default.isAbsolute(cert)) {
        logger.info('Cert parameter is reading as a string value');
        return true;
    }
    return false;
}
function buildSAMLConfig(configName, rawConfig) {
    const samlConfig = {
        name: configName,
        enabled: rawConfig.enabled == null ? true : !!rawConfig.enabled,
        buttonName: rawConfig.buttonName == null ? '' : rawConfig.buttonName,
        issuer: rawConfig.issuer == null ? 'ror' : rawConfig.issuer,
        entryPoint: rawConfig.entryPoint,
        logoutUrl: rawConfig.logoutUrl,
        kibanaExternalHost: rawConfig.kibanaExternalHost,
        protocol: rawConfig.protocol == null ? 'http' : rawConfig.protocol,
        usernameParameter: rawConfig.usernameParameter == null ? 'nameID' : rawConfig.usernameParameter,
        groupsParameter: rawConfig.groupsParameter == null ? 'memberOf' : rawConfig.groupsParameter,
        // To keep backward compatibility, cert can be a string or file
        cert: stringBasedCertType(rawConfig.cert) ? rawConfig.cert : readFileFromAbsolutePath('cert', rawConfig.cert)
    };
    // All above config was mandatory, the whole config is invalid if any value is undefined.
    if (hasUndefinedValues(`readonlyrest_kbn.auth.${configName}`, samlConfig)) {
        logger.warn(`Missing SAML configuration for ${configName}`, rawConfig);
        return null;
    }
    // Some configuration parameters are optional, but are required to be not-null (if present) by passport-saml
    ['decryptionPvk', 'privateCert']
        .filter(optionalParameter => rawConfig[optionalParameter])
        .forEach(optionalParameter => {
        samlConfig[optionalParameter] = readFileFromAbsolutePath(optionalParameter, rawConfig[optionalParameter]);
    });
    // Add to extraConfig field any extra configuration that didn't fit in the typed interface `SamlConfig`
    samlConfig.extraConfig = Object.keys(rawConfig)
        .filter(key => !Object.prototype.hasOwnProperty.call(samlConfig, key))
        .reduce((accumulator, key) => {
        accumulator[key] = rawConfig[key];
        return accumulator;
    }, {});
    return samlConfig;
}
function buildOIDCConfig(configName, rawConfig) {
    const oidcConfig = {
        name: configName,
        enabled: rawConfig.enabled == null ? true : !!rawConfig.enabled,
        buttonName: rawConfig.buttonName == null ? '' : rawConfig.buttonName,
        issuer: rawConfig.issuer == null ? 'ror' : rawConfig.issuer,
        kibanaExternalHost: rawConfig.kibanaExternalHost,
        protocol: rawConfig.protocol == null ? 'http' : rawConfig.protocol,
        tokenURL: rawConfig.tokenURL,
        authorizationURL: rawConfig.authorizationURL,
        userInfoURL: rawConfig.userInfoURL,
        logoutUrl: rawConfig.logoutUrl,
        clientId: rawConfig.clientID,
        clientSecret: rawConfig.clientSecret,
        scope: rawConfig.scope,
        usernameParameter: rawConfig.usernameParameter == null ? 'nameID' : rawConfig.usernameParameter,
        groupsParameter: rawConfig.groupsParameter == null ? 'memberOf' : rawConfig.groupsParameter,
        jwksURL: rawConfig.jwksURL
    };
    const containsUndefined = hasUndefinedValues(`readonlyrest_kbn.auth.${configName}`, oidcConfig);
    // Optional params
    oidcConfig.proxyURL = rawConfig.proxyURL;
    return containsUndefined ? null : oidcConfig;
}
function parseAuthConfiguration(rorConfig) {
    let parsedAuthConfigParameters = null;
    if (!rorConfig || !rorConfig.auth) {
        return null;
    }
    const signatureKey = rorConfig.auth[AUTH_SIGNATURE_KEY];
    const samlRawConfigs = [];
    const oidcRawConfigs = [];
    Object.entries(rorConfig.auth)
        .filter(([key]) => key !== AUTH_SIGNATURE_KEY)
        .forEach(([configName, rawConfig]) => {
        if (!rawConfig || typeof rawConfig === 'string' || !rawConfig.type) {
            logger.warn(`Missing config type for readonlyrest_kbn.auth.${configName}`);
            return;
        }
        const ssoType = SSO_TYPE[rawConfig.type.toString().toUpperCase()];
        logger.info(`parsing auth config: ${configName} of SSO_TYPE: ${ssoType}`);
        if (ssoType === undefined) {
            logger.warn(`Unknown config type "${rawConfig.type.toString()}" for readonlyrest_kbn.auth.${configName}`);
            return;
        }
        if (ssoType === SSO_TYPE.SAML) {
            const samlRawConfig = buildSAMLConfig(configName, rawConfig);
            if (samlRawConfig) {
                samlRawConfigs.push(samlRawConfig);
                return;
            }
        }
        const oidcRawConfig = buildOIDCConfig(configName, rawConfig);
        if (oidcRawConfig) {
            oidcRawConfigs.push(oidcRawConfig);
        }
    });
    // eslint-disable-next-line prefer-const
    parsedAuthConfigParameters = {
        signatureKey,
        samlConfigurations: samlRawConfigs,
        oidcConfigurations: oidcRawConfigs
    };
    return parsedAuthConfigParameters;
}
exports.parseAuthConfiguration = parseAuthConfiguration;
