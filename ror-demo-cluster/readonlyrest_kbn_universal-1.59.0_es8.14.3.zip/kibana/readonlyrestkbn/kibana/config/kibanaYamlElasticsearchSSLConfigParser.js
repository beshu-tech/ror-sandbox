"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseSSLConfig = void 0;
const rorLoggerFactory_1 = require("../../proxy/core/logging/rorLoggerFactory");
const configUtils_1 = require("./configUtils");
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
const isSSLEnabled = (esHosts) => {
    const referentialProtocol = esHosts[0].split('://')[0];
    esHosts.forEach(host => {
        if (host.split('://')[0] !== referentialProtocol) {
            logger.error('The Elasticsearch hosts provided use different protocols. Please use either http or https for all hosts.');
            (0, configUtils_1.exitInOneSecond)();
        }
    });
    return referentialProtocol === 'https';
};
const singleToAnArray = (value) => (Array.isArray(value) ? value : [value]);
function parseSSLConfig(elasticsearchObject, derivedElasticHosts) {
    const elasticsearchSSLEnabled = isSSLEnabled(derivedElasticHosts);
    const elasticsearchSSL = elasticsearchObject?.ssl;
    const elasticsearchSSLCertificateAuthorities = elasticsearchSSL?.certificateAuthorities && singleToAnArray(elasticsearchSSL.certificateAuthorities);
    const elasticsearchTruststorePath = elasticsearchSSL?.truststore?.path;
    const elasticsearchTruststorePassword = elasticsearchSSL?.truststore?.password;
    const elasticsearchVerificationMode = elasticsearchSSL?.verificationMode;
    return {
        sslEnabled: elasticsearchSSLEnabled,
        certificateAuthorities: elasticsearchSSLCertificateAuthorities,
        truststorePath: elasticsearchTruststorePath,
        truststorePassword: elasticsearchTruststorePassword,
        verificationMode: elasticsearchVerificationMode
    };
}
exports.parseSSLConfig = parseSSLConfig;
