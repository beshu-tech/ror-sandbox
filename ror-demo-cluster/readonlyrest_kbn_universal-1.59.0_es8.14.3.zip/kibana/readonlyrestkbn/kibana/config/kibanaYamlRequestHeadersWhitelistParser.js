"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRequestHeadersWhitelist = exports.normalizeWithDefaultsRequestHeadersWhiteList = void 0;
const defaultValues_1 = require("../../server/defaultValues");
function normalizeWithDefaultsRequestHeadersWhiteList(headers) {
    const defaults = defaultValues_1.DEFAULT_KIBANA_YAML_ROR_VALUES.requestHeadersWhitelist;
    const normalized = Array.isArray(headers) ? headers.concat(defaults) : defaults;
    return Array.from(new Set(normalized)).map(h => h.toLowerCase());
}
exports.normalizeWithDefaultsRequestHeadersWhiteList = normalizeWithDefaultsRequestHeadersWhiteList;
function getRequestHeadersWhitelist(rorConfig) {
    return normalizeWithDefaultsRequestHeadersWhiteList(rorConfig?.requestHeadersWhitelist);
}
exports.getRequestHeadersWhitelist = getRequestHeadersWhitelist;
