"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthorizationHeadersCollector = void 0;
const jwt = __importStar(require("jsonwebtoken"));
const jwtLegacy = __importStar(require("jsonwebtoken-legacy"));
const rorRequest_1 = require("../rorRequest/rorRequest");
const types_1 = require("../common/types");
const rorLoggerFactory_1 = require("../logging/rorLoggerFactory");
const distributionInfoProvider_1 = require("../../../kibana/patchers/distributionInfoProvider");
class AuthorizationHeadersCollector {
    authProxy;
    jwtQueryParam;
    authSignatureKey;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    jwt = distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('7.11.0') ? jwtLegacy : jwt;
    constructor(authProxy, jwtQueryParam, authSignatureKey) {
        this.authProxy = authProxy;
        this.jwtQueryParam = jwtQueryParam;
        this.authSignatureKey = authSignatureKey;
    }
    fromForwardedUserHeader(request, credentialHeaders) {
        if (!this.authProxy.enabled) {
            return credentialHeaders;
        }
        const forwardAuthHeader = this.authProxy.forward_auth_header;
        const value = request.getHeaders()[forwardAuthHeader];
        if (value) {
            this.logger.debug(`Found proxy auth header ${forwardAuthHeader}: ${value}`);
            credentialHeaders.set(forwardAuthHeader, value);
        }
        return credentialHeaders;
    }
    static fromBasicAuth(request, credentialHeaders) {
        const basicHeaderValue = request.getHeaders()[types_1.AUTHORIZATION_HEADER];
        if (basicHeaderValue?.includes('Basic')) {
            credentialHeaders.set(types_1.AUTHORIZATION_HEADER, basicHeaderValue);
        }
        return credentialHeaders;
    }
    fromJWT(request, credentialHeaders) {
        const token = request.getQueries()[this.jwtQueryParam.value];
        if (token) {
            credentialHeaders.set(types_1.AUTHORIZATION_HEADER, `Bearer ${token}`);
            return credentialHeaders;
        }
        const authorization = request.getHeaders()[types_1.AUTHORIZATION_HEADER];
        if (authorization && authorization.indexOf('Bearer') >= 0) {
            credentialHeaders.set(types_1.AUTHORIZATION_HEADER, authorization);
            return credentialHeaders;
        }
        const body = request.getBody();
        if (body && request.getPath().includes('/login') && request.getMethod() === types_1.Method.POST) {
            const postField = body[types_1.CONNECTOR_SVC_TRANSIENT_JWT];
            if (postField) {
                credentialHeaders.set(types_1.AUTHORIZATION_HEADER, `Bearer ${postField}`);
                // @ts-ignore
                const origin = this.jwt.verify(postField, this.authSignatureKey)[types_1.X_ROR_ORIGIN];
                if (origin) {
                    credentialHeaders.set(types_1.X_ROR_ORIGIN, origin);
                }
            }
        }
        return credentialHeaders;
    }
    static fromConnectorService(request, credentialHeaders) {
        const body = request.getBody();
        if (body && request.getMethod() === types_1.Method.POST) {
            const transientToken = body[types_1.CONNECTOR_SVC_TRANSIENT_JWT];
            if (transientToken) {
                credentialHeaders.set(types_1.AUTHORIZATION_HEADER, `Bearer ${transientToken}`);
            }
        }
        return credentialHeaders;
    }
    static fromFormJSON(request, credentialHeaders) {
        const body = request.getBody();
        if (body && (0, rorRequest_1.isLoginFormBody)(body)) {
            const encodedCredentials = Buffer.from(`${body.username}:${body.password}`).toString('base64');
            credentialHeaders.set(types_1.AUTHORIZATION_HEADER, `Basic ${encodedCredentials}`);
        }
        return credentialHeaders;
    }
    collectCredentialHeaders(request) {
        // Merging all credentials headers together
        // if more than one has the same header name, the latter overwrites former
        let credentialHeaders = new Map();
        // LOW PRIORITY UP ☝
        credentialHeaders = this.fromForwardedUserHeader(request, credentialHeaders);
        credentialHeaders = AuthorizationHeadersCollector.fromBasicAuth(request, credentialHeaders);
        credentialHeaders = this.fromJWT(request, credentialHeaders);
        credentialHeaders = AuthorizationHeadersCollector.fromConnectorService(request, credentialHeaders);
        credentialHeaders = AuthorizationHeadersCollector.fromFormJSON(request, credentialHeaders); // LOGIN FORM takes priority on everything, so it's still usable if you use proxy_auth
        // HIGH PRIORITY DOWN 👇
        // no need to inline the cookie header ever
        // TODO: We need to check it, since it's the map, we shouldn't delete cookie like this
        // @ts-ignore
        delete credentialHeaders.cookie;
        return credentialHeaders;
    }
}
exports.AuthorizationHeadersCollector = AuthorizationHeadersCollector;
