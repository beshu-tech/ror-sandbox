"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestHeadersWhitelistApplier = void 0;
class RequestHeadersWhitelistApplier {
    static applyToMap(logger, requestHeadersWhitelist, from, to) {
        const toAsDict = {};
        this.apply(logger, requestHeadersWhitelist, from, toAsDict);
        Object.keys(toAsDict).forEach(key => {
            const outgoingHttpHeaders = toAsDict[key];
            if (outgoingHttpHeaders) {
                to.set(key, outgoingHttpHeaders.toString());
            }
        });
    }
    static apply(logger, requestHeadersWhitelist, from, to) {
        for (const h of requestHeadersWhitelist) {
            if (from[h]) {
                to[h] = from[h];
            }
        }
    }
}
exports.RequestHeadersWhitelistApplier = RequestHeadersWhitelistApplier;
