"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RorLoggerFactory = void 0;
const path_1 = __importDefault(require("path"));
const rorLogger_1 = require("./rorLogger");
const logLevel_1 = require("./logLevel");
// eslint-disable-next-line import/no-cycle
const consoleAppender_1 = require("./appenders/consoleAppender");
// eslint-disable-next-line import/no-cycle
const fileAppender_1 = require("./appenders/fileAppender");
class RorLoggerFactory {
    static DEFAULT_LOG_LEVEL = logLevel_1.LogLevel.INFO;
    static CURRENT_LOG_LEVEL = RorLoggerFactory.DEFAULT_LOG_LEVEL;
    static loggers = new Map();
    static logger = RorLoggerFactory.getLogger('LoggerFactory');
    static destination;
    static getLoggerForFile(filePath) {
        return RorLoggerFactory.getLogger(path_1.default.parse(filePath).name);
    }
    static setAppender(destination, fileName) {
        switch (destination?.type) {
            case 'file': {
                return new fileAppender_1.FileAppender(fileName, destination.path);
            }
            default: {
                return new consoleAppender_1.ConsoleAppender(fileName);
            }
        }
    }
    static setDestination(rawDestination) {
        switch (rawDestination) {
            case 'stdout':
            case undefined: {
                RorLoggerFactory.logger.debug(`Setting log destination to: console`);
                return {
                    type: 'console'
                };
            }
            default: {
                RorLoggerFactory.logger.debug(`Setting log destination to: ${rawDestination} folder`);
                return {
                    type: 'file',
                    path: rawDestination
                };
            }
        }
    }
    static getLogger(fileName) {
        const rorLogger = this.loggers.get(fileName);
        if (rorLogger != null) {
            return rorLogger;
        }
        return new rorLogger_1.RorLogger(this.setAppender(RorLoggerFactory.destination, fileName));
    }
    static initLogs(logLevel, rawDestination) {
        RorLoggerFactory.CURRENT_LOG_LEVEL = logLevel;
        RorLoggerFactory.destination = RorLoggerFactory.setDestination(rawDestination);
        RorLoggerFactory.logger.debug(`Setting logLevel to: ${logLevel_1.LogLevel[logLevel]}`);
    }
    static isLoggingEnabled(logLevel) {
        return RorLoggerFactory.CURRENT_LOG_LEVEL.valueOf() >= logLevel.valueOf();
    }
}
exports.RorLoggerFactory = RorLoggerFactory;
