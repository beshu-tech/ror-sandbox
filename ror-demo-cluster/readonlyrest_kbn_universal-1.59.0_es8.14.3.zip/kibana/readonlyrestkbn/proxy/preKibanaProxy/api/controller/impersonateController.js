"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImpersonateController = void 0;
class ImpersonateController {
    authenticationFacade;
    constructor(authenticationFacade) {
        this.authenticationFacade = authenticationFacade;
    }
    handleImpersonateUser = async (req, res) => {
        const identityMetadata = req.rorRequest.getIdentitySession()?.metadata;
        if (!this.sufficientAccessLevel(identityMetadata?.kibanaAccess)) {
            return this.notSufficientAccessLevelError(res);
        }
        await this.authenticationFacade.impersonateUser(req.rorRequest, res);
    };
    handleFinishImpersonation = async (req, res) => {
        try {
            await this.authenticationFacade.finishImpersonation(req.rorRequest, res);
            res.status(204).json({ status: 'ok' });
        }
        catch (e) {
            res.status(500).json({ message: e.message });
        }
    };
    notSufficientAccessLevelError(res) {
        res.status(401).json({ message: 'You are not authorized to perform this operation' });
    }
    sufficientAccessLevel(accessLevel) {
        return accessLevel === 'unrestricted' || accessLevel === 'admin';
    }
}
exports.ImpersonateController = ImpersonateController;
