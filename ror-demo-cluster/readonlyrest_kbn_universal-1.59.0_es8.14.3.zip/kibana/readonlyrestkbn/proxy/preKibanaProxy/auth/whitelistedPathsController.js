"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WhitelistedPathsController = void 0;
class WhitelistedPathsController {
    directAccessProxy;
    whitelistedPathsRegex;
    constructor(whitelistedPaths, directAccessProxy) {
        this.directAccessProxy = directAccessProxy;
        this.whitelistedPathsRegex =
            whitelistedPaths.length === 0
                ? null
                : new RegExp(WhitelistedPathsController.getRegexPattern(whitelistedPaths), 'i');
    }
    static getRegexPattern(values) {
        let regexpPattern = `^${values.join('$|^')}$`;
        if (regexpPattern.startsWith('^^')) {
            regexpPattern = regexpPattern.replace('^^', '^');
        }
        if (regexpPattern.endsWith('$$')) {
            regexpPattern = regexpPattern.replace('$$', '$');
        }
        return regexpPattern;
    }
    isWhitelistedPath(path) {
        return this.whitelistedPathsRegex?.test(path);
    }
    handleWhitelistedPaths = (req, res, next) => {
        if (this.isWhitelistedPath(req.path)) {
            return this.directAccessProxy(req, res, next);
        }
        return next();
    };
}
exports.WhitelistedPathsController = WhitelistedPathsController;
