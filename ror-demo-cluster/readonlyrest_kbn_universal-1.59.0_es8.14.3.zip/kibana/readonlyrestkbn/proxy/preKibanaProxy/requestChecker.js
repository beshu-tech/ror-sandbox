"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestChecker = void 0;
const xregexp_1 = __importDefault(require("xregexp"));
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
class RequestChecker {
    kibanaBasePath;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(kibanaBasePath) {
        this.kibanaBasePath = kibanaBasePath;
    }
    ifPathAllowed = (req, res, next) => {
        try {
            const rorRequest = req?.rorRequest;
            const metadata = rorRequest.getIdentitySession()?.metadata;
            if (metadata?.allowedApiPaths &&
                metadata.allowedApiPaths.every(allowedPath => {
                    const isAllowedMethod = allowedPath.http_method === 'ANY' ||
                        allowedPath.http_method.toLowerCase() === rorRequest.getMethod().toLowerCase();
                    const unescapedRegex = allowedPath.path_regex.replace(/\\(.)/g, '$1');
                    const isAllowedRequest = (0, xregexp_1.default)(unescapedRegex).test(req.rorRequest.getPath());
                    return !isAllowedMethod || !isAllowedRequest;
                })) {
                const forbiddenSuffixesRegexp = new RegExp(`^${this.withBasePath('(/api/.*|/pkp/api/.*)')}`);
                if (forbiddenSuffixesRegexp.test(req.path)) {
                    return res.status(403).json({ status_code: 403, status: 'forbidden', message: 'forbidden' });
                }
                return res.redirect(this.withBasePath('/logout'));
            }
            return next();
        }
        catch (e) {
            this.logger.error(`api path allowed check`, e);
            res.status(500);
            return res.json({ status_code: 500, status: 'ko', message: e.message });
        }
    };
    ifApiOnlyAccessType(req, res, next) {
        if (req?.rorRequest?.getIdentitySession()?.metadata.kibanaAccess === 'api_only') {
            if (req?.rorRequest?.getPath().startsWith('/api')) {
                return next();
            }
            return res.status(403).json({ status_code: 403, status: 'forbidden', message: 'forbidden' });
        }
        return next();
    }
    withBasePath = path => this.kibanaBasePath + path;
}
exports.RequestChecker = RequestChecker;
