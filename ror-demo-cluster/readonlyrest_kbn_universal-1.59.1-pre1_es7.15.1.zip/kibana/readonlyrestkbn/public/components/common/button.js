"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Button = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function Button({ children, className, style, color = 'primary', textProps, contentProps, onClick, fullWidth, href, target }) {
    return ((0, jsx_runtime_1.jsx)(eui_1.EuiButton, { href: href, target: target, 
        // @ts-ignore
        contentProps: contentProps, fullWidth: fullWidth, onClick: onClick, 
        // @ts-ignore
        textProps: textProps, className: className, color: color, 
        // @ts-ignore
        style: style, children: children }));
}
exports.Button = Button;
