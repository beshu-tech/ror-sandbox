"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkIfPortsAreFree = exports.portVerification = exports.getRandomPort = exports.HIGHEST_AVAILABLE_PORT = void 0;
const detect_port_1 = __importDefault(require("detect-port"));
exports.HIGHEST_AVAILABLE_PORT = 65536;
function getRandomPort(initialPort, maxPort = exports.HIGHEST_AVAILABLE_PORT) {
    const maximumLimitWithInitialPortCalculated = maxPort - initialPort - 1;
    const randomPort = Math.floor(Math.random() * maximumLimitWithInitialPortCalculated) + initialPort;
    if (randomPort > maxPort) {
        return maxPort;
    }
    return randomPort;
}
exports.getRandomPort = getRandomPort;
function portVerification(input) {
    return new Promise((resolve, reject) => {
        (0, detect_port_1.default)(input, (err, _port) => {
            if (err) {
                reject(err);
            }
            const portInUse = input !== _port;
            if (portInUse) {
                reject(new Error(`Port ${input} is already in use.`));
            }
            else {
                resolve(true);
            }
        });
    });
}
exports.portVerification = portVerification;
function checkIfPortsAreFree(pkpPort, pepPort) {
    return Promise.all([portVerification(pkpPort), portVerification(pepPort)]);
}
exports.checkIfPortsAreFree = checkIfPortsAreFree;
