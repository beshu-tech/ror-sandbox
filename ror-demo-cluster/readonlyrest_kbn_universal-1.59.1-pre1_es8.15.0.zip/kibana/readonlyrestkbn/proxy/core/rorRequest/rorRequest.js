"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RorRequest = exports.isLoginFormBody = void 0;
const types_1 = require("../common/types");
function isLoginFormBody(body) {
    return body?.username !== undefined;
}
exports.isLoginFormBody = isLoginFormBody;
class RorRequest {
    cookies;
    method;
    path;
    params;
    queries;
    url;
    headers;
    originAddress;
    body;
    identitySession;
    customIdentitySessionMetadata = {};
    constructor(
    // TODO: this should be of type Cookies
    cookies, method, path, params, queries, url, headers, originAddress, body) {
        this.cookies = cookies;
        this.method = method;
        this.path = path;
        this.params = params;
        this.queries = queries;
        this.url = url;
        this.headers = headers;
        this.originAddress = originAddress;
        this.body = body;
    }
    getAuthorizationHeaders() {
        return this.identitySession?.metadata?.authorizationHeaders ?? new Map();
    }
    getCookies() {
        return this.cookies;
    }
    getMethod() {
        return this.method;
    }
    getPath() {
        return this.path;
    }
    getUrl() {
        return this.url;
    }
    getBody() {
        return this.body;
    }
    getParams() {
        return this.params;
    }
    getQueries() {
        return this.queries;
    }
    setQuery(key, value) {
        this.queries[key] = value;
    }
    getOriginAddress() {
        return this.originAddress;
    }
    getHeaders() {
        return this.headers;
    }
    isAuthenticated() {
        return this.getIdentitySession() != null;
    }
    isCookiePresent(cookieName) {
        return this.cookies?.includes(cookieName);
    }
    getIdentitySession() {
        if (!this.identitySession) {
            return undefined;
        }
        return {
            ...this.identitySession,
            metadata: { ...this.identitySession.metadata, ...this.customIdentitySessionMetadata }
        };
    }
    setIdentitySession(identitySession) {
        this.identitySession = identitySession;
    }
    enrichIdentitySessionMetadata(customMetadata) {
        if (!this.identitySession?.metadata) {
            return;
        }
        this.customIdentitySessionMetadata = { ...this.customIdentitySessionMetadata, ...customMetadata };
    }
    get lastSessionActivityDate() {
        return this.identitySession?.metadata?.lastSessionActivityDate;
    }
    extractHiddenAppsNames() {
        return this.getIdentitySession()?.metadata.kibanaHiddenApps ?? [];
    }
}
exports.RorRequest = RorRequest;
