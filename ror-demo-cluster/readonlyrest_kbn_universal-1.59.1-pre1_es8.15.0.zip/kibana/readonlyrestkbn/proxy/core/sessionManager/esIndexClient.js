"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EsIndexClient = void 0;
const crypto_js_1 = __importDefault(require("crypto-js"));
const rorLoggerFactory_1 = require("../logging/rorLoggerFactory");
const cacheSize = 1000;
const searchParams = {
    size: cacheSize,
    sort: [{ expiresAt: { order: 'desc', unmapped_type: 'long' } }]
};
class EsIndexClient {
    indexName;
    sessionKey;
    esClient;
    static SEARCH_PATH = '/_search';
    static DOCUMENT_PATH = '/_doc';
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    indexSearchPath;
    indexDocumentPath;
    constructor(indexName, sessionKey, esClient) {
        this.indexName = indexName;
        this.sessionKey = sessionKey;
        this.esClient = esClient;
        this.indexSearchPath = indexName + EsIndexClient.SEARCH_PATH;
        this.indexDocumentPath = indexName + EsIndexClient.DOCUMENT_PATH;
    }
    createSessionIndex = async () => {
        try {
            const body = {
                settings: {
                    number_of_shards: 1,
                    auto_expand_replicas: '0-1'
                }
            };
            await this.esClient.putAsKibana(this.indexName, body);
            this.logger.debug(`The index ${this.indexName} was created.`);
        }
        catch (e) {
            if (e && JSON.stringify(e).includes('resource_already_exists_exception')) {
                this.logger.debug(`The index ${this.indexName} already exists.`);
            }
            else {
                this.logger.error('Unexpected error creating the in-index session manager', e);
            }
        }
    };
    getSessions = async () => {
        const response = await this.esClient.postAsKibana(this.indexSearchPath, JSON.stringify(searchParams));
        const responseBody = await response.json();
        if (response.status >= 300) {
            this.logger.warn(`Failed fetching sessions: ${JSON.stringify(responseBody)}`);
            return new Map();
        }
        const sessionsMap = this.extractSessionsFromResponse(responseBody);
        this.logger.debug(`Fetched all sessions from index, found: ${sessionsMap.size}`);
        return this.cleanFromInvalidSessions(sessionsMap);
    };
    saveInIndex = async (sid, session) => this.esClient.postAsKibana(`${this.indexDocumentPath}/${sid}?refresh=true`, JSON.stringify(this.encryptIdentitySessionMetadata(session)));
    getFromIndex = async (sid) => {
        const response = await this.esClient.getAsKibana(`${this.indexDocumentPath}/${sid}`);
        const responseBody = await response.json();
        if (response.status >= 300) {
            this.logger.warn(`Failed fetching session: ${JSON.stringify(responseBody)}`);
            return undefined;
        }
        const parsed = this.parseSessionFromResponse(responseBody);
        return (parsed && parsed[1]) || undefined;
    };
    deleteFromIndex = async (sid) => {
        this.logger.debug(`Deleting session with SID:${sid} from index`);
        await this.esClient.deleteAsKibana(`${this.indexDocumentPath}/${sid}`);
    };
    deleteFromIndexBatch = async (sids) => {
        await this.esClient.deleteBatchAsKibana(`${this.indexDocumentPath}/_delete_by_query`, sids);
    };
    deleteSessionIndex = async () => {
        await this.esClient.deleteAsKibana(`${this.indexName}`);
    };
    extractSessionsFromResponse = (responseBody) => {
        const mappedEntries = responseBody?.hits?.hits
            .map(this.parseSessionFromResponse)
            .filter(session => session != null);
        return new Map(mappedEntries);
    };
    parseSessionFromResponse = (response) => {
        const sid = response._id;
        const source = response._source;
        try {
            if (!sid) {
                return null;
            }
            const identitySessionMetadata = this.decryptIdentitySessionMetadata(source);
            if (!identitySessionMetadata) {
                this.logger.debug(`Could not decrypt session metadata. Session invalid for SID: ${sid}`);
                return [sid, null];
            }
            if (!identitySessionMetadata.authorizationHeaders) {
                this.logger.debug(`Could not find authorizationHeaders. Session invalid for SID: ${sid}`);
                return [sid, null];
            }
            return [sid, identitySessionMetadata];
        }
        catch (e) {
            if (e instanceof Error) {
                e = e.message;
            }
            this.logger.debug('Error while parsing sessions from response for SID:', e);
            return [sid, null];
        }
    };
    decryptIdentitySessionMetadata = (dto) => {
        if (!dto.encryptedAuthorizationHeaders) {
            this.logger.warn('encryptedAuthorizationHeaders not available, but there is a session', JSON.stringify(dto));
        }
        const authorizationHeaders = crypto_js_1.default.AES.decrypt(dto.encryptedAuthorizationHeaders, this.sessionKey).toString(crypto_js_1.default.enc.Utf8);
        return {
            expiresAt: new Date(dto.expiresAt),
            lastSessionActivityDate: dto.lastSessionActivityDate ? new Date(dto.lastSessionActivityDate) : undefined,
            authorizationHeaders: new Map(JSON.parse(authorizationHeaders)),
            username: dto.username,
            currentGroup: dto.currentGroup,
            availableGroups: dto.availableGroups ? dto.availableGroups : [],
            kibanaHiddenApps: dto.kibanaHiddenApps,
            kibanaAccess: dto.kibanaAccess,
            kibanaIndex: dto.kibanaIndex,
            kibanaTemplateIndex: dto.kibanaTemplateIndex,
            origin: dto.origin,
            impersonatedBy: dto.impersonatedBy,
            correlationId: dto.correlationId,
            customMetadata: dto.customMetadata
        };
    };
    encryptIdentitySessionMetadata = (session) => {
        const authorizationHeaders = crypto_js_1.default.AES.encrypt(JSON.stringify(Array.from(session.authorizationHeaders.entries())), this.sessionKey).toString();
        return {
            expiresAt: session.expiresAt.getTime(),
            lastSessionActivityDate: session.lastSessionActivityDate ? session.lastSessionActivityDate.getTime() : undefined,
            encryptedAuthorizationHeaders: authorizationHeaders,
            username: session.username,
            currentGroup: session.currentGroup,
            availableGroups: session.availableGroups,
            kibanaHiddenApps: session.kibanaHiddenApps,
            kibanaAccess: session.kibanaAccess,
            kibanaIndex: session.kibanaIndex,
            kibanaTemplateIndex: session.kibanaTemplateIndex,
            origin: session.origin,
            impersonatedBy: session.impersonatedBy,
            correlationId: session.correlationId,
            customMetadata: session.customMetadata
        };
    };
    cleanFromInvalidSessions = async (sessionsMap) => {
        const goodOnes = new Map();
        const sidsOfInvalidSessions = [];
        for (const sid of sessionsMap.keys()) {
            const metadata = sessionsMap.get(sid);
            if (metadata == null) {
                this.logger.warn(`Could not find a valid session in index for SID ${sid} (probably the cookiePass or internal format changed?)`);
                sidsOfInvalidSessions.push(sid);
            }
            else {
                goodOnes.set(sid, metadata);
            }
        }
        await this.deleteFromIndexBatch(sidsOfInvalidSessions);
        return goodOnes;
    };
}
exports.EsIndexClient = EsIndexClient;
