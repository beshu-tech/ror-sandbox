"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.KibanaIndexTweaker = void 0;
class KibanaIndexTweaker {
    static normalizeKibanaIndex = (input, kibanaIndex) => {
        if (!input.includes(kibanaIndex)) {
            return input;
        }
        // Because we need to concatenate this string into a regex, we need to escape any dots or special characters
        const escapedKibanaIndexForRegex = kibanaIndex.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
        // .kibana_admin_7.12.0_001 -> .kibana_admin
        const longFormatMatcher = new RegExp(`${escapedKibanaIndexForRegex}_((\\d){1,2}).((\\d){1,2})\\.(\\d){1,2}_(\\d){3}`, 'gm');
        // .kibana_admin_7.12.0 -> .kibana_admin
        const shortFormatMatcher = new RegExp(`${escapedKibanaIndexForRegex}_((\\d){1,2}).((\\d){1,2})\\.(\\d){1,2}`, 'gm');
        // .kibana_tenant_7.12.0,.kibana_tenant_task_manager_7.12.0 -> .kibana_tenant,.kibana_tenant_task_manager
        const taskManagerIndexMatcher = new RegExp(`${escapedKibanaIndexForRegex}_task_manager_((\\d){1,2}).((\\d){1,2})\\.(\\d){1,2}`, 'gm');
        if (new RegExp(taskManagerIndexMatcher).test(input)) {
            return input
                .replace(shortFormatMatcher, kibanaIndex)
                .replace(taskManagerIndexMatcher, `${kibanaIndex}_task_manager`);
        }
        if (new RegExp(longFormatMatcher).test(input)) {
            return input.replace(longFormatMatcher, kibanaIndex);
        }
        if (new RegExp(shortFormatMatcher).test(input)) {
            return input.replace(shortFormatMatcher, kibanaIndex);
        }
        return input;
    };
    static replaceKibanaIndexWithTenantIndexAndNormalize = (baseString, kibanaIndexFromSession, kibanaIndex, reportingIndex) => {
        const baseStringWithReplacedKibanaIndex = KibanaIndexTweaker.replaceSubstringIfNotAlreadyPresent(baseString, kibanaIndex, kibanaIndexFromSession);
        // eslint-disable-next-line @typescript-eslint/no-var-requires,global-require
        const finalReportingIndex = require('../core/reportingIndex').getFinalReportingIndex();
        const result = KibanaIndexTweaker.replaceSubstringIfNotAlreadyPresent(baseStringWithReplacedKibanaIndex, reportingIndex, `${finalReportingIndex}${kibanaIndexFromSession}`);
        return KibanaIndexTweaker.normalizeKibanaIndex(result, kibanaIndexFromSession);
    };
    static replaceSubstringIfNotAlreadyPresent(original, substringToBeReplaced, replacement) {
        if (original.includes(replacement)) {
            return original;
        }
        return original.split(substringToBeReplaced).join(replacement);
    }
}
exports.KibanaIndexTweaker = KibanaIndexTweaker;
