"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildPkpApiRouter = void 0;
const express = __importStar(require("express"));
const settingsRouter_1 = require("./settingsRouter");
const kibanaAppRegistryController_1 = require("../controller/kibanaAppRegistryController");
const testRouter_1 = require("./testRouter");
const testController_1 = require("../controller/testController");
const impersonateController_1 = require("../controller/impersonateController");
const LicenseController_1 = require("../../../core/license/LicenseController");
const infoController_1 = require("../controller/infoController");
const accessLevel_1 = require("../../../core/common/accessLevel");
function buildPkpApiRouter(esClient, authenticationFacade, licenseService, authController) {
    const router = express.Router();
    const infoController = new infoController_1.InfoController(licenseService);
    const kibanaAppRegistryController = new kibanaAppRegistryController_1.KibanaAppRegistryController();
    const testController = new testController_1.TestController(esClient);
    const impersonateController = new impersonateController_1.ImpersonateController(authenticationFacade);
    const licenseController = new LicenseController_1.LicenseController(licenseService);
    router.get('/info', async (req, res) => infoController.handleGet(req.rorRequest, res));
    router.get('/kbn_app_registry/hidden', async (req, res) => kibanaAppRegistryController.handleGetHiddenApps(req.rorRequest, res));
    router.get('/kbn_app_registry', async (req, res) => kibanaAppRegistryController.handleGetAllApps(req.rorRequest, res));
    router.use('/kbn_app_registry', async (req, res) => kibanaAppRegistryController.handlePost(req, res));
    router.use('/settings', (0, settingsRouter_1.buildSettingsRouter)(esClient, licenseService, authController, authenticationFacade));
    router.use('/test', (0, testRouter_1.buildTestRouter)(testController));
    router.post('/impersonate-user', impersonateController.handleImpersonateUser);
    router.post('/finish-impersonation', impersonateController.handleFinishImpersonation);
    router.get('/license', licenseController.handleGet.bind(licenseController));
    router.post('/license', (req, res, next) => authController.verifyAccessLevel(req, res, next, [accessLevel_1.AccessLevel.UNRESTRICTED, accessLevel_1.AccessLevel.ADMIN]), (req, res) => licenseController.handleAdd.bind(licenseController)(req, res, (isLicenseEditionChanged) => {
        if (isLicenseEditionChanged) {
            authenticationFacade.deleteAllSessions();
        }
    }));
    router.delete('/license', (req, res, next) => authController.verifyAccessLevel(req, res, next, [accessLevel_1.AccessLevel.UNRESTRICTED, accessLevel_1.AccessLevel.ADMIN]), (req, res) => licenseController.handleDelete.bind(licenseController)(req, res, (isLicenseEditionChanged) => {
        if (isLicenseEditionChanged) {
            authenticationFacade.deleteAllSessions();
        }
    }));
    router.get('/license/cluster_uuid', licenseController.handleGetClusterUUID.bind(licenseController));
    return router;
}
exports.buildPkpApiRouter = buildPkpApiRouter;
