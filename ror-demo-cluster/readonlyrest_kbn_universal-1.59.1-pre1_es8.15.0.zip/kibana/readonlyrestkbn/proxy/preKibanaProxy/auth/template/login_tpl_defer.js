/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

window.console = window.console || {
  log: () => 'noop'
};

function parseInjectedArray(name, stringifiedArray) {
  try {
    return JSON.parse(stringifiedArray);
  } catch (e) {
    console.log(`Could not parse ${name} from: ${stringifiedArray}`);
  }
  return [];
}

const NEXT_URL_PARAM = 'nextUrl';
const BASE_PATH = '${basePath}';
const CLEAR_SESSION_ON_EVENTS = parseInjectedArray('clearSessionOnEvents', '${clearSessionOnEvents}');
const SSO_CONNECTORS = parseInjectedArray('ssoConnectors', '${ssoConnectors}');
const CSRF_TOKEN = '${csrfToken}';
const CSRF_HEADER_NAME = '${csrfHeaderName}';

$.blockUI.defaults = {
  message: null,
  onBlock: () => $('#spinner').fadeIn(1200),
  onUnblock: () => $('#spinner').hide()
};
$(document).ajaxStart($.blockUI).ajaxStop($.unblockUI);

function getParameterByName(name) {
  const searchParam = new URLSearchParams(window.location.search).get(name);
  return searchParam ? decodeURIComponent(searchParam) : null;
}

function buildNextUrlQueryParam() {
  const nextUrl = getParameterByName(NEXT_URL_PARAM);
  if (nextUrl) {
    return encodeURIComponent(nextUrl + window.location.hash);
  }
  return encodeURIComponent(window.location.hash);
}

function initLocalStorage() {
  if (window.localStorage) {
    // Stop nagging about enabling Xpack security in 7.10.x and older
    window.localStorage.setItem(`insecureClusterWarningVisibility${BASE_PATH}`, '{ "show": false }');
  }
}

function initSessionStorage() {
  if (window.sessionStorage) {
    const queryParam = buildNextUrlQueryParam();
    console.log(`Setting nextUrl to:${queryParam}`);
    window.sessionStorage.setItem(NEXT_URL_PARAM, queryParam);
  }
}

function displayFormMessage(message) {
  $('#form-username').val('').focus();
  $('#form-password').val('');
  $('#form-message').text(message);
  $('.form-wrapper').shake({
    speed: 45,
    distance: 5,
    direction: 'down'
  });
}

function buildLoginRequest(csrfHeaderName) {
  const headers = new Headers();
  headers.set('Content-Type', 'application/json;charset=UTF-8');
  headers.set(csrfHeaderName, CSRF_TOKEN);

  return {
    method: 'POST',
    redirect: 'follow',
    headers,
    body: JSON.stringify({
      username: $('#form-username').val(),
      password: $('#form-password').val()
    })
  };
}

function clearSessionOnEvents() {
  if (CLEAR_SESSION_ON_EVENTS && CLEAR_SESSION_ON_EVENTS.includes('login')) {
    console.log('Will clear localstorage and session storage - login phase');
    if (window.localStorage) {
      window.localStorage?.clear();
      window.localStorage.setItem(`insecureClusterWarningVisibility${BASE_PATH}`, '{ "show": false}');
      window.sessionStorage?.clear();
    }
  }
}

function onLoginRequestSuccess(response) {
  if (response.status !== 200) {
    throw response;
  }
  clearSessionOnEvents();
  return response.json();
}

function disableSubmitButton() {
  const formSubmit = document.getElementById('form-submit');

  if (formSubmit) {
    formSubmit.disabled = true;
    formSubmit.textContent = 'Entering...';
  }
}

function enableSubmitButton() {
  const formSubmit = document.getElementById('form-submit');

  if (formSubmit) {
    formSubmit.disabled = false;
    formSubmit.textContent = 'Enter Kibana ⏎';
  }
}

function onLoginRequestError(error) {
  switch (error.status) {
    case 401:
      error.json().then(json => {
        displayFormMessage(json.message);
      });
      break;
    default:
      displayFormMessage('Wrong credentials');
  }
  enableSubmitButton();
}

function buildLoginUri() {
  const nextUrlQueryParam = buildNextUrlQueryParam();
  const loginUri = `${BASE_PATH}/login`;
  return nextUrlQueryParam ? `${loginUri}?${NEXT_URL_PARAM}=${nextUrlQueryParam}` : loginUri;
}

function redirectAfterLogin(nextUrl) {
  const redirectUrl = nextUrl.split('redirectTo=')[1];
  const url = new URL(`${window.location.origin}${nextUrl}`);

  if (redirectUrl) {
    url.hash = '';
    url.searchParams.set('redirectTo', encodeURIComponent(redirectUrl));
  }
  window.location.href = url.href;
  return window.location.href;
}
function submitFormAndHeader(csrfHeaderName) {
  disableSubmitButton();
  return fetch(buildLoginUri(), buildLoginRequest(csrfHeaderName))
    .then(onLoginRequestSuccess)
    .then(data => {
      redirectAfterLogin(data.nextUrl);
    })
    .catch(onLoginRequestError);
}

function fillAuthConnectorsButtons() {
  SSO_CONNECTORS.forEach(connector => {
    const buttonName = connector.buttonName ? connector.buttonName : `Enter using ${connector.name} 🌍`;
    const button = `
    <div id="saml_auth">
      <a style="display: block" href="${connector.loginUrl}"><button class="loginButton saml-submit ${connector.type}Button">${buttonName}</button></a>
    </div>`;
    $('#connectors_auth').append(button).show();
  });
}

function reloadPageAfterTimeout(minutes) {
  setTimeout(() => {
    window.location.reload();
  }, 1000 * 60 * minutes);
}

function initSnackbarMessage() {
  const searchParams = new URLSearchParams(window.location.search);
  const message = searchParams.get('message');

  const snackbar = document.getElementById('snackbar');
  const snackbarDeleteIcon = document.getElementById('snackbar--DeleteIcon');

  if (snackbarDeleteIcon) {
    snackbarDeleteIcon.addEventListener('click', () => {
      snackbar.className = 'hidden';

      const url = new URL(window.location.href);
      url.searchParams.delete('message');

      window.history.pushState({}, null, url.toString());
    });
  }

  switch (message) {
    case 'LICENSE_CHANGED': {
      const snackbarMessage = document.getElementById('snackbar--message');

      snackbar.className = 'show';
      snackbarMessage.textContent =
        'The licensing edition has been changed. To ensure proper handling of all features, you have been automatically logged out of the system.';

      break;
    }

    default: {
      break;
    }
  }
}

initLocalStorage();
initSessionStorage();
$('#login_form').on('submit', event => {
  event.preventDefault();
  submitFormAndHeader(CSRF_HEADER_NAME);
});
$('#form-username').focus();
fillAuthConnectorsButtons();

if (typeof module !== 'undefined' && Object.prototype.hasOwnProperty.call(module, 'exports')) {
  module.exports = {
    submitFormAndHeader,
    CLEAR_SESSION_ON_EVENTS,
    redirectAfterLogin
  };
}

reloadPageAfterTimeout(30);

// TODO We need to find a way to pass message query string param on logout via session-probe
// initSnackbarMessage();
