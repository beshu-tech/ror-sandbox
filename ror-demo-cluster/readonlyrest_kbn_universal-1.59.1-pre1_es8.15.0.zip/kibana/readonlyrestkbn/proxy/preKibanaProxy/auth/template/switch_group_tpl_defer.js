/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

function getSwitchGroupUrl(url) {
  const logger = message => console.log('Error during getting switch group url:', message);

  const redirectTo = url && url.split('redirectTo=')[1];

  if (!redirectTo) {
    logger('RedirectTo query string parameter is not available');
    return window.location.origin;
  }

  return decodeURIComponent(unescape(redirectTo));
}

function removeAppDetailsFromUrl(url) {
  const logger = message => console.log('Remove app details from url failed:', message);
  const throwError = message =>
    (() => {
      throw new Error(message);
    })();

  try {
    if (!url) {
      logger('URL is not available.');
      return window.location.origin;
    }

    const urlInstance = new URL(url);
    const splitPathname = urlInstance.pathname.split('/');
    const spaceSymbolPath = splitPathname[1] || throwError('Space symbol is not available');

    const spaceIdPath = splitPathname[2] || throwError('Space id is not available');
    const appPath = splitPathname[3] || throwError('app path is not available');
    const appIdPath = splitPathname[4] || throwError('app id is not available');

    if (appPath !== 'app') {
      logger('Wrong pathname format. The "/app" path is not available in the correct place');
      return url;
    }
    const switchGroupUrl = `${urlInstance.protocol}//${urlInstance.hostname}:${urlInstance.port}/${spaceSymbolPath}/${spaceIdPath}/${appPath}/${appIdPath}`;
    if (appIdPath === 'management') {
      const subAppSectionPathname = splitPathname[5];
      const subAppApplicationPathname = splitPathname[6];

      return `${switchGroupUrl}/${subAppSectionPathname}/${subAppApplicationPathname}`;
    }

    return switchGroupUrl;
  } catch (e) {
    logger(e.message);
    return url;
  }
}

function redirectUser(url) {
  window.location.href = removeAppDetailsFromUrl(getSwitchGroupUrl(url));
}

redirectUser(window.location.href);

if (typeof module !== 'undefined' && Object.prototype.hasOwnProperty.call(module, 'exports')) {
  module.exports = {
    getSwitchGroupUrl,
    removeAppDetailsFromUrl
  };
}
