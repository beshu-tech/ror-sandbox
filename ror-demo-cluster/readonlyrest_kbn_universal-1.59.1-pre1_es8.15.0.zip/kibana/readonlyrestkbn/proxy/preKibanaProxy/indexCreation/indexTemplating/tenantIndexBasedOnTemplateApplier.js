"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantIndexBasedOnTemplateApplier = void 0;
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const templateIndexSurplusRemover_1 = require("./templateIndexSurplusRemover");
class TenantIndexBasedOnTemplateApplier {
    esClient;
    resetKibanaIndexToTemplate;
    templateIndexFromConfig;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    templateIndexSurplusRemover;
    constructor(esClient, resetKibanaIndexToTemplate, templateIndexFromConfig) {
        this.esClient = esClient;
        this.resetKibanaIndexToTemplate = resetKibanaIndexToTemplate;
        this.templateIndexFromConfig = templateIndexFromConfig;
        this.templateIndexSurplusRemover = new templateIndexSurplusRemover_1.TemplateIndexSurplusRemover(esClient);
    }
    async applyTemplateToIndex(tenantIndex, kibanaTemplateIndexFromSession) {
        const templateIndex = kibanaTemplateIndexFromSession || this.templateIndexFromConfig;
        if (templateIndex == null) {
            this.logger.debug('Template index not defined. Returning');
            return Promise.resolve();
        }
        if (templateIndex === tenantIndex) {
            this.logger.info('Template and target indices are the same. Aborting reindexing.');
            return Promise.resolve();
        }
        try {
            const totalDocumentsCopied = await this.copyAllDocumentsFromTemplateTo(tenantIndex, templateIndex);
            if (this.resetKibanaIndexToTemplate) {
                return this.templateIndexSurplusRemover.removeFromTargetDocumentsMissingInTemplate(totalDocumentsCopied, tenantIndex, templateIndex);
            }
        }
        catch (error) {
            this.handleErrors(error, tenantIndex, templateIndex);
        }
    }
    async copyAllDocumentsFromTemplateTo(tenantIndex, templateIndex) {
        this.logger.info(`Copying all Kibana objects from '${templateIndex}' to '${tenantIndex}'`);
        return this.esClient
            .postAsKibana('_reindex', JSON.stringify({
            source: {
                index: templateIndex
            },
            dest: {
                index: tenantIndex,
                version_type: 'internal' // blindly overwrite (was internal by default, but better force it: default may vary in the future)
            }
        }))
            .then(async (response) => {
            const data = await response.json();
            this.logger.debug('Re-indexed documents', JSON.stringify(data));
            return data;
        })
            .catch(e => {
            this.logger.error(`Re-indexed documents error: ${e}`);
        })
            .then((json) => json.total);
    }
    handleErrors(error, target, templateIndex) {
        if (error.message?.includes('index_not_found_exception')) {
            this.logger.warn("Template index was not found, won't copy anything");
        }
        else {
            this.logger.error(`Reindexing for '${target}' based on template index '${templateIndex}' failed: ${JSON.stringify(error)}`, error);
        }
    }
}
exports.TenantIndexBasedOnTemplateApplier = TenantIndexBasedOnTemplateApplier;
