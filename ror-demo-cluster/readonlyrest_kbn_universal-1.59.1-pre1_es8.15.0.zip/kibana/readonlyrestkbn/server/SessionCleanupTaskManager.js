"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionCleanupTaskManager = void 0;
const kibanaConfigInterceptor_1 = require("../kibana/kibanaConfigInterceptor");
const kibanaYamlSessionManagerConfigParser_1 = require("../kibana/config/kibanaYamlSessionManagerConfigParser");
const rorLoggerFactory_1 = require("../proxy/core/logging/rorLoggerFactory");
class SessionCleanupTaskManager {
    TASK_NAME = 'ror_session_cleanup';
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    elasticsearchClient;
    setup(taskManager) {
        this.registerTaskDefinitions(taskManager);
    }
    start(elasticsearchClient, taskManager) {
        this.elasticsearchClient = elasticsearchClient;
        this.ensureScheduled(taskManager);
    }
    registerTaskDefinitions(taskManager) {
        const config = kibanaConfigInterceptor_1.parsedConfig.get();
        if (!config) {
            return;
        }
        const { indexName, storeInIndex } = (0, kibanaYamlSessionManagerConfigParser_1.parseSessionManagerConfig)(config.readonlyrest_kbn);
        if (!storeInIndex) {
            this.logger.debug('Session is not stored in index. Cleanup task is not registered');
            return;
        }
        taskManager.registerTaskDefinitions({
            [this.TASK_NAME]: {
                title: 'Expired sessions cleanup',
                createTaskRunner: () => ({
                    run: () => {
                        this.logger.info(`Session Cleanup task for ${indexName} is running`);
                        this.elasticsearchClient?.asInternalUser
                            .deleteByQuery({
                            index: indexName,
                            refresh: true,
                            body: { query: { range: { expiresAt: { lte: Date.now() } } } }
                        }, { ignore: [409, 404] })
                            // @ts-ignore
                            .then((data) => {
                            this.logger.debug(`Number of deleted stale Index sessions: ${data?.deleted ?? 0}`);
                        })
                            .catch(e => {
                            this.logger.error(`Session Cleanup task error: ${e}`);
                        });
                    }
                }),
                timeout: '5m'
            }
        });
    }
    ensureScheduled(taskManager) {
        const config = kibanaConfigInterceptor_1.parsedConfig.get();
        if (!config) {
            return;
        }
        const { cleanupInterval, storeInIndex } = (0, kibanaYamlSessionManagerConfigParser_1.parseSessionManagerConfig)(config.readonlyrest_kbn);
        if (!storeInIndex) {
            this.logger.debug('The session is not stored in the index. The cleanup task is not scheduled');
            return;
        }
        taskManager
            .get(this.TASK_NAME)
            .then(data => {
            this.logger.info('Task already registered:', data);
        })
            .catch(e => {
            if (e?.output?.payload?.error === 'Not Found') {
                this.logger.info(`${e?.output?.payload.message}, Task scheduled`);
                return taskManager.ensureScheduled({
                    id: this.TASK_NAME,
                    taskType: this.TASK_NAME,
                    scope: [],
                    schedule: { interval: cleanupInterval },
                    params: {},
                    state: {}
                });
            }
            this.logger.error('Task manager scheduling error', e);
        });
    }
}
exports.SessionCleanupTaskManager = SessionCleanupTaskManager;
