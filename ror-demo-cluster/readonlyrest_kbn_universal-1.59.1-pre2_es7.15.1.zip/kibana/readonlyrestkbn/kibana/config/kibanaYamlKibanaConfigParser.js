"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseKibanaConfigForPep = exports.parseKibanaConfigForPkp = exports.DEFAULT_KIBANA_INDEX = void 0;
const kibanaYamlKibanaSSLConfigParser_1 = require("./kibanaYamlKibanaSSLConfigParser");
const rorPort_1 = require("./rorPort");
exports.DEFAULT_KIBANA_INDEX = '.kibana';
const DEFAULT_KIBANA_PORT = 5601;
const DEFAULT_REQUEST_TIMEOUT_MS = 30000; // same as Kibana defaults
const DEFAULT_PING_TIMEOUT_MS = DEFAULT_REQUEST_TIMEOUT_MS; // same as Kibana defaults
function getKibanaIndex(deepObject) {
    return deepObject.kibana?.index || exports.DEFAULT_KIBANA_INDEX;
}
function asValidPortNumber(input) {
    if (typeof input === 'string' && !/^[1-9][0-9]*$/.test(String(input))) {
        throw new Error(`The port value is invalid: ${input}`);
    }
    const port = +input;
    if (Number.isNaN(port)) {
        throw new Error(`The port value is not numeric: ${input}`);
    }
    if (Math.floor(port) !== port) {
        throw new Error(`The port number is not an integer: ${input}`);
    }
    if (port < 0 || port > rorPort_1.HIGHEST_AVAILABLE_PORT) {
        throw new Error(`The port number is  out of range: ${input}`);
    }
    return port;
}
function parseKibanaConfigForPkp(deepObject) {
    const serverHost = deepObject.server?.host || 'localhost';
    const kibanaYamlServerPort = deepObject.server?.port;
    const newKibanaPort = asValidPortNumber((0, rorPort_1.getRandomPort)(1024));
    const kibanaBasePath = deepObject.server?.basePath || '';
    const pkpPort = kibanaYamlServerPort ? asValidPortNumber(kibanaYamlServerPort) : DEFAULT_KIBANA_PORT;
    const pkpHostAndPort = {
        host: serverHost,
        port: pkpPort
    };
    const kibanaSslConfig = (0, kibanaYamlKibanaSSLConfigParser_1.parseKibanaSSLConfig)(deepObject);
    const kibanaUrl = `http://localhost:${asValidPortNumber(newKibanaPort)}`;
    const rewriteBasePath = deepObject.server?.rewriteBasePath ?? false;
    const reportingQueueTimeout = deepObject.xpack?.reporting?.queue?.timeout ?? 240;
    return {
        pkpHostAndPort,
        kibanaUrl,
        kibanaBasePath,
        kibanaIndex: getKibanaIndex(deepObject),
        newKibanaPort,
        kibanaSslConfig,
        rewriteBasePath,
        reportingQueueTimeout
    };
}
exports.parseKibanaConfigForPkp = parseKibanaConfigForPkp;
function parseKibanaConfigForPep(deepObject, kibanaTechUserEsAuthToken, requestHeadersWhitelist) {
    const pepPort = asValidPortNumber((0, rorPort_1.getRandomPort)(1024));
    const pepUrl = `http://localhost:${asValidPortNumber(pepPort)}`;
    // eslint-disable-next-line @typescript-eslint/no-var-requires,global-require
    const reportingIndex = require('../../proxy/core/reportingIndex').getTemporaryReportingIndex();
    const pingTimeout = deepObject.elasticsearch?.pingTimeout || DEFAULT_PING_TIMEOUT_MS;
    const requestTimeout = deepObject.elasticsearch?.requestTimeout || DEFAULT_REQUEST_TIMEOUT_MS;
    return {
        pepPort,
        pepUrl,
        networkParameters: { pingTimeout, requestTimeout },
        reportingIndex,
        kibanaIndex: getKibanaIndex(deepObject),
        kibanaTechUserEsAuthToken,
        requestHeadersWhitelist
    };
}
exports.parseKibanaConfigForPep = parseKibanaConfigForPep;
