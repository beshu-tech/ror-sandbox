"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyNoUnsupportedFeaturesConfigSupplied = exports.checkLoggingFeatures = void 0;
const configUtils_1 = require("./configUtils");
const rorLoggerFactory_1 = require("../../proxy/core/logging/rorLoggerFactory");
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
const defaultAvailableFeatures = ['json', 'dest'];
function checkLoggingFeatures(features, availableFeatures = defaultAvailableFeatures) {
    for (const key in features) {
        if (!availableFeatures.includes(key)) {
            logger.warn(`logging.${key} config parameter declared in kibana.yml is not supported yet. It will be ignored`);
        }
    }
}
exports.checkLoggingFeatures = checkLoggingFeatures;
function verifyNoUnsupportedFeaturesConfigSupplied(deepObject) {
    const elasticsearchObject = deepObject.elasticsearch;
    if (elasticsearchObject == null) {
        return;
    }
    checkLoggingFeatures(deepObject.logging);
    if (elasticsearchObject.sniffInterval) {
        logger.error(`Sniffing is not supported yet. Please set 'elasticsearch.sniffInterval' to 'false' in kibana.yml config.`);
        (0, configUtils_1.exitInOneSecond)();
    }
    if (elasticsearchObject.sniffOnStart) {
        logger.error(`Sniffing is not supported yet. Please set 'elasticsearch.sniffOnStart' to 'false' in kibana.yml config.`);
        (0, configUtils_1.exitInOneSecond)();
    }
    if (elasticsearchObject.sniffOnConnectionFault) {
        logger.error(`SSL is not supported yet. Please set 'elasticsearch.sniffOnConnectionFault' to 'false' in kibana.yml config.`);
        (0, configUtils_1.exitInOneSecond)();
    }
}
exports.verifyNoUnsupportedFeaturesConfigSupplied = verifyNoUnsupportedFeaturesConfigSupplied;
