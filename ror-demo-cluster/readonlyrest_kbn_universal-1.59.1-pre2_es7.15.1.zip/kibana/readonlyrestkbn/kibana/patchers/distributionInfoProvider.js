"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DistributionInfoProvider = exports.Environment = void 0;
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const fs_1 = require("fs");
var Environment;
(function (Environment) {
    Environment[Environment["DEV"] = 0] = "DEV";
    Environment[Environment["PRODUCTION"] = 1] = "PRODUCTION";
})(Environment = exports.Environment || (exports.Environment = {}));
class DistributionInfoProvider {
    static instance;
    _versionString;
    _kibanaVersion;
    _rorVersion;
    environment;
    _isBuildExpired;
    constructor(versionString) {
        try {
            this._versionString = versionString;
            this._kibanaVersion = versionString.split('_es')[1];
            this._rorVersion = versionString.substring(versionString.indexOf('-') + 1).split('_')[0];
        }
        catch (e) {
            throw new Error(`Error parsing version string, error in parsing: ${e.message}`);
        }
        if (!this._versionString || !this._kibanaVersion) {
            throw new Error(`Invalid version string, error in parsing: ${versionString}`);
        }
        try {
            this._isBuildExpired = false;
        }
        catch (e) {
            if (!e.message.includes('hal' + 'ted')) {
                console.log('Something went wrong in build expired..', e);
            }
            this._isBuildExpired = true;
        }
        const env = DistributionInfoProvider.readPackageJson(`${__dirname}/../../package.json`).environment;
        this.environment = env === 'PRODUCTION' ? Environment.PRODUCTION : Environment.DEV;
    }
    isBuildExpired() {
        return this._isBuildExpired;
    }
    toJsonObject() {
        return {
            versionString: this._versionString,
            kibanaVersion: this._kibanaVersion,
            rorVersion: this._rorVersion,
            isProduction: Boolean(this.environment),
            isBuildExpired: this._isBuildExpired
        };
    }
    toString() {
        return JSON.stringify(this.toJsonObject());
    }
    get kibanaVersion() {
        return this._kibanaVersion;
    }
    get rorVersion() {
        return this._rorVersion;
    }
    get versionString() {
        return this._versionString;
    }
    get getEnvironment() {
        return this.environment;
    }
    static isEnvironmentDev() {
        return this.getInstance().environment === Environment.DEV;
    }
    // For the backend
    static getInstance() {
        if (!this.instance) {
            try {
                const rorPackageJson = this.readPackageJson(`${__dirname}/../../package.json`);
                let versionString;
                if (rorPackageJson.ror_version && rorPackageJson.ror_version.includes('_es')) {
                    versionString = rorPackageJson.ror_version;
                }
                else {
                    // This is for when we are in development, and version string would return __ROR_VERSION...
                    versionString = `enterprise` + `-${rorPackageJson.version}_es${rorPackageJson.kibana.version}`;
                }
                this.instance = new DistributionInfoProvider(versionString);
            }
            catch (e) {
                console.log(e);
                throw new Error(`Cannot retrieve information from package.json. If this call comes from the browser, use StatusService.js instead.${e.message}`);
            }
        }
        return this.instance;
    }
    // for the front end, after taking the version string from StatusAPI
    static fromVersionString(versionString) {
        return new DistributionInfoProvider(versionString);
    }
    static resetInstance() {
        this.instance = undefined;
    }
    static setInstance(version) {
        this.instance = new DistributionInfoProvider(version);
    }
    static readPackageJson(path) {
        const packageString = (0, fs_1.readFileSync)(path, { encoding: 'utf8', flag: 'r' });
        return JSON.parse(packageString);
    }
    isRorMoreAncientThan(ofWhat) {
        return this.isMoreAncientThan(this._rorVersion, ofWhat);
    }
    isKibanaMoreAncientThan(ofWhat) {
        return this.isMoreAncientThan(this._kibanaVersion, ofWhat);
    }
    isMoreAncientThan(what, ofWhat) {
        // return < 0 if  = a is bigger
        function cmpVersions(a, b) {
            let i;
            let diff;
            const regExStrip0 = /(\.0+)+$/;
            const segmentsA = a.replace(regExStrip0, '').split('.');
            const segmentsB = b.replace(regExStrip0, '').split('.');
            const l = Math.min(segmentsA.length, segmentsB.length);
            for (i = 0; i < l; i++) {
                diff = parseInt(segmentsA[i], 10) - parseInt(segmentsB[i], 10);
                if (diff) {
                    return diff;
                }
            }
            return segmentsA.length - segmentsB.length;
        }
        return cmpVersions(what, ofWhat) < 0;
    }
}
exports.DistributionInfoProvider = DistributionInfoProvider;
