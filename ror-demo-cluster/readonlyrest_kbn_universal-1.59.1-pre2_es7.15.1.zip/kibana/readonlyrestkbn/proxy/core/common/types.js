"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Method = exports.CONNECTOR_SVC_TRANSIENT_JWT = exports.X_ROR_KIBANA_INDEX = exports.X_ROR_KIBANA_METADATA = exports.X_ROR_CORRELATION_ID = exports.X_ROR_IMPERSONATING = exports.AUTOLOGIN_QUERY_PARAM = exports.MESSAGE_QUERY_PARAM = exports.NEXT_URL = exports.ORIGIN_HEADER = exports.COOKIE_HEADER = exports.AUTHORIZATION_HEADER = exports.X_ROR_KIBANA_REQ_METHOD = exports.X_ROR_KIBANA_REQ_PATH = exports.X_ROR_CURRENT_GROUP = exports.X_FORWARDED_FOR = exports.X_FORWARDED_USER = exports.X_ROR_ORIGIN = exports.CONTENT_TYPE_HEADER = void 0;
exports.CONTENT_TYPE_HEADER = 'Content-Type';
exports.X_ROR_ORIGIN = 'x-ror-origin';
exports.X_FORWARDED_USER = 'x-forwarded-user';
exports.X_FORWARDED_FOR = 'x-forwarded-for';
exports.X_ROR_CURRENT_GROUP = 'x-ror-current-group';
exports.X_ROR_KIBANA_REQ_PATH = 'x-ror-kibana-request-path';
exports.X_ROR_KIBANA_REQ_METHOD = 'x-ror-kibana-request-method';
exports.AUTHORIZATION_HEADER = 'authorization';
exports.COOKIE_HEADER = 'cookie';
exports.ORIGIN_HEADER = 'origin';
exports.NEXT_URL = 'nextUrl';
exports.MESSAGE_QUERY_PARAM = 'message';
exports.AUTOLOGIN_QUERY_PARAM = 'autologin';
exports.X_ROR_IMPERSONATING = 'x-ror-impersonating';
exports.X_ROR_CORRELATION_ID = 'x-ror-correlation-id';
exports.X_ROR_KIBANA_METADATA = 'x-ror-kibana-metadata';
exports.X_ROR_KIBANA_INDEX = 'x-ror-kibana-index';
exports.CONNECTOR_SVC_TRANSIENT_JWT = 'conn_svc_transient_jwt';
var Method;
(function (Method) {
    Method["HEAD"] = "head";
    Method["OPTION"] = "option";
    Method["GET"] = "get";
    Method["PUT"] = "put";
    Method["POST"] = "post";
    Method["PATCH"] = "patch";
    Method["DELETE"] = "delete";
})(Method = exports.Method || (exports.Method = {}));
