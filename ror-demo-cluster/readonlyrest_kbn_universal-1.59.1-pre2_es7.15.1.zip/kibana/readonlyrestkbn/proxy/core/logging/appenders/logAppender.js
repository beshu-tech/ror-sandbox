"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogAppender = void 0;
const logLevel_1 = require("../logLevel");
const types_1 = require("../../common/types");
class LogAppender {
    logPattern(logLevel, fileName, message, impersonating, correlationId) {
        const time = (0, logLevel_1.getLogFormattedTime)();
        const level = (0, logLevel_1.getLogLevelDescription)(logLevel);
        let prefixes = `[${time}] [${level}][plugins][ReadonlyREST][${fileName}]`;
        if (impersonating) {
            prefixes = `${prefixes}[impersonating ${impersonating}]`;
        }
        if (correlationId) {
            prefixes = `${prefixes}[${types_1.X_ROR_CORRELATION_ID}=${correlationId}]`;
        }
        return `${prefixes} ${message}`;
    }
}
exports.LogAppender = LogAppender;
