"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionManagerFactory = void 0;
const inMemorySessionManager_1 = require("./inMemorySessionManager");
const indexBasedSessionManager_1 = require("./indexBasedSessionManager");
const esIndexClient_1 = require("./esIndexClient");
const timeUtils_1 = require("../common/timeUtils");
class SessionManagerFactory {
    static sessionManager;
    static clearInstance() {
        SessionManagerFactory.sessionManager = undefined;
    }
    static build(esClient, config, sessionConfig, licenseService, reportingQueueTimeout) {
        const sessionTimeoutMillis = timeUtils_1.TimeUtils.minutesToMillis(sessionConfig.timeoutMinutes);
        const inMemorySessionManager = new inMemorySessionManager_1.InMemorySessionManager(sessionTimeoutMillis, licenseService, config.cleanupInterval, reportingQueueTimeout);
        if (!config.storeInIndex) {
            return inMemorySessionManager;
        }
        const esIndexClient = new esIndexClient_1.EsIndexClient(config.indexName, config.sessionKey, esClient);
        if (!SessionManagerFactory.sessionManager) {
            SessionManagerFactory.sessionManager = new indexBasedSessionManager_1.IndexBasedSessionManager(sessionTimeoutMillis, inMemorySessionManager, esIndexClient, config.refreshAfter, licenseService);
        }
        return SessionManagerFactory.sessionManager;
    }
}
exports.SessionManagerFactory = SessionManagerFactory;
