"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.KibanaAppRegistryController = void 0;
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const kibanaAppsRegistry_1 = require("../../kibana_apps/kibanaAppsRegistry");
class KibanaAppRegistryController {
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    async handleGetHiddenApps(req, res) {
        this.logger.trace('Handling hidden apps GET request');
        const hiddenAppNames = req.extractHiddenAppsNames();
        return res.json(kibanaAppsRegistry_1.KibanaAppsRegistry.getPathsOfAppsToHide(hiddenAppNames));
    }
    async handleGetAllApps(req, res) {
        this.logger.trace('Handling all registry apps GET request');
        return res.json(kibanaAppsRegistry_1.KibanaAppsRegistry.allRegistryApps);
    }
    async handlePost(req, res) {
        try {
            this.logger.trace(`Received app registry payload of length ${req.body.length}`);
            kibanaAppsRegistry_1.KibanaAppsRegistry.enrichRegistry(req.body);
            return res.json({ message: 'ok' });
        }
        catch (e) {
            res.status(500);
            this.logger.error(`Error enriching kibana app registry from request: ${e.name}: ${e.message}`, e);
            return res.json({ message: e.message });
        }
    }
}
exports.KibanaAppRegistryController = KibanaAppRegistryController;
