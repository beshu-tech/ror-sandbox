"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogoutLinkProvider = void 0;
const types_1 = require("../../core/common/types");
const rorLoggerFactory_1 = require("../../core/logging/rorLoggerFactory");
class LogoutLinkProvider {
    kibanaBasePath;
    samlRouterConfigs;
    oidcRouterConfigs;
    customLogoutLink;
    proxyAuthConfig;
    static CUSTOM_LOGOUT_LINK_PARAM_VALUE = 'custom_logout_link';
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(kibanaBasePath, samlRouterConfigs, oidcRouterConfigs, customLogoutLink, proxyAuthConfig) {
        this.kibanaBasePath = kibanaBasePath;
        this.samlRouterConfigs = samlRouterConfigs;
        this.oidcRouterConfigs = oidcRouterConfigs;
        this.customLogoutLink = customLogoutLink;
        this.proxyAuthConfig = proxyAuthConfig;
    }
    buildLogoutLink(identitySessionMetadata) {
        const originFromSession = identitySessionMetadata?.origin;
        if (originFromSession) {
            const samlRouterConfig = this.samlRouterConfigs.find(config => config.connectorName === originFromSession);
            if (samlRouterConfig) {
                return samlRouterConfig.logoutPathRelativeToRoot();
            }
            const oidcRouterConfig = this.oidcRouterConfigs.find(config => config.connectorName === originFromSession);
            if (oidcRouterConfig) {
                return oidcRouterConfig.logoutPathRelativeToRoot();
            }
        }
        if (this.customLogoutLink == null) {
            return this.buildLoginLink(identitySessionMetadata);
        }
        return this.buildCustomLogoutLink(identitySessionMetadata);
    }
    buildLoginLink(identitySessionMetadata) {
        return this.buildDefaultLoginLink(Boolean(this.proxyAuthConfig?.enabled && this.isProxyAuthHeaderSupplied(identitySessionMetadata)));
    }
    isProxyAuthHeaderSupplied(identitySessionMetadata) {
        return identitySessionMetadata?.authorizationHeaders.get(this.proxyAuthConfig?.forward_auth_header ?? '') != null;
    }
    buildDefaultLoginLink(autologinDisabled) {
        return this.withBasePath(autologinDisabled ? `/login?${types_1.AUTOLOGIN_QUERY_PARAM}=false` : '/login');
    }
    buildCustomLogoutLink(identitySessionMetadata) {
        const originFromSession = identitySessionMetadata?.origin;
        const customLogoutLink = this.replaceIdentityVariables(identitySessionMetadata);
        const customLogoutUrl = new URL(customLogoutLink?.includes('://') ? customLogoutLink : `http://${customLogoutLink}`);
        if (customLogoutUrl.searchParams.has(types_1.X_ROR_ORIGIN)) {
            return customLogoutUrl.toString();
        }
        customLogoutUrl.searchParams.set(types_1.X_ROR_ORIGIN, originFromSession || LogoutLinkProvider.CUSTOM_LOGOUT_LINK_PARAM_VALUE);
        return customLogoutUrl.toString();
    }
    replaceIdentityVariables(identity) {
        this.logger.trace('Beginning to replace identity variables in the custom logout url');
        if (!this.customLogoutLink?.includes('@{identity') || !identity) {
            this.logger.debug('No identity variables found in the custom logout url or identity session metadata is empty');
            return this.customLogoutLink;
        }
        let logoutLinkWithReplacedVariables = this.customLogoutLink;
        Object.entries(identity).forEach(([key, value]) => {
            if (value) {
                const valueSerialized = JSON.stringify(value);
                this.logger.trace(`Replacing @{identity:${key}} with ${valueSerialized}`);
                logoutLinkWithReplacedVariables = logoutLinkWithReplacedVariables.replace(`@{identity:${key}}`, valueSerialized);
            }
        });
        this.logger.debug(`Replaced identity variables. The new logout url is: ${logoutLinkWithReplacedVariables}`);
        return logoutLinkWithReplacedVariables;
    }
    withBasePath = path => this.kibanaBasePath + path;
}
exports.LogoutLinkProvider = LogoutLinkProvider;
