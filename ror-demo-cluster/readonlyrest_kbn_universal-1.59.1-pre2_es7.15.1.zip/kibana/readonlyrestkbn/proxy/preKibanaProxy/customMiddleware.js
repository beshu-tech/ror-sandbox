"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomMiddleware = void 0;
const node_fetch_1 = __importDefault(require("node-fetch"));
const fs_extra_1 = __importDefault(require("fs-extra"));
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
const ActivationKey_1 = require("../core/license/ActivationKey");
class CustomMiddleware {
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor() {
        // @ts-ignore
        global.fetch = node_fetch_1.default;
        // @ts-ignore
        global.logger = this.logger;
    }
    async inject(req, res, next, licenseService, customMiddlewareInjectFile, customMiddlewareInject) {
        const license = licenseService.getActivationKey().license;
        const isEnterprise = (0, ActivationKey_1.isEnterpriseLicense)(license);
        if (!isEnterprise) {
            return next();
        }
        if (customMiddlewareInjectFile) {
            return this.injectFromFile(req, res, next, customMiddlewareInjectFile);
        }
        if (customMiddlewareInject) {
            return this.injectInline(req, res, next, customMiddlewareInject);
        }
        return next();
    }
    async injectFromFile(req, res, next, customMiddlewareInjectFile) {
        try {
            const read = f => fs_extra_1.default.readFileSync(f).toString();
            const include = f => {
                const content = read(f);
                // eslint-disable-next-line no-eval
                eval.apply(global, [content]);
                return this.getFunctionName(content);
            };
            const { functionName } = include(customMiddlewareInjectFile);
            return await global[functionName](req, res, next);
        }
        catch (e) {
            this.logger.error('error:', e);
        }
    }
    async injectInline(req, res, next, customMiddlewareInject) {
        try {
            const include = content => {
                // eslint-disable-next-line no-eval
                eval.apply(global, [content]);
                return this.getFunctionName(content);
            };
            const { functionName } = include(customMiddlewareInject);
            return await global[functionName](req, res, next);
        }
        catch (e) {
            this.logger.error('error:', e);
        }
    }
    getFunctionName(content) {
        const functionDeclarationName = content.split('(')?.[0]?.split('function ')?.[1];
        const constBasedExpression = content.split(' =')?.[0]?.split('const ')?.[1];
        const letBasedExpression = content.split(' =')?.[0]?.split('let ')?.[1];
        const functionExpressionName = content.split(' =')?.[0]?.split('var ')?.[1];
        if ((!functionDeclarationName && constBasedExpression) || letBasedExpression) {
            throw new Error(' You need to declare your customMiddleware as function declaration (function FUNCTION_NAME()) or function expression with a var (var FUNCTION_NAME =)');
        }
        return { functionName: functionDeclarationName || functionExpressionName };
    }
}
exports.CustomMiddleware = CustomMiddleware;
