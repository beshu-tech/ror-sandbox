"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Identity = void 0;
class Identity {
    username;
    kibanaHiddenApps;
    kibanaAccess;
    currentGroup;
    availableGroups;
    impersonatedBy;
    correlationId;
    constructor(username, kibanaHiddenApps, kibanaAccess, currentGroup, availableGroups, impersonatedBy, correlationId) {
        this.username = username;
        this.kibanaHiddenApps = kibanaHiddenApps;
        this.kibanaAccess = kibanaAccess;
        this.currentGroup = currentGroup;
        this.availableGroups = availableGroups;
        this.impersonatedBy = impersonatedBy;
        this.correlationId = correlationId;
    }
}
exports.Identity = Identity;
