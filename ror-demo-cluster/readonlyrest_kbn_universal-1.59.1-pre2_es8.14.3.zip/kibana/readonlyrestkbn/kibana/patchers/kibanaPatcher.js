"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.isPatchedAll = exports.main = void 0;
const filePatcher_1 = require("./filePatcher");
const distributionInfoProvider_1 = require("./distributionInfoProvider");
const fs = require('fs');
const rorPackage = JSON.parse(fs.readFileSync(`${__dirname}/../../package.json`, 'utf8'));
const kibanaPackage = JSON.parse(fs.readFileSync(`${__dirname}/../../../../package.json`, 'utf8'));
const isDevEnv = distributionInfoProvider_1.DistributionInfoProvider.isEnvironmentDev();
function getPatchDir() {
    const kbnVersion = kibanaPackage.version;
    const dir2kbnVersionMap = rorPackage.ror_patch_versions;
    for (const dir of Object.keys(dir2kbnVersionMap)) {
        if (dir2kbnVersionMap[dir].includes(kbnVersion)) {
            return dir;
        }
    }
    throw new Error(`unsupported version for patching ${kbnVersion}`);
}
function main() {
    try {
        const command = process.argv.length >= 3 ? process.argv[2] : 'help';
        log(`Received command: ${command}`);
        switch (command) {
            case 'unpatch':
                if (!unpatchAll()) {
                    process.exitCode = -1;
                }
                break;
            case 'verify':
                if (!isPatchedAll()) {
                    process.exitCode = -1;
                }
                break;
            case 'fix':
                if (!fixAll()) {
                    process.exitCode = -1;
                }
                break;
            case 'patch':
                if (!patchAll()) {
                    process.exitCode = -1;
                }
                break;
            default:
                help();
        }
    }
    catch (e) {
        log("ReadonlyREST encountered problems with compatibility manager script, please run manually using 'ror-tools.js'  ", e);
    }
}
exports.main = main;
function log(msg, obj = null) {
    msg = `[ROR COMPAT] ${msg}`;
    if (obj) {
        console.log(msg, obj);
    }
    else {
        console.log(msg);
    }
}
function patchAll() {
    try {
        if (!distroRequiresPatch()) {
            return true;
        }
        log('Modify a few Kibana files for ReadonlyREST...');
        return doWithPatcher(patcher => {
            if (patcher.hasBackup()) {
                log('Backup file found, assuming already patched. Will first unpatch and then re-patch with potentially newer code.');
                patcher.unpatch();
            }
            patcher.patch();
            return true;
        });
    }
    catch (e) {
        log("ReadonlyREST encountered problems during patching:", e);
        return false;
    }
}
function isPatchedAll() {
    try {
        log('Verifying the presence of ROR hooks on Kibana files..');
        return doWithPatcher(patcher => {
            if (!patcher.isPatched()) {
                log('This file  was not patched');
                return false;
            }
            return true;
        });
    }
    catch (e) {
        log("ReadonlyREST encountered problems during patching verification:", e);
        return false;
    }
}
exports.isPatchedAll = isPatchedAll;
function unpatchAll() {
    try {
        if (!distroRequiresPatch()) {
            return true;
        }
        return doWithPatcher(patcher => {
            if (patcher.hasBackup()) {
                log('Backup file found!');
                patcher.unpatch();
            }
            else {
                log('Backup file not found: assuming patch was not applied.');
            }
            return true;
        });
    }
    catch (e) {
        log("ReadonlyREST encountered problems during unpatching:", e);
        return false;
    }
}
function doWithPatcher(action) {
    const directory = isDevEnv ? '/patches_for_kbn_source' : '/patches_for_kbn_distribution';
    const patchDir = `${__dirname + directory + (isDevEnv ? `/${getPatchDir()}` : '')}/`;
    const matcher = /.*\.patch/gi;
    const patchFiles = fs.readdirSync(patchDir).filter((f) => f.match(matcher));
    for (let f of patchFiles) {
        f = patchDir + f; // full qualified path
        log(`Found patch file ${f}`);
        const backupFileSuffix = `.${kibanaPackage.version}_${rorPackage.version}.orig`;
        const patcher = new filePatcher_1.FilePatcher(f, `${__dirname}/../../../../`.replace('//', '/'), backupFileSuffix); // kibana main dir
        if (!action(patcher)) {
            return false;
        }
    }
    return true;
}
function distroRequiresPatch() {
    return true;
}
function fixAll() {
    try {
        log('Will verify and, where necessary, attempt to automatically fix patched Kibana files...');
        if (!distroRequiresPatch()) {
            return true;
        }
        let verifiedOK = false;
        try {
            verifiedOK = isPatchedAll();
        }
        catch (e) {
            log('Compatibility verification failed: ', e);
            verifiedOK = false;
        }
        if (!verifiedOK) {
            log('Attempting to re-patch...');
            try {
                verifiedOK = patchAll();
            }
            catch (e) {
                log("Could not fix compatibility automatically. Maybe a permissions issue? See stack trace. To fix this, use './ror-tools.js unpatch' and './ror-tools.js patch' manually", e);
                verifiedOK = false;
            }
        }
        if (verifiedOK) {
            log('compatibility did no need fixing. All is patched OK.');
        }
        else {
            log('compatibility could not be fixed: FAILED.');
        }
        return verifiedOK;
    }
    catch (e) {
        log("ReadonlyREST encountered problems during fixing patch:", e);
        return false;
    }
}
function help() {
    log(`This tool is used to (un)install some code hooks in Kibana main source code that are necessary for ReadonlyREST to work appropriately with the non-OSS Kibana distribution` +
        `\n\n` +
        `usage: node/bin/node ${process.argv[0]} ${process.argv[1]} <patch|unpatch|verify|fix>`);
}
