"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InMemorySessionManager = void 0;
const timestring_1 = __importDefault(require("timestring"));
const sessionManager_1 = require("./sessionManager");
const lazyUtils_1 = require("../lazyUtils");
const rorLoggerFactory_1 = require("../logging/rorLoggerFactory");
class InMemorySessionManager extends sessionManager_1.SessionManager {
    sessionTimeoutMillis;
    licenseService;
    reportingQueueTimeout;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(sessionTimeoutMillis, licenseService, cleanupInterval, reportingQueueTimeout) {
        super();
        this.sessionTimeoutMillis = sessionTimeoutMillis;
        this.licenseService = licenseService;
        this.reportingQueueTimeout = reportingQueueTimeout;
        (0, lazyUtils_1.executeWithInterval)(this.clearStaleSessions, (0, timestring_1.default)(cleanupInterval, 'ms'));
    }
    sessionsInMemory = new Map();
    set = async (sid, session) => {
        this.sessionsInMemory.set(sid, session);
        this.mostRecentlyAccessed = session;
    };
    setShortLivedSessionInMemory = async (sid, session) => {
        const date = new Date();
        const secondsToClearSession = this.reportingQueueTimeout + 60;
        date.setSeconds(date.getSeconds() + secondsToClearSession);
        await this.set(sid, { ...session, expiresAt: date });
        setTimeout(() => {
            this.checkIfSessionTimeout(sid);
        }, secondsToClearSession * 1000);
    };
    get = async (sid) => {
        let session = this.sessionsInMemory.get(sid);
        if (session != null) {
            session = this.cleanAfterGet(this.licenseService, session);
            this.mostRecentlyAccessed = session;
        }
        return session || null;
    };
    delete = (sid) => {
        this.sessionsInMemory.delete(sid);
    };
    checkIfSessionTimeout = async (sid) => {
        if (sid && (await this.isSessionTimeout(sid))) {
            this.sessionsInMemory.delete(sid);
            return true;
        }
        return false;
    };
    clearStaleSessions = async () => {
        const promises = [];
        for (const sid of this.sessionsInMemory.keys()) {
            promises.push(this.checkIfSessionTimeout(sid));
        }
        Promise.all(promises).then(numberOfDeletes => {
            this.logger.debug(`Number of deleted stale In-memory sessions: ${numberOfDeletes.filter(numberOfDelete => numberOfDelete).length}`);
        });
    };
    deleteAllSessions = async () => {
        this.sessionsInMemory.clear();
        this.mostRecentlyAccessed = undefined;
    };
    reloadSessions(sessions) {
        this.sessionsInMemory = sessions;
    }
}
exports.InMemorySessionManager = InMemorySessionManager;
