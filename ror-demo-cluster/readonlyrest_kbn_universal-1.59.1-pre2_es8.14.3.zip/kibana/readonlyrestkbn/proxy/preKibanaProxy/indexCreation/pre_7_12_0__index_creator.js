"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Pre_7_12_0_IndexCreator = void 0;
const abstractIndexCreator_1 = require("./abstractIndexCreator");
class Pre_7_12_0_IndexCreator extends abstractIndexCreator_1.AbstractIndexCreator {
    defaultKibanaIndex;
    esClient;
    constructor(defaultKibanaIndex, esClient, resetKibanaIndexToTemplate, kibanaTemplateIndex) {
        super(esClient, defaultKibanaIndex, __filename, resetKibanaIndexToTemplate, kibanaTemplateIndex);
        this.defaultKibanaIndex = defaultKibanaIndex;
        this.esClient = esClient;
    }
    async createKibanaIndex(kibanaIndexFromSession, baseIndex) {
        const mapping = await this.getDefaultIndexMapping(baseIndex);
        const realDefaultKibanaIndexPotentiallyBehindAlias = Object.keys(mapping)[0];
        const mappingWithAliasHandled = mapping[realDefaultKibanaIndexPotentiallyBehindAlias].mappings;
        const putPayload = { mappings: { properties: mappingWithAliasHandled.properties } };
        this.logger.debug(`kibana_index resolution: default=${baseIndex}, fromSession=${kibanaIndexFromSession}, willBeCreated=${kibanaIndexFromSession}`);
        this.logger.debug(`Creating kibana index ${kibanaIndexFromSession} with mappings from ${baseIndex}: PUT ${JSON.stringify(putPayload).substring(0, 50)}...`);
        await this.esClient.putAsKibana(kibanaIndexFromSession, putPayload);
    }
    isMigrationNeeded(_) {
        return false;
    }
}
exports.Pre_7_12_0_IndexCreator = Pre_7_12_0_IndexCreator;
