"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObservabilityTransformer = void 0;
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
// eslint-disable-next-line import/no-cycle
const index_1 = require("../index");
const hiddenAppsChecker_1 = __importDefault(require("../../../kibana_apps/hiddenAppsChecker"));
const rorLoggerFactory_1 = require("../../../../core/logging/rorLoggerFactory");
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
class ObservabilityTransformer {
    static transform(cap, metadata) {
        const observabilityOverviewBasedCaps = [
            'Observability|Observability',
            'Observability|Overview',
            'Observability|Alerts',
            'Observability|Cases',
            'Observability|SLOs'
        ];
        const isRegexNegation = /\(\?!\(.*(Observability|Alerts|Overview|Cases|SLOs).*\)/;
        if (observabilityOverviewBasedCaps.some(observabilityOverviewBasedCap => metadata.kibanaHiddenApps.some(kibanaHiddenApp => isRegexNegation.test(kibanaHiddenApp)
            ? false
            : (0, hiddenAppsChecker_1.default)(kibanaHiddenApp, observabilityOverviewBasedCap, logger)))) {
            (0, index_1.overridePropertiesByJsonPath)(cap, ['navLinks.observability-overview'], () => false);
        }
        else {
            (0, index_1.overridePropertiesByJsonPath)(cap, ['navLinks.observability-overview'], () => true);
        }
        return cap;
    }
}
exports.ObservabilityTransformer = ObservabilityTransformer;
