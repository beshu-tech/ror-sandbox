"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ROUserTransformer = void 0;
// eslint-disable-next-line import/no-cycle
const index_1 = require("../index");
const accessLevel_1 = require("../../../../core/common/accessLevel");
const NON_RO_OP_MATCHER = /.*create.*|.*write.*|.*save.*|.*edit.*|.*delete.*|.*update.*|.*manage.*|.*copy.*|shareIntoSpace|.*crud.*/i;
const MANAGEMENT_WHITELIST = /indexPatterns|objects|reporting|dataViews/;
class ROUserTransformer {
    static transform(cap, metadata) {
        if (accessLevel_1.AccessLevel.RO !== metadata.kibanaAccess && accessLevel_1.AccessLevel.RO_STRICT !== metadata.kibanaAccess) {
            return cap;
        }
        for (const entry in cap) {
            if (entry === 'catalogue' || entry === 'navLinks' || entry === 'management') {
                continue;
            }
            (0, index_1.mutateAllCapabilitiesInObject)(cap[entry], e => !NON_RO_OP_MATCHER.test(e));
        }
        const { management } = cap;
        for (const i in management) {
            if (Object.prototype.hasOwnProperty.call(management, i)) {
                (0, index_1.mutateAllCapabilitiesInObject)(management[i], e => MANAGEMENT_WHITELIST.test(e));
            }
        }
        (0, index_1.mutateAllCapabilitiesInObject)(cap.savedObjectsManagement, () => false);
        (0, index_1.overridePropertiesByJsonPath)(cap, ['catalogue.advanced_settings', 'fileUpload.show', 'navLinks.ingestManager'], () => false);
        return cap;
    }
}
exports.ROUserTransformer = ROUserTransformer;
