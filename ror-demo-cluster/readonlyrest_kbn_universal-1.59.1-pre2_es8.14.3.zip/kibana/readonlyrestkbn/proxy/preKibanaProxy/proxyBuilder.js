"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProxyBuilder = void 0;
const express_http_proxy_1 = __importDefault(require("express-http-proxy"));
const dns_1 = __importDefault(require("dns"));
const authorizationHeaderBuilder_1 = require("../core/authorization/authorizationHeaderBuilder");
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
const kibanaAppsRegistry_1 = require("./kibana_apps/kibanaAppsRegistry");
const CapabilitiesApiFilter_1 = require("./injection/capabilities/CapabilitiesApiFilter");
const requestHeadersWhitelistApplier_1 = require("../core/common/requestHeadersWhitelistApplier");
const distributionInfoProvider_1 = require("../../kibana/patchers/distributionInfoProvider");
const ActivationKey_1 = require("../core/license/ActivationKey");
const types_1 = require("../core/common/types");
if (dns_1.default.setDefaultResultOrder) {
    /*
     * From node 17 version ipv6 is favored over ipv4 https://github.com/nodejs/node/issues/40537 which break Kibana win the ECK https://readonlyrest.atlassian.net/browse/RORDEV-1031
     * Since dns node module is introduced in the v16.4.0 and v14.18.0, we need to check if the module is available because lower versions of the Kibana like 7.9.0 use Node 10.x
     */
    dns_1.default.setDefaultResultOrder('ipv4first');
}
class ProxyBuilder {
    kibanaUrl;
    pkpKibanaToken;
    requestHeadersWhitelist;
    htmlInjector;
    kibanaBasePath;
    rewriteBasePath;
    authController;
    spacesEnabled;
    licenseService;
    cookieManager;
    multiTenancyEnabled;
    kibanaIndex;
    static logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    authorizationHeaderBuilder;
    constructor(kibanaUrl, pkpKibanaToken, requestHeadersWhitelist, htmlInjector, kibanaBasePath, rewriteBasePath, authController, spacesEnabled, licenseService, cookieManager, multiTenancyEnabled, kibanaIndex) {
        this.kibanaUrl = kibanaUrl;
        this.pkpKibanaToken = pkpKibanaToken;
        this.requestHeadersWhitelist = requestHeadersWhitelist;
        this.htmlInjector = htmlInjector;
        this.kibanaBasePath = kibanaBasePath;
        this.rewriteBasePath = rewriteBasePath;
        this.authController = authController;
        this.spacesEnabled = spacesEnabled;
        this.licenseService = licenseService;
        this.cookieManager = cookieManager;
        this.multiTenancyEnabled = multiTenancyEnabled;
        this.kibanaIndex = kibanaIndex;
        this.authorizationHeaderBuilder = new authorizationHeaderBuilder_1.AuthorizationHeaderBuilder(multiTenancyEnabled, kibanaIndex);
    }
    build() {
        // #HACK from https://github.com/villadora/express-http-proxy/issues/127#issuecomment-491996594
        // Needed for addressing RORDEV-502
        const isMultipartRequest = req => {
            const contentTypeHeader = req.headers['content-type'];
            return contentTypeHeader?.indexOf('multipart') > -1;
        };
        return (req, res, next) => {
            const proxyOptions = {
                parseReqBody: !isMultipartRequest(req),
                https: false,
                preserveHostHdr: true,
                // @ts-ignore
                proxyReqOptDecorator: this.authorizationHeaderDecorator,
                // @ts-ignore
                proxyReqPathResolver: distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('7.11.0')
                    ? undefined
                    : this.addDefaultSpaceInRequestPath,
                // @ts-ignore
                userResDecorator: this.interceptResponse,
                // @ts-ignore
                proxyErrorHandler: this.proxyErrorHandler,
                limit: '500gb'
            };
            // @ts-ignore
            return (0, express_http_proxy_1.default)(this.kibanaUrl, proxyOptions)(req, res, next);
        };
    }
    static isResponseValidHTML(response, responseData) {
        return (response.headers['content-type'] &&
            response.headers['content-type'].toString().includes('html') &&
            responseData.toString().includes('<head>') &&
            responseData.toString().includes('<body>'));
    }
    authorizationHeaderDecorator = async (proxyRequestOptions, sourceRequest) => {
        console.log('pkp call', sourceRequest.url, sourceRequest.headers);
        if (!proxyRequestOptions.headers) {
            proxyRequestOptions.headers = {};
        }
        // It fixed the ECONNREFUSED socket hang up issue in the case of Elasticsearch calls. This issue is probably caused by the Node 20.x version, which is used starting from Kibana 7.17.17. By default, the connection header has the value 'close'. It is a similar problem to the one mentioned here https://github.com/node-fetch/node-fetch/issues/1735.
        proxyRequestOptions.headers.connection = 'keep-alive';
        proxyRequestOptions.headers['keep-alive'] = 'timeout=10, max=1000';
        requestHeadersWhitelistApplier_1.RequestHeadersWhitelistApplier.apply(ProxyBuilder.logger, this.requestHeadersWhitelist, sourceRequest.headers, proxyRequestOptions.headers);
        proxyRequestOptions.headers['x-ror-pkp-kibana-token'] = this.pkpKibanaToken;
        const sourceResponseHeaders = sourceRequest.res?.getHeaders();
        if (sourceResponseHeaders?.['set-cookie']) {
            const cookie = this.cookieManager.parseCookieHeader(sourceResponseHeaders['set-cookie'].toString())?.[this.cookieManager.cookieConfig.name];
            proxyRequestOptions.headers.cookie = `${this.cookieManager.cookieConfig.name}=${cookie}`;
        }
        const activationKey = this.licenseService.getActivationKey();
        proxyRequestOptions.headers.Authorization =
            await this.authorizationHeaderBuilder.prepareAuthorizationHeaderFromRequest(sourceRequest.rorRequest, activationKey);
        proxyRequestOptions.headers[types_1.X_ROR_KIBANA_INDEX] =
            (0, ActivationKey_1.isEnterpriseLicense)(activationKey.license) && this.multiTenancyEnabled
                ? sourceRequest.rorRequest.getIdentitySession()?.metadata.kibanaIndex || this.kibanaIndex
                : this.kibanaIndex;
        return proxyRequestOptions;
    };
    addDefaultSpaceInRequestPath = async (sourceRequest) => {
        const url = sourceRequest.rorRequest.getUrl();
        if (!this.spacesEnabled) {
            return url;
        }
        if (url.includes('/s/') || url.includes('/spaces/space_selector')) {
            return url;
        }
        if (this.kibanaBasePath && this.rewriteBasePath) {
            const urlWithoutBasePath = url.replace(this.kibanaBasePath, '');
            return `${this.kibanaBasePath}/s/default${urlWithoutBasePath}`;
        }
        return `/s/default${url}`;
    };
    interceptResponse = async (proxyResponse, proxyResData, userReq, userRes) => {
        if (userRes.statusCode === 500) {
            const parsedData = proxyResData.length > 0 ? JSON.parse(proxyResData.toString()) : proxyResData;
            const urlsToPerformLogout = ['/', '/spaces/space_selector'];
            ProxyBuilder.logger.info(`Receiving 500 error from Kibana response with a data: ${proxyResData.toString()}, from url: ${userReq.url} and requested from address: ${userReq.headers.referer}`);
            // It handles this particular case https://readonlyrest.atlassian.net/browse/RORDEV-677
            if (urlsToPerformLogout.some(urlToPerformLogout => urlToPerformLogout.includes(userReq.url)) &&
                parsedData.statusCode === 500 &&
                parsedData.error === 'Internal Server Error') {
                const message = 'Kibana returned an error status and the session is finished. There is probably something wrong with your configuration files and the ReadonlyREST Elasticsearch security plugin for Kibana could not work properly.';
                ProxyBuilder.logger.error(message);
                await this.authController.handleLogout(userReq, userRes);
                throw new Error(message);
            }
        }
        // RORDEV-693: Prevent showing basic auth prompt in Kibana even when `prompt_for_basic_auth: true`
        if (userRes.getHeader('www-authenticate')) {
            userRes.removeHeader('www-authenticate');
        }
        if (CapabilitiesApiFilter_1.CapabilitiesApiFilter.shouldInterceptResponseBody(userReq)) {
            return CapabilitiesApiFilter_1.CapabilitiesApiFilter.interceptResponseBody(userReq, proxyResData);
        }
        if (ProxyBuilder.isResponseValidHTML(proxyResponse, proxyResData)) {
            const hiddenAppNames = userReq.rorRequest.extractHiddenAppsNames();
            if (!kibanaAppsRegistry_1.KibanaAppsRegistry.isNavigationAllowed(userReq.path, hiddenAppNames)) {
                ProxyBuilder.logger.info(`Attempted navigation to prohibited path ${userReq.path}`);
                userRes.redirect('/'); // #TODO add path prefix when implemented
                return proxyResData;
            }
            return this.htmlInjector.injectCssAndJsScriptsIntoHtml(proxyResData);
        }
        return proxyResData;
    };
    proxyErrorHandler = (error, res, next) => {
        ProxyBuilder.logger.trace('PreKibanaProxy error ', error);
        next(error);
    };
}
exports.ProxyBuilder = ProxyBuilder;
