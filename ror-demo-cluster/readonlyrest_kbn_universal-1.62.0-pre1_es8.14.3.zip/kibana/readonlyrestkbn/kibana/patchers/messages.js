"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.messages = void 0;
const helpers_1 = require("./helpers");
const path_1 = require("path");
const docsUpgradePluginUrl = 'https://docs.readonlyrest.com/kibana#upgrading';
exports.messages = {
    unableToRetrieveRorVersion: `Unable to retrieve the ReadonlyREST plugin version for which the file was patched. Please ensure all steps in the upgrade guide have been followed: ${docsUpgradePluginUrl}.`,
    metadataInfo: (destinationFilePath, rorVersion, kibanaVersion, patchingDate) => `${destinationFilePath} was patched with the ReadonlyREST plugin version ${rorVersion} and Kibana version ${kibanaVersion} on ${(0, helpers_1.formatDate)(new Date(patchingDate))}.`,
    mismatchRorVersionInfo: (patchedRorVersion, runningRorVersion) => `Kibana has been patched with ROR Patcher for the ReadonlyREST ${patchedRorVersion}, and you're currently running version ${runningRorVersion}. Please make sure you’ve followed all the steps in the upgrade guide to ensure a successful update: ${docsUpgradePluginUrl}.`,
    kibanaAlreadyPatched: 'Kibana has already been patched.',
    missingBackup: (sourceFile) => `NO_BACKUP: Unable to verify the patched status of ${sourceFile} as the backup file is missing. Please try patching Kibana again.`,
    kibanaNotPatched: (sourceFile) => `${(0, path_1.basename)(sourceFile)} patch status: NOT_PATCHED. The backup file is identical to the patched file. Please try patching Kibana again.`,
    patchOutdated: (sourceFile) => `${(0, path_1.basename)(sourceFile)} patch status: OUTDATED. It needs to be unpatched and patched again.`,
    patchVerified: (sourceFile) => `${(0, path_1.basename)(sourceFile)} patch status: VERIFIED.`,
    failedToApplyPatch: (patchFilePath, sourceFile) => `Failed to apply patch ${(0, path_1.basename)(patchFilePath)} to ${sourceFile}. Please ensure all steps in the upgrade guide have been followed: ${docsUpgradePluginUrl}. If the problem persists, try to reinstall Kibana and apply the patch again`,
    backupFileNotApplied: 'Backup file not found: assuming patch was not applied. Please try patching Kibana again.'
};
