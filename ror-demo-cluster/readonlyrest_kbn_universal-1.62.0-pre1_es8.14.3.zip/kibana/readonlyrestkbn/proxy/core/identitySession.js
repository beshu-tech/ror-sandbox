"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdentitySessionMetadataDifferenceChecker = void 0;
const lodash_1 = require("lodash");
class IdentitySessionMetadataDifferenceChecker {
    static isDifferent(m1, m2) {
        return !(m1.username === m2.username &&
            m1.kibanaAccess === m2.kibanaAccess &&
            (0, lodash_1.isEqual)(m1.currentGroup, m2.currentGroup) &&
            m1.kibanaIndex === m2.kibanaIndex &&
            IdentitySessionMetadataDifferenceChecker.areGroupsEqual(m1.availableGroups, m2.availableGroups) &&
            IdentitySessionMetadataDifferenceChecker.isEqual(m1.kibanaHiddenApps, m2.kibanaHiddenApps));
    }
    static isMissingMetadata(nesSession) {
        return !nesSession.username;
    }
    static isEqual(a1, a2) {
        return (0, lodash_1.isEqual)(Array.from(a1).sort(), Array.from(a2).sort());
    }
    static areGroupsEqual(a1, a2) {
        const compareFn = (g1, g2) => g1.id.localeCompare(g2.id);
        return (0, lodash_1.isEqual)(Array.from(a1).sort(compareFn), Array.from(a2).sort(compareFn));
    }
}
exports.IdentitySessionMetadataDifferenceChecker = IdentitySessionMetadataDifferenceChecker;
