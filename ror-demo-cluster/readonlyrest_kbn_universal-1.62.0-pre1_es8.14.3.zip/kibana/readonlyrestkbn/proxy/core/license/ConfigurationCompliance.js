"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigurationCompliance = void 0;
const rorLoggerFactory_1 = require("../logging/rorLoggerFactory");
const ActivationKey_1 = require("./ActivationKey");
const configUtils_1 = require("../../../kibana/config/configUtils");
class ConfigurationCompliance {
    activationKey;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    isFree;
    isEnterprise;
    constructor(activationKey) {
        this.activationKey = activationKey;
        this.isFree = (0, ActivationKey_1.isFreeLicense)(this.activationKey.license);
        this.isEnterprise = (0, ActivationKey_1.isEnterpriseLicense)(this.activationKey.license);
        this.logger.info(`ConfigurationCompliance: isFree=${this.isFree}, isEnterprise=${this.isEnterprise}`);
    }
    verify(enterpriseOnly, nonFreeOnly) {
        const errors = [];
        enterpriseOnly.forEach(rule => {
            const error = this.enterpriseOnly(rule.message, rule.value);
            if (error) {
                errors.push(error);
            }
        });
        nonFreeOnly.forEach(rule => {
            const error = this.nonFreeOnly(rule.message, rule.value);
            if (error) {
                errors.push(error);
            }
        });
        if (errors.length > 0) {
            this.logger.error(`FATAL: Current Activation Key is for a "${this.activationKey.license.edition_name}" license. Your kibana.yml enables features that are not available at this subscription level. You can upgrade to an Enterprise license at https://readonlyrest.com`);
            errors.forEach(error => this.logger.error(error));
            (0, configUtils_1.exitInOneSecond)();
        }
    }
    enterpriseOnly(featureName, value) {
        if (this.isEnterprise) {
            return null;
        }
        return this.hasValue(value, `"${featureName}" is only available for Enterprise subscribers.`);
    }
    hasValue(value, message) {
        const err = `❌ ${message}`;
        if (Array.isArray(value)) {
            return value.length > 0 ? err : null;
        }
        return value ? err : null;
    }
    nonFreeOnly(featureName, value) {
        if (!this.isFree) {
            return null;
        }
        return this.hasValue(value, `"${featureName}" is only available for PRO and Enterprise subscribers.`);
    }
}
exports.ConfigurationCompliance = ConfigurationCompliance;
