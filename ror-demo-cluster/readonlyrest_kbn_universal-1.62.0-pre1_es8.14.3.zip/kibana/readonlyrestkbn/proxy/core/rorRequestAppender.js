"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RorRequestAppender = void 0;
const rorRequestCreator_1 = require("./rorRequest/rorRequestCreator");
// Ultimately we should attach just the session to the Express request, so this class can then be called RequestSessionAppender
class RorRequestAppender {
    sessionManager;
    cookieManager;
    constructor(sessionManager, cookieManager) {
        this.sessionManager = sessionManager;
        this.cookieManager = cookieManager;
    }
    static appendRorRequest(req, res, next) {
        req.rorRequest = rorRequestCreator_1.RorRequestCreator.fromExpressRequest(req);
        next();
    }
    appendIdentitySession = async (req, res, next) => {
        if (!(await this.hasValidSession(req.rorRequest))) {
            next();
            return;
        }
        const identitySession = await this.getIdentitySession(req.rorRequest);
        req.rorRequest.setIdentitySession(identitySession);
        next();
    };
    async hasValidSession(request) {
        const sid = await this.cookieManager.decryptRorCookieFromHeader(request.getCookies());
        return Boolean(sid && (await this.sessionManager.exists(sid)) && !(await this.sessionManager.isSessionExpired(sid)));
    }
    async getIdentitySession(request) {
        const sid = await this.cookieManager.decryptRorCookieFromHeader(request.getCookies());
        if (sid == null) {
            return;
        }
        const identitySessionMetadata = await this.sessionManager.get(sid);
        if (identitySessionMetadata == null) {
            return;
        }
        return {
            sid,
            metadata: identitySessionMetadata
        };
    }
}
exports.RorRequestAppender = RorRequestAppender;
