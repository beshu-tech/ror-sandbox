"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.InfoController = void 0;
const identity_1 = require("../../identity");
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const distributionInfoProvider_1 = require("../../../../kibana/patchers/distributionInfoProvider");
const ActivationKey_1 = require("../../../core/license/ActivationKey");
class InfoController {
    licenseService;
    constructor(licenseService) {
        this.licenseService = licenseService;
    }
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    async handleGet(req, res) {
        const identitySession = req.getIdentitySession();
        if (!identitySession) {
            return;
        }
        const metadata = identitySession.metadata;
        const license = this.licenseService.getActivationKey().license;
        const isEnt = (0, ActivationKey_1.isEnterpriseLicense)(license);
        const isFree = (0, ActivationKey_1.isFreeLicense)(license);
        const identity = new identity_1.Identity(metadata.username, isFree ? [] : metadata.kibanaHiddenApps, metadata.kibanaAccess, isEnt ? metadata.currentGroup : undefined, isEnt ? metadata.availableGroups : [], metadata.impersonatedBy, metadata.correlationId);
        this.logger.trace('returning identity metadata ', JSON.stringify(identity, null, 2));
        return res.json({
            identity,
            licenseInfo: this.licenseService.getLicenseInfo(),
            distribution: distributionInfoProvider_1.DistributionInfoProvider.getInstance().toJsonObject(),
            cluster_uuid: this.licenseService.getClusterUUID()
        });
    }
}
exports.InfoController = InfoController;
