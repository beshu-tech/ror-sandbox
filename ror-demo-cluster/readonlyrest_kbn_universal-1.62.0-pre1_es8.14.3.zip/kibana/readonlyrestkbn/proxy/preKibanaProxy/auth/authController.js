"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const rorRequest_1 = require("../../core/rorRequest/rorRequest");
const rorRequestCreator_1 = require("../../core/rorRequest/rorRequestCreator");
const rorLoggerFactory_1 = require("../../core/logging/rorLoggerFactory");
const types_1 = require("../../core/common/types");
const cookieManager_1 = require("../../core/cookieManager");
const identitySession_1 = require("../../core/identitySession");
const errors_1 = __importDefault(require("../../constants/errors"));
const csrf_1 = require("./csrf");
class AuthController {
    kibanaBasePath;
    proxyAuth;
    authenticationFacade;
    logoutLinkProvider;
    auditLogEmitter;
    cookieConfig;
    probeIntervalMillis;
    getKibanaIndex;
    jwtQueryParam;
    customLoginLink;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    pathsOkForEmbeddedAuth;
    constructor(kibanaBasePath, proxyAuth, authenticationFacade, logoutLinkProvider, auditLogEmitter, cookieConfig, probeIntervalMillis, withBasePath, getKibanaIndex, jwtQueryParam, customLoginLink) {
        this.kibanaBasePath = kibanaBasePath;
        this.proxyAuth = proxyAuth;
        this.authenticationFacade = authenticationFacade;
        this.logoutLinkProvider = logoutLinkProvider;
        this.auditLogEmitter = auditLogEmitter;
        this.cookieConfig = cookieConfig;
        this.probeIntervalMillis = probeIntervalMillis;
        this.getKibanaIndex = getKibanaIndex;
        this.jwtQueryParam = jwtQueryParam;
        this.customLoginLink = customLoginLink;
        this.pathsOkForEmbeddedAuth = new RegExp(`^${withBasePath('(/s/.*/api/.*|/api/.*|/pkp/api/.*)')}`);
    }
    handleExternalSourceAuth = async (req, res, next) => {
        if (req.rorRequest.isAuthenticated()) {
            return next();
        }
        const forwardedAuthValue = req.headers[this.proxyAuth.forward_auth_header];
        const forwardedAuthProxyConfigured = forwardedAuthValue != null && this.proxyAuth.enabled;
        const jwtAuthConfigured = req.query[this.jwtQueryParam?.value];
        if (!forwardedAuthProxyConfigured && !jwtAuthConfigured) {
            return next();
        }
        try {
            const [encryptedCookie, identitySession] = await this.authenticationFacade.authorizeRequest(req.rorRequest);
            if (!(await this.verifyUserAccessAfterAuthorization(req, res, identitySession.metadata.authorizationHeaders, identitySession.metadata.kibanaIndex)) ||
                !(await this.verifyUserApiOnlyAccess(req, res, identitySession.metadata.kibanaAccess))) {
                return;
            }
            req.rorRequest.setIdentitySession(identitySession);
            res.cookie(this.cookieConfig.name, encryptedCookie, cookieManager_1.CookieManager.getCookiesOptions({ secure: this.cookieConfig.secure, sameSite: this.cookieConfig.sameSite }));
        }
        catch (e) {
            this.logger.info(`Could not authorize through external source: ${e.message}`);
        }
        next();
    };
    redirectAuthenticated = async (req, res, next) => {
        if (req.query && req.query[types_1.AUTOLOGIN_QUERY_PARAM] === 'false') {
            next();
            return;
        }
        if (req.rorRequest.isAuthenticated()) {
            res.redirect(this.getNextUrl(req) || this.withBasePath('/'));
            return;
        }
        next();
    };
    handleCustomLoginRedirection = async (req, res, next) => {
        if (this.customLoginLink != null) {
            res.redirect(this.customLoginLink);
            return;
        }
        next();
    };
    handleAuthentication = async (req, res, handleSuccess, handleError) => {
        // body is never parsed, unless it hits LoginPost hence the need to rebuild the rorRequest
        req.rorRequest = rorRequestCreator_1.RorRequestCreator.fromExpressRequest(req);
        try {
            const [encryptedCookie, identitySession] = await this.authenticationFacade.authorizeRequest(req.rorRequest);
            if (!identitySession.metadata.username) {
                throw new Error('EMPTY_METADATA');
            }
            return handleSuccess(encryptedCookie, identitySession);
        }
        catch (e) {
            return handleError(res, e);
        }
    };
    handleAuthenticationDirectRequestWithCredentials = async (req, res, handleSuccess, handleError) => {
        // body is never parsed, unless it hits LoginPost hence the need to rebuild the rorRequest
        req.rorRequest = rorRequestCreator_1.RorRequestCreator.fromExpressRequest(req);
        try {
            const [encryptedCookie, identitySession] = await this.authenticationFacade.authorizeDirectRequestWithCredentials(req.rorRequest);
            if (!identitySession.metadata.username) {
                throw new Error('EMPTY_METADATA');
            }
            return handleSuccess(encryptedCookie, identitySession);
        }
        catch (e) {
            return handleError(res, e);
        }
    };
    handleAuthenticationError = (res, e) => {
        res.status(401);
        res.setHeader('Content-Type', 'application/json');
        if (e.message === 'EMPTY_METADATA') {
            this.logger.error('There is a problem with the ACL configuration. The login request is checked by the ACL and gets accepted by an ACL block with no authentication rule in it. Check documentation  https://docs.readonlyrest.com/kibana#no-authentication-rule-defined for more references');
        }
        else {
            this.logger.info(`Could not login in: ${e.message}`);
        }
        return res.json({ message: 'Wrong credentials' });
    };
    handleLoginPost = async (req, res) => {
        const handleSuccess = async (encryptedCookie, identitySession) => {
            if (!(await this.verifyUserAccessAfterAuthorization(req, res, identitySession.metadata.authorizationHeaders, identitySession.metadata.kibanaIndex)) ||
                !(await this.verifyUserApiOnlyAccess(req, res, identitySession.metadata.kibanaAccess))) {
                return;
            }
            const redirectUrl = this.getNextUrl(req) || this.withBasePath('/');
            res.clearCookie(types_1.NEXT_URL);
            csrf_1.Csrf.clearCookie(res);
            res.cookie(this.cookieConfig.name, encryptedCookie, cookieManager_1.CookieManager.getCookiesOptions({ secure: this.cookieConfig.secure, sameSite: this.cookieConfig.sameSite }));
            res.setHeader('Content-Type', 'application/json');
            this.logger.debug(`login request granted: username: ${identitySession.metadata.username}, groups: [${JSON.stringify(identitySession.metadata.availableGroups)}]`);
            return res.json({ nextUrl: redirectUrl });
        };
        await this.handleAuthentication(req, res, handleSuccess, (res, errors) => {
            this.logRejectedLoginUsername(req);
            return this.handleAuthenticationError(res, errors);
        });
    };
    handleApiReqWithCredentialsOnboard = async (req, res, next) => {
        if ((!this.pathsOkForEmbeddedAuth.test(req.path) && req.query.jwt == null) ||
            req.rorRequest.isCookiePresent(this.cookieConfig.name) ||
            req.rorRequest.getHeaders()['user-agent'].includes('Elastic-apm-server')) {
            return next();
        }
        const handleSuccess = (encryptedCookie, identitySession) => {
            req.rorRequest.setIdentitySession(identitySession);
            return next();
        };
        return this.handleAuthenticationDirectRequestWithCredentials(req, res, handleSuccess, this.handleAuthenticationError);
    };
    handleLogout = async (req, res) => {
        const logoutUrl = this.getLogoutRedirectUrl(req.rorRequest);
        const message = req.query.message;
        const logoutUrlWithNextUrl = AuthController.setUrlParams(logoutUrl, this.kibanaBasePath, this.getNextUrl(req), message);
        await this.authenticationFacade.clearSession(req.rorRequest);
        await this.handleLogoutEvent(req.rorRequest);
        req.rorRequest.setIdentitySession(undefined);
        res.clearCookie(this.cookieConfig.name);
        res.clearCookie(`${this.cookieConfig.name}-SP`);
        res.redirect(logoutUrlWithNextUrl);
    };
    handleSessionProbe = async (req, res) => {
        res.setHeader('Content-Type', 'application/json');
        const impersonatedBy = req.rorRequest.getIdentitySession()?.metadata.impersonatedBy;
        const { rorRequest } = req;
        if (impersonatedBy) {
            const impersonateAs = req.rorRequest.getIdentitySession()?.metadata.username ?? '';
            const checkImpersonateResponse = await this.authenticationFacade.checkImpersonationStatus(req.rorRequest, impersonateAs);
            if (checkImpersonateResponse.status === 401 || checkImpersonateResponse.status === 403) {
                await this.authenticationFacade.finishImpersonation(req.rorRequest, res);
                this.logger.info('Ttl is reached');
                res.status(401);
                res.json({ message: 'Ttl is reached' });
                return;
            }
        }
        if (!rorRequest.isAuthenticated()) {
            this.logger.info('No valid session');
            res.status(401);
            res.json({ message: 'No valid session' });
            return;
        }
        const isSessionTimeout = await this.authenticationFacade.verifySessionTimeout(rorRequest);
        if (isSessionTimeout) {
            this.logger.info('Session timeout');
            res.status(401);
            res.json({ message: 'Session timeout' });
            return;
        }
        try {
            this.logger.info('Refreshing session against ES');
            const currentSession = rorRequest.getIdentitySession();
            if (!currentSession) {
                this.logger.error('Current session is not available');
                return;
            }
            const newSession = await this.authenticationFacade.refreshSessionAgainstEs(currentSession);
            await this.handleNewSession(currentSession, newSession, res);
        }
        catch (e) {
            this.logger.info(`Could not refresh the session against ES: + ${e.message}`);
            res.status(401);
            res.json({ message: 'Session no longer valid' });
        }
    };
    handleNewSession(currentSession, newSession, res) {
        if (identitySession_1.IdentitySessionMetadataDifferenceChecker.isMissingMetadata(newSession.metadata)) {
            this.logger.info('Missing metadata');
            res.status(401);
            res.json({ message: 'Missing metadata' });
            return;
        }
        if (identitySession_1.IdentitySessionMetadataDifferenceChecker.isDifferent(currentSession.metadata, newSession.metadata)) {
            this.logger.info('Significant session change detected');
            this.logger.debug(`Current sessionMetadata: ${JSON.stringify(currentSession.metadata)}`);
            this.logger.debug(`New sessionMetadata: ${JSON.stringify(newSession.metadata)}`);
            res.status(200);
            res.json({
                message: 'Session updated',
                reload: true,
                intervalMillis: this.probeIntervalMillis
            });
            return;
        }
        res.status(200);
        res.json({ message: 'Session valid', reload: false, intervalMillis: this.probeIntervalMillis });
    }
    async redirectUnauthenticated(req, res, next) {
        if (!req.rorRequest.isAuthenticated()) {
            const redirectUrl = this.withBasePath('/logout');
            const nextUrlParam = req.originalUrl;
            if (nextUrlParam.includes('/logout') || nextUrlParam.includes('/login')) {
                this.logger.error('There is a problem with handling this request. If you use reverse proxy and server.rewriteBasePath is set into a false, check the documentation for more information https://docs.readonlyrest.com/kibana#using-ror-with-a-reverse-proxy');
                res.sendStatus(400);
                return;
            }
            const redirectUrlWithNextUrl = AuthController.setUrlParams(redirectUrl, this.kibanaBasePath, nextUrlParam);
            res.redirect(redirectUrlWithNextUrl);
            return;
        }
        next();
    }
    async refreshSession(req, res, next) {
        try {
            if ((!this.pathsOkForEmbeddedAuth.test(req.path) && req.query.jwt == null) ||
                req.rorRequest.isCookiePresent(this.cookieConfig.name)) {
                await this.authenticationFacade.refreshSession(req.rorRequest);
            }
            next();
        }
        catch (e) {
            this.logger.error('Error during a session refresh:', e);
            await this.handleLogout(req, res);
        }
    }
    async handleLogoutEvent(request) {
        const origin = request.getParams()[types_1.X_ROR_ORIGIN] || 'N/A';
        if (request.isAuthenticated()) {
            await this.auditLogEmitter.emitLogoutEvent(request.getAuthorizationHeaders(), origin);
        }
    }
    getLogoutRedirectUrl(request) {
        const identitySession = request.getIdentitySession();
        const identitySessionMetadata = identitySession?.metadata;
        return this.logoutLinkProvider.buildLogoutLink(identitySessionMetadata);
    }
    static setUrlParams(url, kibanaBasePath, nextUrlParam, message) {
        const urlSearchParams = new URLSearchParams();
        if (nextUrlParam) {
            /**
             * It can be a situation that kibanaBasePath is removed from nextUrlParam, for example when server.rewriteBasePath is set on false
             * and reverse proxy remove basePath
             */
            if (!nextUrlParam.startsWith(kibanaBasePath)) {
                nextUrlParam = kibanaBasePath + nextUrlParam;
            }
            urlSearchParams.set(types_1.NEXT_URL, nextUrlParam);
        }
        if (message) {
            urlSearchParams.set(types_1.MESSAGE_QUERY_PARAM, message);
        }
        return Array.from(urlSearchParams).length > 0 ? `${url}?${urlSearchParams}` : url;
    }
    getNextUrl(request) {
        let nextUrl = request.query && request.query[types_1.NEXT_URL];
        // Avoid nonsense nextUrls
        if (!nextUrl || nextUrl.indexOf('ror_kbn_') >= 0 || nextUrl.indexOf('/logout') >= 0) {
            return;
        }
        /**
         * Avoid issue when you open the kibana app in a browser, and you are redirected to https://localhost:5601/login?nextUrl=%2F
         * But your basePath is for example /kibana, we need to add it manually before nextUrl open
         */
        const isNextUrlWithoutPathname = nextUrl === '/' || nextUrl === '';
        if (isNextUrlWithoutPathname) {
            nextUrl = this.withBasePath(nextUrl);
        }
        this.logger.trace(`NextUrl in param: ${nextUrl}`);
        return nextUrl;
    }
    withBasePath = path => this.kibanaBasePath + path;
    logRejectedLoginUsername(req) {
        let username = '';
        const body = req.rorRequest.getBody();
        const jwtToken = body?.[types_1.CONNECTOR_SVC_TRANSIENT_JWT];
        const forwardedUser = req.headers[types_1.X_FORWARDED_USER];
        if ((0, rorRequest_1.isLoginFormBody)(body)) {
            username = body.username;
        }
        else if (jwtToken) {
            const parsedJWT = JSON.parse(Buffer.from(jwtToken.split('.')[1], 'base64').toString());
            username = parsedJWT.user;
        }
        else if (typeof forwardedUser === 'string') {
            username = forwardedUser;
        }
        this.logger.debug(`login request rejected: username: ${username}`);
    }
    async verifyUserApiOnlyAccess(req, res, kibanaAccess) {
        if (kibanaAccess === 'api_only') {
            this.logRejectedLoginUsername(req);
            this.handleAuthenticationError(res, new Error('api_only Kibana access type user cannot log in to the Kibana.'));
            return false;
        }
        return true;
    }
    async verifyUserAccessAfterAuthorization(req, res, authorizationHeaders, kibanaIndexFromSession) {
        const responseSpace = await this.authenticationFacade.verifyUserAccess(authorizationHeaders, this.getKibanaIndex(kibanaIndexFromSession));
        if (responseSpace.status !== 200) {
            this.logRejectedLoginUsername(req);
            this.handleAuthenticationError(res, new Error('There is a problem with authorization, default space is not available.'));
            return false;
        }
        return true;
    }
    async verifyAccessLevel(req, res, next, requiredAccessLevels) {
        const accessLevel = await this.authenticationFacade.getAccessLevel(req);
        if (requiredAccessLevels.some(requiredAccessLevel => requiredAccessLevel === accessLevel)) {
            return next();
        }
        return res.status(403).send({
            status: 'FORBIDDEN',
            message: errors_1.default.inSufficientPermissions
        });
    }
}
exports.AuthController = AuthController;
