"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TemplateIndexSurplusRemover = void 0;
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
class TemplateIndexSurplusRemover {
    esClient;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(esClient) {
        this.esClient = esClient;
    }
    async removeFromTargetDocumentsMissingInTemplate(numberOfDocumentsInTemplate, tenantIndex, templateIndex) {
        this.logger.info(`Looking for documents present in '${tenantIndex}' but not in template index`);
        const allDocumentsInTarget = await this.retrieveAllDocumentsFrom(tenantIndex);
        const surplus = await this.identifySurplus(numberOfDocumentsInTemplate, tenantIndex, allDocumentsInTarget, templateIndex);
        return this.removeSurplusFrom(tenantIndex, surplus);
    }
    retrieveAllDocumentsFrom(tenantIndex) {
        return this.esClient
            .getAsKibana(`${tenantIndex}/_search`)
            .then(response => response.json())
            .then((json) => {
            this.logger.trace('Response: ', JSON.stringify(json));
            return json;
        })
            .then(json => json.hits.hits.map(hit => hit._id));
    }
    async identifySurplus(numberOfDocumentsInTemplate, tenantIndex, allDocumentsInTarget, templateIndex) {
        if (allDocumentsInTarget.length === numberOfDocumentsInTemplate) {
            this.logger.info(`All documents in '${templateIndex}' match documents in '${tenantIndex}'. Nothing to remove.`);
            return Promise.resolve([]);
        }
        this.logger.info(`Target '${tenantIndex}' contains ${allDocumentsInTarget.length} documents but '${templateIndex}' contains ${numberOfDocumentsInTemplate}. Need to delete surplus.`);
        return Promise.all(allDocumentsInTarget.map(this.verifyDocumentExistsIn(templateIndex))).then(documents => documents.filter(document => !document.exists).map(document => document.id));
    }
    verifyDocumentExistsIn = (index) => (documentId) => this.esClient
        .headAsKibana(`${index}/_doc/${documentId}`)
        .then(response => response.status)
        .then(status => ({ id: documentId, exists: status === 200 }));
    removeSurplusFrom(index, surplus) {
        Promise.all(surplus.map(documentId => {
            this.logger.debug(`Deleting document with id: '${documentId}'`);
            return this.esClient.deleteAsKibana(`${index}/_doc/${documentId}`);
        }));
    }
}
exports.TemplateIndexSurplusRemover = TemplateIndexSurplusRemover;
