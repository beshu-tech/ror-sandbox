"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArrowLeftIcon = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
function ArrowLeftIcon({ title = '', titleId = '', fill, ...props }) {
    return ((0, jsx_runtime_1.jsxs)("svg", { xmlns: "http://www.w3.org/2000/svg", height: "24px", viewBox: "0 0 24 24", width: "24px", fill: fill, "aria-labelledby": titleId, ...props, children: [title ? (0, jsx_runtime_1.jsx)("title", { id: titleId, children: title }) : null, (0, jsx_runtime_1.jsx)("path", { d: "M14 7l-5 5 5 5V7z" }), (0, jsx_runtime_1.jsx)("path", { d: "M24 0v24H0V0h24z", fill: "none" })] }));
}
exports.ArrowLeftIcon = ArrowLeftIcon;
