"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.plugin = void 0;
const plugin_1 = require("./plugin");
// This exports static code and TypeScript types,
// as well as, Kibana Platform `plugin()` initializer.
function plugin(initializerContext) {
    return new plugin_1.ReadonlyrestKbnPlugin(initializerContext);
}
exports.plugin = plugin;
