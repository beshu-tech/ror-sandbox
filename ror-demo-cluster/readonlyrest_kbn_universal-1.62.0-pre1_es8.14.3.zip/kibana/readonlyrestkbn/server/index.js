"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = exports.plugin = void 0;
const plugin_1 = require("./plugin");
const config_1 = require("./config");
//  This exports static code and TypeScript types,
//  as well as, Kibana Platform `plugin()` initializer.
function plugin(pluginInitializerContext) {
    return new plugin_1.ReadonlyrestKbnPlugin(pluginInitializerContext);
}
exports.plugin = plugin;
exports.config = {
    schema: config_1.rorConfigSchema,
    exposeToBrowser: {
        clearSessionOnEvents: true,
        identity: true
    }
};
