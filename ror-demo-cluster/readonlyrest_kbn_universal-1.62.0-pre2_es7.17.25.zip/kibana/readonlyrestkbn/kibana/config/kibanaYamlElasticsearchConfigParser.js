"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseElasticsearchConfig = void 0;
const kibanaYamlElasticsearchSSLConfigParser_1 = require("./kibanaYamlElasticsearchSSLConfigParser");
const kibanaYamlRequestHeadersWhitelistParser_1 = require("./kibanaYamlRequestHeadersWhitelistParser");
const rorLoggerFactory_1 = require("../../proxy/core/logging/rorLoggerFactory");
const DEFAULT_ELASTICSEARCH_URL = 'http://localhost:9200';
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
const getKibanaTechUserEsCredentialsAuthToken = (user, password) => {
    if (user && password) {
        return `Basic ${Buffer.from(`${user}:${password}`).toString('base64')}`;
    }
    const missing = [];
    if (!user) {
        missing.push('user');
    }
    if (!password) {
        missing.push('password');
    }
    throw new Error(`Valid values for 'elasticsearch.username' and 'elasticsearch.password' are required by ReadonlyREST. ${missing.length === 2 ? 'Both are' : `'elasticsearch.${missing[0]}' is `} missing.`);
};
function parseElasticsearchConfig(elasticsearchObject) {
    try {
        const originalElasticHosts = elasticsearchObject?.hosts || [DEFAULT_ELASTICSEARCH_URL];
        const derivedElasticHosts = typeof originalElasticHosts === 'string' ? [originalElasticHosts] : originalElasticHosts;
        if (derivedElasticHosts.length > 1) {
            logger.warn('You configured more than one Elasticsearch nodes. ' +
                "If you also have multiple Kibana nodes in high availability (HA), you MUST add to kibana.yml 'readonlyrest_kbn.store_sessions_in_index: true' or it won't work. ");
        }
        const kibanaTechUserEsAuthToken = elasticsearchObject?.serviceAccountToken
            ? `Bearer ${elasticsearchObject.serviceAccountToken}`
            : getKibanaTechUserEsCredentialsAuthToken(elasticsearchObject?.username, elasticsearchObject?.password);
        const elasticsearchSSLConfig = (0, kibanaYamlElasticsearchSSLConfigParser_1.parseSSLConfig)(elasticsearchObject, derivedElasticHosts);
        const requestHeadersWhitelist = (0, kibanaYamlRequestHeadersWhitelistParser_1.getRequestHeadersWhitelist)(elasticsearchObject);
        const customHeaders = elasticsearchObject.customHeaders || {};
        return {
            sslConfig: elasticsearchSSLConfig,
            elasticsearchHosts: derivedElasticHosts,
            kibanaTechUserEsAuthToken,
            requestHeadersWhitelist,
            customHeaders
        };
    }
    catch (e) {
        throw new Error(e);
    }
}
exports.parseElasticsearchConfig = parseElasticsearchConfig;
