"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseLoginPageCustomizations = void 0;
const kibanaYamlCustomUXCodeInjectionParser_1 = require("./kibanaYamlCustomUXCodeInjectionParser");
function isLoginPageCustomizationsConfigPresent(rorObject) {
    return (rorObject.login_title != null ||
        rorObject.login_subtitle != null ||
        rorObject.login_custom_logo != null ||
        rorObject.login_html_head_inject != null ||
        rorObject.log != null ||
        rorObject.login_custom_js_inject_file != null ||
        rorObject.login_custom_css_inject_file != null);
}
function parseLoginPageCustomizations(rorObject) {
    if (rorObject == null || !isLoginPageCustomizationsConfigPresent(rorObject)) {
        return undefined;
    }
    return {
        title: rorObject.login_title,
        subtitle: rorObject.login_subtitle,
        logoPath: rorObject.login_custom_logo,
        htmlHeadInject: rorObject.login_html_head_inject,
        customCSSInjectFile: rorObject.login_custom_css_inject_file
            ? (0, kibanaYamlCustomUXCodeInjectionParser_1.parseCssFile)(rorObject.login_custom_css_inject_file)
            : undefined,
        customJSInjectFile: rorObject.login_custom_js_inject_file
            ? (0, kibanaYamlCustomUXCodeInjectionParser_1.parseJsFile)(rorObject.login_custom_js_inject_file)
            : undefined
    };
}
exports.parseLoginPageCustomizations = parseLoginPageCustomizations;
