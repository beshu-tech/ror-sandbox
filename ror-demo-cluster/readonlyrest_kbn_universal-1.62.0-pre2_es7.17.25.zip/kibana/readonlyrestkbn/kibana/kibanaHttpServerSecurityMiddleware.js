"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.redirectToPkpMiddleware = void 0;
// eslint-disable-next-line @typescript-eslint/no-var-requires
const rorStore = require('./rorStore');
function getProtocol(request) {
    if (request.headers['x-forwarded-proto']) {
        return request.headers['x-forwarded-proto'];
    }
    if (request.connection?.info?.protocol) {
        return request.connection.info.protocol;
    }
    return request.server.info.protocol;
}
function buildRedirectUrl(request) {
    const path = request.url.path || request.url.pathname;
    const redirectUrl = new URL(`${getProtocol(request)}://${request.info.host}${path}`);
    redirectUrl.port = rorStore.getPkpPort().toString();
    return redirectUrl.toString();
}
function hasValidPkpKibanaToken(request) {
    return request.headers['x-ror-pkp-kibana-token'] === rorStore.getPkpKibanaToken();
}
function redirectToPkpMiddleware(request, responseToolkit) {
    if (!hasValidPkpKibanaToken(request)) {
        return responseToolkit.redirect(buildRedirectUrl(request)).takeover();
    }
    return responseToolkit.continue;
}
exports.redirectToPkpMiddleware = redirectToPkpMiddleware;
