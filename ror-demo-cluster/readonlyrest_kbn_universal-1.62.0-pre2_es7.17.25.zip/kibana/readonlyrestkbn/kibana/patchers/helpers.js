"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatDate = exports.createFileChecksum = exports.log = exports.getPatchDir = exports.targetPathRoot = exports.getKbnVersion = exports.getRunningRorVersion = void 0;
const crypto_js_1 = __importDefault(require("crypto-js"));
const fs_1 = __importDefault(require("fs"));
const distributionInfoProvider_1 = require("./distributionInfoProvider");
const rorPackage = JSON.parse(fs_1.default.readFileSync(`${__dirname}/../../package.json`, 'utf8'));
const getKibanaPackage = () => JSON.parse(fs_1.default.readFileSync(`${__dirname}/../../../../package.json`, 'utf8'));
const isDevEnv = distributionInfoProvider_1.DistributionInfoProvider.isEnvironmentDev();
const dir2kbnVersionMap = rorPackage.ror_patch_versions;
const getRunningRorVersion = () => rorPackage.version;
exports.getRunningRorVersion = getRunningRorVersion;
const getKbnVersion = () => getKibanaPackage().version;
exports.getKbnVersion = getKbnVersion;
const targetPathRoot = () => `${__dirname}/../../../../`.replace('//', '/');
exports.targetPathRoot = targetPathRoot;
function getPathDirForDevelopment() {
    if (!dir2kbnVersionMap) {
        throw new Error(`There is no patch files available`);
    }
    const patchDirectory = dir2kbnVersionMap.find(dir => dir2kbnVersionMap[dir].includes((0, exports.getKbnVersion)()));
    if (patchDirectory) {
        return `${__dirname}/patches_for_kbn_source/${patchDirectory}/`;
    }
    throw new Error(`unsupported version for patching ${(0, exports.getKbnVersion)()}`);
}
function getPathDirForProduction() {
    return `${__dirname}/patches_for_kbn_distribution/`;
}
function getPatchDir() {
    return isDevEnv ? getPathDirForDevelopment() : getPathDirForProduction();
}
exports.getPatchDir = getPatchDir;
function log(msg, obj = null) {
    msg = `[ROR COMPAT] ${msg}`;
    if (obj) {
        console.log(msg, obj);
    }
    else {
        console.log(msg);
    }
}
exports.log = log;
function createFileChecksum(content) {
    const wordArray = crypto_js_1.default.lib.WordArray.create(content);
    return crypto_js_1.default.SHA256(wordArray).toString(crypto_js_1.default.enc.Hex);
}
exports.createFileChecksum = createFileChecksum;
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed, so add 1
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}:${month}:${day} ${hours}:${minutes}:${seconds}`;
}
exports.formatDate = formatDate;
