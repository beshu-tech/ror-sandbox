"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CookieManager = void 0;
const iron_1 = __importDefault(require("@hapi/iron"));
const rorLoggerFactory_1 = require("./logging/rorLoggerFactory");
class CookieManager {
    cookieConfig;
    static INFINITE_COOKIE_DURATION_MILLIS = 2147483647 * 60 * 1000;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(cookieConfig) {
        this.cookieConfig = cookieConfig;
    }
    async encryptRorCookie(sid) {
        try {
            const cookieToBeEncrypted = { sid };
            return await iron_1.default.seal(cookieToBeEncrypted, this.cookieConfig.password, iron_1.default.defaults);
        }
        catch (error) {
            this.logger.error(error);
            throw error;
        }
    }
    async decryptRorCookieFromHeader(cookieHeader) {
        if (!cookieHeader) {
            return null;
        }
        const cookie = this.parseCookieHeader?.(cookieHeader)?.[this.cookieConfig.name];
        if (!cookie) {
            return null;
        }
        return this.decryptRorCookie(cookie);
    }
    async decryptRorCookie(cookie) {
        try {
            const unsealedCookie = await iron_1.default.unseal(cookie, this.cookieConfig.password, iron_1.default.defaults);
            return unsealedCookie.sid;
        }
        catch (error) {
            this.logger.error(error);
            this.logger
                .error(`"If you use more than one Kibana nodes (High availability configurations), you MUST share the same "readonlyrest_kbn.cookiePass" in ALL Kibana nodes. 
See documentation: https://docs.readonlyrest.com/kibana#session-management-with-multiple-kibana-instances`);
            return null;
        }
    }
    static getCookiesOptions(options) {
        const maxAge = options?.maxAge ?? CookieManager.INFINITE_COOKIE_DURATION_MILLIS;
        const sameSite = options?.sameSite ?? 'lax';
        const httpOnly = options?.httpOnly ?? true;
        const secure = options?.secure ?? true;
        return { maxAge, sameSite, httpOnly, secure };
    }
    parseCookieHeader(cookieHeader) {
        if (!cookieHeader) {
            return null;
        }
        const cookies = cookieHeader.split('; ');
        const cookiesMap = new Map();
        cookies.forEach(cookie => {
            const cookieSplit = cookie.split('=');
            cookiesMap[cookieSplit[0]] = cookieSplit[1];
        });
        return cookiesMap;
    }
}
exports.CookieManager = CookieManager;
