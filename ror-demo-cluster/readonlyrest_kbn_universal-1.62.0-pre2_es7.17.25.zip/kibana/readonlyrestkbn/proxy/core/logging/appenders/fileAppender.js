"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileAppender = void 0;
const fs_extra_1 = __importDefault(require("fs-extra"));
const lodash_1 = __importDefault(require("lodash"));
const logAppender_1 = require("./logAppender");
// eslint-disable-next-line import/no-cycle
const rorLoggerFactory_1 = require("../rorLoggerFactory");
const rorLogger_1 = require("../rorLogger");
// eslint-disable-next-line import/no-cycle
const consoleAppender_1 = require("./consoleAppender");
class FileAppender extends logAppender_1.LogAppender {
    fileName;
    logFileDestination;
    constructor(fileName, logFileDestination) {
        super();
        this.fileName = fileName;
        this.logFileDestination = logFileDestination;
    }
    log(logLevel, message, impersonatedBy, correlationId, ...optionalParams) {
        if (!rorLoggerFactory_1.RorLoggerFactory.isLoggingEnabled(logLevel)) {
            return;
        }
        if (optionalParams.length > 0) {
            for (const param of lodash_1.default.flatten(optionalParams)) {
                if (param.toString() === '[object Object]') {
                    message += `, ${JSON.stringify(param)}`;
                }
                else if (Array.isArray(param)) {
                    message += `, ${param.join(', ')}`;
                }
                else {
                    message += `, ${param}`;
                }
            }
        }
        fs_extra_1.default.outputFile(this.logFileDestination, `${this.logPattern(logLevel, this.fileName, message, impersonatedBy, correlationId)}\n`, { flag: 'a' }, err => {
            if (err) {
                const logger = new rorLogger_1.RorLogger([new consoleAppender_1.ConsoleAppender('LoggerFactory|FileAppender')]);
                return logger.error(err.message);
            }
        });
    }
}
exports.FileAppender = FileAppender;
