"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TestController = void 0;
const errors_1 = __importDefault(require("../../../constants/errors"));
class TestController {
    esClient;
    constructor(esClient) {
        this.esClient = esClient;
    }
    async handleGetTestConfiguration(request, res) {
        const identityMetadata = request.getIdentitySession()?.metadata;
        if (!this.sufficientAccessLevel(identityMetadata?.kibanaAccess)) {
            return this.notSufficientAccessLevelError(res);
        }
        const esResponse = await this.esClient.getTestConfiguration(request.getAuthorizationHeaders());
        return this.esClient.writeEsResponse(res, esResponse);
    }
    async handlePostTestConfiguration(request, res) {
        const identityMetadata = request.getIdentitySession()?.metadata;
        if (!this.sufficientAccessLevel(identityMetadata?.kibanaAccess)) {
            return this.notSufficientAccessLevelError(res);
        }
        let esResponse = {
            status: 403,
            statusMessage: 'forbidden',
            body: { message: errors_1.default.notSufficientLicenseToUseImpersonateFeature }
        };
        esResponse = await this.esClient.postTestConfiguration(request.getAuthorizationHeaders(), request.getBody());
        this.esClient.writeEsResponse(res, esResponse);
    }
    async handleDeleteTestConfiguration(request, res) {
        const identityMetadata = request.getIdentitySession()?.metadata;
        if (!this.sufficientAccessLevel(identityMetadata?.kibanaAccess)) {
            return this.notSufficientAccessLevelError(res);
        }
        let esResponse = {
            status: 403,
            statusMessage: 'forbidden',
            body: { message: errors_1.default.notSufficientLicenseToUseImpersonateFeature }
        };
        esResponse = await this.esClient.deleteTestConfiguration(request.getAuthorizationHeaders());
        this.esClient.writeEsResponse(res, esResponse);
    }
    async handleGetAuthMock(request, res) {
        const identityMetadata = request.getIdentitySession()?.metadata;
        if (!this.sufficientAccessLevel(identityMetadata?.kibanaAccess)) {
            return this.notSufficientAccessLevelError(res);
        }
        const esResponse = await this.esClient.getAuthMock(request.getAuthorizationHeaders());
        this.esClient.writeEsResponse(res, esResponse);
    }
    async handlePostAuthMock(request, res) {
        const identityMetadata = request.getIdentitySession()?.metadata;
        if (!this.sufficientAccessLevel(identityMetadata?.kibanaAccess)) {
            return this.notSufficientAccessLevelError(res);
        }
        let esResponse = {
            status: 403,
            statusMessage: 'forbidden',
            body: { message: errors_1.default.notSufficientLicenseToUseImpersonateFeature }
        };
        esResponse = await this.esClient.postAuthMock(request.getAuthorizationHeaders(), request.getBody());
        this.esClient.writeEsResponse(res, esResponse);
    }
    async handleGetLocalUsers(request, res) {
        const identityMetadata = request.getIdentitySession()?.metadata;
        if (!this.sufficientAccessLevel(identityMetadata?.kibanaAccess)) {
            return this.notSufficientAccessLevelError(res);
        }
        const esResponse = await this.esClient.getLocalUsers(request.getAuthorizationHeaders());
        return this.esClient.writeEsResponse(res, esResponse);
    }
    notSufficientAccessLevelError(res) {
        res.status(401).json({ message: 'You are not authorized to perform this operation' });
    }
    sufficientAccessLevel(accessLevel) {
        return accessLevel === 'unrestricted' || accessLevel === 'admin';
    }
}
exports.TestController = TestController;
