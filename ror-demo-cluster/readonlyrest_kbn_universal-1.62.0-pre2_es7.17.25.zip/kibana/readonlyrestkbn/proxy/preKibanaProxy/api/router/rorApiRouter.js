"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildRorApiRouter = void 0;
const express_1 = require("express");
const rorApiController_1 = require("../controller/rorApiController");
const errors_1 = __importDefault(require("../../../constants/errors"));
const accessLevel_1 = require("../../../core/common/accessLevel");
function buildRorApiRouter(esClient, licenseService, authController, authenticationFacade) {
    const router = (0, express_1.Router)();
    const rorApiController = new rorApiController_1.RorApiController(esClient, licenseService);
    router.post('/settings', (req, res, next) => licenseService.enterpriseLicenseRequired(res, next, errors_1.default.updateSettingsViaApiEnterpriseOnly), (req, res, next) => esClient.verifyMediaType(req, res, next, ['application/yaml']), async (req, res) => rorApiController.handlePostConfiguration(req.rorRequest, res));
    router.post('/settings/upload', (req, res, next) => licenseService.enterpriseLicenseRequired(res, next, errors_1.default.updateSettingsViaApiEnterpriseOnly), (req, res, next) => esClient.verifyMediaType(req, res, next, ['multipart/form-data']), async (req, res) => rorApiController.handleUploadConfiguration(req, res));
    router.post('/license', (req, res, next) => authController.verifyAccessLevel(req, res, next, [accessLevel_1.AccessLevel.UNRESTRICTED, accessLevel_1.AccessLevel.ADMIN]), (req, res, next) => esClient.verifyMediaType(req, res, next, ['application/json']), async (req, res) => rorApiController.handleAddLicenseKey(req, res, isLicenseEditionChanged => {
        if (isLicenseEditionChanged) {
            authenticationFacade.deleteAllSessions();
        }
    }));
    return router;
}
exports.buildRorApiRouter = buildRorApiRouter;
