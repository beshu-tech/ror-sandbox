"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OidcRouterFactory = void 0;
const express = __importStar(require("express"));
const express_session_1 = __importDefault(require("express-session"));
const passport_1 = require("passport");
const oidcController_1 = require("./oidcController");
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const timeUtils_1 = require("../../../core/common/timeUtils");
const cookieManager_1 = require("../../../core/cookieManager");
const distributionInfoProvider_1 = require("../../../../kibana/patchers/distributionInfoProvider");
const PASSPORT_OIDC_STRATEGY = 'oidc';
class OidcRouterFactory {
    jwtSigner;
    legacyRenderer;
    static logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(jwtSigner, legacyRenderer) {
        this.jwtSigner = jwtSigner;
        this.legacyRenderer = legacyRenderer;
    }
    static get openIdClient() {
        if (distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('7.12.0')) {
            OidcRouterFactory.logger.warn('Your Kibana version ships with an obsolete Node.js version, incompatible with the most recent OIDC client. WE HIGHLY RECOMMENDED TO UPGRADE TO KIBANA >= 7.12.0 so that ROR can use the most updated, certified OIDC client version with all security fixes applied.');
            // eslint-disable-next-line global-require
            return require('openid-client-ancient');
        }
        // eslint-disable-next-line global-require
        return require('openid-client');
    }
    static get HttpProxyAgent() {
        if (distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('7.11.0')) {
            OidcRouterFactory.logger.warn('Your Kibana version ships with an obsolete Node.js version, incompatible with the most recent HTTP proxy agent. WE HIGHLY RECOMMENDED TO UPGRADE TO KIBANA >= 7.11.0 so that ROR can use the most updated, HTTP proxy agent version with all security fixes applied.');
            // eslint-disable-next-line @typescript-eslint/no-var-requires,global-require
            const { HttpProxyAgent } = require('http-proxy-agent-ancient');
            return HttpProxyAgent;
        }
        // eslint-disable-next-line @typescript-eslint/no-var-requires,global-require
        const { HttpProxyAgent } = require('http-proxy-agent');
        return HttpProxyAgent;
    }
    static get HttpsProxyAgent() {
        if (distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('7.11.0')) {
            OidcRouterFactory.logger.warn('Your Kibana version ships with an obsolete Node.js version, incompatible with the most recent HTTPS proxy agent. WE HIGHLY RECOMMENDED TO UPGRADE TO KIBANA >= 7.11.0 so that ROR can use the most updated, HTTPS proxy agent version with all security fixes applied.');
            // eslint-disable-next-line @typescript-eslint/no-var-requires,global-require
            const { HttpsProxyAgent } = require('https-proxy-agent-ancient');
            return HttpsProxyAgent;
        }
        // eslint-disable-next-line @typescript-eslint/no-var-requires,global-require
        const { HttpsProxyAgent } = require('https-proxy-agent');
        return HttpsProxyAgent;
    }
    static buildOidcStrategyConfig(config) {
        const openIdClient = OidcRouterFactory.openIdClient;
        const issuer = new openIdClient.Issuer({
            issuer: config.issuer,
            token_endpoint: config.oidcTokenURL,
            authorization_endpoint: config.oidcAuthorizationURL,
            userinfo_endpoint: config.oidcUserInfoURL,
            jwks_uri: config.jwksURL
        });
        const client = new issuer.Client({
            client_id: config.clientId,
            client_secret: config.clientSecret,
            redirect_uris: [config.loginCallbackURL],
            post_logout_redirect_uris: [config.oidcLogoutUrl],
            token_endpoint_auth_method: config.tokenEndpointAuthMethod
        });
        client.authorizationUrl({
            scope: config.scope
        });
        client[openIdClient.custom.http_options] = (options = {}) => {
            if (config.proxyURL) {
                const isOidcSSL = config.issuer?.toLowerCase()?.trim()?.startsWith('https');
                if (distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('7.11.0')) {
                    if (isOidcSSL) {
                        options.agent = {
                            https: new OidcRouterFactory.HttpsProxyAgent(config.proxyURL, { rejectUnauthorized: false })
                        };
                    }
                    else {
                        options.agent = {
                            http: new OidcRouterFactory.HttpProxyAgent(config.proxyURL)
                        };
                    }
                }
                else {
                    options.agent = isOidcSSL
                        ? new OidcRouterFactory.HttpsProxyAgent(config.proxyURL, { rejectUnauthorized: false })
                        : new OidcRouterFactory.HttpProxyAgent(config.proxyURL);
                }
            }
            options.timeout = 10000;
            return options;
        };
        return {
            client
        };
    }
    static buildOidcControllerConfig(config) {
        return {
            connectorName: config.connectorName,
            usernameParameter: config.usernameParameter,
            groupsParameter: config.groupsParameter,
            cookieConfig: config.cookieConfig,
            logoutPath: config.logoutPath,
            logoutCallBackUrl: config.logoutCallbackUrl,
            oidcLogoutUrl: config.oidcLogoutUrl
        };
    }
    static configurePassport(oidcStrategy) {
        const passport = new passport_1.Passport();
        passport.serializeUser((user, next) => next(null, user));
        passport.deserializeUser((obj, next) => next(null, obj));
        passport.use(PASSPORT_OIDC_STRATEGY, oidcStrategy);
        return passport;
    }
    build(config) {
        const oidcStrategy = this.buildOidcStrategy(config);
        const oidcControllerConfig = OidcRouterFactory.buildOidcControllerConfig(config);
        const oidcController = new oidcController_1.OidcController(oidcControllerConfig, this.jwtSigner, this.legacyRenderer);
        const router = express.Router();
        const passport = OidcRouterFactory.configurePassport(oidcStrategy);
        router.use(express.urlencoded({ extended: true }));
        const isRorSSL = config.loginCallbackURL?.toLowerCase()?.trim()?.startsWith('https');
        // For OIDC to work we need sameSite to be either "none" or "lax", but never "strict".
        // In order to have "sameSite: none", we need "secure: true", otherwise Chrome won't set the cookie.
        // If we want "secure: true" we need SSL. But we cannot guarantee we have SSL.
        // So we set sameSite to "lax" which can handle both the secure and non-secure cookie.
        const cookieOptions = cookieManager_1.CookieManager.getCookiesOptions({ sameSite: 'lax', secure: isRorSSL });
        OidcRouterFactory.logger.trace(`${config.connectorName} will set a cookie valid for ${timeUtils_1.TimeUtils.nowPlusMillis(cookieOptions?.maxAge ?? 0)} minutes.`);
        const sessionOptions = {
            proxy: true,
            name: config.cookieConfig.name,
            secret: config.cookieConfig.password,
            cookie: cookieOptions,
            resave: false,
            saveUninitialized: false,
            unset: 'destroy'
        };
        // @ts-ignore
        router.use((0, express_session_1.default)(sessionOptions));
        // @ts-ignore
        router.use(passport.initialize());
        router.use(passport.session());
        router.get(config.loginPath, passport.authenticate(PASSPORT_OIDC_STRATEGY, { failureRedirect: '/', scope: config.scope }));
        router.use(config.loginCallbackPath, (req, res) => passport.authenticate(PASSPORT_OIDC_STRATEGY, { failureRedirect: '/', scope: config.scope }, (err, user, info) => {
            if (!user) {
                return this.handleLoginCallbackError(config, err, req, res, info);
            }
            /**
             * We cannot save user information directly in the req.user because login redirect clearing all request, and it ends up with req.user undefined
             * To avoid it, we need to store user info directly in the session
             */
            req.session.user = user;
            return oidcController.onLoginCallback(req, res);
        })(req, res));
        router.use(config.logoutPath, oidcController.onLogout);
        router.use(config.logoutCallbackPath, oidcController.onLogoutCallback);
        return router;
    }
    handleLoginCallbackError(config, err, req, res, info) {
        const isRorSSL = config.loginCallbackURL?.toLowerCase()?.trim()?.startsWith('https');
        const isReverseProxy = req.headers.host !== config.kibanaExternalHost;
        const missingHttpsForwaredProtoHeader = req.headers['x-forwarded-proto'] !== 'https';
        if (isRorSSL && isReverseProxy && missingHttpsForwaredProtoHeader) {
            OidcRouterFactory.logger.error(`${config.connectorName} error:`, `If you use a reverse proxy, you need to configure x-forwarded-proto header with an HTTPS value to run the OIDC connector properly`);
        }
        OidcRouterFactory.logger.error(`${config.connectorName} error:`, err || info || res);
        req.logout(() => {
            res.clearCookie(config.cookieConfig.name, { path: '/' });
            return res.send(`<h2> There was an error in the OIDC connector ${config.connectorName}</h2> 
       <p>For more information, consult the kibana logs.</p>`);
        });
    }
    buildOidcStrategy(config) {
        const strategyConfig = OidcRouterFactory.buildOidcStrategyConfig(config);
        OidcRouterFactory.logger.trace(`Strategy config: ${JSON.stringify(strategyConfig)}`);
        return new OidcRouterFactory.openIdClient.Strategy(strategyConfig, (tokenset, profile, done) => {
            rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename).debug(`Obtained raw profile: ${JSON.stringify(profile)}`);
            return done(null, profile);
        });
    }
}
exports.OidcRouterFactory = OidcRouterFactory;
