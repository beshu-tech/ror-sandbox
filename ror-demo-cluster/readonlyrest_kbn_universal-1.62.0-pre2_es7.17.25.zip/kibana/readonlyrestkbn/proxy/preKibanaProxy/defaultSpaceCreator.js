"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefaultSpaceCreator = void 0;
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
class DefaultSpaceCreator {
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    DEFAULT_SPACE_DOCUMENT_ID = 'space:default';
    /**
     * When a new major release of Kibana gets released, we can check if we need to update the structure
     * of this document. Here is how to extract it from a running Elasticsearch instance:
  
     curl -H "content-type: application/json" -u kibana:kibana -X POST "localhost:9200/_search" -d '{"query": {"simple_query_string":{"query": "space"}}}' | jq
  
     */
    DEFAULT_SPACE_DOCUMENT_BODY = {
        space: {
            name: 'Default',
            description: 'This is your default space! (created by ReadonlyREST Enterprise)',
            color: '#00bfb3',
            disabledFeatures: [],
            _reserved: true
        },
        type: 'space',
        references: [],
        migrationVersion: {
            space: '6.6.0'
        }
    };
    esClient;
    constructor(kibanaIndex, esClient) {
        this.esClient = esClient;
    }
    createDefaultSpaceDocumentIfNeeded = async (kibanaIndex) => {
        const spaceDocumentExists = await this.spaceDocumentExists(kibanaIndex);
        if (!spaceDocumentExists) {
            await this.createDefaultSpaceDocument(kibanaIndex, this.DEFAULT_SPACE_DOCUMENT_BODY);
        }
    };
    spaceDocumentExists = async (kibanaIndex) => this.esClient.getAsKibana(`${kibanaIndex}/_doc/${this.DEFAULT_SPACE_DOCUMENT_ID}`).then(async (response) => {
        const text = await response.text();
        this.logger.trace(`spaceDocumentExists response ${response.status}: ${text}`);
        return response.status === 200;
    });
    createDefaultSpaceDocument = async (currentKibanaIndex, spaceDocumentBody) => {
        this.logger.trace(`Creating default space document for index: ${currentKibanaIndex}`);
        return this.esClient
            .postAsKibana(`${currentKibanaIndex}/_create/${this.DEFAULT_SPACE_DOCUMENT_ID}?refresh=true`, JSON.stringify(spaceDocumentBody))
            .then(async (response) => {
            const text = await response.text();
            this.logger.trace(`createDefaultSpaceDocument response ${response.status}: ${text}`);
        });
    };
}
exports.DefaultSpaceCreator = DefaultSpaceCreator;
