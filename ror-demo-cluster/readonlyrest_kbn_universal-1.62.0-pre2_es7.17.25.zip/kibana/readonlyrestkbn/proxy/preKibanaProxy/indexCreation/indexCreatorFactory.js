"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.IndexCreatorFactory = void 0;
const distributionInfoProvider_1 = require("../../../kibana/patchers/distributionInfoProvider");
const pre_7_12_0__index_creator_1 = require("./pre_7_12_0__index_creator");
const indexCreator_1 = require("./indexCreator");
class IndexCreatorFactory {
    static create(defaultKibanaIndex, esClient, resetKibanaIndexToTemplate, kibanaTemplateIndex, tenantIndex) {
        return distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('7.12.0')
            ? new pre_7_12_0__index_creator_1.Pre_7_12_0_IndexCreator(defaultKibanaIndex, esClient, resetKibanaIndexToTemplate, kibanaTemplateIndex)
            : new indexCreator_1.IndexCreator(defaultKibanaIndex, esClient, resetKibanaIndexToTemplate, kibanaTemplateIndex, tenantIndex);
    }
}
exports.IndexCreatorFactory = IndexCreatorFactory;
