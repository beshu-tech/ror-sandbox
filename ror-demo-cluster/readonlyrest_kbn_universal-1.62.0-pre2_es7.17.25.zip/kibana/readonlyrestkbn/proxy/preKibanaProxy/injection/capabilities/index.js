"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCapabilitiesToRemove = exports.transform = exports.overridePropertiesByJsonPath = exports.overridePropertyByJsonPath = exports.mutateAllCapabilitiesInObject = void 0;
// eslint-disable-next-line import/no-cycle
const HiddenAppsTransformer_1 = require("./transformers/HiddenAppsTransformer");
// eslint-disable-next-line import/no-cycle
const ROUserTransformer_1 = require("./transformers/ROUserTransformer");
// eslint-disable-next-line import/no-cycle
const ManagementDisableTransformer_1 = require("./transformers/ManagementDisableTransformer");
const kibanaAppsRegistry_1 = require("../../kibana_apps/kibanaAppsRegistry");
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
// eslint-disable-next-line import/no-cycle
const ObservabilityTransformer_1 = require("./transformers/ObservabilityTransformer");
// eslint-disable-next-line import/no-cycle
const MinimumManagementTransformer_1 = require("./transformers/MinimumManagementTransformer");
const logger = () => rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
function mutateAllCapabilitiesInObject(obj, shouldEnable) {
    for (const i in obj) {
        if (obj[i] !== undefined) {
            if (typeof obj[i] === 'object') {
                for (const j in obj[i]) {
                    if (Object.prototype.hasOwnProperty.call(obj[i], j)) {
                        obj[i][j] = shouldEnable(i, j);
                    }
                }
            }
            else {
                obj[i] = shouldEnable(i);
            }
        }
        else {
            console.log(`Tried to mutate NON existing property ${i} of `, obj);
        }
    }
    return obj;
}
exports.mutateAllCapabilitiesInObject = mutateAllCapabilitiesInObject;
// export const overrideOnePath = (obj, thePath: string, value: any) => _.has(obj, thePath) && _.set(obj, thePath, value)
function overridePropertyByJsonPath(obj, thePath, value) {
    const path = thePath.split('.');
    let i;
    for (i = 0; i < path.length - 1; i++) {
        const val = obj[path[i]];
        if (val === undefined) {
            return;
        }
        obj = val;
    }
    if (obj[path[i]] === undefined) {
        return;
    }
    obj[path[i]] = value;
}
exports.overridePropertyByJsonPath = overridePropertyByJsonPath;
function overridePropertiesByJsonPath(obj, paths, getValue) {
    paths.forEach(path => overridePropertyByJsonPath(obj, path, getValue(path)));
}
exports.overridePropertiesByJsonPath = overridePropertiesByJsonPath;
function transform(cap, metadata) {
    const transformers = [
        HiddenAppsTransformer_1.HiddenAppsTransformer.transform,
        ROUserTransformer_1.ROUserTransformer.transform,
        ManagementDisableTransformer_1.ManagementDisableTransformer.transform,
        ObservabilityTransformer_1.ObservabilityTransformer.transform,
        MinimumManagementTransformer_1.MinimumManagementTransformer.transform
    ];
    // Apply all the transformers
    cap = transformers.reduce((acc, fn) => fn(acc, metadata), cap);
    return cap;
}
exports.transform = transform;
function getCapabilitiesToRemove(metadata) {
    const hiddenApps = [...metadata.kibanaHiddenApps, 'Security'];
    if (hiddenApps.length === 0) {
        return [];
    }
    let capabilities2remove = [];
    for (const g of hiddenApps) {
        capabilities2remove = capabilities2remove.concat(kibanaAppsRegistry_1.KibanaAppsRegistry.app2capabilities(g) || []);
    }
    capabilities2remove = [...new Set(capabilities2remove.map(c => c?.trim()).filter(c => Boolean(c)))];
    logger().debug(`Will hide apps ${hiddenApps}. Hence will remove capabilities: ${capabilities2remove}`);
    return capabilities2remove;
}
exports.getCapabilitiesToRemove = getCapabilitiesToRemove;
