"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MinimumManagementTransformer = void 0;
// eslint-disable-next-line import/no-cycle
const index_1 = require("../index");
class MinimumManagementTransformer {
    static transform(cap, metadata) {
        if (metadata.kibanaHiddenApps.includes('ROR Manage Kibana')) {
            return cap;
        }
        (0, index_1.overridePropertiesByJsonPath)(cap, [
            'navLinks.management',
            'catalogue.indexPatterns',
            'catalogue.saved_objects',
            'savedObjectManagement.read',
            'savedObjectsManagement.read',
            'kibana.objects'
        ], () => true);
        const capsToDeactivate = (0, index_1.getCapabilitiesToRemove)(metadata);
        if (capsToDeactivate.includes('management')) {
            (0, index_1.overridePropertiesByJsonPath)(cap, [
                'management.insightsAndAlerting.reporting',
                'management.kibana.dataViews',
                'management.kibana.indexPatterns',
                'management.kibana.objects',
                'catalogue.reporting'
            ], () => true);
        }
        return cap;
    }
}
exports.MinimumManagementTransformer = MinimumManagementTransformer;
