"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KibanaAppsRegistry = void 0;
const rorLoggerFactory_1 = require("../../core/logging/rorLoggerFactory");
const hiddenAppsChecker_1 = __importDefault(require("./hiddenAppsChecker"));
const distributionInfoProvider_1 = require("../../../kibana/patchers/distributionInfoProvider");
class KibanaAppsRegistry {
    static rorManageKibanaButtonHiddenId = 'ROR Manage Kibana';
    static pathsWhitelist = [
        '/app/management/insightsAndAlerting/reporting',
        '/app/management/kibana/indexPatterns',
        '/app/management/kibana/objects',
        '/app/management/kibana/dataViews'
    ];
    static navigationItems = [
        {
            id: 'Analytics|Analytics',
            path: '/app/kibana_overview',
            flags: ['kibanaOverview']
        },
        {
            id: 'Analytics|Overview',
            path: '/app/kibana_overview',
            flags: ['kibanaOverview']
        },
        {
            id: 'Analytics|Discover',
            path: '/app/discover',
            flags: ['discover']
        },
        {
            id: 'Analytics|Dashboard',
            path: '/app/dashboards',
            flags: ['dashboards', 'dashboard']
        },
        {
            id: 'Analytics|Dashboards',
            path: '/app/dashboards',
            flags: ['dashboards', 'dashboard']
        },
        {
            id: 'Analytics|Canvas',
            path: '/app/canvas',
            flags: ['canvas']
        },
        {
            id: 'Analytics|Maps',
            path: '/app/maps',
            flags: ['maps']
        },
        {
            id: 'Analytics|Machine Learning',
            path: '/app/ml',
            flags: ['ml', 'ml_file_data_visualizer']
        },
        {
            id: 'Analytics|Visualize Library',
            path: '/app/visualize',
            flags: ['visualize']
        },
        {
            id: 'Analytics|Graph',
            path: '/app/graph',
            flags: ['graph']
        },
        {
            id: 'Search|Content',
            path: '/app/enterprise_search/content',
            flags: ['enterpriseSearchContent']
        },
        {
            id: 'Search|Elasticsearch',
            path: '/app/enterprise_search/elasticsearch',
            flags: ['enterpriseSearchElasticsearch']
        },
        {
            id: 'Search|Vector Search',
            path: '/app/enterprise_search/vector_search',
            flags: ['enterpriseSearchVectorSearch']
        },
        {
            id: 'Search|Semantic Search',
            path: '/app/enterprise_search/semantic_search',
            flags: ['enterpriseSearchSemanticSearch']
        },
        {
            id: 'Search|Playground',
            path: '/app/enterprise_search/playground',
            flags: []
        },
        {
            id: 'Search|Behavioral Analytics',
            path: '/app/enterprise_search/analytics',
            flags: []
        },
        {
            id: 'Enterprise Search|Overview',
            path: '/app/enterprise_search/overview',
            flags: ['enterpriseSearch']
        },
        {
            id: 'Enterprise Search|App Search',
            path: '/app/enterprise_search/app_search',
            flags: ['appSearch']
        },
        {
            id: 'Enterprise Search|Workplace Search',
            path: '/app/enterprise_search/workplace_search',
            flags: ['workplaceSearch']
        },
        {
            id: 'Observability|Observability',
            path: '/app/observability',
            flags: ['observability']
        },
        {
            id: 'Observability|Overview',
            path: '/app/observability',
            flags: ['observability-overview']
        },
        {
            id: 'Observability|Logs',
            path: '/app/observability/logs',
            flags: ['logs']
        },
        {
            id: 'Observability|Alerts',
            path: '/app/observability/alerts',
            flags: ['alerts']
        },
        {
            id: 'Observability|Cases',
            path: '/app/observability/cases',
            flags: ['cases']
        },
        {
            id: 'Observability|SLOs',
            flags: ['slos', 'slo'],
            path: '/app/observability/slos'
        },
        {
            id: 'Observability|Synthetics',
            flags: ['synthetics'],
            path: '/app/synthetics'
        },
        {
            id: 'Observability|Metrics',
            path: '/app/observability/metrics',
            flags: ['metrics']
        },
        {
            id: 'Observability|APM',
            path: '/app/apm',
            flags: ['apm']
        },
        {
            id: 'Observability|Uptime',
            path: '/app/uptime',
            flags: ['uptime']
        },
        {
            id: 'Observability|User Experience',
            path: '/app/ux',
            flags: ['ux']
        },
        {
            id: 'Observability|Inventory',
            path: '/app/inventory',
            flags: ['inventory']
        },
        {
            id: 'Observability|Infrastructure',
            path: '/app/metrics',
            flags: []
        },
        {
            id: 'Security|Overview',
            path: '/app/security/overview',
            flags: ['siem', 'securitySolution']
        },
        {
            id: 'Security|Security',
            path: '/app/security',
            flags: ['siem', 'securitySolution', 'security']
        },
        {
            id: 'Security|Detections',
            path: '/app/security/detections',
            flags: ['siem', 'securitySolution']
        },
        {
            id: 'Security|Rules',
            path: '/app/security/rules',
            flags: ['siem', 'securitySolution']
        },
        {
            id: 'Security|Hosts',
            path: '/app/security/hosts',
            flags: [
                'siem',
                'securitySolution',
                'securitySolution:administration',
                'securitySolution:case',
                'securitySolution:detections',
                'securitySolution:hosts',
                'securitySolution:network',
                'securitySolution:overview',
                'securitySolution:timelines'
            ]
        },
        {
            id: 'Security|Network',
            path: '/app/security/network',
            flags: ['siem', 'securitySolution']
        },
        {
            id: 'Security|Timelines',
            path: '/app/security/timelines',
            flags: ['siem', 'securitySolution']
        },
        {
            id: 'Security|Cases',
            path: '/app/security/cases',
            flags: ['siem', 'securitySolution']
        },
        {
            id: 'Security|Administration',
            path: '/app/security/administration',
            flags: ['siem', 'securitySolution']
        },
        {
            id: 'Security|TrustedApplications',
            path: '/app/security/trusted_apps',
            flags: ['siem', 'securitySolution']
        },
        {
            id: 'Security|Exceptions',
            path: '/app/security/exceptions',
            flags: ['siem', 'securitySolution']
        },
        {
            id: 'Management|Dev Tools',
            path: '/app/dev_tools',
            flags: ['dev_tools', 'console']
        },
        {
            id: 'Management|Fleet',
            path: '/app/fleet',
            flags: ['fleet']
        },
        {
            id: 'Management|Integrations',
            path: '/app/integrations',
            flags: ['integrations']
        },
        {
            id: 'Management|Stack Management',
            path: '/app/management',
            flags: ['management']
        },
        {
            id: 'Management|Management',
            path: '/app/management',
            flags: ['management']
        },
        {
            id: 'Management|Osquery',
            path: '/app/osquery',
            flags: ['osquery']
        },
        {
            id: 'Management|Stack Monitoring',
            path: '/app/monitoring',
            flags: ['Stack Monitoring', 'monitoring']
        }
    ];
    static stackManagementIngest = [
        {
            id: 'Management|Stack Management|Ingest|Ingest Pipelines',
            path: '/app/management/ingest/ingest_pipelines',
            flags: ['ingest_pipelines', 'pipelines']
        }
    ];
    static stackManagementData = () => {
        const apps = [
            {
                id: 'Management|Stack Management|Data|Index Management',
                path: '/app/management/data/index_management',
                flags: ['index_management']
            },
            {
                id: 'Management|Stack Management|Data|Index Lifecycle Policies',
                path: '/app/management/data/index_lifecycle_management',
                flags: ['index_lifecycle_management']
            },
            {
                id: 'Management|Stack Management|Data|Snapshot and Restore',
                path: '/app/management/data/snapshot_restore/snapshots',
                flags: ['snapshot_restore']
            },
            {
                id: 'Management|Stack Management|Data|Rollup Jobs',
                path: '/app/management/data/rollup_jobs/job_list',
                flags: ['rollup_jobs']
            },
            {
                id: 'Management|Stack Management|Data|Transforms',
                path: '/app/management/data/transform',
                flags: ['transform']
            },
            {
                id: 'Management|Stack Management|Data|Remote Clusters',
                path: '/app/management/data/remote_clusters',
                flags: ['remote_clusters', 'cross_cluster_replication']
            }
        ];
        if (!distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('8.7.0')) {
            apps.push({
                id: 'Management|Stack Management|Data|Migrate',
                path: '/app/management/data/migrate_data',
                flags: ['migrate_data']
            });
        }
        return apps;
    };
    static stackManagementAlertsAndInsights = [
        {
            id: 'Management|Stack Management|Alerts and Insights|Reporting',
            path: '/app/management/insightsAndAlerting/reporting',
            flags: ['reporting']
        },
        {
            id: 'Management|Stack Management|Alerts and Insights|Rules',
            path: '/app/management/insightsAndAlerting/triggersActions',
            flags: ['triggersActions']
        },
        {
            id: 'Management|Stack Management|Alerts and Insights|Connectors',
            path: '/app/management/insightsAndAlerting/triggersActionsConnectors',
            flags: ['triggersActionsConnectors']
        },
        {
            id: 'Management|Stack Management|Alerts and Insights|Cases',
            path: '/app/management/insightsAndAlerting/cases',
            flags: ['cases']
        },
        {
            id: 'Management|Stack Management|Alerts and Insights|Machine Learning',
            path: '/app/management/insightsAndAlerting/jobsListLink',
            flags: ['jobsListLink']
        }
    ];
    static stackManagementKibana = () => {
        const apps = [
            {
                id: 'Management|Stack Management|Kibana|Spaces',
                path: '/app/management/kibana/spaces',
                flags: ['spaces']
            },
            {
                id: 'Management|Stack Management|Kibana|Advanced Settings',
                path: '/app/management/kibana/settings',
                flags: ['settings']
            },
            {
                id: 'Management|Stack Management|Kibana|Search Sessions',
                path: '/app/management/kibana/search_sessions',
                flags: ['search_sessions']
            },
            {
                id: 'Management|Stack Management|Kibana|Tags',
                path: '/app/management/kibana/tags',
                flags: ['tags']
            },
            {
                id: 'Management|Stack Management|Kibana|Saved Objects',
                path: '/app/management/kibana/objects',
                flags: ['objects']
            },
            {
                id: 'Management|Stack Management|Kibana|AI Assistants',
                path: '/app/management/kibana/aiAssistantManagementSelection',
                flags: ['aiAssistantManagementSelection', 'securityAiAssistantManagement', 'observabilityAiAssistantManagement']
            }
        ];
        if (distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('8.0.0')) {
            apps.push({
                id: 'Management|Stack Management|Kibana|Index Patterns',
                path: '/app/management/kibana/indexPatterns',
                flags: ['indexPatterns']
            });
        }
        else {
            apps.push({
                id: 'Management|Stack Management|Kibana|Data Views',
                path: '/app/management/kibana/dataViews',
                flags: ['indexPatterns']
            });
        }
        if (!distributionInfoProvider_1.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan('8.7.0')) {
            apps.push({
                id: 'Management|Stack Management|Kibana|Files',
                path: '/app/management/kibana/filesManagement',
                flags: ['filesManagement']
            });
        }
        return apps;
    };
    static stackManagementStack = [
        {
            id: 'Management|Stack Management|Stack|License Management',
            path: '/app/management/stack/license_management',
            flags: ['license_management']
        },
        {
            id: 'Management|Stack Management|Stack|Upgrade Assistant',
            path: '/app/management/stack/upgrade_assistant',
            flags: ['upgrade_assistant']
        }
    ];
    // initialize with basic known apps, so we avoid people getting smart with nextUrl query param
    // #TODO keep in sync with new versions of Kibana (pick the most updated list from the browser console.log)
    static registry = [];
    static logger = () => rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    static initialize() {
        KibanaAppsRegistry.registry = [
            ...this.navigationItems,
            ...this.stackManagementIngest,
            ...this.stackManagementData(),
            ...this.stackManagementAlertsAndInsights,
            ...this.stackManagementKibana(),
            ...this.stackManagementStack
        ];
    }
    static app2capabilities(groupName) {
        return this.registry
            .filter(i => this.expressionMatchesAppId(groupName, i.id))
            .map(i => i.flags)
            .reduce((acc, val) => acc.concat(val), []);
    }
    static enrichRegistry(kibanaApps) {
        kibanaApps.forEach(a => {
            if (!this.registry.find(x => x.id === a.id)) {
                KibanaAppsRegistry.logger().info('Found new kibana app, adding to registry ', a);
                this.registry.push(a);
            }
        });
    }
    static isNavigationAllowed(path, hiddenAppsIdsOrPartialIds) {
        const pathStrippedOfSpacePrefix = path.replace(/\/s\/[a-z0-9]+\//, '/');
        if (KibanaAppsRegistry.pathsWhitelist.includes(pathStrippedOfSpacePrefix) &&
            !hiddenAppsIdsOrPartialIds.includes(this.rorManageKibanaButtonHiddenId)) {
            KibanaAppsRegistry.logger().trace(`${pathStrippedOfSpacePrefix} path is added into a whitelist`);
            return true;
        }
        if (hiddenAppsIdsOrPartialIds.length === 0) {
            KibanaAppsRegistry.logger().trace('No hidden apps configured for identity');
            return true;
        }
        const currentApp = KibanaAppsRegistry.getAppByPath(pathStrippedOfSpacePrefix);
        if (!currentApp) {
            KibanaAppsRegistry.logger().trace('Cannot extract app name from request path: ', pathStrippedOfSpacePrefix);
            return true;
        }
        KibanaAppsRegistry.logger().trace(`Matched app from path: ${pathStrippedOfSpacePrefix}`, currentApp.id);
        const hiddenApps = this.getAppsByIdOrPartialId(hiddenAppsIdsOrPartialIds);
        KibanaAppsRegistry.logger().trace(`Hidden apps for user`, hiddenApps.map(a => a.id));
        if (hiddenApps.find(x => x.id === currentApp.id)) {
            KibanaAppsRegistry.logger().trace(`Current app "${currentApp.id}" is hidden. Hence, will NOT allow navigation.`);
            return false;
        }
        return true;
    }
    static getPathsOfAppsToHide(hiddenAppsIdsOrPartialIds) {
        return KibanaAppsRegistry.registry.filter(app => this.shouldAppBeHidden(app, hiddenAppsIdsOrPartialIds));
    }
    static get allRegistryApps() {
        return KibanaAppsRegistry.registry;
    }
    static shouldAppBeHidden(app, hiddenAppsIdsOrPartialIds) {
        KibanaAppsRegistry.logger().trace(`Deciding whether to hide app: ${app.id}`);
        const isStackManagementInHiddenApps = hiddenAppsIdsOrPartialIds.some(hiddenAppsIdsOrPartialId => (0, hiddenAppsChecker_1.default)(hiddenAppsIdsOrPartialId, 'Management|Stack Management', KibanaAppsRegistry.logger()));
        if (KibanaAppsRegistry.pathsWhitelist.includes(app.path) &&
            isStackManagementInHiddenApps &&
            !hiddenAppsIdsOrPartialIds.includes(this.rorManageKibanaButtonHiddenId)) {
            KibanaAppsRegistry.logger().trace(`${app.path} path is added into a whitelist, hence will not hide it`);
            return false;
        }
        if (hiddenAppsIdsOrPartialIds.length === 0) {
            KibanaAppsRegistry.logger().trace('No hidden apps configured for identity, hence will not hide ');
            return false;
        }
        const hiddenApps = this.getAppsByIdOrPartialId(hiddenAppsIdsOrPartialIds);
        if (hiddenApps.find(x => x.id === app.id)) {
            KibanaAppsRegistry.logger().trace(`The app "${app.id}" is configured as hidden for identity. Hence, will hide.`);
            return true;
        }
        KibanaAppsRegistry.logger().trace(`Not hiding app: ${app.id}`);
        return false;
    }
    static expressionMatchesAppId(expression, appId) {
        return (0, hiddenAppsChecker_1.default)(expression, appId, KibanaAppsRegistry.logger());
    }
    static getAppByPath(path) {
        return KibanaAppsRegistry.registry.find(app => path.startsWith(app.path));
    }
    static getAppsByIdOrPartialId(appIdOrPartial) {
        const appsDeep = appIdOrPartial.map(x => KibanaAppsRegistry.registry.filter(app => (0, hiddenAppsChecker_1.default)(x, app.id, KibanaAppsRegistry.logger())));
        return [].concat.apply([], appsDeep); // Flatten
    }
}
exports.KibanaAppsRegistry = KibanaAppsRegistry;
KibanaAppsRegistry.initialize();
