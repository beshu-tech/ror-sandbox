"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseKibanaSSLConfig = void 0;
const configUtils_1 = require("./configUtils");
const rorLoggerFactory_1 = require("../../proxy/core/logging/rorLoggerFactory");
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
function parseKibanaSSLConfig(deepObject) {
    const sslObject = deepObject.server?.ssl;
    if (sslObject?.enabled === true) {
        if ((sslObject.key === undefined || sslObject.certificate === undefined) &&
            (sslObject.keystore === undefined || sslObject.keystore.path === undefined)) {
            logger.error(`Either the SSL key & certificate paths or the keystore path need to be specified! Exiting.`);
            (0, configUtils_1.exitInOneSecond)();
        }
        if (sslObject.truststore !== undefined) {
            logger.error('Truststore is not implemented yet. If you need this feature, please ask for it in ROR forum: https://forum.readonlyrest.com');
            (0, configUtils_1.exitInOneSecond)();
        }
        return {
            keyPath: sslObject.key,
            keyPassphrase: sslObject.keyPassphrase,
            cipherSuites: sslObject.cipherSuites,
            certificatePath: sslObject.certificate,
            keystorePath: sslObject.keystore?.path,
            keystorePassword: sslObject.keystore?.password,
            supportedProtocols: sslObject.supportedProtocols
        };
    }
}
exports.parseKibanaSSLConfig = parseKibanaSSLConfig;
