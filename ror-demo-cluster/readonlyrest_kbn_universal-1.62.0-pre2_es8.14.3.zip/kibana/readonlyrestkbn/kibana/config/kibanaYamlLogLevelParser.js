"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLogsDestination = exports.parseLogLevel = void 0;
const lodash_1 = require("lodash");
const logLevel_1 = require("../../proxy/core/logging/logLevel");
const rorLoggerFactory_1 = require("../../proxy/core/logging/rorLoggerFactory");
function parseLogLevel(kibanaYmlConfig) {
    const rorConfig = kibanaYmlConfig?.readonlyrest_kbn;
    const rawLogLevel = rorConfig?.logLevel;
    if (rawLogLevel == null) {
        return rorLoggerFactory_1.RorLoggerFactory.DEFAULT_LOG_LEVEL;
    }
    const derivedLogLevel = logLevel_1.LogLevel[rawLogLevel.toString().toUpperCase()];
    if (derivedLogLevel == null) {
        // this will be caught by Kibana's own validation mechanism, no need to handle it here.
        return rorLoggerFactory_1.RorLoggerFactory.DEFAULT_LOG_LEVEL;
    }
    return derivedLogLevel;
}
exports.parseLogLevel = parseLogLevel;
function getLogsDestination(logging) {
    const destinations = [];
    // It's for Kibana before 8.x
    if (logging?.dest === 'stdout') {
        destinations.push({
            type: 'console'
        });
    }
    else if (logging?.dest) {
        destinations.push({
            type: 'file',
            path: logging?.dest
        });
    }
    const rootAppendToFile = logging?.root?.appenders.includes('file') && logging?.appenders?.file;
    if (rootAppendToFile) {
        destinations.push({
            type: 'file',
            path: rootAppendToFile.fileName
        });
    }
    if (logging?.root?.appenders.includes('default')) {
        destinations.push({
            type: 'console'
        });
    }
    if ((!logging?.root || !rootAppendToFile) && !logging?.dest) {
        destinations.push({
            type: 'console'
        });
    }
    return (0, lodash_1.uniqBy)(destinations, 'type');
}
exports.getLogsDestination = getLogsDestination;
