"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeRorStore = void 0;
// eslint-disable-next-line @typescript-eslint/no-var-requires
const rorStore = require('../rorStore');
function initializeRorStore(kibanaConfig, rorConfig) {
    rorStore.setOncePkpPort(kibanaConfig.pkpHostAndPort.port);
    rorStore.setOncePkpKibanaToken(rorConfig.pkpKibanaToken);
    const pkpUrl = `${kibanaConfig.kibanaSslConfig ? 'https' : 'http'}://${kibanaConfig.pkpHostAndPort.host}:${kibanaConfig.pkpHostAndPort.port}`;
    rorStore.setOncePkpUrl(pkpUrl);
}
exports.initializeRorStore = initializeRorStore;
