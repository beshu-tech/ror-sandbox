"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.exitInOneSecond = void 0;
const exitInOneSecond = () => {
    console.log('ReadonlyREST terminating Kibana in 1 second...');
    return setTimeout(() => process.exit(1), 1000);
};
exports.exitInOneSecond = exitInOneSecond;
