"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.FilePatcher = void 0;
const helpers_1 = require("./helpers");
const metadataPatcher_1 = require("./metadataPatcher");
const messages_1 = require("./messages");
const diff = require('diff');
const fs = require('fs');
const { basename } = require('path');
class FilePatcher {
    patchFilePath;
    backup_suffix;
    targetPatchRoot;
    patchContent;
    sourceFile;
    destinationFile;
    metadataPatcher;
    constructor(patchFilePath, targetPatchRoot = `${__dirname}../../`, backup_suffix = '.orig') {
        this.patchFilePath = patchFilePath;
        this.backup_suffix = backup_suffix;
        // now we are in kibana/plugins/readonlyrest_kbn, so kibana sources are up two dirs.
        this.targetPatchRoot = targetPatchRoot;
        // Read the patch file
        this.patchContent = fs.readFileSync(patchFilePath, 'utf8');
        // Extract source file path
        const sourceFileMatch = /--- ([^ \n\r\t]+).*/.exec(this.patchContent);
        let sourceFile;
        if (sourceFileMatch && sourceFileMatch[1]) {
            sourceFile = sourceFileMatch[1];
        }
        else {
            throw Error(`Unable to find source file in '${this.patchFilePath}'`);
        }
        this.sourceFile = `${this.targetPatchRoot}/${sourceFile}`.replace('//', '/');
        // Extract destination file path
        const destinationFileMatch = /\+\+\+ ([^ \n\r\t]+).*/.exec(this.patchContent);
        let destinationFile;
        if (destinationFileMatch && destinationFileMatch[1]) {
            destinationFile = destinationFileMatch[1];
        }
        else {
            throw Error(`Unable to find destination file in '${patchFilePath}'`);
        }
        this.destinationFile = `${this.targetPatchRoot}/${destinationFile}`.replace('//', '/');
        this.metadataPatcher = new metadataPatcher_1.MetadataPatcher(this.destinationFile);
    }
    backup(pathAndFile = this.sourceFile) {
        fs.copyFileSync(pathAndFile, pathAndFile + this.backup_suffix);
        return this;
    }
    restore(pathAndFile = this.sourceFile) {
        if (!this.hasBackup(pathAndFile)) {
            throw new Error(`Cannot restore ${pathAndFile} as no backup was found`);
        }
        const backupFile = pathAndFile + this.backup_suffix;
        fs.copyFileSync(backupFile, pathAndFile);
        fs.unlinkSync(backupFile);
        this.metadataPatcher.removePatchingVersionFile();
        (0, helpers_1.log)(`Restored ${pathAndFile}`);
        return this;
    }
    hasBackup(pathAndFile = this.sourceFile) {
        return fs.existsSync(pathAndFile + this.backup_suffix);
    }
    unpatch(pathAndFile = this.sourceFile) {
        const { patchedRorVersion, isCurrentlyInstalledRorVersionPatched, displayFileMetadata } = this.metadataPatcher;
        if (patchedRorVersion) {
            displayFileMetadata();
            if (!isCurrentlyInstalledRorVersionPatched) {
                throw new Error(messages_1.messages.mismatchRorVersionInfo(patchedRorVersion, (0, helpers_1.getRunningRorVersion)()));
            }
        }
        else {
            throw new Error(messages_1.messages.unableToRetrieveRorVersion);
        }
        return this.restore(pathAndFile);
    }
    isPatched() {
        const { patchedRorVersion, isCurrentlyInstalledRorVersionPatched, patchedFileChecksumFromMetadata, displayFileMetadata } = this.metadataPatcher;
        (0, helpers_1.log)('Verifying patched state...');
        if (patchedRorVersion) {
            displayFileMetadata();
        }
        else {
            throw new Error(messages_1.messages.unableToRetrieveRorVersion);
        }
        if (!this.hasBackup()) {
            throw new Error(messages_1.messages.missingBackup(this.sourceFile));
        }
        if (patchedRorVersion && !isCurrentlyInstalledRorVersionPatched) {
            throw new Error(messages_1.messages.mismatchRorVersionInfo(patchedRorVersion, (0, helpers_1.getRunningRorVersion)()));
        }
        const backupFileChecksum = (0, helpers_1.createFileChecksum)(fs.readFileSync(this.sourceFile + this.backup_suffix, 'utf8').toString('utf-8'));
        const patchedFileChecksum = (0, helpers_1.createFileChecksum)(fs.readFileSync(this.sourceFile, 'utf8').toString('utf-8'));
        if (backupFileChecksum === patchedFileChecksum) {
            (0, helpers_1.log)(messages_1.messages.kibanaNotPatched(this.sourceFile));
            return false;
        }
        const wasSuccess = patchedFileChecksumFromMetadata == patchedFileChecksum;
        if (wasSuccess) {
            (0, helpers_1.log)(messages_1.messages.patchVerified(this.sourceFile));
        }
        else {
            (0, helpers_1.log)(messages_1.messages.patchOutdated(this.sourceFile));
        }
        return wasSuccess;
    }
    patch() {
        const { writeMetadataToFile, patchedRorVersion, isCurrentlyInstalledRorVersionPatched } = this.metadataPatcher;
        if (patchedRorVersion) {
            if (isCurrentlyInstalledRorVersionPatched) {
                throw new Error(messages_1.messages.kibanaAlreadyPatched);
            }
            else {
                throw new Error(messages_1.messages.mismatchRorVersionInfo(patchedRorVersion, (0, helpers_1.getRunningRorVersion)()));
            }
        }
        if (this.hasBackup()) {
            throw new Error(`A backup file was found: ‘${this.sourceFile}${this.backup_suffix}’. Is it already patched?`);
        }
        const originalFileContent = fs.readFileSync(this.sourceFile, 'utf8').toString('utf-8');
        const patchedFileContent = diff.applyPatch(originalFileContent, this.patchContent, { fuzzFactor: 2 });
        if (patchedFileContent === false) {
            throw Error(messages_1.messages.failedToApplyPatch(this.patchFilePath, this.sourceFile));
        }
        else if (this.sourceFile !== this.destinationFile) {
            (0, helpers_1.log)(`Applied '${basename(this.patchFilePath)}' to '${this.sourceFile}' and stored it as '${this.destinationFile}'`);
        }
        else {
            (0, helpers_1.log)(`Applied '${basename(this.patchFilePath)}' to '${this.sourceFile}'`);
        }
        this.backup();
        fs.writeFileSync(this.destinationFile, patchedFileContent);
        writeMetadataToFile(patchedFileContent);
        return this;
    }
}
exports.FilePatcher = FilePatcher;
