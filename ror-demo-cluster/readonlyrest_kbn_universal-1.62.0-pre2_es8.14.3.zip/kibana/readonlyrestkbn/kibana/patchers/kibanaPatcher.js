"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.isPatchedAll = exports.main = void 0;
const filePatcher_1 = require("./filePatcher");
const helpers_1 = require("./helpers");
const messages_1 = require("./messages");
const handlePatchingConfirmation_1 = require("./handlePatchingConfirmation");
const fs = require('fs');
function main(command = process.argv.length >= 3 ? process.argv[2] : 'help') {
    try {
        (0, helpers_1.log)(`Received command: ${command}`);
        switch (command) {
            case 'unpatch':
                if (unpatchAll()) {
                    process.exitCode = 0;
                }
                else {
                    process.exitCode = -1;
                }
                break;
            case 'verify':
                if (isPatchedAll()) {
                    process.exitCode = 0;
                }
                else {
                    process.exitCode = -1;
                }
                break;
            case 'fix':
                if (fixAll()) {
                    process.exitCode = 0;
                }
                else {
                    process.exitCode = -1;
                }
                break;
            case 'patch':
                (0, handlePatchingConfirmation_1.handlePatchingConfirmation)().then((isAccepted) => {
                    if (isAccepted) {
                        if (patchAll()) {
                            process.exitCode = 0;
                        }
                        else {
                            process.exitCode = -1;
                        }
                    }
                });
                break;
            default:
                help();
        }
    }
    catch (e) {
        (0, helpers_1.log)("ReadonlyREST encountered problems with compatibility manager script, please run manually using 'ror-tools.js'  ", e);
    }
}
exports.main = main;
function patchAll() {
    try {
        if (!distroRequiresPatch()) {
            return true;
        }
        (0, helpers_1.log)('Modify a few Kibana files for ReadonlyREST...');
        return doWithPatcher(patcher => {
            if (patcher.hasBackup()) {
                (0, helpers_1.log)('Backup file found, assuming already patched. Will first unpatch and then re-patch with potentially newer code.');
                patcher.unpatch();
            }
            patcher.patch();
            return true;
        });
    }
    catch (e) {
        (0, helpers_1.log)(`ReadonlyREST encountered problems during patching: ${e.message}`);
        return false;
    }
}
function isPatchedAll() {
    try {
        (0, helpers_1.log)('Verifying the presence of ROR hooks on Kibana files..');
        return doWithPatcher(patcher => {
            if (!patcher.isPatched()) {
                (0, helpers_1.log)('This file was not patched');
                return false;
            }
            return true;
        });
    }
    catch (e) {
        (0, helpers_1.log)(`ReadonlyREST encountered problems during patching verification: ${e.message}`);
        return false;
    }
}
exports.isPatchedAll = isPatchedAll;
function unpatchAll() {
    try {
        if (!distroRequiresPatch()) {
            return true;
        }
        return doWithPatcher(patcher => {
            if (patcher.hasBackup()) {
                (0, helpers_1.log)('Backup file found!');
                patcher.unpatch();
            }
            else {
                (0, helpers_1.log)(messages_1.messages.backupFileNotApplied);
                return false;
            }
            return true;
        });
    }
    catch (e) {
        (0, helpers_1.log)(`ReadonlyREST encountered problems during unpatching: ${e.message}`);
        return false;
    }
}
function doWithPatcher(action) {
    const patchDir = (0, helpers_1.getPatchDir)();
    const matcher = /.*\.patch/gi;
    const patchFiles = fs.readdirSync(patchDir).filter((f) => f.match(matcher));
    for (let f of patchFiles) {
        f = patchDir + f; // full qualified path
        (0, helpers_1.log)(`Found patch file ${f}`);
        const backupFileSuffix = `.${(0, helpers_1.getKbnVersion)()}_${(0, helpers_1.getRunningRorVersion)()}.orig`;
        const patcher = new filePatcher_1.FilePatcher(f, (0, helpers_1.targetPathRoot)(), backupFileSuffix); // kibana main dir
        if (!action(patcher)) {
            return false;
        }
    }
    return true;
}
function distroRequiresPatch() {
    return true;
}
function fixAll() {
    try {
        (0, helpers_1.log)('Will verify and, where necessary, attempt to automatically fix patched Kibana files...');
        if (!distroRequiresPatch()) {
            return true;
        }
        let verifiedOK = false;
        try {
            verifiedOK = isPatchedAll();
        }
        catch (e) {
            (0, helpers_1.log)('Compatibility verification failed: ', e);
            verifiedOK = false;
        }
        if (!verifiedOK) {
            (0, helpers_1.log)('Attempting to re-patch...');
            try {
                verifiedOK = patchAll();
            }
            catch (e) {
                (0, helpers_1.log)("Could not fix compatibility automatically. Maybe a permissions issue? See stack trace. To fix this, use './ror-tools.js unpatch' and './ror-tools.js patch' manually", e);
                verifiedOK = false;
            }
        }
        if (verifiedOK) {
            (0, helpers_1.log)('compatibility did no need fixing. All is patched OK.');
        }
        else {
            (0, helpers_1.log)('compatibility could not be fixed: FAILED.');
        }
        return verifiedOK;
    }
    catch (e) {
        (0, helpers_1.log)('ReadonlyREST encountered problems during fixing patch:', e);
        return false;
    }
}
function help() {
    (0, helpers_1.log)(`This tool is used to (un)install some code hooks in Kibana main source code that are necessary for ReadonlyREST to work appropriately with the non-OSS Kibana distribution` +
        `\n\n` +
        `usage: node/bin/node ${process.argv[0]} ${process.argv[1]} <patch|unpatch|verify|fix>`);
}
