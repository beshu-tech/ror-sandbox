"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MetadataPatcher = void 0;
const fs_1 = __importDefault(require("fs"));
const helpers_1 = require("./helpers");
const messages_1 = require("./messages");
class MetadataPatcher {
    destinationFilePath;
    metadataFilePath;
    constructor(destinationFilePath) {
        this.destinationFilePath = destinationFilePath;
        this.metadataFilePath = `${this.destinationFilePath}.metadata.json`;
    }
    writeMetadataToFile = (patchedFileContent) => {
        try {
            const date = new Date().toISOString();
            const fileChecksum = (0, helpers_1.createFileChecksum)(patchedFileContent);
            const metadata = {
                date,
                rorVersion: (0, helpers_1.getRunningRorVersion)(),
                kbnVersion: (0, helpers_1.getKbnVersion)(),
                fileChecksum
            };
            fs_1.default.writeFileSync(this.metadataFilePath, JSON.stringify(metadata), { encoding: 'utf8', flag: 'w' });
            (0, helpers_1.log)(`${this.metadataFilePath} metadata added`);
        }
        catch (e) {
            (0, helpers_1.log)(`Error while adding metadata to the ${this.metadataFilePath} file.`, e.message);
            throw e;
        }
    };
    displayFileMetadata = () => {
        (0, helpers_1.log)(messages_1.messages.metadataInfo(this.destinationFilePath, this.patchedRorVersion, this.kibanaVersion, this.patchingDate));
    };
    removePatchingVersionFile = () => {
        try {
            fs_1.default.unlinkSync(this.metadataFilePath);
            (0, helpers_1.log)(`${this.metadataFilePath} file removed`);
        }
        catch (err) {
            const fileFound = err.code !== 'ENOENT';
            if (fileFound) {
                (0, helpers_1.log)(`Error while removing the ${this.metadataFilePath} file.`, err.message);
                throw err;
            }
        }
    };
    readMetadataFromFile() {
        let fileContents = undefined;
        try {
            fileContents = fs_1.default.readFileSync(this.metadataFilePath, 'utf8');
        }
        catch (err) {
            const fileFound = err.code !== 'ENOENT';
            if (fileFound) {
                (0, helpers_1.log)(`Error while reading the ${this.metadataFilePath} file.`, err.message);
                throw err;
            }
        }
        return fileContents ? JSON.parse(fileContents) : undefined;
    }
    get isCurrentlyInstalledRorVersionPatched() {
        const metadata = this.readMetadataFromFile();
        return metadata?.rorVersion === (0, helpers_1.getRunningRorVersion)();
    }
    get patchedRorVersion() {
        const metadata = this.readMetadataFromFile();
        return metadata?.rorVersion;
    }
    get kibanaVersion() {
        const metadata = this.readMetadataFromFile();
        return metadata?.kbnVersion;
    }
    get patchingDate() {
        const metadata = this.readMetadataFromFile();
        return metadata?.date;
    }
    get patchedFileChecksumFromMetadata() {
        const metadata = this.readMetadataFromFile();
        return metadata?.fileChecksum;
    }
}
exports.MetadataPatcher = MetadataPatcher;
