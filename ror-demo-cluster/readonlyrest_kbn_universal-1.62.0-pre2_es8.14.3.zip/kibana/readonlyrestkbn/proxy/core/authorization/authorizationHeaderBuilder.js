"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthorizationHeaderBuilder = void 0;
const types_1 = require("../common/types");
const rorLoggerFactory_1 = require("../logging/rorLoggerFactory");
const ActivationKey_1 = require("../license/ActivationKey");
class AuthorizationHeaderBuilder {
    multiTenancyEnabled;
    kibanaIndex;
    static encodeToBase64 = string => Buffer.from(string).toString('base64');
    static DUMMY_AUTHORIZATION = `Basic ${AuthorizationHeaderBuilder.encodeToBase64('_:_')}`;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(multiTenancyEnabled, kibanaIndex) {
        this.multiTenancyEnabled = multiTenancyEnabled;
        this.kibanaIndex = kibanaIndex;
    }
    deduplicateArray(array) {
        return Array.from(new Set(array));
    }
    async prepareAuthorizationHeaderFromRequest(request, activationKey) {
        const authorizationHeaders = request?.getIdentitySession?.()?.metadata.authorizationHeaders;
        const metadataToInline = this.collectMetadataFromRequest(request, activationKey);
        return this.prepareFrom(authorizationHeaders, this.deduplicateArray(metadataToInline));
    }
    async prepareAuthorizationHeaderFromMetadata(authorizationHeaders, groupId) {
        return this.prepareFrom(authorizationHeaders, [this.inlineGroupHeader(groupId)]);
    }
    prepareFrom(authorizationHeaders, metadataToInline) {
        const authorizationHeadersToInline = authorizationHeaders &&
            Array.from(authorizationHeaders.entries())
                .filter(([header]) => header !== types_1.AUTHORIZATION_HEADER)
                .map(([header, value]) => `${header}:${value}`);
        const dataToInline = authorizationHeadersToInline?.concat(metadataToInline) ?? [];
        const encodedDataToInline = `${AuthorizationHeaderBuilder.encodeToBase64(JSON.stringify({ headers: dataToInline }))}`;
        const authorization = authorizationHeaders?.get(types_1.AUTHORIZATION_HEADER) || AuthorizationHeaderBuilder.DUMMY_AUTHORIZATION;
        const finalAuthorizationHeaderWithMetadata = `${authorization}, ror_metadata=${encodedDataToInline}`;
        const headerSize = finalAuthorizationHeaderWithMetadata.length;
        if (headerSize >= 8000) {
            this.logger.warn(`Base64 encoded metadata headers length of ${headerSize} exceeded maximum length of 8KB! Please reduce the metadata size! The sum of the following headers lengths should be less than 6000: `, dataToInline.map(h => `${h.substr(0, h.indexOf(':'))}: ${Buffer.byteLength(h, 'utf8')} is characters long`));
        }
        return finalAuthorizationHeaderWithMetadata;
    }
    collectMetadataFromRequest(request, activationKey) {
        const metadata = [
            this.inlineRequestPath(request),
            this.inlineRequestMethod(request),
            this.inlineXForwardedForHeader(request),
            this.inlineKibanaIndex((0, ActivationKey_1.isEnterpriseLicense)(activationKey.license) && this.multiTenancyEnabled
                ? request.getIdentitySession()?.metadata.kibanaIndex || this.kibanaIndex
                : this.kibanaIndex)
        ];
        if ((0, ActivationKey_1.isEnterpriseLicense)(activationKey.license) && this.multiTenancyEnabled) {
            const inlineCurrentGroupHeader = this.inlineCurrentGroupHeader(request?.getIdentitySession?.()?.metadata);
            if (inlineCurrentGroupHeader) {
                metadata.push(inlineCurrentGroupHeader);
            }
        }
        function notEmpty(value) {
            return value !== null && value !== undefined;
        }
        return metadata.filter(notEmpty);
    }
    inlineGroupHeader(groupId) {
        return `${types_1.X_ROR_CURRENT_GROUP}:${groupId}`;
    }
    inlineKibanaIndex(kibanaIndex) {
        return `${types_1.X_ROR_KIBANA_INDEX}:${kibanaIndex}`;
    }
    inlineCurrentGroupHeader(session) {
        const currentGroup = session?.currentGroup;
        if (!currentGroup) {
            return null;
        }
        return `${types_1.X_ROR_CURRENT_GROUP}:${currentGroup.id}`;
    }
    inlineRequestPath(request) {
        return `${types_1.X_ROR_KIBANA_REQ_PATH}:${request.getPath()}`;
    }
    inlineRequestMethod(request) {
        return `${types_1.X_ROR_KIBANA_REQ_METHOD}:${request.getMethod()}`;
    }
    inlineXForwardedForHeader(request) {
        const xForwardedForHeader = request.getHeaders()[types_1.X_FORWARDED_FOR] || this.getIpFromOriginHeader(request) || request.getOriginAddress();
        return `${types_1.X_FORWARDED_FOR}:${xForwardedForHeader}`;
    }
    getIpFromOriginHeader(request) {
        if (!request.getHeaders()[types_1.ORIGIN_HEADER]) {
            return undefined;
        }
        const originHeaderSplit = request.getHeaders()[types_1.ORIGIN_HEADER].split('://');
        return originHeaderSplit[1];
    }
}
exports.AuthorizationHeaderBuilder = AuthorizationHeaderBuilder;
