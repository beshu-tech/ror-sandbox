"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimeUtils = void 0;
class TimeUtils {
    static MILLIS_IN_A_MINUTE = 60 * 1000;
    static minutesToMillis = (minutes) => minutes * TimeUtils.MILLIS_IN_A_MINUTE;
    static nowPlusMillis = (millisToAdd) => {
        const nowMillis = Date.now();
        return new Date(nowMillis + millisToAdd);
    };
}
exports.TimeUtils = TimeUtils;
