"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EsClient = exports.checkEsAuthorizationResponseSuccessStatus = exports.checkEsAuthorizationResponseErrorStatus = void 0;
const node_fetch_1 = __importDefault(require("node-fetch"));
const lodash_1 = __importDefault(require("lodash"));
const authorizationHeaderBuilder_1 = require("./authorization/authorizationHeaderBuilder");
const types_1 = require("./common/types");
const esSecurityHeaderBuilder_1 = require("./common/esSecurityHeaderBuilder");
const rorLogger_1 = require("./logging/rorLogger");
const rorLoggerFactory_1 = require("./logging/rorLoggerFactory");
const errors_1 = __importDefault(require("../constants/errors"));
const configUtils_1 = require("../../kibana/configUtils");
function checkEsAuthorizationResponseErrorStatus(status) {
    if (status.status < 300) {
        throw new Error('Not an error status');
    }
}
exports.checkEsAuthorizationResponseErrorStatus = checkEsAuthorizationResponseErrorStatus;
function checkEsAuthorizationResponseSuccessStatus(status) {
    if (status.status >= 300) {
        throw new Error('Not an success status');
    }
}
exports.checkEsAuthorizationResponseSuccessStatus = checkEsAuthorizationResponseSuccessStatus;
class EsClient {
    static BATCH_DELETE_CHUNK_SIZE = 100;
    esStatusRetryInterval = 5000;
    esStatusMaxRetries = 24;
    esAuthorizeUserUri = '_readonlyrest/metadata/current_user';
    configUri = '_readonlyrest/admin/config';
    testConfigUri = '_readonlyrest/admin/config/test';
    authMockUri = '_readonlyrest/admin/config/test/authmock';
    localUsersUri = '_readonlyrest/admin/config/test/localusers';
    configFileUri = '_readonlyrest/admin/config/file';
    auditLogEventUri = '_readonlyrest/admin/audit/event';
    getDefaultSpaceUrl = (kibanaIndex) => `${kibanaIndex}/_doc/space:default`;
    kibanaTechUserEsAuthToken;
    authorizationHeaderBuilder;
    esHostBalancer;
    esSSLConnectionProvider;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    customHeaders;
    constructor(kibanaTechUserEsAuthToken, esHostBalancer, esSSLConnectionProvider, multiTenancyEnabled, customHeaders, kibanaIndex) {
        this.kibanaTechUserEsAuthToken = kibanaTechUserEsAuthToken;
        this.authorizationHeaderBuilder = new authorizationHeaderBuilder_1.AuthorizationHeaderBuilder(multiTenancyEnabled, kibanaIndex);
        this.esHostBalancer = esHostBalancer;
        this.esSSLConnectionProvider = esSSLConnectionProvider;
        this.customHeaders = customHeaders;
    }
    async authorizeUser(credentialHeaders, correlationId, groupId) {
        try {
            const requestInit = await this.prepareRequestInit(credentialHeaders, correlationId, groupId);
            rorLogger_1.RorLogger.appendCorrelationId(correlationId);
            const authorizeUserResponse = await this.fetch(this.getElasticsearchUrl() + this.esAuthorizeUserUri, requestInit);
            const authorizeUserDataJson = await authorizeUserResponse.json();
            const authorizeUserData = this.formAuthorizationResponse(authorizeUserDataJson);
            this.logger.trace('Authorization attempt returned: ', JSON.stringify(authorizeUserData));
            return this.validateSuccessfulAuthorizationResponse(authorizeUserResponse, authorizeUserData);
        }
        catch (e) {
            this.logger.error(e.message, e);
            throw new Error('WRONG_CREDENTIALS');
        }
    }
    async authorizeUserAttachingMetadata(authorizationHeaders, newGroupId) {
        try {
            const headerValue = await this.authorizationHeaderBuilder.prepareAuthorizationHeaderFromMetadata(authorizationHeaders, newGroupId);
            const header = { [types_1.AUTHORIZATION_HEADER]: headerValue };
            const authorizeUserResponse = await this.fetch(this.getElasticsearchUrl() + this.esAuthorizeUserUri, {
                headers: header
            });
            const authorizeUserDataJson = await authorizeUserResponse.json();
            const authorizeUserData = this.formAuthorizationResponse(authorizeUserDataJson);
            this.logger.trace('Authorization attempt returned: ', JSON.stringify(authorizeUserData));
            return this.validateSuccessfulAuthorizationResponse(authorizeUserResponse, authorizeUserData);
        }
        catch (e) {
            this.logger.error(e.message, e);
            throw new Error('SERVER_ERROR');
        }
    }
    async getAsKibana(uri) {
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForGetRequestFrom(this.kibanaTechUserEsAuthToken);
        return this.fetch(this.getElasticsearchUrl() + uri, { headers: header });
    }
    async postAsKibana(uri, body) {
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForPostRequestFrom(this.kibanaTechUserEsAuthToken);
        return this.fetch(this.getElasticsearchUrl() + uri, {
            method: 'POST',
            headers: header,
            body
        });
    }
    async headAsKibana(uri) {
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForGetRequestFrom(this.kibanaTechUserEsAuthToken);
        return this.fetch(this.getElasticsearchUrl() + uri, { method: 'HEAD', headers: header });
    }
    async deleteAsKibana(uri) {
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForGetRequestFrom(this.kibanaTechUserEsAuthToken);
        return this.fetch(this.getElasticsearchUrl() + uri, {
            method: 'DELETE',
            headers: header
        });
    }
    async deleteBatchAsKibana(uri, documentIds) {
        const responses = [];
        let chunkId = 0;
        for (const chunk of lodash_1.default.chunk(documentIds, EsClient.BATCH_DELETE_CHUNK_SIZE)) {
            this.logger.debug(`Batch-${chunkId}: deleting ${chunk.length} ids: ${JSON.stringify(lodash_1.default.take(chunk, 3))}${chunk.length > 1 ? ' etc.' : ''}`);
            // eslint-disable-next-line no-await-in-loop
            const response = await this.postAsKibana(uri, JSON.stringify({ query: { ids: { values: chunk } } }));
            if (response.status >= 300) {
                // eslint-disable-next-line no-await-in-loop
                this.logger.warn(`Batch-${chunkId}: delete failed with response: ${JSON.stringify(await response.json())}`);
            }
            responses.push(response);
            chunkId += 1;
        }
        return responses;
    }
    async putAsKibana(uri, body) {
        const header = esSecurityHeaderBuilder_1.EsSecurityHeaderBuilder.headerForPostRequestFrom(this.kibanaTechUserEsAuthToken);
        const response = await this.fetch(this.getElasticsearchUrl() + uri, {
            method: 'PUT',
            headers: header,
            body: JSON.stringify(body)
        });
        return EsClient.toEsResponse(response);
    }
    async getConfiguration(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.configUri, {
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async getConfigurationFile(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.configFileUri, {
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async getTestConfiguration(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.testConfigUri, {
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async postTestConfiguration(authorizationHeaders, body) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.testConfigUri, {
            method: 'POST',
            headers: Array.from(authorizationHeaders.entries()).concat([['Content-Type', 'application/json']]),
            body: JSON.stringify({ settings: body.settings, ttl: body.ttl })
        });
        return EsClient.toEsResponse(response);
    }
    async getAuthMock(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.authMockUri, {
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async postAuthMock(authorizationHeaders, body) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.authMockUri, {
            method: 'POST',
            headers: Array.from(authorizationHeaders.entries()).concat([['Content-Type', 'application/json']]),
            body: JSON.stringify(body)
        });
        return EsClient.toEsResponse(response);
    }
    async getLocalUsers(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.localUsersUri, {
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async deleteTestConfiguration(authorizationHeaders) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.testConfigUri, {
            method: 'DELETE',
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    async postAuditEvent(authorizationHeaders, body) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.auditLogEventUri, {
            method: 'POST',
            headers: Array.from(authorizationHeaders.entries()).concat([['Content-Type', 'application/json']]),
            body: JSON.stringify(body)
        });
        return EsClient.toEsResponse(response);
    }
    async postConfiguration(authorizationHeaders, settings) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.configUri, {
            method: 'POST',
            headers: Array.from(authorizationHeaders.entries()).concat([['Content-Type', 'application/json']]),
            body: JSON.stringify(settings)
        });
        return EsClient.toEsResponse(response);
    }
    async checkImpersonatedUser(authorizationHeaders, impersonateAs) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.esAuthorizeUserUri, {
            headers: Array.from(authorizationHeaders.entries()).concat([[types_1.X_ROR_IMPERSONATING, impersonateAs]])
        });
        const bodyString = await response.text();
        const body = bodyString ? JSON.parse(bodyString) : bodyString;
        const authorizationResponse = this.formAuthorizationResponse(body);
        return {
            status: response.status,
            statusMessage: response.statusText,
            body: authorizationResponse
        };
    }
    async verifyUserAccess(authorizationHeaders, kibanaIndex) {
        const response = await this.fetch(this.getElasticsearchUrl() + this.getDefaultSpaceUrl(kibanaIndex), {
            method: 'GET',
            headers: Array.from(authorizationHeaders.entries())
        });
        return EsClient.toEsResponse(response);
    }
    getElasticsearchUrl() {
        return `${this.esHostBalancer.getElasticsearchUrl()}/`;
    }
    writeEsResponse(res, esResponse) {
        res.statusCode = esResponse.status;
        res.statusMessage = esResponse.statusMessage;
        res.send(esResponse.body);
    }
    async prepareRequestInit(credentialHeaders, correlationId, groupId) {
        if (groupId) {
            return {
                headers: {
                    [types_1.AUTHORIZATION_HEADER]: await this.authorizationHeaderBuilder.prepareAuthorizationHeaderFromMetadata(credentialHeaders, groupId),
                    [types_1.X_ROR_CORRELATION_ID]: correlationId,
                    ...this.customHeaders
                }
            };
        }
        const customHeadersToArray = Object.entries(this.customHeaders).map(entry => entry);
        const correlationIdToArray = Object.entries({ [types_1.X_ROR_CORRELATION_ID]: correlationId }).map(entry => entry);
        return {
            headers: Array.from(credentialHeaders.entries()).concat(customHeadersToArray, correlationIdToArray)
        };
    }
    validateSuccessfulAuthorizationResponse(response, authorizeUserData) {
        if (response.status === 401 || response.status === 403) {
            throw new Error(`ES Authorization error: ${response.status}`);
        }
        return authorizeUserData;
    }
    static async toEsResponse(response) {
        const bodyString = await response.text();
        const body = bodyString ? JSON.parse(bodyString) : bodyString;
        return {
            status: response.status,
            statusMessage: response.statusText,
            body
        };
    }
    async fetch(url, init) {
        return (0, node_fetch_1.default)(url, {
            ...init,
            headers: init?.headers,
            agent: this.esSSLConnectionProvider.getConnectionAgent()
        }).then(async (data) => {
            if (data.status === 503 || data.status === 404) {
                await this.verifyDiskThreshold(url);
            }
            return data;
        });
    }
    // method introduced to handle two formats of groups (string or object) within ROR API change (2.0.0 -> 3.0.0) (ROR 1.57.0)
    // should be removed after a few releases and the response should be treated like EsSuccessfulAuthorizationResponse
    formAuthorizationResponse(response) {
        let availableGroups;
        const availableGroupsFromResponse = response['x-ror-available-groups'];
        if (availableGroupsFromResponse) {
            if (availableGroupsFromResponse.every(item => typeof item === 'object' && item !== null)) {
                // in the new format (since ROR 1.57.0) available groups are array of objects ('id','name' properties)
                availableGroups = availableGroupsFromResponse;
            }
            else if (availableGroupsFromResponse.every(item => typeof item === 'string')) {
                // in the old format available groups are array of strings
                availableGroups = availableGroupsFromResponse.map(groupId => ({
                    id: groupId,
                    name: groupId
                }));
            }
            else {
                // should not happen
                availableGroups = [];
            }
        }
        let currentGroup;
        const currentGroupFromResponse = response['x-ror-current-group'];
        if (currentGroupFromResponse) {
            if (typeof currentGroupFromResponse === 'object' && currentGroupFromResponse !== null) {
                // in the new format  (since ROR 1.57.0) current group is object ('id','name' properties)
                currentGroup = currentGroupFromResponse;
            }
            else if (typeof currentGroupFromResponse === 'string') {
                // in the old format current group is string
                currentGroup = { id: currentGroupFromResponse, name: currentGroupFromResponse };
            }
            else {
                // should not happen
                currentGroup = undefined;
            }
        }
        const authorizationResponse = response;
        if (availableGroups) {
            authorizationResponse['x-ror-available-groups'] = availableGroups;
        }
        if (currentGroup) {
            authorizationResponse['x-ror-current-group'] = currentGroup;
        }
        return authorizationResponse;
    }
    async verifyDiskThreshold(url) {
        const allocationExplainUrl = '_cluster/allocation/explain';
        const isAllocationExplainBasedUrl = typeof url === 'string' && url.includes(allocationExplainUrl);
        if (isAllocationExplainBasedUrl) {
            return;
        }
        const response = await this.getAsKibana(allocationExplainUrl);
        const data = await response.json();
        function getDiskAllocationDecider(nodeAllocationDecisions) {
            for (const nodeDecision of nodeAllocationDecisions?.node_allocation_decisions ?? []) {
                const diskAllocationDecider = nodeDecision?.deciders?.find(deciderObj => deciderObj.decider === 'disk_threshold');
                if (diskAllocationDecider) {
                    return diskAllocationDecider;
                }
            }
            return undefined;
        }
        const decision = getDiskAllocationDecider(data);
        if (decision) {
            this.logger.error(`${decision.explanation}. Check documentation for more information https://www.elastic.co/guide/en/elasticsearch/reference/current/fix-watermark-errors.html`);
            (0, configUtils_1.exitInOneSecond)();
        }
    }
    verifyMediaType(req, res, next, acceptedMediaTypes) {
        if (req.is(acceptedMediaTypes)) {
            return next();
        }
        return res.status(415).send({
            status: 'UNSUPPORTED_MEDIA_TYPE',
            message: errors_1.default.unsupportedMediaType
        });
    }
    checkESStatus() {
        return this.getAsKibana('_cluster/health')
            .then(response => {
            if (!response.ok) {
                throw new Error(`Elasticsearch not available. Status: ${response.status}`);
            }
            return response.json();
        })
            .then(data => {
            this.logger.info(`Elasticsearch is available with status: ${data.status}`);
            return Promise.resolve();
        })
            .catch(error => {
            if (error.code === 'ECONNREFUSED') {
                this.logger.error(`Elasticsearch hasn't been initialized yet`);
            }
            else {
                this.logger.error(`Error: ${error.message}`);
            }
            return Promise.reject();
        });
    }
    waitForES = (retriesLeft = this.esStatusMaxRetries) => new Promise((resolve, reject) => {
        const attempt = () => {
            this.checkESStatus()
                .then(() => {
                resolve('success');
            })
                .catch(() => {
                if (retriesLeft === 0) {
                    this.logger.error(`Failed to connect to Elasticsearch after ${this.esStatusMaxRetries} attempts.`);
                    (0, configUtils_1.exitInOneSecond)();
                }
                else {
                    this.logger.info(`Retrying in ${this.esStatusRetryInterval / 1000} seconds... ${retriesLeft} attempts left`);
                    setTimeout(() => {
                        this.waitForES(retriesLeft - 1)
                            .then(resolve)
                            .catch(reject);
                    }, this.esStatusRetryInterval);
                }
            });
        };
        attempt();
    });
}
exports.EsClient = EsClient;
