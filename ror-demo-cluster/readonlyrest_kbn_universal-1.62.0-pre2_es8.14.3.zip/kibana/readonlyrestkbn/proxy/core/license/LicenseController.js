"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LicenseController = void 0;
const rorLoggerFactory_1 = require("../logging/rorLoggerFactory");
class LicenseController {
    licenseService;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(licenseService) {
        this.licenseService = licenseService;
    }
    async handleGetClusterUUID(req, res) {
        this.logger.info('Received GET CLUSTER UUID request');
        return res.json({ status_code: 200, status: 'ok', cluster_uuid: await this.licenseService.getClusterUUID() });
    }
    handleGet(req, res) {
        const activationKey = this.licenseService.getActivationKey();
        if (!activationKey) {
            res.status(404);
            return res.json({ status_code: 404, status: 'not found', message: 'empty license, please add a license.' });
        }
        return res.json(activationKey);
    }
    async handleDelete(req, res, onSuccess) {
        this.logger.info('Received token delete request');
        try {
            const existing = this.licenseService.getActivationKey();
            const info = await this.licenseService.removeTokenFromIndex();
            res.status(200);
            onSuccess(existing.license.edition !== info.license.edition);
            return res.json({ status_code: 200, status: 'ok' });
        }
        catch (e) {
            this.logger.error('Failed to delete license token', e);
            res.status(500);
            return res.json({ status_code: 500, status: 'ko', message: e.message });
        }
    }
    async handleAdd(req, res, onSuccess) {
        this.logger.info('Received token add request. Local cluster_uuid is: ', this.licenseService.getClusterUUID());
        const token = req.body.token;
        if (!token) {
            this.logger.error('Called add token, but no token received: ', req.body);
            res.status(400);
            return res.json({ status_code: 400, status: 'bad request', message: 'empty input' });
        }
        try {
            const existing = this.licenseService.getActivationKey();
            if (!existing || (existing && req.query.overwrite)) {
                this.logger.info(`Adding activation key ${token.substring(0, 10)}...`);
                const info = await this.licenseService.saveTokenToIndex(token);
                this.logger.info(`Found valid activation key: ID=${info.jti}`);
                res.status(200);
                onSuccess(existing.license.edition !== info.license.edition);
                return res.json({ status_code: 200, status: 'saved', license: info });
            }
            this.logger.info('License token already exists, but overwrite not requested');
            res.status(304);
            return res.json({ status_code: 304, status: 'unmodified', license: existing });
        }
        catch (e) {
            this.logger.error('Failed to add license token', e.name, e.message);
            const reason = ['LICENSE_KEY_EXPIRED', 'LICENSE_KEY_MALFORMED', 'INVALID_JWT', 'INVALID_JWT_SIGNATURE'];
            if (reason.includes(e.name)) {
                res.status(400);
                return res.json({ status_code: 400, status: e.name, message: e.message });
            }
            res.status(500);
            return res.json({ status_code: 500, status: e.name, message: e.message });
        }
    }
}
exports.LicenseController = LicenseController;
