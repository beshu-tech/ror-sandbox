"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigurationController = void 0;
class ConfigurationController {
    authController;
    authenticationFacade;
    esClient;
    constructor(esClient, authController, authenticationFacade) {
        this.authController = authController;
        this.authenticationFacade = authenticationFacade;
        this.esClient = esClient;
    }
    async handleGetConfiguration(request, res) {
        const esResponse = await this.esClient.getConfiguration(request.getAuthorizationHeaders());
        this.esClient.writeEsResponse(res, esResponse);
    }
    async handleGetConfigurationFile(request, res) {
        const esResponse = await this.esClient.getConfigurationFile(request.getAuthorizationHeaders());
        this.esClient.writeEsResponse(res, esResponse);
    }
    async handlePostConfiguration(request, res) {
        const rorRequest = request.rorRequest;
        const esResponse = await this.esClient.postConfiguration(rorRequest.getAuthorizationHeaders(), rorRequest.getBody());
        try {
            await this.authenticationFacade.verifyCurrentUser(request);
            this.esClient.writeEsResponse(res, esResponse);
        }
        catch (e) {
            await this.authController.handleLogout(request, res);
        }
    }
}
exports.ConfigurationController = ConfigurationController;
