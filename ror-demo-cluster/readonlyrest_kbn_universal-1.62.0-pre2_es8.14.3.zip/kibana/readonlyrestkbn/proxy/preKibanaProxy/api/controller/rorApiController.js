"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RorApiController = void 0;
const fs_extra_1 = __importDefault(require("fs-extra"));
const multiparty_1 = __importDefault(require("multiparty"));
const path_1 = __importDefault(require("path"));
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const errors_1 = __importDefault(require("../../../constants/errors"));
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
function isErrorInResponse(value) {
    if (!('error' in value))
        throw new Error('Response body has no error response defined');
}
function isSuccessInResponse(value) {
    if (!('status' in value))
        throw new Error('Response body has no success response defined');
}
class RorApiController {
    esClient;
    licenseService;
    constructor(esClient, licenseService) {
        this.esClient = esClient;
        this.licenseService = licenseService;
    }
    async handlePostConfiguration(request, res) {
        try {
            const esResponse = await this.esClient.postConfiguration(request.getAuthorizationHeaders(), {
                settings: request.getBody()
            });
            this.esClient.writeEsResponse(res, { ...esResponse, body: this.postEsResponseHandling(esResponse) });
        }
        catch (e) {
            res.status(500);
            logger.error(`Error handle post configuration request: ${e.name}: ${e.message}`, e);
            return res.json({ message: errors_1.default.internalServerError, status: 'INTERNAL_SERVER_ERROR' });
        }
    }
    async handleUploadConfiguration(request, res) {
        try {
            const rorRequest = request.rorRequest;
            const form = new multiparty_1.default.Form();
            form.parse(request, async (err, fields, files) => {
                try {
                    if (err) {
                        throw err;
                    }
                    if (!files?.file?.[0]) {
                        res.status(400);
                        return res.json({
                            message: errors_1.default.fileIsRequiredField,
                            status: 'NO_FILE_FIELD_PROVIDED'
                        });
                    }
                    const file = files.file[0];
                    const acceptedExtensions = ['.yml', '.yaml'];
                    const fileExtension = path_1.default.extname(file.originalFilename);
                    if (!acceptedExtensions.some(acceptedExtension => acceptedExtension === fileExtension)) {
                        res.status(400);
                        return res.json({
                            message: errors_1.default.fileExtensionOnlyYmlSupported,
                            status: 'WRONG_FILE_EXTENSION'
                        });
                    }
                    if (this.getFileSizeInMB(file.size) > 10) {
                        res.status(413);
                        return res.json({
                            message: errors_1.default.fileSizeExceeds('10MB'),
                            status: 'FILE_SIZE_EXCEEDS'
                        });
                    }
                    const esResponse = await this.esClient.postConfiguration(rorRequest.getAuthorizationHeaders(), {
                        settings: await this.fileToString(file)
                    });
                    this.esClient.writeEsResponse(res, { ...esResponse, body: this.postEsResponseHandling(esResponse) });
                }
                catch (e) {
                    res.status(500);
                    logger.error(`Error handle upload configuration request: ${e.name}: ${e.message}`, e);
                    return res.json({ message: errors_1.default.internalServerError, status: 'INTERNAL_SERVER_ERROR' });
                }
            });
        }
        catch (e) {
            res.status(500);
            logger.error(`Error handle upload configuration request: ${e.name}: ${e.message}`, e);
            return res.json({ message: errors_1.default.internalServerError, status: 'INTERNAL_SERVER_ERROR' });
        }
    }
    async handleAddLicenseKey(req, res, onSuccess) {
        logger.info('Received add activation key request. Local cluster_uuid is: ', this.licenseService.getClusterUUID());
        const license = req.body.license;
        if (!license) {
            logger.error('Called add activation key, but no license received: ', req.body);
            res.status(400);
            return res.json({ status: 'NO_LICENSE_KEY_PROVIDED', message: errors_1.default.activationKey.noLicenseKeyProvided });
        }
        try {
            const existing = this.licenseService.getActivationKey();
            if (!existing || (existing && req.query.overwrite)) {
                logger.info(`Adding activation key ${license.substring(0, 10)}...`);
                const info = await this.licenseService.saveTokenToIndex(license);
                logger.info(`Found valid activation key: ID=${info.jti}`);
                res.status(200);
                onSuccess(existing.license.edition !== info.license.edition);
                return res.json({ message: 'ok', status: 'SUCCESS', license: info });
            }
            logger.info('Activation key already exists, but overwrite not requested');
            res.status(200);
            return res.json({
                status: 'UNMODIFIED',
                message: errors_1.default.activationKey.unmodified,
                license: existing
            });
        }
        catch (e) {
            logger.error('Failed to add activation key', e.name, e.message);
            const reason = ['LICENSE_KEY_EXPIRED', 'LICENSE_KEY_MALFORMED'];
            if (reason.includes(e.name)) {
                res.status(400);
                return res.json({ status: e.name, message: e.message });
            }
            res.status(500);
            return res.json({ status: 'INTERNAL_SERVER_ERROR', message: errors_1.default.internalServerError });
        }
    }
    postEsResponseHandling(esResponse) {
        let body;
        switch (esResponse.status) {
            case 200: {
                isSuccessInResponse(esResponse.body);
                switch (esResponse.body.status) {
                    case 'ok': {
                        body = { status: 'SUCCESS', message: 'ok' };
                        break;
                    }
                    case 'ko': {
                        body = { status: 'FAILURE', message: `${esResponse.body.message}` };
                        break;
                    }
                    default: {
                        logger.warn('Cannot reload new settings:', JSON.stringify(esResponse.body));
                        body = { status: 'FAILURE', message: errors_1.default.cannotReloadNewSettings };
                        break;
                    }
                }
                break;
            }
            case 403: {
                isErrorInResponse(esResponse.body);
                const due_to = esResponse.body.error.due_to;
                if (due_to?.includes('FORBIDDEN_BY_BLOCK')) {
                    body = { status: 'FORBIDDEN', message: errors_1.default.forbidByBlockWithForbidTypeMatch };
                    break;
                }
                if (due_to?.includes('OPERATION_NOT_ALLOWED')) {
                    body = { status: 'FORBIDDEN', message: errors_1.default.noAclBlockWasMatched };
                    break;
                }
                if (due_to?.includes('READONLYREST_NOT_READY_YET')) {
                    body = { status: 'FORBIDDEN', message: errors_1.default.readonlyRestWasNotStarted };
                    break;
                }
                if (due_to?.includes('READONLYREST_FAILED_TO_START')) {
                    body = { status: 'FORBIDDEN', message: errors_1.default.readonlyRestFailedToStart };
                    break;
                }
                logger.warn(`Error status ${due_to} is not handled:`, JSON.stringify(esResponse.body));
                body = { status: 'FORBIDDEN', message: errors_1.default.operationNotAllowed };
                break;
            }
            default: {
                body = { message: esResponse.statusMessage };
                logger.warn('Post configuration Http status is not handled:', JSON.stringify(esResponse.body));
            }
        }
        return body;
    }
    fileToString = file => new Promise((resolve, reject) => {
        fs_extra_1.default.readFile(file.path, (err, data) => {
            if (err)
                return reject(err);
            resolve(data.toString());
        });
    });
    getFileSizeInMB(sizeInBytes) {
        const fileSizeInKB = sizeInBytes / 1024;
        return fileSizeInKB / 1024;
    }
}
exports.RorApiController = RorApiController;
