"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditLogEmitter = void 0;
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
var AUDIT_EVENT_TYPE;
(function (AUDIT_EVENT_TYPE) {
    AUDIT_EVENT_TYPE["LOGOUT"] = "logout";
})(AUDIT_EVENT_TYPE || (AUDIT_EVENT_TYPE = {}));
class AuditLogEmitter {
    esClient;
    static AGENT_NAME = 'readonlyrestkbn';
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(esClient) {
        this.esClient = esClient;
    }
    async emitLogoutEvent(authHeaders, origin) {
        return this.emitAuditEvent(authHeaders, {
            event_type: AUDIT_EVENT_TYPE.LOGOUT,
            agent: AuditLogEmitter.AGENT_NAME,
            origin
        });
    }
    async emitAuditEvent(authHeaders, auditEvent) {
        this.logger.debug(`Emitting audit log event: ${JSON.stringify(auditEvent)}`);
        try {
            const response = await this.esClient.postAuditEvent(authHeaders, auditEvent);
            if (response.status < 300) {
                this.logger.debug(`Successfully emitted audit event: ${JSON.stringify(auditEvent)} response: ${JSON.stringify(response)}`);
                return;
            }
            this.logger.error(`Error ${response.status} for ${auditEvent.event_type} audit event submission. (Message: ${response.statusMessage})`);
        }
        catch (e) {
            this.logger.error('Error emitting audit event:', e);
        }
    }
}
exports.AuditLogEmitter = AuditLogEmitter;
