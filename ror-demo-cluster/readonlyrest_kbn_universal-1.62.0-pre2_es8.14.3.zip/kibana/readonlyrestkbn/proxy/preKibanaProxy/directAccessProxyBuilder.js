"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DirectAccessProxyBuilder = void 0;
const express_http_proxy_1 = __importDefault(require("express-http-proxy"));
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
const requestHeadersWhitelistApplier_1 = require("../core/common/requestHeadersWhitelistApplier");
class DirectAccessProxyBuilder {
    kibanaUrl;
    pkpKibanaToken;
    requestHeadersWhitelist;
    static logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(kibanaUrl, pkpKibanaToken, requestHeadersWhitelist) {
        this.kibanaUrl = kibanaUrl;
        this.pkpKibanaToken = pkpKibanaToken;
        this.requestHeadersWhitelist = requestHeadersWhitelist;
    }
    build() {
        const proxyOptions = {
            https: false,
            preserveHostHdr: true,
            parseReqBody: true,
            // @ts-ignore
            proxyReqOptDecorator: this.authorizationHeaderDecorator,
            // @ts-ignore
            proxyErrorHandler: this.proxyErrorHandler,
            limit: '500gb',
            skipToNextHandlerFilter(proxyRes) {
                if (proxyRes.statusCode === 404) {
                    // It's the only way to handle proxy 404 request since proxyErrorHandler doesn't work in this case
                    rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename).error(`The request ${proxyRes.method} ${proxyRes.url} was handled as a readonlyrest_kbn.whitelistedPaths, but resulted in a 404. Please check the list of whitelisted paths and review they are all valid and correct. Typically this option is used only for health checks. See documentation: https://docs.readonlyrest.com/kibana#enable-health-check-endpoint`);
                }
                return false;
            }
        };
        // @ts-ignore
        return (0, express_http_proxy_1.default)(this.kibanaUrl, proxyOptions);
    }
    authorizationHeaderDecorator = async (proxyRequestOptions, sourceRequest) => {
        if (!proxyRequestOptions.headers) {
            proxyRequestOptions.headers = {};
        }
        requestHeadersWhitelistApplier_1.RequestHeadersWhitelistApplier.apply(DirectAccessProxyBuilder.logger, this.requestHeadersWhitelist, sourceRequest.headers, proxyRequestOptions.headers);
        proxyRequestOptions.headers['x-ror-pkp-kibana-token'] = this.pkpKibanaToken;
        return proxyRequestOptions;
    };
    proxyErrorHandler = (error, res, next) => {
        rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename).trace('error: ', error);
        next(error);
    };
}
exports.DirectAccessProxyBuilder = DirectAccessProxyBuilder;
