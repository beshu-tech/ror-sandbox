"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ManagementDisableTransformer = void 0;
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const lodash_1 = __importDefault(require("lodash"));
// eslint-disable-next-line import/no-cycle
const index_1 = require("../index");
class ManagementDisableTransformer {
    static transform(cap, metadata) {
        const capsToDeactivate = (0, index_1.getCapabilitiesToRemove)(metadata);
        ManagementDisableTransformer.hideManagementSecurityBasedSubApps(cap);
        if (!capsToDeactivate.includes('management')) {
            return cap;
        }
        // Update catalogue: remove management menu related capabilities
        cap = lodash_1.default.merge(cap, {
            catalogue: {
                index_lifecycle_management: false,
                snapshot_restore: false,
                rollup_jobs: false,
                watcher: false,
                transform: false,
                spaces: false
            }
        });
        // Management submenu: remove everything
        const managementSection = cap.management;
        for (const subsection in managementSection) {
            if (Object.prototype.hasOwnProperty.call(managementSection, subsection)) {
                ManagementDisableTransformer.disableAll(managementSection[subsection]);
            }
        }
        return cap;
    }
    static disableAll(o) {
        (0, index_1.mutateAllCapabilitiesInObject)(o, () => false);
    }
    static hideManagementSecurityBasedSubApps(cap) {
        ManagementDisableTransformer.disableAll(cap.management.security);
        (0, index_1.overridePropertiesByJsonPath)(cap, ['navLinks.securitySolutionUI', 'management.stack.license_management'], () => false);
    }
}
exports.ManagementDisableTransformer = ManagementDisableTransformer;
