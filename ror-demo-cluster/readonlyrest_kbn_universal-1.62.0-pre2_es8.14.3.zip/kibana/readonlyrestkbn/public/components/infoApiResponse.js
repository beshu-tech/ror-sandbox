"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.InfoApiResponse = exports.Distribution = exports.Identity = void 0;
class Identity {
    username;
    kibanaHiddenApps;
    correlationId;
    kibanaAccess;
    impersonatedBy;
    currentGroup;
    availableGroups;
    constructor(username, kibanaHiddenApps, correlationId, kibanaAccess, impersonatedBy, currentGroup, availableGroups) {
        this.username = username;
        this.kibanaHiddenApps = kibanaHiddenApps;
        this.correlationId = correlationId;
        this.kibanaAccess = kibanaAccess;
        this.impersonatedBy = impersonatedBy;
        this.currentGroup = currentGroup;
        this.availableGroups = availableGroups;
    }
}
exports.Identity = Identity;
class Distribution {
    versionString;
    kibanaVersion;
    rorEdition;
    rorVersion;
    isProduction;
    isEnterprise;
    isPro;
    isFree;
    isBuildExpired;
    constructor(versionString, kibanaVersion, rorEdition, rorVersion, isProduction, isEnterprise, isPro, isFree, isBuildExpired) {
        this.versionString = versionString;
        this.kibanaVersion = kibanaVersion;
        this.rorEdition = rorEdition;
        this.rorVersion = rorVersion;
        this.isProduction = isProduction;
        this.isEnterprise = isEnterprise;
        this.isPro = isPro;
        this.isFree = isFree;
        this.isBuildExpired = isBuildExpired;
    }
}
exports.Distribution = Distribution;
class InfoApiResponse {
    identity;
    licenseInfo;
    distribution;
    cluster_uuid;
    constructor(identity, licenseInfo, distribution, cluster_uuid) {
        this.identity = identity;
        this.licenseInfo = licenseInfo;
        this.distribution = distribution;
        this.cluster_uuid = cluster_uuid;
    }
}
exports.InfoApiResponse = InfoApiResponse;
