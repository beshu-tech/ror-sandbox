"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
module.exports = (() => {
    let migrator;
    return {
        setMigrator: (newMigrator) => {
            if (!migrator) {
                migrator = newMigrator;
            }
        },
        runMigration: async (kibanaIndex, logger) => {
            if (!migrator) {
                logger.debug('Automatic migration is only available for the Kibana >= 8.x. Automatic migration skipped.');
                return;
            }
            const kibanaIndexMigrator = migrator.kibanaIndexMigrator(kibanaIndex);
            kibanaIndexMigrator.prepareMigrations();
            await kibanaIndexMigrator.runMigrations();
        },
        clearMigrator: () => {
            migrator = undefined;
        }
    };
})();
