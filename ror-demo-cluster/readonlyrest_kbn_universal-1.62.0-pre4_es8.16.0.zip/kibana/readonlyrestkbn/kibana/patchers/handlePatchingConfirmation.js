"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handlePatchingConfirmation = exports.rl = void 0;
const helpers_1 = require("./helpers");
const readline_1 = __importDefault(require("readline"));
function getArgValue(argName) {
    const arg = process.argv.find(arg => arg.startsWith(`--${argName}=`));
    return arg ? arg.split('=')[1] : null;
}
function patchingConfirmation() {
    (0, helpers_1.log)("NOTICE: This script patches Kibana to work with the ReadonlyREST plugin. The patch modifies Kibana source files\nas required by the ReadonlyREST plugin. By proceeding, you confirm understanding and acceptance of responsibility for\nmodifying Kibana in compliance with Elastic's licensing. Please read: https://docs.readonlyrest.com/kibana#patching-kibana");
    return new Promise(resolve => {
        const acceptedFromArgParameter = getArgValue('I_UNDERSTAND_AND_ACCEPT_KBN_PATCHING');
        const acceptedFromEnvVariable = process.env.I_UNDERSTAND_AND_ACCEPT_KBN_PATCHING;
        if (acceptedFromArgParameter === 'yes' || acceptedFromEnvVariable === 'yes') {
            (0, helpers_1.log)(`The script received the I_UNDERSTAND_AND_ACCEPT_KBN_PATCHING value as ${acceptedFromArgParameter ? 'argument' : 'environment variable'}.`);
            resolve('yes');
        }
        else {
            exports.rl = readline_1.default.createInterface({
                input: process.stdin,
                output: process.stdout
            });
            exports.rl.question('Type "yes" to continue: ', choice => {
                resolve(choice.trim());
                exports.rl.close();
            });
        }
    });
}
async function handlePatchingConfirmation() {
    const choice = await patchingConfirmation();
    switch (choice.trim()) {
        case 'yes':
            (0, helpers_1.log)('Patching process is continuing...');
            return true;
        default:
            (0, helpers_1.log)('Invalid choice. Please try again.\n');
            return await handlePatchingConfirmation();
    }
}
exports.handlePatchingConfirmation = handlePatchingConfirmation;
