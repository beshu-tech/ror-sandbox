"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RorLoggerFactory = void 0;
const path_1 = __importDefault(require("path"));
const rorLogger_1 = require("./rorLogger");
const logLevel_1 = require("./logLevel");
// eslint-disable-next-line import/no-cycle
const consoleAppender_1 = require("./appenders/consoleAppender");
// eslint-disable-next-line import/no-cycle
const fileAppender_1 = require("./appenders/fileAppender");
class RorLoggerFactory {
    static DEFAULT_LOG_LEVEL = logLevel_1.LogLevel.INFO;
    static CURRENT_LOG_LEVEL = RorLoggerFactory.DEFAULT_LOG_LEVEL;
    static logger = RorLoggerFactory.getLogger('LoggerFactory');
    static destinations = [{ type: 'console' }];
    static getLoggerForFile(filePath) {
        return RorLoggerFactory.getLogger(path_1.default.parse(filePath).name);
    }
    static setAppender(logDestinations, fileName) {
        const appenders = [];
        logDestinations?.forEach(logDestination => {
            switch (logDestination?.type) {
                case 'file': {
                    appenders.push(new fileAppender_1.FileAppender(fileName, logDestination.path));
                    break;
                }
                default: {
                    appenders.push(new consoleAppender_1.ConsoleAppender(fileName));
                }
            }
        });
        return appenders;
    }
    static getLogger(fileName) {
        return new rorLogger_1.RorLogger(this.setAppender(RorLoggerFactory.destinations, fileName));
    }
    static initLogs(logLevel, logDestinations) {
        RorLoggerFactory.CURRENT_LOG_LEVEL = logLevel;
        RorLoggerFactory.destinations = logDestinations;
        RorLoggerFactory.logger.debug(`Setting logLevel to: ${logLevel_1.LogLevel[logLevel]}`);
    }
    static isLoggingEnabled(logLevel) {
        return RorLoggerFactory.CURRENT_LOG_LEVEL.valueOf() >= logLevel.valueOf();
    }
}
exports.RorLoggerFactory = RorLoggerFactory;
