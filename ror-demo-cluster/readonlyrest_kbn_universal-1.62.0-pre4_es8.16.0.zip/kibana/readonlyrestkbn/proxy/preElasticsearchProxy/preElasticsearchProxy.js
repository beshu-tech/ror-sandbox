"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PreElasticsearchProxy = void 0;
const express_http_proxy_1 = __importDefault(require("express-http-proxy"));
const express_1 = __importDefault(require("express"));
const tcp_port_used_1 = __importDefault(require("tcp-port-used"));
const morgan_1 = __importDefault(require("morgan"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const requestInterceptor_1 = require("./requestInterceptor");
const distributionInfoProvider_1 = require("../../kibana/patchers/distributionInfoProvider");
const esSSLConnectionProvider_1 = require("../core/esSSLConnectionProvider");
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
const rorRequestAppender_1 = require("../core/rorRequestAppender");
const requestHeadersWhitelistApplier_1 = require("../core/common/requestHeadersWhitelistApplier");
const types_1 = require("../core/common/types");
const SpecialCaseDetector_1 = require("./SpecialCaseDetector");
class PreElasticsearchProxy {
    rorRequestAppender;
    esHostBalancer;
    esSSLConnectionProvider;
    app;
    server;
    interceptor;
    networkParameters;
    kibanaTechUserEsAuthToken;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    requestHeadersWhitelist;
    authorizationHeadersValidation;
    constructor(sessionManager, rorRequestAppender, esHostBalancer, esSSLConnectionProvider, params, authorizationHeadersValidation, licenseService) {
        this.rorRequestAppender = rorRequestAppender;
        this.esHostBalancer = esHostBalancer;
        this.esSSLConnectionProvider = esSSLConnectionProvider;
        this.app = (0, express_1.default)();
        this.interceptor = new requestInterceptor_1.RequestInterceptor(sessionManager, params.kibanaIndex, params.reportingIndex, params.multiTenancyEnabled, licenseService);
        this.esHostBalancer = esHostBalancer;
        this.kibanaTechUserEsAuthToken = params.kibanaTechUserEsAuthToken;
        this.networkParameters = params.networkParameters;
        this.requestHeadersWhitelist = params.requestHeadersWhitelist;
        this.authorizationHeadersValidation = authorizationHeadersValidation;
        this.init(params.port);
    }
    close() {
        this.server?.close();
    }
    init(proxyPort) {
        this.app.use((0, cookie_parser_1.default)());
        this.app.disable('x-powered-by');
        this.app.use((req, res, next) => {
            res.on('finish', async () => {
                if (res.statusCode === 401 || res.statusCode === 403) {
                    await this.authorizationHeadersValidation.revalidate(req);
                }
            });
            next();
        });
        this.app.use(rorRequestAppender_1.RorRequestAppender.appendRorRequest);
        this.app.use(this.rorRequestAppender.appendIdentitySession);
        this.app.use(this.roAndRoStrictUserResponseMock);
        this.initDevInterceptors();
        // @ts-ignore
        this.app.use((0, express_http_proxy_1.default)(this.getElasticsearchUrl, this.getProxyOptions()));
        this.launchProxyServer(proxyPort);
    }
    initDevInterceptors() {
        if (distributionInfoProvider_1.DistributionInfoProvider.isEnvironmentDev()) {
            this.app.use((0, morgan_1.default)('PEP :method :url :status :response-time ms - :res[content-length]')); // http logging interceptor
        }
    }
    getElasticsearchUrl = () => this.esHostBalancer.getElasticsearchUrl();
    getProxyOptions() {
        return {
            https: false,
            timeout: this.networkParameters.requestTimeout,
            preserveHostHdr: false,
            parseReqBody: true,
            limit: '500gb',
            memoizeHost: false,
            proxyReqOptDecorator: this.proxyReqOptDecorator,
            proxyReqPathResolver: async (req) => this.interceptor.replaceIdxInPath(req.rorRequest),
            proxyReqBodyDecorator: (body, req) => this.interceptor.replaceIdxInBody(body, req.rorRequest),
            userResDecorator: this.interceptor.userResDecorator,
            proxyErrorHandler: this.proxyErrorHandler
        };
    }
    proxyErrorHandler = (error, res, next) => {
        if (error?.code === 'ECONNREFUSED') {
            res.status(503).send(`Elasticsearch host ${this.getElasticsearchUrl()} is unavailable`);
            return;
        }
        next(error);
    };
    proxyReqOptDecorator = async (proxyRequestOptions, sourceRequest) => {
        if (!proxyRequestOptions.headers) {
            proxyRequestOptions.headers = {};
        }
        // It fixed the ECONNREFUSED socket hang up issue in the case of Elasticsearch calls. This issue is probably caused by the Node 20.x version, which is used starting from Kibana 7.17.17. By default, the connection header has the value 'close'. It is a similar problem to the one mentioned here https://github.com/node-fetch/node-fetch/issues/1735.
        proxyRequestOptions.headers.connection = 'keep-alive';
        proxyRequestOptions.headers['keep-alive'] = 'timeout=10, max=1000';
        const getIdentitySession = sourceRequest.rorRequest.getIdentitySession();
        if (getIdentitySession?.metadata.correlationId) {
            proxyRequestOptions.headers[types_1.X_ROR_CORRELATION_ID] = getIdentitySession?.metadata.correlationId;
        }
        requestHeadersWhitelistApplier_1.RequestHeadersWhitelistApplier.apply(this.logger, this.requestHeadersWhitelist, sourceRequest.headers, proxyRequestOptions.headers);
        // Make sure we forward authorization when present
        if (sourceRequest.headers.authorization) {
            proxyRequestOptions.headers.authorization = sourceRequest.headers.authorization;
        }
        if (SpecialCaseDetector_1.SpecialCaseDetector.shouldChangeUserCredentialsToTechUserCredentials(proxyRequestOptions)) {
            proxyRequestOptions.headers.authorization = this.kibanaTechUserEsAuthToken;
        }
        if (!proxyRequestOptions.headers.authorization) {
            const reason = SpecialCaseDetector_1.SpecialCaseDetector.shouldAttachTechUserCredentialsWhenMissing(proxyRequestOptions);
            if (reason) {
                this.logger.trace(`No auth headers found: attaching tech user creds for "${reason}" request: ${proxyRequestOptions.method} ${proxyRequestOptions.path}`);
                proxyRequestOptions.headers.authorization = this.kibanaTechUserEsAuthToken;
            }
        }
        if (this.esSSLConnectionProvider.getCertificationType() === esSSLConnectionProvider_1.SSLCertificationType.PEM) {
            proxyRequestOptions.ca = this.esSSLConnectionProvider.getCertificateAuthorities();
        }
        if (this.esSSLConnectionProvider.getCertificationType() === esSSLConnectionProvider_1.SSLCertificationType.PKC12) {
            proxyRequestOptions.pfx = this.esSSLConnectionProvider.getTruststore().truststore;
            proxyRequestOptions.passphrase = this.esSSLConnectionProvider.getTruststore().password;
        }
        proxyRequestOptions.rejectUnauthorized = this.esSSLConnectionProvider.isVerificationEnabled();
        delete proxyRequestOptions.headers.cookie;
        return proxyRequestOptions;
    };
    launchProxyServer(port) {
        // for some reason kibana invokes this 3 times, so this is in order to avoid ERRADDRRINUSE
        // edit: in fact, there are probably 3 threads, let's see if we can do something about it
        const host = '127.0.0.1';
        tcp_port_used_1.default.check(port, host).then(async (inUse) => {
            if (!inUse) {
                this.logger.info(`Pre-Elasticsearch-proxy will listen on ${host}:${port}`);
                this.server = await this.app.listen(port, host);
            }
        });
    }
    /**
     * ro and ro_strict kibana access user is allowed to perform read actions but sometimes kibana wants to perform POST action for example
     * to send statistics, in this case, we need to intercept this request and send mocked success status, if not user won't, ro and ro_strict user
     * won't be able to open Discover, Dashboard, Canvas, or Data Views kibana pages
     */
    roAndRoStrictUserResponseMock = (req, res, next) => {
        const kibanaAccessToRequestMock = ['ro', 'ro_strict'].some(access => access === req?.rorRequest?.getIdentitySession()?.metadata?.kibanaAccess);
        const pathsToCheck = ['/_bulk', '_update/core-usage-stats%3Acore-usage-stats'].some(path => req.path.includes(path));
        const allowedMethods = req.method.toLowerCase() === 'post';
        if (allowedMethods && pathsToCheck && kibanaAccessToRequestMock) {
            try {
                const rorMetadata = req.headers.authorization?.split('ror_metadata=')[1];
                if (!rorMetadata) {
                    throw new Error('ror_metadata not available');
                }
                const decryptedRorMetadata = JSON.parse(Buffer.from(rorMetadata, 'base64').toString('ascii'));
                const kibanaRequestPath = decryptedRorMetadata.headers.find(value => value.includes(types_1.X_ROR_KIBANA_REQ_PATH)) ??
                    ''.split(`${types_1.X_ROR_KIBANA_REQ_PATH}:`)?.[1];
                if (!kibanaRequestPath) {
                    throw new Error('Kibana request path not available');
                }
                const whitelistedKibanaBulkRequests = [
                    'api/canvas/workpad/resolve',
                    'api/saved_objects/_bulk_resolve',
                    'api/timelion/run',
                    'api/metrics/vis/data',
                    'api/lens/existing_fields',
                    'api/lens/stats'
                ];
                if (whitelistedKibanaBulkRequests.every(whitelistedKibanaBulkRequest => !kibanaRequestPath.includes(whitelistedKibanaBulkRequest))) {
                    this.logger.debug(`${req.path} path sent by ${kibanaRequestPath} was not mocked`);
                    next();
                }
                res.setHeader('x-opaque-id', 'unknownId');
                res.setHeader('x-elastic-product', 'Elasticsearch');
                res.setHeader('content-type', 'application/json; charset=utf-8');
                return res.status(200).send(JSON.stringify({
                    took: 0,
                    errors: false,
                    items: [
                        {
                            create: {
                                status: 201
                            }
                        }
                    ]
                }));
            }
            catch (e) {
                this.logger.error('RO user /_bulk response decorator error', e);
                return res.status(500).json({ status_code: 500, status: 'ko', message: e.message });
            }
        }
        next();
    };
}
exports.PreElasticsearchProxy = PreElasticsearchProxy;
