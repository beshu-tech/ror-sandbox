"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestInterceptor = void 0;
const errors_1 = __importDefault(require("../constants/errors"));
const kibanaIndexTweaker_1 = require("./kibanaIndexTweaker");
const rorLoggerFactory_1 = require("../core/logging/rorLoggerFactory");
const SpecialCaseDetector_1 = require("./SpecialCaseDetector");
const ActivationKey_1 = require("../core/license/ActivationKey");
const types_1 = require("../core/common/types");
/**
 *   Main logic
 * - if (!req.headers.authorization && req.url.includes(reportingIndex)), string replace using getMostRecentlyAccessed
 * - if (!(req.url + req.body).includes(defaultKibanaIndex)) do nothing
 * - If no session found, special cases (_bulk,  user-agent=elasticsearch.js, etc.) append tech user credentials
 * - Normalize URL & body to minimal form .kibana*_X.Y.Z -> .kibana*
 * - If no session found, API special cases (reporting, /action/, /alert/) string replace using getMostRecentlyAccessed
 * - If session has metadata AND has metadata.kibanaIndex, use that to string replace (URL & body)
 * - don’t touch anything otherwise
 *
 * We need to have this logic split in two handlers (one for the path & headers replacement, one for the body string replacement
 * Because we are using express-http-proxy library which does not have a global request changing hook.
 * see: https://github.com/villadora/express-http-proxy/issues/507
 */
class RequestInterceptor {
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    kibanaIndex;
    reportingIndex;
    sessionManager;
    multiTenancyEnabled;
    licenseService;
    DUMMY_ORIGIN = 'http://dummy-origin';
    constructor(sessionManager, kibanaIndex, reportingIndex, multiTenancyEnabled, licenseService) {
        this.kibanaIndex = kibanaIndex;
        this.reportingIndex = reportingIndex;
        this.sessionManager = sessionManager;
        this.multiTenancyEnabled = multiTenancyEnabled;
        this.licenseService = licenseService;
    }
    async replaceIdxInPath(request) {
        const { source, kibanaIndex } = await this.getKibanaIndexForReplacement(request);
        switch (source) {
            case 'kibanaIndexFromSession':
            case 'kibanaIndexFromMetadata':
            case 'kibanaIndexFromMostRecentlyAccessedSession': {
                return kibanaIndexTweaker_1.KibanaIndexTweaker.replaceKibanaIndexWithTenantIndexAndNormalize(request.getUrl(), kibanaIndex, this.kibanaIndex, this.reportingIndex);
            }
            case 'kibanaIndexFromQuery': {
                const url = new URL(`${this.DUMMY_ORIGIN}${request.getUrl()}`);
                // Es cannot handle custom query params
                url.searchParams.delete(types_1.X_ROR_KIBANA_INDEX);
                return kibanaIndexTweaker_1.KibanaIndexTweaker.replaceKibanaIndexWithTenantIndexAndNormalize(url.pathname, kibanaIndex, this.kibanaIndex, this.reportingIndex);
            }
            case 'PreElasticsearchProxyParams': {
                return kibanaIndexTweaker_1.KibanaIndexTweaker.normalizeKibanaIndex(request.getUrl(), kibanaIndex);
            }
            case 'whitelistedUrl':
            case 'noKibanaIndexToReplace': {
                return request.getUrl();
            }
            default: {
                throw new Error(errors_1.default.wrongTypeOfIndicesSource);
            }
        }
    }
    async replaceIdxInBody(bodyContent, request) {
        const { source, kibanaIndex } = await this.getKibanaIndexForReplacement(request);
        switch (source) {
            case 'kibanaIndexFromSession':
            case 'kibanaIndexFromMetadata':
            case 'kibanaIndexFromQuery':
            case 'kibanaIndexFromMostRecentlyAccessedSession': {
                return Buffer.from(kibanaIndexTweaker_1.KibanaIndexTweaker.replaceKibanaIndexWithTenantIndexAndNormalize(bodyContent.toString(), kibanaIndex, this.kibanaIndex, this.reportingIndex));
            }
            case 'PreElasticsearchProxyParams': {
                return Buffer.from(kibanaIndexTweaker_1.KibanaIndexTweaker.normalizeKibanaIndex(bodyContent.toString(), kibanaIndex));
            }
            case 'whitelistedUrl':
            case 'noKibanaIndexToReplace': {
                return bodyContent;
            }
            default: {
                throw new Error(errors_1.default.wrongTypeOfIndicesSource);
            }
        }
    }
    userResDecorator = (proxyRes, proxyResData, userReq, userRes) => {
        const anySpaceConfigRegexp = /(.*\/[^/]*\.\.\/|.*\/_doc\/[^/]*config%3A.*)/;
        if (userReq.method === 'GET' && anySpaceConfigRegexp.test(userReq.url)) {
            const parsedData = proxyResData.length > 0 ? JSON.parse(proxyResData.toString()) : proxyResData;
            if (parsedData.found) {
                const userSettings = userReq.cookies.rorUserSettings ? JSON.parse(userReq.cookies.rorUserSettings) : {};
                return Buffer.from(JSON.stringify(this.parseUserSettingsData(userSettings, parsedData)));
            }
        }
        if (userRes.statusCode === 404) {
            const parsedData = proxyResData.length > 0 ? JSON.parse(proxyResData.toString()) : proxyResData;
            if (parsedData?.error?.root_cause?.some(rootCause => rootCause.type === 'no_such_remote_cluster_exception')) {
                /**
                 * We need to override the status to success to resolve the issue of defining a remote cluster
                 * in the data views https://readonlyrest.atlassian.net/browse/RORDEV-778
                 */
                userRes.statusCode = 200;
                this.logger.warn(proxyResData.toString());
            }
        }
        return proxyResData;
    };
    async getKibanaIndexForReplacement(request) {
        const kibanaIndexFromSession = request.getIdentitySession()?.metadata?.kibanaIndex;
        const whitelistedUrls = [
            '/_mapping?expand_wildcards=none',
            '/_settings',
            '/_security/user/_has_privileges',
            '_reindex',
            '_index_template'
        ];
        if (whitelistedUrls.some(whitelistedUrl => request.getUrl().includes(whitelistedUrl))) {
            return { source: 'whitelistedUrl', kibanaIndex: undefined };
        }
        if (kibanaIndexFromSession &&
            this.multiTenancyEnabled &&
            (0, ActivationKey_1.isEnterpriseLicense)(this.licenseService.getActivationKey().license)) {
            return { source: 'kibanaIndexFromSession', kibanaIndex: kibanaIndexFromSession };
        }
        // ".kibana_7.13.4" -> ".kibana" (necessary because kibana_access rule expects ".kibana")
        if (request.getIdentitySession()?.metadata) {
            return { source: 'PreElasticsearchProxyParams', kibanaIndex: this.kibanaIndex };
        }
        const reason = SpecialCaseDetector_1.SpecialCaseDetector.shouldAttachMostRecentSessionKibanaIndex(request.getUrl(), this.reportingIndex);
        if (reason) {
            if (reason === 'isReportingRequest') {
                const url = new URL(`${this.DUMMY_ORIGIN}${request.getUrl()}`);
                const params = new URLSearchParams(url.search);
                const kibanaIndexFromQuery = params.get(types_1.X_ROR_KIBANA_INDEX);
                if (kibanaIndexFromQuery) {
                    return {
                        source: 'kibanaIndexFromQuery',
                        kibanaIndex: kibanaIndexFromQuery
                    };
                }
                // TODO: We need to patch all Kibana versions to be able to use kibanaIndexFromQuery, for now, we still need to be able to set kibanaIndexFromMostRecentlyAccessedSession for non-patching versions
                // return { source: 'noKibanaIndexToReplace', kibanaIndex: undefined };
            }
            const kibanaIndexFromMostRecentlyAccessedSession = this.sessionManager.getMostRecentlyAccessed()?.kibanaIndex;
            if (kibanaIndexFromMostRecentlyAccessedSession) {
                return {
                    source: 'kibanaIndexFromMostRecentlyAccessedSession',
                    kibanaIndex: kibanaIndexFromMostRecentlyAccessedSession
                };
            }
            this.logger.trace(`Could not access most recently accessed session's kibanaIndex for ${reason}`);
            return { source: 'noKibanaIndexToReplace', kibanaIndex: undefined };
        }
        const rorMetadata = request.getHeaders()?.authorization?.split('ror_metadata=')[1];
        if (rorMetadata) {
            const decryptedRorMetadata = JSON.parse(Buffer.from(rorMetadata, 'base64').toString('ascii'));
            const kibanaIndexFromMetadata = decryptedRorMetadata.headers.find(value => value.includes(types_1.X_ROR_KIBANA_INDEX)) ??
                ''.split(`${types_1.X_ROR_KIBANA_INDEX}:`)?.[1];
            if (kibanaIndexFromMetadata) {
                return {
                    source: 'kibanaIndexFromMetadata',
                    kibanaIndex: kibanaIndexFromMetadata.split(':')[1]
                };
            }
        }
        return { source: 'noKibanaIndexToReplace', kibanaIndex: undefined };
    }
    parseUserSettingsData(userSettings, parsedData) {
        const convertBooleanStringToBoolean = (object, key) => {
            const trimmedKey = key.trim();
            object[trimmedKey] = userSettings[trimmedKey];
            if (object[trimmedKey] === 'true') {
                object[trimmedKey] = true;
            }
            if (object[trimmedKey] === 'false') {
                object[trimmedKey] = false;
            }
            return object;
        };
        const mappedSettings = Object.keys(userSettings).reduce(convertBooleanStringToBoolean, {});
        parsedData._source.config = {
            ...parsedData._source.config,
            ...mappedSettings
        };
        return parsedData;
    }
}
exports.RequestInterceptor = RequestInterceptor;
