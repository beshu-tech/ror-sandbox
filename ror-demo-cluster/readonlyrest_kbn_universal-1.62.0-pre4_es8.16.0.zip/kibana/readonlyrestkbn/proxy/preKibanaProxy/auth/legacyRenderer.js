"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LegacyRenderer = void 0;
const fs_1 = __importDefault(require("fs"));
const sanitizer_1 = __importDefault(require("sanitizer"));
const types_1 = require("../../core/common/types");
const templateCompiler_1 = require("./template/templateCompiler");
const rorLoggerFactory_1 = require("../../core/logging/rorLoggerFactory");
const logLevel_1 = require("../../core/logging/logLevel");
const ActivationKey_1 = require("../../core/license/ActivationKey");
const distributionInfoProvider_1 = require("../../../kibana/patchers/distributionInfoProvider");
const csrf_1 = require("./csrf");
const TEXT_HTML_UTF8 = 'text/html; charset=utf-8';
const TEXT_CSS_UTF8 = 'text/css; charset=utf-8';
const APPLICATION_JAVASCRIPT_UTF8 = 'application/javascript; charset=UTF-8';
class LegacyRenderer {
    basePath;
    legacySSOButtonProps;
    licenseService;
    clearSessionOnEvents;
    loginPageCustomizations;
    injectCustomJs;
    sessionProbeTemplateArgs;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(basePath, probeIntervalMillis, cookieName, legacySSOButtonProps, licenseService, clearSessionOnEvents, loginPageCustomizations, customJsInjection, customJsFileContentInjection, customLoginJsInjection) {
        this.basePath = basePath;
        this.legacySSOButtonProps = legacySSOButtonProps;
        this.licenseService = licenseService;
        this.clearSessionOnEvents = clearSessionOnEvents;
        this.loginPageCustomizations = loginPageCustomizations;
        this.sessionProbeTemplateArgs = {
            intervalMillis: probeIntervalMillis,
            sessionProbeUrl: `${this.basePath}/pkp/session-probe`,
            baseLogoutUrl: `${this.basePath}/logout`,
            sessionProbePrefix: `${cookieName}`,
            enableLogging: rorLoggerFactory_1.RorLoggerFactory.isLoggingEnabled(logLevel_1.LogLevel.DEBUG)
        };
        const mixedCustomJsContentInjection = `${customJsInjection ?? ''} 
    ${customJsFileContentInjection ?? ''}`;
        this.logger.trace(`Injecting custom user js: ${Boolean(customJsInjection)}. ` +
            `Injecting custom user js for the login page: ${Boolean(customLoginJsInjection)}. ` +
            `Injecting custom user js file content: ${Boolean(customJsFileContentInjection)}`);
        this.injectCustomJs = LegacyRenderer.buildCustomJsInjection(mixedCustomJsContentInjection);
    }
    renderLoginPage = async (req, res) => {
        try {
            const compiledHtml = (0, templateCompiler_1.compile)('./login_tpl.html', await this.buildLoginTemplateArgs());
            res.setHeader(types_1.CONTENT_TYPE_HEADER, TEXT_HTML_UTF8);
            return res.send(compiledHtml);
        }
        catch (error) {
            this.logger.error(`Failed to render login page: ${error}`);
            return res.status(200).send((0, templateCompiler_1.compile)('./loading_tpl.html', {
                title: 'Kibana is not ready yet',
                error: 'Please hold while we sync up with Elasticsearch...',
                year: new Date().getFullYear()
            }));
        }
    };
    renderLoginDeferredScript = async (req, res) => {
        try {
            const csrfToken = csrf_1.Csrf.generateToken(res, req);
            const compiled = (0, templateCompiler_1.compile)('./login_tpl_defer.js', await this.buildLoginTemplateArgs(csrfToken));
            return this.renderJs(res, compiled);
        }
        catch (error) {
            this.logger.error(`<h1>Failed to render login deferred script</h1> <p>${error}</p>`);
            return res.sendStatus(500);
        }
    };
    renderSessionProbeInjection = (req, res) => this.renderJs(res, (0, templateCompiler_1.compile)('../../injection/scripts/sessionProbe.js', this.sessionProbeTemplateArgs));
    renderCustomUserJsInjection = (req, res) => this.renderJs(res, this.injectCustomJs(req.rorRequest?.getIdentitySession?.()?.metadata));
    renderActivationKeyExpirationAlert = (req, res) => {
        const license = this.licenseService.getActivationKey();
        const identitySession = req.rorRequest.getIdentitySession();
        const javascript = (0, templateCompiler_1.compile)('../../injection/scripts/activationKeyExpirationAlert.js', {
            expirationDateEpoch: license.exp,
            isTrial: license.license.isTrial,
            kibanaAccess: identitySession?.metadata?.kibanaAccess
        });
        return this.renderJs(res, javascript);
    };
    renderSwitchGroup = (req, res) => {
        const compiledHtml = (0, templateCompiler_1.compile)('./switch_group_tpl.html', this.buildSwitchGroupTemplateArgs());
        res.setHeader(types_1.CONTENT_TYPE_HEADER, TEXT_HTML_UTF8);
        return res.send(compiledHtml);
    };
    renderSwitchGroupDeferredScript = (req, res) => this.renderJs(res, (0, templateCompiler_1.compile)('./switch_group_tpl_defer.js', this.buildSwitchGroupTemplateArgs()));
    renderHiddenAppsInjection = (req, res) => {
        const kibanaHiddenApps = req.rorRequest?.getIdentitySession?.()?.metadata.kibanaHiddenApps;
        const appNames = kibanaHiddenApps || [];
        const templateArgs = {
            hiddenApps: [appNames.map(app => `"${app}"`)],
            basePath: this.basePath,
            appRegistryPath: `${this.basePath}/pkp/api/kbn_app_registry`,
            hiddenAppsRegistryPath: `${this.basePath}/pkp/api/kbn_app_registry/hidden`
        };
        const javascript = (0, templateCompiler_1.compile)('../../injection/scripts/hiddenApps.js', templateArgs);
        return this.renderJs(res, javascript);
    };
    renderRorCssClassesInjection = (req, res) => {
        const rorMetadata = req.rorRequest?.getIdentitySession?.()?.metadata;
        const kibanaHiddenApps = rorMetadata?.kibanaHiddenApps;
        const appNames = kibanaHiddenApps || [];
        const javascript = (0, templateCompiler_1.compile)('../../injection/scripts/rorCssClasses.js', {
            username: rorMetadata?.username || '',
            currentGroupId: rorMetadata?.currentGroup?.id || '',
            kibanaAccess: rorMetadata?.kibanaAccess || '',
            hiddenApps: [appNames.map(app => `"${app}"`)]
        });
        return this.renderJs(res, javascript);
    };
    renderRedirect(url) {
        return `<script>console.log("redirecting to ${url}"); window.location.href = '${url}'</script>`;
    }
    renderJwtRedirect = (jwt, headers) => `<script src="${this.basePath}/pkp/autodeps?file=jquery/dist/jquery.min.js"></script>
    <script>
    const nextUrl = window.sessionStorage.getItem("nextUrl");
    let loginRedirect = "${this.basePath}/login";
    if (nextUrl) {
        loginRedirect = loginRedirect + "?nextUrl=" + nextUrl
    }
    const destUrl = "${this.basePath}/login"
    const jsonBodyAsString = '{"${types_1.CONNECTOR_SVC_TRANSIENT_JWT}": "${jwt}"}'
    
    jQuery.ajax({
      url: destUrl,
      method: 'POST',
      contentType : 'application/json',
      headers: ${headers},
      dataType: "json",
      data: jsonBodyAsString,
      async: false
    })
    window.location.href = loginRedirect
    </script>`;
    serveDependenciesAutomaticallyFromNodeModules = (req, res) => {
        const pathRequested = sanitizer_1.default.sanitize(req?.query?.file?.toString());
        if (pathRequested?.indexOf('..') >= 0) {
            const msg = 'You cannot navigate backwards..';
            this.logger.warn(msg);
            return res.status(403).send(msg);
        }
        const path2serve = `${__dirname}/../../../node_modules/${pathRequested}`.replace('//', '/');
        this.logger.debug(`Fetching frontend dependency: ${path2serve}`);
        const callback = (err, data) => {
            if (err) {
                const msg = `Something went wrong with finding the dependency: ${err.message}`;
                this.logger.warn(msg, err);
                return res.status(404).send('Something went wrong with finding the dependency. See errors in Kibana logs.');
            }
            if (path2serve.endsWith('.js')) {
                res.setHeader(types_1.CONTENT_TYPE_HEADER, APPLICATION_JAVASCRIPT_UTF8);
            }
            else if (path2serve.endsWith('.css')) {
                res.setHeader(types_1.CONTENT_TYPE_HEADER, TEXT_CSS_UTF8);
            }
            else {
                const msg = `File extension not allowed: ${pathRequested}`;
                this.logger.warn(msg, err);
                return res.status(403).send('File extension not allowed. See errors in Kibana logs.');
            }
            return res.send(data);
        };
        fs_1.default.readFile(path2serve, 'utf8', (err, data) => {
            try {
                callback(err, data);
            }
            catch (e) {
                this.logger.error(`Autodeps failed to serve ${pathRequested}`, e);
            }
        });
        return res;
    };
    renderJs = (res, javascript) => {
        res.setHeader(types_1.CONTENT_TYPE_HEADER, APPLICATION_JAVASCRIPT_UTF8);
        return res.send(javascript);
    };
    buildLoginTemplateArgs = (csrfToken) => {
        const license = this.licenseService.getActivationKey().license;
        const isEnterprise = (0, ActivationKey_1.isEnterpriseLicense)(license);
        const isFree = (0, ActivationKey_1.isFreeLicense)(license);
        const title = isFree ? null : this.loginPageCustomizations?.title;
        const subtitle = isFree ? null : this.loginPageCustomizations?.subtitle;
        const logoPath = isFree ? null : this.loginPageCustomizations?.logoPath;
        const headInject = isFree ? null : this.loginPageCustomizations?.htmlHeadInject;
        const customJSInject = isFree ? null : this.loginPageCustomizations?.customJSInjectFile;
        const customCSSInject = isFree ? null : this.loginPageCustomizations?.customCSSInjectFile;
        const ssoConnectors = isEnterprise ? this.legacySSOButtonProps : [];
        const activationKey = this.licenseService.getActivationKey();
        return {
            basePath: this.basePath,
            kbnVersion: distributionInfoProvider_1.DistributionInfoProvider.getInstance().kibanaVersion,
            logoutUrl: `${this.basePath}/logout`,
            loginUrl: `${this.basePath}/login`,
            ssoConnectors: JSON.stringify(ssoConnectors),
            clearSessionOnEvents: JSON.stringify(this.clearSessionOnEvents),
            year: new Date().getFullYear(),
            edition: activationKey.license.edition,
            editionDisplayName: activationKey.license.edition_name,
            loginLogo: logoPath || `${this.basePath}/pkp/legacy/web/assets/readonlyrest_square_white.png`,
            loginTitle: title || '',
            loginSubtitle: subtitle || '',
            columns: !title && !subtitle ? 1 : 2,
            headInject: headInject || '',
            customJSInject: customJSInject || '',
            customCSSInject: `<style>${customCSSInject}</style>` || '',
            message: '',
            csrfToken,
            csrfHeaderName: csrf_1.Csrf.CSRF_HEADER_NAME
        };
    };
    buildSwitchGroupTemplateArgs = () => ({
        basePath: this.basePath
    });
    static buildCustomJsInjection(customJsInjection) {
        return function (rorMetadata) {
            if (customJsInjection == null) {
                return '';
            }
            return `
        const kibanaLoaded = new Promise((resolve) => {
        new MutationObserver((mutations, observer) => {
          for (const mutation of mutations) {
            for (const removedNode of mutation.removedNodes) {
              const kibanaSpinnerId = 'kbn_loading_message';
              if(removedNode.id === kibanaSpinnerId) {
                observer.disconnect();
                resolve();
                break;
              }
            }
          }
        })
          .observe(document.body, { childList: true  });
      });
      
      kibanaLoaded.then(() => {
        window.ROR_METADATA = ${JSON.stringify(rorMetadata)};
        ${customJsInjection}
      });
    `;
        };
    }
}
exports.LegacyRenderer = LegacyRenderer;
