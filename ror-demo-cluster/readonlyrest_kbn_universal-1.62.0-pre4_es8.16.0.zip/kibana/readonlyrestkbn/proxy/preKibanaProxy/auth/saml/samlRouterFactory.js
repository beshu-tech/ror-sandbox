"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SamlRouterFactory = void 0;
const express = __importStar(require("express"));
const passport_saml_1 = require("passport-saml");
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const express_session_1 = __importDefault(require("express-session"));
const passport_1 = require("passport");
const samlController_1 = require("./samlController");
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const timeUtils_1 = require("../../../core/common/timeUtils");
const cookieManager_1 = require("../../../core/cookieManager");
const PASSPORT_SAML_STRATEGY = 'saml';
class SamlRouterFactory {
    jwtSigner;
    legacyRenderer;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(jwtSigner, legacyRenderer) {
        this.jwtSigner = jwtSigner;
        this.legacyRenderer = legacyRenderer;
    }
    build(config) {
        const samlStrategy = this.buildSamlStrategy(config);
        const samlControllerConfig = SamlRouterFactory.buildSamlControllerConfig(config);
        const samlController = new samlController_1.SamlController(samlControllerConfig, samlStrategy, this.jwtSigner, this.legacyRenderer);
        const router = express.Router();
        const passport = SamlRouterFactory.configurePassport(samlStrategy);
        router.use(express.urlencoded({ extended: true }));
        router.use((0, cookie_parser_1.default)());
        const cookieOptions = cookieManager_1.CookieManager.getCookiesOptions();
        cookieOptions.secure = config.callbackURL?.toLowerCase()?.trim().startsWith('https');
        this.logger.trace(`${config.connectorName} will set a cookie valid for ${timeUtils_1.TimeUtils.nowPlusMillis(cookieOptions?.maxAge ?? 0)} minutes.`);
        const sessionOptions = {
            name: config.cookieConfig.name,
            secret: config.cookieConfig.password,
            cookie: cookieOptions,
            resave: false,
            saveUninitialized: false,
            unset: 'destroy'
        };
        // @ts-ignore
        router.use((0, express_session_1.default)(sessionOptions));
        // @ts-ignore
        router.use(passport.initialize());
        router.use(passport.session());
        router.get('metadata.xml', samlController.onGetMetadata);
        router.get(config.loginPath, passport.authenticate(PASSPORT_SAML_STRATEGY, err => {
            if (err) {
                this.logger.error(`${config.connectorName} error:`, err);
            }
        }));
        router.use(config.loginCallbackPath, (req, res) => passport.authenticate(PASSPORT_SAML_STRATEGY, { failureRedirect: '/', failureFlash: true }, (err, user, info) => {
            if (!user) {
                return this.handleLoginCallbackError(config, err, req, res, info);
            }
            /**
             * We cannot save user information directly in the req.user because login redirect clearing all request, and it ends up with req.user undefined
             * To avoid it, we need to store user info directly in the session
             */
            req.session.user = user;
            return samlController.onLoginCallback(req, res);
        })(req, res));
        router.use(config.logoutPath, samlController.onLogout);
        router.use(config.logoutCallbackPath, samlController.onLogoutCallback);
        return router;
    }
    static buildSamlStrategyConfig(config) {
        const samlStrategyConfig = {
            cert: config.cert,
            protocol: config.protocol,
            entryPoint: config.entryPoint,
            issuer: config.issuer,
            callbackUrl: config.callbackURL,
            logoutCallbackUrl: config.logoutCallbackUrl,
            decryptionPvk: config.decryptionPvk
        };
        if (config.disableRequestedAuthnContext) {
            samlStrategyConfig.disableRequestedAuthnContext = config.disableRequestedAuthnContext;
        }
        if (config.authnContext) {
            samlStrategyConfig.authnContext = config.authnContext;
        }
        if (config.identifierFormat || config.identifierFormat === null) {
            samlStrategyConfig.identifierFormat = config.identifierFormat;
        }
        // These configuration values need to be either not null OR be completely absent, otherwise passport-saml crashes.
        if (config.privateCert) {
            samlStrategyConfig.privateCert = config.privateCert;
        }
        if (config.decryptionPvk) {
            samlStrategyConfig.decryptionPvk = config.decryptionPvk;
        }
        return Object.assign(samlStrategyConfig, config.extraConfig);
    }
    static buildSamlControllerConfig(config) {
        return {
            connectorName: config.connectorName,
            usernameParameter: config.usernameParameter,
            groupsParameter: config.groupsParameter,
            cookieConfig: config.cookieConfig,
            logoutPath: config.logoutPath
        };
    }
    static configurePassport(samlStrategy) {
        const passport = new passport_1.Passport();
        passport.serializeUser((user, next) => next(null, user));
        passport.deserializeUser((obj, next) => next(null, obj));
        // @ts-ignore
        passport.use(samlStrategy);
        return passport;
    }
    buildSamlStrategy(config) {
        const strategyConfig = SamlRouterFactory.buildSamlStrategyConfig(config);
        this.logger.trace(`Strategy config: ${JSON.stringify(strategyConfig)}`);
        const verifyWithoutReq = (profile, done) => {
            rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename).debug(`Obtained raw profile: ${JSON.stringify(profile)}`);
            done(null, profile ?? undefined);
        };
        return new passport_saml_1.Strategy(strategyConfig, verifyWithoutReq);
    }
    handleLoginCallbackError(config, err, req, res, info) {
        this.logger.error(`${config.connectorName} error:`, err || info || res);
        req.logout(() => {
            res.clearCookie(config.cookieConfig.name, { path: '/' });
            return res.send(`<h2> There was an error in the SAML connector ${config.connectorName}</h2> 
       <p>For more information, consult the kibana logs.</p>`);
        });
    }
}
exports.SamlRouterFactory = SamlRouterFactory;
