"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbstractIndexCreator = void 0;
const rorLoggerFactory_1 = require("../../core/logging/rorLoggerFactory");
const tenantIndexBasedOnTemplateApplier_1 = require("./indexTemplating/tenantIndexBasedOnTemplateApplier");
// eslint-disable-next-line @typescript-eslint/no-var-requires
const migrator = require('../../../kibana/migrator');
class AbstractIndexCreator {
    esClient;
    defaultKibanaIndex;
    logger;
    indexTemplateApplier;
    constructor(esClient, defaultKibanaIndex, implementorFilePathForLogging, resetKibanaIndexToTemplate, templateIndexFromConfig) {
        this.esClient = esClient;
        this.defaultKibanaIndex = defaultKibanaIndex;
        this.esClient = esClient;
        this.logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(implementorFilePathForLogging);
        this.indexTemplateApplier = new tenantIndexBasedOnTemplateApplier_1.TenantIndexBasedOnTemplateApplier(esClient, resetKibanaIndexToTemplate, templateIndexFromConfig);
    }
    async createIndexIfNecessary(kibanaIndex, kibanaTemplateIndexFromSession) {
        if (!(await this.doesIndexExist(kibanaIndex))) {
            this.logger.debug(`Kibana index ${kibanaIndex} did not exist`);
            await this.createKibanaIndex(kibanaIndex, this.defaultKibanaIndex);
        }
        await this.createKibanaTenantBasedIndex(kibanaIndex, 'analytics');
        await this.createKibanaTenantBasedIndex(kibanaIndex, 'alerting_cases');
        await this.createKibanaTenantBasedIndex(kibanaIndex, 'security_solution');
        await this.createKibanaTenantBasedIndex(kibanaIndex, 'ingest');
        await this.createKibanaTenantBasedIndex(kibanaIndex, 'usage_counters');
        await this.indexTemplateApplier.applyTemplateToIndex(kibanaIndex, kibanaTemplateIndexFromSession);
    }
    async createKibanaTenantBasedIndex(kibanaIndex, suffix) {
        if (await this.doesIndexExist(`${this.defaultKibanaIndex}_${suffix}`)) {
            if (!(await this.doesIndexExist(`${kibanaIndex}_${suffix}`))) {
                this.logger.debug(`Creating tenant based index for .kibana_${suffix}`);
                await this.createKibanaIndex(kibanaIndex, `${this.defaultKibanaIndex}_${suffix}`);
            }
        }
    }
    async migrateIndexes(kibanaIndex) {
        if (await this.isMigrationNeeded(kibanaIndex)) {
            await migrator.runMigration(kibanaIndex, this.logger);
        }
    }
    async getDefaultIndexMapping(index) {
        const response = await this.esClient.getAsKibana(`${index}/_mapping`);
        const mappingsJsonResponse = await response.json();
        const { error } = mappingsJsonResponse;
        if (mappingsJsonResponse.status === 404) {
            this.logger.debug('Kibana index mappings not found', JSON.stringify(mappingsJsonResponse));
            throw new Error('Kibana index mappings not found');
        }
        if (error) {
            this.logger.error('Error in reading kibana index mappings: ', mappingsJsonResponse);
            throw new Error(JSON.stringify(mappingsJsonResponse));
        }
        this.logger.debug(`Mappings extracted from default kibana index (${index}):`, `${JSON.stringify(mappingsJsonResponse).substring(0, 30)}...`);
        return mappingsJsonResponse;
    }
    async doesIndexExist(kibanaIndex) {
        const response = await this.esClient.headAsKibana(kibanaIndex);
        return response.status === 200;
    }
}
exports.AbstractIndexCreator = AbstractIndexCreator;
