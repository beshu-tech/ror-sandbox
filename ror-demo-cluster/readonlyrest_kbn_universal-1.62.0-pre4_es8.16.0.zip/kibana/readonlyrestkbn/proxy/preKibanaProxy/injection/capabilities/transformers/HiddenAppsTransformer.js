"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.HiddenAppsTransformer = void 0;
// eslint-disable-next-line import/no-cycle
const index_1 = require("../index");
const rorLoggerFactory_1 = require("../../../../core/logging/rorLoggerFactory");
class HiddenAppsTransformer {
    static logger = () => rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    static transform(cap, metadata) {
        const capsToDeactivate = (0, index_1.getCapabilitiesToRemove)(metadata);
        const mutate = (section, o) => (0, index_1.mutateAllCapabilitiesInObject)(o[section], (capability, subApp) => {
            const enableSubAppCapability = () => {
                const isSubAppDisabledViaSpacesApi = subApp && !o[section][capability][subApp];
                if (isSubAppDisabledViaSpacesApi) {
                    return false;
                }
                const enable = !capsToDeactivate.find(c => c === subApp);
                if (!enable) {
                    HiddenAppsTransformer.logger().trace(`Disabling capability ${section}.${capability}.${subApp}`);
                }
                return enable;
            };
            const enableCapability = () => {
                const isAppDisabledViaSpacesApi = !o[section][capability];
                if (isAppDisabledViaSpacesApi) {
                    return false;
                }
                const enable = !capsToDeactivate.find(c => c === capability);
                if (!enable) {
                    HiddenAppsTransformer.logger().trace(`Disabling capability ${section}.${capability}`);
                }
                return enable;
            };
            if (subApp) {
                return enableSubAppCapability();
            }
            return enableCapability();
        });
        mutate('navLinks', cap);
        mutate('catalogue', cap);
        mutate('management', cap);
        return cap;
    }
}
exports.HiddenAppsTransformer = HiddenAppsTransformer;
