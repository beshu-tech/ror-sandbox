/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

import '@testing-library/jest-dom';
import MutationObserver from '@sheerun/mutationobserver-shim';

import { TextEncoder, TextDecoder } from 'util';
import replaceAllInserter from 'string.prototype.replaceall';
import dns from 'dns';
import { BroadcastChannelMock } from './test/__mocks__/BroadcastChannelMock';

global.BroadcastChannel = BroadcastChannelMock;

// eslint-disable-next-line no-undef
jest.retryTimes(3);

global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;
global.MutationObserver = MutationObserver;

// eslint-disable-next-line @typescript-eslint/no-empty-function
dns.setDefaultResultOrder = () => {};

replaceAllInserter.shim();
