"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const fieldset_1 = __importDefault(require("../common/fieldset"));
function Group({ label, children }) {
    const theme = sessionStorage.getItem('rorTheme');
    const borderColor = theme === 'dark' ? '#4d4c4c' : '#d3dae6';
    const textColor = theme === 'dark' ? '#dfe5ef' : '#1a1c21';
    return ((0, jsx_runtime_1.jsx)(fieldset_1.default, { legend: {
            children: label,
            style: { color: textColor }
        }, style: {
            border: `1px solid ${borderColor}`,
            margin: '2px 0',
            padding: '5.6px 12px 10px'
        }, children: children }));
}
exports.default = Group;
