"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PageBody = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function PageBody({ children }) {
    return (0, jsx_runtime_1.jsx)(eui_1.EuiPageBody, { children: children });
}
exports.PageBody = PageBody;
