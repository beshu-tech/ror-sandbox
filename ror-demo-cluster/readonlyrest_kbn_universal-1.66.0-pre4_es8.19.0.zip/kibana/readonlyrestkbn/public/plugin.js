"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReadonlyrestKbnPlugin = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const react_dom_1 = __importDefault(require("react-dom"));
const rorMenu_1 = require("./components/rorMenu");
const coreFunctions_1 = __importDefault(require("./utils/coreFunctions"));
const infoApiResponse_1 = require("./components/infoApiResponse");
const ActivationKey_1 = require("../proxy/core/license/ActivationKey");
const themeProvider_1 = require("./providers/themeProvider");
class ReadonlyrestKbnPlugin {
    kibanaVersion;
    info = new infoApiResponse_1.InfoApiResponse(new infoApiResponse_1.Identity('', [], '', '', '', undefined, []), undefined, undefined, '', { clearSessionOnEvents: ['login', 'tenancyHop'] });
    constructor(initializerContext) {
        this.kibanaVersion = initializerContext.env.packageInfo.version;
    }
    setup() {
        return {};
    }
    async start(core) {
        coreFunctions_1.default.initialization(core);
        const response = await fetch(`${coreFunctions_1.default.serverBasePathPrepend('/pkp')}/api/info`);
        this.info = await response.json();
        console.log('>> info ', this.info);
        coreFunctions_1.default.overwriteKibanaContent(this.kibanaVersion, this.info.licenseInfo?.license.edition ?? ActivationKey_1.EDITIONS_ENUM.FREE);
        core.chrome.navControls.registerRight({
            order: 10000,
            mount: target => this.mount(target)
        });
        return {};
    }
    mount(target) {
        const redirectToLogout = coreFunctions_1.default.serverBasePathPrepend('/logout');
        react_dom_1.default.render((0, jsx_runtime_1.jsx)(themeProvider_1.ThemeProvider, { kibanaVersion: this.kibanaVersion, children: (0, jsx_runtime_1.jsx)(rorMenu_1.RorMenu, { pkpBasePath: coreFunctions_1.default.serverBasePathPrepend('/pkp'), logoutRedirect: redirectToLogout, clearSessionOnEvents: this.info.config.clearSessionOnEvents, info: this.info }) }), target);
        return () => react_dom_1.default.unmountComponentAtNode(target);
    }
}
exports.ReadonlyrestKbnPlugin = ReadonlyrestKbnPlugin;
