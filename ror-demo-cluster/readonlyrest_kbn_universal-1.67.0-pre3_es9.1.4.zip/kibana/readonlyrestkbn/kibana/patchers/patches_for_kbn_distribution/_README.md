# Features
## [RORDEV-888-APM-support for all versions](https://readonlyrest.atlassian.net/browse/RORDEV-888) and Handle xpack.security.enabled=true
[authorization_mode.patch](authorization_mode.patch)
[authorized_user_pre_routing.patch](authorized_user_pre_routing.patch)

## [RORDEV-872 Provide a kibana.index support for 8.x > version](https://readonlyrest.atlassian.net/browse/RORDEV-872)
[ensure_valid_configuration.patch](ensure_valid_configuration.patch)
[saved_objects_service.patch](saved_objects_service.patch)

## [RORDEV-878 fix Rules -> logs logout issue](https://readonlyrest.atlassian.net/browse/RORDEV-878)
[event_log_client.patch](event_log_client.patch)

## [RORDEV-1052 reporting for Kibana 8.x.x](https://readonlyrest.atlassian.net/browse/RORDEV-1052)
[get_document_payload.patch](get_document_payload.patch)
[jobs_management_pre_routing.patch](jobs_management_pre_routing.patch)
[jobs_query.patch](jobs_query.patch)
[management_jobs.patch](management_jobs.patch)
[reporting.js.patch](reporting.js.patch)
[request_handler.patch](request_handler.patch)
[store.patch](store.patch)

## [RORDEV-343 Patch kibana port logging](https://readonlyrest.atlassian.net/browse/RORDEV-343)
[http_server.js.patch](http_server.js.patch)

## [RORDEV-1170 fix migration issue for Kibana > 8.7.1](https://readonlyrest.atlassian.net/browse/RORDEV-1170)
[run_v2_migration.js.patch](run_v2_migration.js.patch)

## [RORDEV-898 Provide a POC for the automated migration of tenancy indices on major Kibana version upgrade](https://readonlyrest.atlassian.net/browse/RORDEV-898)
[saved_objects_service.patch](saved_objects_service.patch)
[saved_object_index_pattern.patch](saved_object_index_pattern.patch)
[server.patch](server.patch)

## [RORDEV-511 Intercept KBN configuration after ENV and CLI overrides](https://readonlyrest.atlassian.net/browse/RORDEV-511)
[serve.js.patch](serve.js.patch)

## [RORDEV-1541 readonlyrest_kbn.whitelistedPaths does't work when xpack.security.enabled: true](https://readonlyrest.atlassian.net/browse/RORDEV-1541)
[authentication_service.patch](authentication_service.patch)
