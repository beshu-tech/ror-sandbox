"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Popover = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
const themeProvider_1 = require("../../providers/themeProvider");
function Popover({ children, style, id, isOpen, anchorPosition, closePopover, panelPaddingSize, hasArrow, button, repositionOnScroll = true, ownFocus = false, ...props }) {
    const emptyCloseAction = () => 'noop';
    const { theme } = (0, themeProvider_1.useTheme)();
    const backgroundColor = theme.colors.bgPaper;
    return (
    // @ts-ignore
    (0, jsx_runtime_1.jsx)(eui_1.EuiPopover, { panelStyle: { backgroundColor }, button: button, 
        // @ts-ignore
        style: style, id: id, isOpen: isOpen, anchorPosition: anchorPosition, closePopover: closePopover || emptyCloseAction, panelPaddingSize: panelPaddingSize, repositionOnScroll: repositionOnScroll, hasArrow: hasArrow, ownFocus: ownFocus, ...props, children: children }));
}
exports.Popover = Popover;
