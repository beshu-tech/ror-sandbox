"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExternalAlertingAndReportingLink = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const button_1 = require("../common/button");
const text_1 = require("../common/text");
const flexGroup_1 = require("../common/flexGroup");
function ExternalAlertingAndReportingLink() {
    return ((0, jsx_runtime_1.jsxs)(flexGroup_1.FlexGroup, { id: "external-alerting-and-reporting-link", style: { alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }, children: [(0, jsx_runtime_1.jsx)(text_1.Text, { style: { marginBottom: '16px' }, children: "Kibana alerting does not work with ReadonlyREST, but we are working on an even better alerting and reporting solution." }), (0, jsx_runtime_1.jsx)(button_1.Button, { href: "https://anaphora.it", target: "_blank", children: "Register your interest" })] }));
}
exports.ExternalAlertingAndReportingLink = ExternalAlertingAndReportingLink;
