"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LicenseBadge = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const eui_1 = require("@elastic/eui");
function LicenseBadge({ info, showSecuritySettings, openActivationKeyTab }) {
    const getExpiresIn = () => {
        function daysUntilNow(epochSeconds) {
            const A_DAY_IN_MILLISECONDS = 1000 * 60 * 60 * 24;
            const now = new Date();
            const expirationDate = new Date(epochSeconds * 1000);
            const diff = expirationDate.getTime() - now.getTime();
            return Math.ceil(diff / A_DAY_IN_MILLISECONDS);
        }
        // epoch to days until expiry
        return daysUntilNow(info.licenseInfo?.exp ?? -1);
    };
    const licenseBadgeColor = () => {
        const edition = info.licenseInfo?.license.edition;
        if (edition === 'kbn_free') {
            // Free does not expire
            return '#4DD2CA';
        }
        const days2Expiry = getExpiresIn();
        if (days2Expiry < 30) {
            return '#BD271E';
        }
        return '#0077CC';
    };
    const licenseBadgeIcon = () => {
        const days2Expiry = getExpiresIn();
        if (days2Expiry < 30) {
            return 'alert';
        }
        return info.licenseInfo?.license.edition === 'kbn_free' ? 'pencil' : 'check';
    };
    const licenseBadgeText = () => {
        const days2Expiry = getExpiresIn();
        let daysText = '';
        if (days2Expiry < 30) {
            daysText = ` (${days2Expiry} days left!)`;
        }
        return (info.licenseInfo?.license.edition_name ?? 'UNKNOWN') + daysText;
    };
    const licenseTooltipText = () => info.licenseInfo?.license.edition === 'kbn_free' ? 'Add activation key' : 'Edit activation key';
    const canSeeActivationKey = Boolean(info?.identity.kibanaAccess === 'admin' || info?.identity.kibanaAccess === 'unrestricted');
    if (showSecuritySettings() && canSeeActivationKey) {
        return (
        /* @ts-ignore */
        (0, jsx_runtime_1.jsx)(eui_1.EuiToolTip, { content: licenseTooltipText(), children: (0, jsx_runtime_1.jsx)(eui_1.EuiBadge, { onClick: openActivationKeyTab, onClickAriaLabel: "open-activation-key", iconOnClick: openActivationKeyTab, iconOnClickAriaLabel: "icon-open-activation-key", style: { width: 'fit-content', marginLeft: '8px' }, color: licenseBadgeColor(), iconType: licenseBadgeIcon(), children: licenseBadgeText() }) }));
    }
    return ((0, jsx_runtime_1.jsx)(eui_1.EuiBadge, { style: { width: 'fit-content', marginLeft: '8px' }, color: licenseBadgeColor(), iconType: licenseBadgeIcon(), children: licenseBadgeText() }));
}
exports.LicenseBadge = LicenseBadge;
exports.default = LicenseBadge;
