"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.dark9xTheme = exports.lightTheme = exports.darkTheme = void 0;
exports.darkTheme = {
    colors: {
        bgDefault: '#07101f',
        bgPaper: '#1E1D24',
        hover: '#FFFFFF14',
        textPrimary: '#dfe5ef',
        border: '#4d4c4c',
        popoverBorder: 'inherit',
        codeBackground: '#25262E',
        backdropBackground: '#00000080'
    },
    variant: 'dark'
};
exports.lightTheme = {
    colors: {
        bgDefault: '#f5f7fa',
        bgPaper: '#ffffff',
        hover: '#0000000a',
        textPrimary: '#1a1c21',
        border: '#d3dae6',
        popoverBorder: '#d3dae6',
        codeBackground: '#F5F7FA',
        backdropBackground: '#485975B3'
    },
    variant: 'light'
};
exports.dark9xTheme = {
    colors: {
        bgDefault: '#07101f',
        bgPaper: '#0b1628',
        hover: '#FFFFFF14',
        textPrimary: '#FFFFFF',
        border: '#2b394f',
        popoverBorder: '#2b394f',
        codeBackground: '#182335',
        backdropBackground: '#2B394FB3'
    },
    variant: 'dark-9x'
};
