"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.useApplyCssVariables = void 0;
const react_1 = require("react");
const mapToCssVariables = (obj, prefix = '--ror') => {
    const cssVariables = {};
    Object.entries(obj).forEach(([key, value]) => {
        const varName = `${prefix}-${key}`;
        cssVariables[varName] = value;
    });
    return cssVariables;
};
const setCssVariables = (obj) => {
    const root = document.documentElement;
    Object.entries(obj).forEach(([key, value]) => {
        root.style.setProperty(key, value);
    });
};
const useApplyCssVariables = ({ theme }) => {
    const cssVariables = (0, react_1.useMemo)(() => mapToCssVariables(theme.colors), [theme.colors]);
    (0, react_1.useLayoutEffect)(() => {
        setCssVariables(cssVariables);
        document.body.setAttribute('data-theme', theme.variant);
    }, [cssVariables, theme]);
    return { cssVariables };
};
exports.useApplyCssVariables = useApplyCssVariables;
