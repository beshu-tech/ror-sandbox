"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const react_dom_1 = __importDefault(require("react-dom"));
const semver = __importStar(require("semver"));
const external_alerting_and_reporting_link_1 = require("../components/external-alerting-and-reporting-link");
const pro_or_enterprise_feature_page_1 = require("../components/pro-or-enterprise-feature-page");
const ActivationKey_1 = require("../../shared/types/ActivationKey");
/**
 * The Singleton class defines the `getInstance` method that lets clients access
 * the unique singleton instance.
 */
class CoreFunctions {
    core;
    static checkInitialization(core) {
        if (!core) {
            throw new Error('You need to initialized your class first');
        }
    }
    initialization(core) {
        this.core = core;
    }
    redirect(pathname) {
        CoreFunctions.checkInitialization(this.core);
        this.core.application.navigateToUrl(pathname);
    }
    /**
     * Prepend basePath and Include kibana space url namespace
     * @param pathname
     */
    basePathPrepend(pathname) {
        CoreFunctions.checkInitialization(this.core);
        return this.core.http.basePath.prepend(pathname);
    }
    /**
     * Prepend basePath and Ignore kibana space url namespace
     * @param pathname
     */
    serverBasePathPrepend(pathname) {
        CoreFunctions.checkInitialization(this.core);
        return `${this.serverBasePath}${pathname}`;
    }
    getSettingsParameter(parameter) {
        CoreFunctions.checkInitialization(this.core);
        return this.core.uiSettings.get(parameter);
    }
    overwriteKibanaContent(kibanaVersion, licenseEdition) {
        CoreFunctions.checkInitialization(this.core);
        function handleLocationChange() {
            const pathname = window.location.pathname;
            const externalAlertingAndReportingLink = document.querySelector('#external-alerting-and-reporting-link');
            const urlsToOverwriteWithExternalAlertingAndReportingLink = [
                '/app/management/insightsAndAlerting/triggersActions/rules',
                '/app/management/insightsAndAlerting/triggersActions/logs',
                '/app/management/insightsAndAlerting/triggersActionsConnectors',
                '/app/management/insightsAndAlerting/triggersActionsAlerts'
            ];
            const jwtQueryParam = new URLSearchParams(window.location.search).get('jwt');
            const embedQueryParam = new URLSearchParams(window.location.hash.split('?')[1]).get('embed');
            const kbnWrappers = document.querySelectorAll('.kbnAppWrapper');
            const lastKbnWrapper = kbnWrappers?.[kbnWrappers.length - 1];
            const embedDashboardSelector = lastKbnWrapper || document.querySelector('#kibana-body');
            if (jwtQueryParam &&
                Boolean(embedQueryParam) &&
                embedDashboardSelector &&
                licenseEdition === ActivationKey_1.EDITIONS_ENUM.FREE) {
                react_dom_1.default.render((0, jsx_runtime_1.jsx)(pro_or_enterprise_feature_page_1.ProOrEnterpriseFeaturePage, {}), embedDashboardSelector);
                return;
            }
            if (urlsToOverwriteWithExternalAlertingAndReportingLink.some(urlToOverwrite => pathname.includes(urlToOverwrite)) &&
                !externalAlertingAndReportingLink &&
                semver.gte(kibanaVersion, '8.6.0')) {
                const pageBody = document.querySelector('.euiPageContentBody');
                if (pageBody) {
                    react_dom_1.default.render((0, jsx_runtime_1.jsx)(external_alerting_and_reporting_link_1.ExternalAlertingAndReportingLink, {}), pageBody);
                }
            }
        }
        const observer = new MutationObserver(handleLocationChange);
        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });
    }
    /**
     * kibana basePath without space url namespace
     */
    get serverBasePath() {
        CoreFunctions.checkInitialization(this.core);
        return this.core.http.basePath.serverBasePath;
    }
    /**
     * kibana basePath with space url namespace
     */
    get basePath() {
        CoreFunctions.checkInitialization(this.core);
        return this.core.http.basePath.get();
    }
}
exports.default = new CoreFunctions();
