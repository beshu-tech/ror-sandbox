#!./node/bin/node
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */


/*
 * Esm library doesn't work with node versions above 22.17. Also esm is natively supported for 22.17 version, so we don't need to use library for it.
 */
if (process.versions.node && parseFloat(process.versions.node) < 22.17) {
  require = require('esm')(module /* , options */);
}

let activate;
try {
  activate = require('./kibana/patchers/kibanaPatcher.js');
} catch (e) {
  activate = require('./kibana/patchers/kibanaPatcher.ts');
}
module.export = activate;
activate.main();
