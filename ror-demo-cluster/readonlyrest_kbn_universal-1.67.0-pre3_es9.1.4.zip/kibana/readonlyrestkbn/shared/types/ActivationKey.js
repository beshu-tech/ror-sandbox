"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.isFreeLicense = exports.isPROLicense = exports.isEnterpriseLicense = exports.EDITIONS_ENUM = void 0;
var EDITIONS_ENUM;
(function (EDITIONS_ENUM) {
    EDITIONS_ENUM["FREE"] = "kbn_free";
    EDITIONS_ENUM["ENTERPRISE"] = "kbn_ent";
    EDITIONS_ENUM["PRO"] = "kbn_pro";
})(EDITIONS_ENUM = exports.EDITIONS_ENUM || (exports.EDITIONS_ENUM = {}));
function isEnterpriseLicense(license) {
    return license.edition === EDITIONS_ENUM.ENTERPRISE;
}
exports.isEnterpriseLicense = isEnterpriseLicense;
function isPROLicense(license) {
    return license.edition === EDITIONS_ENUM.PRO;
}
exports.isPROLicense = isPROLicense;
function isFreeLicense(license) {
    return license.edition === EDITIONS_ENUM.FREE;
}
exports.isFreeLicense = isFreeLicense;
