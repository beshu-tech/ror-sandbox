"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const React = __importStar(require("react"));
const react_1 = require("react");
const menu_1 = __importDefault(require("../common/menu"));
const menuButton_1 = __importDefault(require("../common/menuButton"));
function TenancySelect({ currentGroup, availableGroups, handleChange, closeMainMenu }) {
    const [menuOpened, setMenuOpened] = React.useState(false);
    const [searchValue, setSearchValue] = (0, react_1.useState)('');
    const toggleMenu = () => setMenuOpened(prevState => !prevState);
    const handleCloseMenu = () => setMenuOpened(false);
    const items = (0, react_1.useMemo)(() => availableGroups
        .filter((group) => group.name.toLowerCase().includes(searchValue.toLowerCase()))
        .map((group) => ({
        title: group.name,
        action: () => {
            handleChange(group);
        }
    })), [availableGroups, handleChange, searchValue]);
    return ((0, jsx_runtime_1.jsx)(menu_1.default, { button: (0, jsx_runtime_1.jsx)(menuButton_1.default, { text: "Change tenancy", handleClick: toggleMenu, className: "ror_change_tenancy" }), isOpen: menuOpened, items: items, selectedGroup: currentGroup, closeMainMenu: closeMainMenu, handleClose: handleCloseMenu, search: availableGroups.length > 5
            ? {
                placeholder: 'Search for tenancy',
                isClearable: true,
                onChange: e => {
                    // @ts-ignore
                    setSearchValue(e.target.value);
                },
                value: searchValue
            }
            : undefined }));
}
exports.default = TenancySelect;
