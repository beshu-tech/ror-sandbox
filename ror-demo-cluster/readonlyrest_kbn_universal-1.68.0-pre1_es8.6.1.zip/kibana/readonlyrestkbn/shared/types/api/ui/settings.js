"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.isSuccessfulKoUpdateSettingsResponse = exports.isSuccessfulUpdateSettingsResponse = exports.isSuccessfulGetSettingsResponse = void 0;
function isSuccessfulGetSettingsResponse(responseData) {
    return responseData.status === 'ok';
}
exports.isSuccessfulGetSettingsResponse = isSuccessfulGetSettingsResponse;
function isSuccessfulUpdateSettingsResponse(responseData) {
    return 'status' in responseData && responseData.status === 'ok';
}
exports.isSuccessfulUpdateSettingsResponse = isSuccessfulUpdateSettingsResponse;
function isSuccessfulKoUpdateSettingsResponse(responseData) {
    return 'status' in responseData && responseData.status === 'ko';
}
exports.isSuccessfulKoUpdateSettingsResponse = isSuccessfulKoUpdateSettingsResponse;
