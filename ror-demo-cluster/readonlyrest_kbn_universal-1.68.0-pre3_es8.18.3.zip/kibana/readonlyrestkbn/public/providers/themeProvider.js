"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getThemeContext = exports.useTheme = exports.ThemeProvider = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const react_1 = require("react");
const semver = __importStar(require("semver"));
const coreFunctions_1 = __importDefault(require("../utils/coreFunctions"));
const useApplyCssVariables_1 = require("./useApplyCssVariables");
const themes_1 = require("./themes");
const ThemeContext = (0, react_1.createContext)(undefined);
const getThemeMode = () => {
    const getThemeModeValue = () => {
        const isDarkMode = coreFunctions_1.default.getSettingsParameter('theme:darkMode');
        // For 8.14.0 and above Kibana version
        if (isDarkMode === 'enabled') {
            return 'dark';
        }
        if (isDarkMode === 'disabled') {
            return 'light';
        }
        if (isDarkMode === 'system') {
            const darkThemeMediaQueryList = window.matchMedia('(prefers-color-scheme: dark)');
            if (darkThemeMediaQueryList.matches) {
                return 'dark';
            }
        }
        // For below 8.14.0 Kibana version and when user settings are set
        if (isDarkMode) {
            return 'dark';
        }
        return 'light';
    };
    return getThemeModeValue();
};
function ThemeProvider({ children, kibanaVersion }) {
    const getTheme = (0, react_1.useCallback)((theme) => {
        switch (theme) {
            case 'dark': {
                if (semver.gte(kibanaVersion, '9.0.0-beta1')) {
                    return themes_1.dark9xTheme;
                }
                return themes_1.darkTheme;
            }
            case 'light':
            default:
                return themes_1.lightTheme;
        }
    }, [kibanaVersion]);
    const [theme, setTheme] = (0, react_1.useState)(getTheme(getThemeMode()));
    const { cssVariables } = (0, useApplyCssVariables_1.useApplyCssVariables)({ theme });
    const toggleTheme = (0, react_1.useCallback)(() => {
        setTheme(currentTheme => getTheme(currentTheme.variant));
    }, [getTheme]);
    const contextValue = (0, react_1.useMemo)(() => ({
        theme,
        cssVariables,
        toggleTheme
    }), [cssVariables, theme, toggleTheme]);
    return (0, jsx_runtime_1.jsx)(ThemeContext.Provider, { value: contextValue, children: children });
}
exports.ThemeProvider = ThemeProvider;
const useTheme = () => {
    const context = (0, react_1.useContext)(ThemeContext);
    if (context === undefined) {
        throw new Error(`${exports.useTheme.name} must be used within a ${ThemeProvider.name}`);
    }
    return context;
};
exports.useTheme = useTheme;
const getThemeContext = () => ThemeContext;
exports.getThemeContext = getThemeContext;
