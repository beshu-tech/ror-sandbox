/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

const licenseChecker = require('license-checker');
const path = require('path');
const fs = require('fs-extra');

const PERMISSIVE_LICENSES = new Set([
  'MIT',
  'MIT*',
  'ISC',
  'BSD',
  'BSD-1-CLAUSE',
  'BSD-2-CLAUSE',
  'BSD-3-CLAUSE',
  'APACHE-1.1',
  'APACHE-2.0',
  'ZLIB',
  'LIBPNG',
  'BZIP2-1.0.6',
  'EXPAT', // Another name for MIT (XML expat)
  'X11', // Often alias of MIT
  'WTFPL',
  'CC0-1.0',
  'UNICODE-DFS-2016',
  'UNICODE-TOU',
  'BOOST-1.0', // Boost Software License 1.0
  'BSL-1.0',
  'PUBLIC-DOMAIN',
  'UNLICENSE', // The Unlicense (NOT "UNLICENSED")
  '0BSD',
  'AFL-2.1',
  'AFL-3.0',
  'ARTISTIC-2.0', // Frequently treated as permissive for distribution (verify internally)
  'MIT-0',
  'PHP-3.0',
  'PYTHON-2.0',
  'XPP',
  'ZLIB-ACKNOWLEDGEMENT',
  'BSD-3-CLAUSE-AND-APACHE-2.0'
]);

function normalizeLicenseToken(token) {
  return (token || '').replace(/[()]/g, '').trim().toUpperCase().replace(/\s+/g, '-');
}

function isNonPermissiveLicense(token) {
  return !PERMISSIVE_LICENSES.has(normalizeLicenseToken(token));
}

function runLicenseChecker(startDir) {
  return new Promise((resolve, reject) => {
    licenseChecker.init(
      {
        start: startDir,
        json: true,
        production: true,
        direct: false
      },
      (err, packages) => (err ? reject(err) : resolve(packages))
    );
  });
}

function excludeInternalPackages(packages, pattern = /^readonlyrestkbn@/) {
  Object.keys(packages).forEach(id => {
    if (pattern.test(id)) delete packages[id];
  });
}

function createPkgReader() {
  const cache = new Map();
  return function readPkg(pkgDir) {
    if (cache.has(pkgDir)) return cache.get(pkgDir);
    let data = {};
    try {
      const raw = fs.readFileSync(path.join(pkgDir, 'package.json'), 'utf8');
      data = JSON.parse(raw);
    } catch (_) {}
    cache.set(pkgDir, data);
    return data;
  };
}

function collectLicenseTokens(value, licenseSet) {
  if (!value) return;
  const add = s => {
    const v = (s || '').trim();
    if (v) licenseSet.add(v);
  };
  if (Array.isArray(value)) value.forEach(add);
  else add(value);

  const list = Array.isArray(value) ? value : [value];
  list.forEach(entry => {
    if (typeof entry !== 'string') return;
    const decomposed = entry.replace(/[()]/g, '').split(/\s+(?:AND|OR)\s+|,\s*/);
    decomposed.forEach(tok => add(tok));
  });
}

function buildPackageLines(packages, readPkg, licenseSet) {
  const keys = Object.keys(packages).sort((a, b) => a.localeCompare(b));
  const lines = [];

  keys.forEach((id, idx) => {
    const meta = packages[id] || {};

    // Licenses
    let licenses = meta.licenses;
    if (Array.isArray(licenses)) licenses = licenses.join(', ');
    if (!licenses) licenses = 'UNKNOWN';
    collectLicenseTokens(meta.licenses || licenses, licenseSet);

    // Repository
    let repo = meta.repository || meta.repositoryURL || meta.repositoryUrl;
    if (repo && typeof repo === 'object' && repo.url) repo = repo.url;
    if (repo) repo = String(repo).trim();
    if (!repo || ['UNKNOWN', 'undefined', ''].includes(repo)) repo = null;

    // Description / copyright
    let description = '';
    let copyrightHolder = '';
    if (meta.path) {
      const pj = readPkg(meta.path);
      if (pj && typeof pj === 'object') {
        if (pj.description) {
          description = String(pj.description).replace(/\s+/g, ' ').trim();
        }
        if (!description && meta.description) {
          description = String(meta.description).replace(/\s+/g, ' ').trim();
        }
        let authorName = '';
        let authorEmail = '';
        const author = pj.author;
        if (author && typeof author === 'object') {
          authorName = (author.name || '').trim();
          authorEmail = (author.email || '').trim();
        } else if (typeof author === 'string') {
          const m = author.match(/^([^<]+)?\s*<([^>]+)>/);
          if (m) {
            authorName = (m[1] || '').trim();
            authorEmail = (m[2] || '').trim();
          } else {
            authorName = author.trim();
          }
        }
        let publisher = meta.publisher && String(meta.publisher).trim();
        if (publisher) {
          if (authorEmail && publisher === authorName) {
            publisher = `${publisher} <${authorEmail}>`;
          }
          copyrightHolder = publisher;
        } else if (authorName) {
          copyrightHolder = authorEmail ? `${authorName} <${authorEmail}>` : authorName;
        }
      }
    }
    if (!description) description = ''; // no placeholder
    if (copyrightHolder === '') copyrightHolder = null;

    // Child lines (licenses first)
    const children = [];
    children.push(`licenses: ${licenses}`);
    if (repo) children.push(`repository: ${repo}`);
    if (description) children.push(`description: ${description}`);
    if (copyrightHolder) children.push(`copyright: ${copyrightHolder}`);

    const isLast = idx === keys.length - 1;
    const topPrefix = isLast ? '└─' : '├─';
    const branchPrefix = isLast ? '  ' : '│ ';

    lines.push(`${topPrefix} ${id}`);
    children.forEach((child, cidx) => {
      const childMarker = cidx === children.length - 1 ? '└─' : '├─';
      lines.push(`${branchPrefix}${childMarker} ${child}`);
    });
  });

  return lines;
}

function appendLicenseSummary(lines, licenseSet) {
  const summary = Array.from(licenseSet).sort((a, b) => a.localeCompare(b));
  lines.push('');
  lines.push(`LICENSES: ${summary.join(', ')}`);
}

module.exports = {
  runLicenseChecker,
  excludeInternalPackages,
  buildPackageLines,
  appendLicenseSummary,
  createPkgReader,
  isNonPermissiveLicense
};
