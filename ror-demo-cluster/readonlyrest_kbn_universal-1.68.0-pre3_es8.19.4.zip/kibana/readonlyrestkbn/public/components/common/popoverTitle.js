"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
const themeProvider_1 = require("../../providers/themeProvider");
function PopoverTitle({ children }) {
    const { theme } = (0, themeProvider_1.useTheme)();
    const borderColor = theme.colors.border;
    return ((0, jsx_runtime_1.jsx)(eui_1.EuiPopoverTitle, { style: { color: 'inherit', borderBottom: `1px solid ${borderColor}` }, children: children }));
}
exports.default = PopoverTitle;
