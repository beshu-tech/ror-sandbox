/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

/* Utility to ensure required Node and Yarn binaries exist in tools/ folder.
 * - Node: downloads and unpacks ONLY to tools/node-<version> (no tools/node copy/symlink)
 * - Yarn: ensures yarn-1.21.1
 */
const fs = require('fs');
const path = require('path');
const https = require('https');
const os = require('os');
const { execSync } = require('child_process');

const TOOLS_DIR = path.resolve(__dirname, 'tools');
if (!fs.existsSync(TOOLS_DIR)) fs.mkdirSync(TOOLS_DIR);
const YARN_DIR = path.join(TOOLS_DIR, 'yarn-1.21.1');

function readNodeVersionFromPackageJson() {
  // Force-select lowest version present in engines (e.g. 14.17.6) to satisfy requirement
  const pkg = JSON.parse(fs.readFileSync(path.resolve(__dirname, 'package.json'), 'utf8'));
  const enginesNode = (pkg.engines && pkg.engines.node) || '';
  const versions = Array.from(enginesNode.matchAll(/\d+\.\d+\.\d+/g)).map(m => m[0]);
  if (versions.length === 0) throw new Error('Cannot parse node version from package.json engines.node');
  versions.sort((a, b) => {
    const pa = a.split('.').map(Number);
    const pb = b.split('.').map(Number);
    for (let i = 0; i < 3; i++) if (pa[i] !== pb[i]) return pa[i] - pb[i];
    return 0;
  });
  return versions[0];
}

function platformTriplet() {
  const platform = os.platform();
  const arch = os.arch();
  const archMap = { x64: 'x64', arm64: 'arm64' };
  if (!archMap[arch]) throw new Error(`Unsupported architecture: ${arch}`);
  const platformMap = { darwin: 'darwin', linux: 'linux', win32: 'win' };
  if (!platformMap[platform]) throw new Error(`Unsupported platform: ${platform}`);
  return { platform: platformMap[platform], arch: archMap[arch] };
}

function nodeArchiveName(version) {
  const { platform, arch } = platformTriplet();
  const ext = platform === 'win' ? 'zip' : 'tar.gz';
  return `node-v${version}-${platform}-${arch}.${ext}`;
}

function download(url, dest, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 5) return reject(new Error('Too many redirects for ' + url));
    const file = fs.createWriteStream(dest);
    https
      .get(url, res => {
        const status = res.statusCode || 0;
        if (status >= 300 && status < 400 && res.headers.location) {
          // Redirect: discard this response and follow location
          file.close(() => fs.rm(dest, { force: true }, () => {
            const nextUrl = res.headers.location.startsWith('http') ? res.headers.location : new URL(res.headers.location, url).href;
            download(nextUrl, dest, redirects + 1).then(resolve).catch(reject);
          }));
          return;
        }
        if (status !== 200) {
          file.close(() => fs.rm(dest, { force: true }, () => reject(new Error(`Download failed ${status} ${url}`))));
          return;
        }
        res.pipe(file);
        file.on('finish', () => file.close(() => resolve()));
      })
      .on('error', err => {
        file.close(() => fs.rm(dest, { force: true }, () => reject(err)));
      });
  });
}

function downloadIfMissing(url, archivePath) {
  if (fs.existsSync(archivePath)) return Promise.resolve(false);
  console.log(`[ensureTools] Downloading ${path.basename(archivePath)} from ${url}`);
  return download(url, archivePath).then(() => true);
}

function extractArchiveIfPresent(archivePath, targetExtractedDirPredicate) {
  if (!fs.existsSync(archivePath)) return false;
  try {
    if (archivePath.endsWith('.tar.gz')) {
      execSync(`tar -xzf ${path.basename(archivePath)}`, { cwd: path.dirname(archivePath), stdio: 'inherit' });
    } else if (archivePath.endsWith('.zip')) {
      execSync(`unzip -q ${path.basename(archivePath)}` , { cwd: path.dirname(archivePath), stdio: 'inherit' });
    }
  } catch (e) {
    console.warn('[ensureTools] Extraction failed for', archivePath, e.message);
    return false;
  }
  // if a predicate is provided, ensure expected dir exists
  if (targetExtractedDirPredicate && !targetExtractedDirPredicate()) {
    console.warn('[ensureTools] Expected extracted content not found for', archivePath);
    return false;
  }
  try { fs.rmSync(archivePath, { force: true }); } catch {}
  return true;
}

function tryDownload(url, dest) {
  return downloadIfMissing(url, dest).catch(err => {
    throw err;
  });
}

async function ensureNode() {
  const version = readNodeVersionFromPackageJson();
  const VERSIONED_DIR = path.join(TOOLS_DIR, `node-${version}`);
  if (fs.existsSync(VERSIONED_DIR) && fs.readdirSync(VERSIONED_DIR).length > 0) {
    return { created: false, version };
  }
  const { platform, arch } = platformTriplet();
  let chosenArch = arch;
  let archive = `node-v${version}-${platform}-${chosenArch}.${platform === 'win' ? 'zip' : 'tar.gz'}`;
  const downloadPath = path.join(TOOLS_DIR, archive);
  const baseUrl = `https://nodejs.org/dist/v${version}`;
  try {
    await tryDownload(`${baseUrl}/${archive}`, downloadPath);
  } catch (e) {
    if (/404/.test(e.message) && platform === 'darwin' && arch === 'arm64') {
      console.warn(`[ensureTools] No official darwin arm64 build for Node ${version}. Falling back to x64 (Rosetta).`);
      try { if (fs.existsSync(downloadPath)) fs.rmSync(downloadPath, { force: true }); } catch {}
      chosenArch = 'x64';
      archive = `node-v${version}-${platform}-${chosenArch}.${platform === 'win' ? 'zip' : 'tar.gz'}`;
      await tryDownload(`${baseUrl}/${archive}`, path.join(TOOLS_DIR, archive));
    } else {
      throw e;
    }
  }
  extractArchiveIfPresent(path.join(TOOLS_DIR, archive), () => fs.existsSync(path.join(TOOLS_DIR, `node-v${version}-${platform}-${chosenArch}`)));
  try {
    const extracted = path.join(TOOLS_DIR, `node-v${version}-${platform}-${chosenArch}`);
    if (!fs.existsSync(extracted)) throw new Error(`Extracted Node directory not found: ${extracted}`);
    if (!fs.existsSync(VERSIONED_DIR)) fs.renameSync(extracted, VERSIONED_DIR);
  } catch (e) {
    console.warn('[ensureTools] Failed preparing Node runtime:', e.message);
  }
  return { created: true, version, arch: chosenArch };
}

async function ensureYarn() {
  if (fs.existsSync(YARN_DIR)) return { created: false };
  const version = '1.21.1';
  const archiveName = `yarn-v${version}.tar.gz`;
  const url = `https://github.com/yarnpkg/yarn/releases/download/v${version}/${archiveName}`;
  const archive = path.join(TOOLS_DIR, archiveName);
  const rootArchive = path.join(__dirname, archiveName);
  if (!fs.existsSync(archive) && fs.existsSync(rootArchive)) {
    try { fs.renameSync(rootArchive, archive); } catch {}
  }
  await downloadIfMissing(url, archive).catch(e => { throw new Error(`[ensureTools] Yarn download failed: ${e.message}`); });
  extractArchiveIfPresent(archive, () => true);
  try {
    // Detect extracted yarn directory dynamically
    const extractedDirName = fs.readdirSync(TOOLS_DIR).find(d => /^yarn-v\d+/.test(d) && fs.statSync(path.join(TOOLS_DIR, d)).isDirectory());
    if (!extractedDirName) throw new Error('Could not detect extracted Yarn directory');
    const extracted = path.join(TOOLS_DIR, extractedDirName);
    if (fs.existsSync(YARN_DIR)) fs.rmSync(YARN_DIR, { recursive: true, force: true });
    fs.renameSync(extracted, YARN_DIR);
  } catch (e) {
    console.warn('[ensureTools] Failed extracting Yarn archive:', e.message);
  }
  return { created: true };
}

async function run() {
  const results = {};
  try { results.node = await ensureNode(); } catch (e) { console.warn('[ensureTools] Failed ensuring Node:', e.message); }
  try { results.yarn = await ensureYarn(); } catch (e) { console.warn('[ensureTools] Failed ensuring Yarn:', e.message); }
  return results;
}

module.exports = { run };
