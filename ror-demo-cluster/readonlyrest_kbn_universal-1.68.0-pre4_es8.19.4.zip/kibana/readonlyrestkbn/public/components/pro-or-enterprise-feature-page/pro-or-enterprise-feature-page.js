"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProOrEnterpriseFeaturePage = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const flexGroup_1 = require("../common/flexGroup");
const text_1 = require("../common/text");
function ProOrEnterpriseFeaturePage() {
    return ((0, jsx_runtime_1.jsx)(flexGroup_1.FlexGroup, { style: {
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
            width: '100vw',
            height: '100vh'
        }, children: (0, jsx_runtime_1.jsx)(text_1.Text, { children: "Embedding with inline JWT is a feature available only in ReadonlyREST PRO and Enterprise. The current edition is: Free" }) }));
}
exports.ProOrEnterpriseFeaturePage = ProOrEnterpriseFeaturePage;
