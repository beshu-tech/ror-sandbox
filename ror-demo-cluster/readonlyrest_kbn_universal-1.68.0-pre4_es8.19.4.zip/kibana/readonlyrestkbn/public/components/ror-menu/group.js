"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const fieldset_1 = __importDefault(require("../common/fieldset"));
const themeProvider_1 = require("../../providers/themeProvider");
function Group({ label, children }) {
    const { theme } = (0, themeProvider_1.useTheme)();
    const borderColor = theme.colors.border;
    const textColor = theme.colors.textPrimary;
    return ((0, jsx_runtime_1.jsx)(fieldset_1.default, { legend: {
            children: label,
            style: { color: textColor }
        }, style: {
            border: `1px solid ${borderColor}`,
            margin: '2px 0',
            padding: '5.6px 12px 10px'
        }, children: children }));
}
exports.default = Group;
