"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Distribution = void 0;
class Distribution {
    versionString;
    kibanaVersion;
    rorVersion;
    isProduction;
    isBuildExpired;
    constructor(versionString, kibanaVersion, rorVersion, isProduction, isBuildExpired) {
        this.versionString = versionString;
        this.kibanaVersion = kibanaVersion;
        this.rorVersion = rorVersion;
        this.isProduction = isProduction;
        this.isBuildExpired = isBuildExpired;
    }
}
exports.Distribution = Distribution;
