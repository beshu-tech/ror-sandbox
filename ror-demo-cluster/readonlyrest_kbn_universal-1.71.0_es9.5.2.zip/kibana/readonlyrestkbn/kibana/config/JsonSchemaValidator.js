"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var JsonSchemaValidator_exports = {};
__export(JsonSchemaValidator_exports, {
  JsonSchemaValidator: () => JsonSchemaValidator
});
module.exports = __toCommonJS(JsonSchemaValidator_exports);
var import_ajv = __toESM(require("ajv"));
var import_ajv_errors = __toESM(require("ajv-errors"));
var import_lodash = require("lodash");
var import_rorLoggerFactory = require("../../proxy/core/logging/rorLoggerFactory");
class JsonSchemaValidator {
  constructor(JsonSchema) {
    this.JsonSchema = JsonSchema;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  validateJsonSchema(validationData) {
    var _a, _b;
    const ajv = new import_ajv.default({
      allErrors: true,
      allowMatchingProperties: true
    });
    (0, import_ajv_errors.default)(ajv);
    const validate = ajv.compile(this.JsonSchema);
    validate(validationData);
    const errors = (_b = (_a = validate.errors) == null ? void 0 : _a.filter((error) => error.keyword !== "if")) != null ? _b : [];
    if (errors.length >= 1) {
      const messagePrefix = errors.length === 1 ? "Validation error:" : "Validation errors:";
      const message = `${messagePrefix} ${errors.map(this.mapAjvErrorToMessage(validationData)).join("\n")}`;
      this.logger.error({ message: `JSON Schema validation failed: ${message}` });
      return {
        ok: false,
        error: message
      };
    }
    return { ok: true, data: "ok" };
  }
  mapAjvErrorToMessage(validationData) {
    return (err) => {
      const invalidValue = err.keyword === "required" || !err.instancePath ? void 0 : this.getValueByInstancePath(validationData, err.instancePath);
      if (err.keyword === "enum" && err.params.allowedValues.length > 0) {
        return `Unknown value '${this.convertDataPath(
          err.instancePath
        )}: ${invalidValue}'. Available options: ${err.params.allowedValues.join(", ")}`;
      }
      const currentValueText = invalidValue ? ` Current value: '${(0, import_lodash.isObject)(invalidValue) || (0, import_lodash.isArray)(invalidValue) ? JSON.stringify(invalidValue) : invalidValue}'` : "";
      return `'${this.convertDataPath(err.instancePath)}' ${err.message}${currentValueText}`;
    };
  }
  getValueByInstancePath(sourceData, instancePath) {
    const pathSegments = instancePath.split("/").slice(1);
    return pathSegments.reduce(
      (currentObject, propertyName) => currentObject && propertyName in currentObject ? currentObject[propertyName] : void 0,
      sourceData
    );
  }
  convertDataPath(jsonPointerPath) {
    if (jsonPointerPath.startsWith("/")) {
      jsonPointerPath = jsonPointerPath.slice(1);
    }
    return jsonPointerPath.replace(/\//g, ".");
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  JsonSchemaValidator
});
