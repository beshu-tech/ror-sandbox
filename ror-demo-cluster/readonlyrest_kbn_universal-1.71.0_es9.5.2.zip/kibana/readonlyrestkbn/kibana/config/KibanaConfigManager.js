"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var KibanaConfigManager_exports = {};
__export(KibanaConfigManager_exports, {
  KibanaConfigManager: () => KibanaConfigManager,
  getKibanaConfigManager: () => getKibanaConfigManager
});
module.exports = __toCommonJS(KibanaConfigManager_exports);
var _ = __toESM(require("lodash"));
var import_rorLoggerFactory = require("../../proxy/core/logging/rorLoggerFactory");
var import_distributionInfoProvider = require("../patchers/distributionInfoProvider");
var import_kibanaYamlRequestHeadersWhitelistParser = require("./parsers/kibanaYamlRequestHeadersWhitelistParser");
const _KibanaConfigManager = class _KibanaConfigManager {
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  constructor() {
    __publicField(this, "kibanaConfig", null);
  }
  static initialize(kibanaRawConfig, kibanaSettingsForPkp, kibanaSettingsForPep) {
    if (_KibanaConfigManager.instance) {
      return _KibanaConfigManager.instance;
    }
    _KibanaConfigManager.instance = new _KibanaConfigManager();
    _KibanaConfigManager.instance.kibanaConfig = _KibanaConfigManager.getInstance().updateKibanaRawSettings(
      kibanaRawConfig,
      kibanaSettingsForPkp,
      kibanaSettingsForPep
    );
    _KibanaConfigManager.getLogger().info("KibanaConfigManager initialized successfully");
    return _KibanaConfigManager.instance;
  }
  static getInstance() {
    _KibanaConfigManager.assertInitialized(_KibanaConfigManager.instance);
    return _KibanaConfigManager.instance;
  }
  static isInitialized() {
    return _KibanaConfigManager.instance !== null;
  }
  getKibanaConfig() {
    if (!this.kibanaConfig) {
      throw new Error("Kibana configuration not set");
    }
    return this.kibanaConfig;
  }
  static assertInitialized(instance) {
    if (!instance) {
      throw new Error("KibanaConfigManager is not initialized");
    }
  }
  updateKibanaRawSettings(kibanaRawConfig, kibanaSettingsForPkp, kibanaSettingsForPep) {
    _.update(kibanaRawConfig, "server.ssl.enabled", (sslEnabled) => {
      _KibanaConfigManager.getLogger().debug(`Overriding 'server.ssl.enabled' from ${sslEnabled} to false`);
      return false;
    });
    if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("8.0.0")) {
      _.update(kibanaRawConfig, "xpack.reporting.index", (reportingIndex) => {
        const { getTemporaryReportingIndex, setXpackReportingIndex } = require("../../proxy/core/reportingIndex");
        setXpackReportingIndex(reportingIndex);
        const newReportingIndex = getTemporaryReportingIndex();
        _KibanaConfigManager.getLogger().debug(
          `Overriding 'xpack.reporting.index' from ${reportingIndex} to ${newReportingIndex}`
        );
        return newReportingIndex;
      });
    }
    _.update(kibanaRawConfig, "server.port", (kibanaYamlServerPort) => {
      _KibanaConfigManager.getLogger().debug(
        `Overriding 'server.port' from ${kibanaYamlServerPort} to ${kibanaSettingsForPkp.newKibanaPort}`
      );
      return kibanaSettingsForPkp.newKibanaPort;
    });
    _.update(kibanaRawConfig, "server.host", (kibanaYamlServerHost) => {
      _KibanaConfigManager.getLogger().debug(`Overriding 'server.host' from ${kibanaYamlServerHost} to 127.0.0.1`);
      return "127.0.0.1";
    });
    if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("8.4.0")) {
      _.update(kibanaRawConfig, "telemetry.enabled", (_2) => {
        _KibanaConfigManager.getLogger().debug(`Overriding 'telemetry.enabled' from ${_2} to false`);
        return false;
      });
    } else {
      _.update(kibanaRawConfig, "telemetry.optIn", (_2) => {
        _KibanaConfigManager.getLogger().debug(`Overriding 'telemetry.optIn' from ${_2} to false`);
        return false;
      });
      _.update(kibanaRawConfig, "telemetry.allowChangingOptInStatus", (_2) => {
        _KibanaConfigManager.getLogger().debug(`Overriding 'telemetry.allowChangingOptInStatus' from ${_2} to false`);
        return false;
      });
    }
    _.update(kibanaRawConfig, "elasticsearch.hosts", (kibanaYamlElasticsearchHosts) => {
      _KibanaConfigManager.getLogger().debug(
        `Overriding 'elasticsearch.hosts' from ${kibanaYamlElasticsearchHosts} to [${kibanaSettingsForPep.pepUrl}]`
      );
      return [kibanaSettingsForPep.pepUrl];
    });
    _.update(kibanaRawConfig, "elasticsearch.requestHeadersWhitelist", (originalValue) => {
      const newValue = (0, import_kibanaYamlRequestHeadersWhitelistParser.normalizeWithDefaultsRequestHeadersWhiteList)(originalValue);
      _KibanaConfigManager.getLogger().debug(
        `Overriding 'elasticsearch.requestHeadersWhitelist' from ${JSON.stringify(originalValue)} to ${JSON.stringify(
          newValue
        )}`
      );
      return newValue;
    });
    if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaNeverOrEqualTo("9.0.0") && !_.has(kibanaRawConfig, "server.restrictInternalApis")) {
      _.update(kibanaRawConfig, "server.restrictInternalApis", () => false);
    }
    return kibanaRawConfig;
  }
  static clearKibanaConfigManager() {
    _KibanaConfigManager.instance = null;
    _KibanaConfigManager.getLogger().info("KibanaConfigManager cleared successfully");
  }
};
// eslint-disable-next-line no-use-before-define
__publicField(_KibanaConfigManager, "instance", null);
__publicField(_KibanaConfigManager, "getLogger", () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let KibanaConfigManager = _KibanaConfigManager;
const getKibanaConfigManager = () => KibanaConfigManager.getInstance();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KibanaConfigManager,
  getKibanaConfigManager
});
