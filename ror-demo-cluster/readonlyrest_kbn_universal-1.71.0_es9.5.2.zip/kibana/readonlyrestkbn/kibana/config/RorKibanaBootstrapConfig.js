"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var RorKibanaBootstrapConfig_exports = {};
__export(RorKibanaBootstrapConfig_exports, {
  getRorKibanaBootstrapConfig: () => getRorKibanaBootstrapConfig,
  initializeRorKibanaBootstrapConfig: () => initializeRorKibanaBootstrapConfig,
  setRorKibanaBootstrapConfig: () => setRorKibanaBootstrapConfig
});
module.exports = __toCommonJS(RorKibanaBootstrapConfig_exports);
let bootstrapConfig;
function setRorKibanaBootstrapConfig(config) {
  bootstrapConfig = {
    pkpKibanaToken: config.pkpKibanaToken,
    memoryDiagnostics: {
      enabled: config.memoryDiagnostics.enabled,
      interval: config.memoryDiagnostics.interval
    }
  };
}
function initializeRorKibanaBootstrapConfig(rorSettingsStore) {
  rorSettingsStore.observerRorKbnSettings(({ pkpKibanaToken, memoryDiagnostics }) => ({
    pkpKibanaToken,
    memoryDiagnostics
  })).subscribe(setRorKibanaBootstrapConfig);
}
function getRorKibanaBootstrapConfig() {
  if (!bootstrapConfig) {
    throw new Error("ROR Kibana bootstrap configuration is not initialized");
  }
  return bootstrapConfig;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getRorKibanaBootstrapConfig,
  initializeRorKibanaBootstrapConfig,
  setRorKibanaBootstrapConfig
});
