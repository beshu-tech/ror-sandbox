"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RorDevWorkerControlServer_exports = {};
__export(RorDevWorkerControlServer_exports, {
  RorDevWorkerControlServer: () => RorDevWorkerControlServer
});
module.exports = __toCommonJS(RorDevWorkerControlServer_exports);
var import_fs = __toESM(require("fs"));
var import_http = __toESM(require("http"));
class RorDevWorkerControlServer {
  constructor(socketPath, control) {
    this.socketPath = socketPath;
    this.control = control;
    __publicField(this, "server");
  }
  async start() {
    this.prepareSocketPath();
    this.server = import_http.default.createServer((request, response) => this.handleRequest(request, response));
    await new Promise((resolve, reject) => {
      const server = this.server;
      let onListening;
      const onError = (error) => {
        server.removeListener("listening", onListening);
        reject(error);
      };
      onListening = () => {
        server.removeListener("error", onError);
        resolve();
      };
      server.once("error", onError);
      server.once("listening", onListening);
      const previousUmask = process.umask(127);
      try {
        server.listen(this.socketPath);
      } finally {
        process.umask(previousUmask);
      }
    });
  }
  stop() {
    const { server } = this;
    this.server = void 0;
    return new Promise((resolve, reject) => {
      if (!(server == null ? void 0 : server.listening)) {
        this.removeSocket();
        resolve();
        return;
      }
      server.close((error) => {
        this.removeSocket();
        if (error) reject(error);
        else resolve();
      });
    });
  }
  handleRequest(request, response) {
    if (request.method === "GET" && request.url === "/status") {
      this.respond(response, 200, this.control.getStatus());
      return;
    }
    if (request.method === "POST" && request.url === "/reload") {
      try {
        this.respond(response, 202, { generation: this.control.requestReload() });
      } catch (error) {
        this.respond(response, 500, {
          error: {
            code: "RELOAD_FAILED",
            message: error instanceof Error ? error.message : String(error)
          }
        });
      }
      return;
    }
    this.respond(response, 404, {
      error: {
        code: "NOT_FOUND",
        message: "Unknown ROR development worker control endpoint"
      }
    });
  }
  respond(response, statusCode, body) {
    response.writeHead(statusCode, { "content-type": "application/json" });
    response.end(JSON.stringify(body));
  }
  prepareSocketPath() {
    if (!import_fs.default.existsSync(this.socketPath)) return;
    if (!import_fs.default.lstatSync(this.socketPath).isSocket()) {
      throw new Error(`ROR development worker socket path ${this.socketPath} exists and is not a Unix socket`);
    }
    import_fs.default.unlinkSync(this.socketPath);
  }
  removeSocket() {
    if (import_fs.default.existsSync(this.socketPath) && import_fs.default.lstatSync(this.socketPath).isSocket()) {
      import_fs.default.unlinkSync(this.socketPath);
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorDevWorkerControlServer
});
