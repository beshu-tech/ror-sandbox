"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RorDevWorkerSupervisor_exports = {};
__export(RorDevWorkerSupervisor_exports, {
  DEFAULT_ROR_DEV_WORKER_SOCKET: () => DEFAULT_ROR_DEV_WORKER_SOCKET,
  RorDevWorkerSupervisor: () => RorDevWorkerSupervisor
});
module.exports = __toCommonJS(RorDevWorkerSupervisor_exports);
var import_child_process = require("child_process");
var import_path = __toESM(require("path"));
var import_RorDevWorkerControlServer = require("./RorDevWorkerControlServer");
var import_workerProtocol = require("./workerProtocol");
const DEFAULT_STARTUP_TIMEOUT_MS = 3e4;
const DEFAULT_STOP_TIMEOUT_MS = 5e3;
const DEFAULT_ROR_DEV_WORKER_SOCKET = "/tmp/readonlyrest-ror-dev-worker.sock";
class RorDevWorkerSupervisor {
  constructor(config, dependencies = {}) {
    this.config = config;
    __publicField(this, "generation", 0);
    __publicField(this, "status", { generation: 0, state: "stopped" });
    __publicField(this, "worker");
    __publicField(this, "workerExit");
    __publicField(this, "controlServer");
    __publicField(this, "reloadGeneration");
    __publicField(this, "reloadInProgress");
    __publicField(this, "dependencies");
    var _a, _b, _c, _d;
    this.dependencies = {
      createWorker: (_a = dependencies.createWorker) != null ? _a : createWorkerProcess,
      startupTimeoutMs: (_b = dependencies.startupTimeoutMs) != null ? _b : DEFAULT_STARTUP_TIMEOUT_MS,
      stopTimeoutMs: (_c = dependencies.stopTimeoutMs) != null ? _c : DEFAULT_STOP_TIMEOUT_MS,
      onBootstrapConfig: (_d = dependencies.onBootstrapConfig) != null ? _d : (() => {
      })
    };
  }
  start() {
    this.generation += 1;
    const { generation } = this;
    const worker = this.dependencies.createWorker();
    this.worker = worker;
    this.status = { generation, state: "starting" };
    let notifyWorkerExit;
    this.workerExit = new Promise((resolve) => {
      notifyWorkerExit = resolve;
    });
    return new Promise((resolve, reject) => {
      let settled = false;
      let timeout;
      const finish = (error, bootstrapConfig) => {
        if (settled) return;
        settled = true;
        if (timeout) clearTimeout(timeout);
        if (error) {
          this.fail(generation, error.message);
          worker.kill();
          reject(error);
        } else {
          this.dependencies.onBootstrapConfig(bootstrapConfig);
          resolve(bootstrapConfig);
        }
      };
      timeout = setTimeout(
        () => finish(
          new Error(
            `ROR worker generation ${generation} did not become ready within ${this.dependencies.startupTimeoutMs}ms`
          )
        ),
        this.dependencies.startupTimeoutMs
      );
      worker.onMessage((message) => {
        const validation = (0, import_workerProtocol.validateWorkerEvent)(message, generation);
        if (!validation.ok) return;
        switch (validation.value.type) {
          case "ready":
            this.status = { generation, state: "ready" };
            finish(void 0, validation.value.bootstrapConfig);
            break;
          case "startup-error":
            finish(new Error(validation.value.message));
            break;
          case "stopped":
            this.status = { generation, state: "stopped" };
            break;
          default:
            break;
        }
      });
      worker.onExit((code, signal) => {
        notifyWorkerExit();
        if (this.status.generation !== generation || this.status.state === "stopped" || this.status.state === "failed")
          return;
        const error = new Error(`ROR worker generation ${generation} exited (code: ${code}, signal: ${signal})`);
        if (settled) {
          this.fail(generation, error.message);
        } else {
          finish(error);
        }
      });
      worker.onError((error) => finish(error));
      try {
        worker.send({ type: "start", generation, config: this.config });
      } catch (error) {
        finish(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }
  stop() {
    var _a;
    const stopControlServer = (_a = this.controlServer) == null ? void 0 : _a.stop();
    this.controlServer = void 0;
    return stopControlServer ? stopControlServer.then(() => this.stopWorker()) : this.stopWorker();
  }
  startControlServer(socketPath = ((_a) => (_a = process.env.ROR_DEV_WORKER_SOCKET) != null ? _a : DEFAULT_ROR_DEV_WORKER_SOCKET)()) {
    if (this.controlServer) return Promise.resolve();
    this.controlServer = new import_RorDevWorkerControlServer.RorDevWorkerControlServer(socketPath, {
      getStatus: () => this.getStatus(),
      requestReload: () => this.requestReload()
    });
    return this.controlServer.start();
  }
  requestReload() {
    if (this.reloadGeneration !== void 0 && !(this.status.generation === this.reloadGeneration && this.status.state === "failed")) {
      return this.reloadGeneration;
    }
    const requestedGeneration = this.generation + 1;
    this.reloadGeneration = requestedGeneration;
    this.reloadInProgress = this.replaceWorker().finally(() => {
      if (this.reloadGeneration === requestedGeneration) {
        this.reloadGeneration = void 0;
        this.reloadInProgress = void 0;
      }
    });
    this.reloadInProgress.catch(() => void 0);
    return requestedGeneration;
  }
  getStatus() {
    return this.status;
  }
  async replaceWorker() {
    await this.stopWorker();
    await this.start();
  }
  stopWorker() {
    const { worker, workerExit, generation } = this;
    if (!worker || generation === 0 || this.status.state === "stopped") return Promise.resolve();
    if (this.status.state === "failed") {
      worker.kill();
      this.worker = void 0;
      this.workerExit = void 0;
      this.status = { generation, state: "stopped" };
      return Promise.resolve();
    }
    this.status = { generation, state: "stopping" };
    return new Promise((resolve) => {
      let settled = false;
      let timeout;
      const finish = () => {
        if (settled) return;
        settled = true;
        if (timeout) clearTimeout(timeout);
        if (this.status.generation === generation && this.status.state !== "failed") {
          this.status = { generation, state: "stopped" };
        }
        if (this.worker === worker) {
          this.worker = void 0;
          this.workerExit = void 0;
        }
        resolve();
      };
      timeout = setTimeout(() => {
        worker.kill();
        finish();
      }, this.dependencies.stopTimeoutMs);
      worker.onMessage((message) => {
        const validation = (0, import_workerProtocol.validateWorkerEvent)(message, generation);
        if (!validation.ok || validation.value.type !== "stopped") return;
        finish();
      });
      workerExit == null ? void 0 : workerExit.then(() => finish());
      try {
        worker.send({ type: "stop", generation });
      } catch {
        worker.kill();
        finish();
      }
    });
  }
  fail(generation, error) {
    if (this.status.generation !== generation) return;
    this.status = { generation, state: "failed", error };
  }
}
function createWorkerProcess() {
  const child = (0, import_child_process.fork)(import_path.default.resolve(__dirname, "rorRuntimeWorker.js"), [], {
    env: { ...process.env, ROR_DEV_RUNTIME_WORKER: "true" }
  });
  return {
    send: (command) => {
      child.send(command);
    },
    onMessage: (listener) => {
      child.on("message", listener);
    },
    onExit: (listener) => {
      child.on("exit", listener);
    },
    onError: (listener) => {
      child.on("error", listener);
    },
    kill: () => {
      child.kill();
    }
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DEFAULT_ROR_DEV_WORKER_SOCKET,
  RorDevWorkerSupervisor
});
