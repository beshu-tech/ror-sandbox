"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var initializeRorConfigManagerInWorker_exports = {};
__export(initializeRorConfigManagerInWorker_exports, {
  initializeRorConfigManagerInWorker: () => initializeRorConfigManagerInWorker
});
module.exports = __toCommonJS(initializeRorConfigManagerInWorker_exports);
var import_authWrapper = require("../../../proxy/core/api/authWrapper");
var import_esApiAdvancedClient = require("../../../proxy/core/api/esApiAdvancedClient");
var import_restRorEsApiClient = require("../../../proxy/core/api/restRorEsApiClient");
var import_esHostBalancer = require("../../../proxy/core/esHostBalancer");
var import_esSSLConnectionProvider = require("../../../proxy/core/esSSLConnectionProvider");
var import_LicenseServiceFactory = require("../../../proxy/core/license/LicenseServiceFactory");
var import_RorSettingsManager = require("../../../proxy/core/rorSettings/RorSettingsManager");
async function initializeRorConfigManagerInWorker(config) {
  const esSSLConnectionProvider = new import_esSSLConnectionProvider.EsSSLConnectionProvider(config.elasticsearchConfig.sslSettings);
  const esHostBalancer = new import_esHostBalancer.EsHostBalancer(
    config.elasticsearchConfig.elasticsearchHosts,
    config.kibanaConfigForPep.networkParameters,
    config.elasticsearchConfig.kibanaTechUserEsAuthToken,
    esSSLConnectionProvider
  );
  const restRorEsApiClient = new import_restRorEsApiClient.RestRorEsApiClient(
    esHostBalancer.getElasticsearchUrl(),
    config.elasticsearchConfig.customHeaders,
    esSSLConnectionProvider,
    config.kibanaConfigForPkp.kibanaIndex
  );
  const rorEsApiClient = new import_authWrapper.AuthWrapper(config.elasticsearchConfig.kibanaTechUserEsAuthToken, restRorEsApiClient);
  const esApiAdvancedClient = new import_esApiAdvancedClient.EsApiAdvancedClient(esHostBalancer.getElasticsearchUrl(), esSSLConnectionProvider, {
    diskThresholdVerificationEnabled: () => false,
    kibanaIndex: config.kibanaConfigForPkp.kibanaIndex
  });
  const esApiAdvancedClientWithAuth = new import_authWrapper.AuthWrapper(
    config.elasticsearchConfig.kibanaTechUserEsAuthToken,
    esApiAdvancedClient
  );
  await esApiAdvancedClientWithAuth.asTechnicalUser().waitForES();
  const licenseService = new import_LicenseServiceFactory.LicenseServiceFactory(esApiAdvancedClientWithAuth).createLicenseService();
  await licenseService.init();
  const settingsManager = await import_RorSettingsManager.RorSettingsManager.initialize(config.kibanaConfig, rorEsApiClient, licenseService);
  return settingsManager.rorKbnSettingsStore().getLatestRorKbnSettings();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  initializeRorConfigManagerInWorker
});
