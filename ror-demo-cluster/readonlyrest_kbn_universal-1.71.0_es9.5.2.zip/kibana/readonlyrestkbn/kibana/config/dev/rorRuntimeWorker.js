"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorRuntimeWorker_exports = {};
__export(rorRuntimeWorker_exports, {
  RorRuntimeWorker: () => RorRuntimeWorker,
  runRorRuntimeWorker: () => runRorRuntimeWorker
});
module.exports = __toCommonJS(rorRuntimeWorker_exports);
var import_rorLoggerFactory = require("../../../proxy/core/logging/rorLoggerFactory");
var import_workerProtocol = require("./workerProtocol");
const getLogger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
class RorRuntimeWorker {
  constructor(dependencies) {
    this.dependencies = dependencies;
    __publicField(this, "generation");
    __publicField(this, "runtime");
    __publicField(this, "runtimeStopped", false);
  }
  async handleMessage(message) {
    const validation = (0, import_workerProtocol.validateWorkerCommand)(message, this.generation);
    if (!validation.ok) return;
    const command = validation.value;
    if (command.type === "start") {
      if (this.generation !== void 0) return;
      this.generation = command.generation;
      this.runtimeStopped = false;
      try {
        const rorConfig = await this.dependencies.initializeConfig(command.config);
        if (this.runtimeStopped) return;
        this.runtime = this.dependencies.createRuntime(command.config, rorConfig);
        await this.runtime.start();
        if (this.runtimeStopped) return;
        this.dependencies.send({
          type: "ready",
          generation: command.generation,
          bootstrapConfig: {
            pkpKibanaToken: rorConfig.pkpKibanaToken,
            memoryDiagnostics: rorConfig.memoryDiagnostics
          }
        });
      } catch (error) {
        const message2 = error instanceof Error ? error.message : String(error);
        try {
          this.stopRuntime();
        } catch {
        }
        this.dependencies.send({ type: "startup-error", generation: command.generation, message: message2 });
      }
      return;
    }
    if (this.generation === void 0) return;
    try {
      this.stopRuntime();
    } finally {
      this.dependencies.send({ type: "stopped", generation: command.generation });
      this.dependencies.disconnect();
    }
  }
  handleParentDisconnect() {
    try {
      this.stopRuntime();
    } catch {
    }
  }
  stopRuntime() {
    var _a;
    if (this.runtimeStopped) return;
    this.runtimeStopped = true;
    (_a = this.runtime) == null ? void 0 : _a.stop();
    this.runtime = void 0;
  }
}
function runRorRuntimeWorker() {
  const { RorInitializer } = require("../rorInitialization");
  const { initializeRorConfigManagerInWorker } = require("./initializeRorConfigManagerInWorker");
  const worker = new RorRuntimeWorker({
    initializeConfig: initializeRorConfigManagerInWorker,
    createRuntime: (config, rorConfig) => {
      const initializer = new RorInitializer(
        rorConfig,
        config.elasticsearchConfig,
        config.kibanaConfigForPkp,
        config.kibanaConfigForPep
      );
      return {
        start: () => initializer.initialize(),
        stop: () => initializer.cleanup()
      };
    },
    send: (event) => {
      var _a;
      return (_a = process.send) == null ? void 0 : _a.call(process, event);
    },
    disconnect: () => {
      var _a;
      return (_a = process.disconnect) == null ? void 0 : _a.call(process);
    }
  });
  process.on("message", (message) => {
    worker.handleMessage(message).catch((error) => {
      const err = error instanceof Error ? error : new Error(String(error));
      getLogger().error({ message: `Unhandled ROR runtime worker error: ${err.message}`, stack: err.stack });
    });
  });
  process.once("disconnect", () => worker.handleParentDisconnect());
}
if (require.main === module) {
  runRorRuntimeWorker();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorRuntimeWorker,
  runRorRuntimeWorker
});
