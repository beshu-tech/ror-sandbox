"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var workerProtocol_exports = {};
__export(workerProtocol_exports, {
  validateWorkerCommand: () => validateWorkerCommand,
  validateWorkerEvent: () => validateWorkerEvent
});
module.exports = __toCommonJS(workerProtocol_exports);
function validateWorkerCommand(value, expectedGeneration) {
  if (!isWorkerCommand(value)) {
    return malformed("Invalid ROR worker command");
  }
  return expectedGeneration === void 0 ? { ok: true, value } : validateGeneration(value, expectedGeneration);
}
function validateWorkerEvent(value, expectedGeneration) {
  if (!isWorkerEvent(value)) {
    return malformed("Invalid ROR worker event");
  }
  return validateGeneration(value, expectedGeneration);
}
function isWorkerCommand(value) {
  if (!isRecordWithGeneration(value)) return false;
  if (value.type === "stop") return true;
  if (value.type !== "start" || !isRecord(value.config)) return false;
  return isRecord(value.config.kibanaConfig) && isRecord(value.config.elasticsearchConfig) && isRecord(value.config.kibanaConfigForPkp) && isRecord(value.config.kibanaConfigForPep) && isIpcSerializable(value.config);
}
function isWorkerEvent(value) {
  if (!isRecordWithGeneration(value)) return false;
  if (value.type === "ready") return isBootstrapConfig(value.bootstrapConfig);
  return value.type === "stopped" || value.type === "startup-error" && typeof value.message === "string";
}
function isBootstrapConfig(value) {
  if (!isRecord(value) || typeof value.pkpKibanaToken !== "string" || !isRecord(value.memoryDiagnostics)) {
    return false;
  }
  return typeof value.memoryDiagnostics.enabled === "boolean" && typeof value.memoryDiagnostics.interval === "string";
}
function isRecordWithGeneration(value) {
  return isRecord(value) && Number.isSafeInteger(value.generation) && value.generation > 0;
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isIpcSerializable(value, ancestors = /* @__PURE__ */ new Set()) {
  if (value === null || value === void 0) return true;
  if (typeof value === "string" || typeof value === "boolean") return true;
  if (typeof value === "number") return Number.isFinite(value);
  if (typeof value !== "object") return false;
  if (ancestors.has(value)) return false;
  if (!Array.isArray(value)) {
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null) return false;
  }
  ancestors.add(value);
  try {
    const entries = Array.isArray(value) ? value : Object.values(value);
    return entries.every((entry) => isIpcSerializable(entry, ancestors));
  } catch {
    return false;
  } finally {
    ancestors.delete(value);
  }
}
function validateGeneration(value, expectedGeneration) {
  if (value.generation !== expectedGeneration) {
    return {
      ok: false,
      error: {
        code: "STALE_GENERATION",
        message: `Expected ROR worker generation ${expectedGeneration}, received ${value.generation}`
      }
    };
  }
  return { ok: true, value };
}
function malformed(message) {
  return {
    ok: false,
    error: {
      code: "MALFORMED_MESSAGE",
      message
    }
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  validateWorkerCommand,
  validateWorkerEvent
});
