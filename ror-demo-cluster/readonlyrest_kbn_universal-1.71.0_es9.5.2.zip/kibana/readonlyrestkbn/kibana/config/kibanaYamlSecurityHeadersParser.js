"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibanaYamlSecurityHeadersParser_exports = {};
__export(kibanaYamlSecurityHeadersParser_exports, {
  buildSecurityHeadersConfig: () => buildSecurityHeadersConfig
});
module.exports = __toCommonJS(kibanaYamlSecurityHeadersParser_exports);
function buildSecurityHeadersConfig(kibanaRawConfig, tlsEnabled) {
  var _a, _b;
  const h = (_b = (_a = kibanaRawConfig.server) == null ? void 0 : _a.securityResponseHeaders) != null ? _b : {};
  return {
    strictTransportSecurity: h.strictTransportSecurity || void 0,
    xContentTypeOptions: h.xContentTypeOptions || void 0,
    referrerPolicy: h.referrerPolicy || void 0,
    permissionsPolicy: h.permissionsPolicy || void 0,
    permissionsPolicyReportOnly: h.permissionsPolicyReportOnly || void 0,
    crossOriginOpenerPolicy: h.crossOriginOpenerPolicy || void 0,
    disableEmbedding: h.disableEmbedding === true,
    tlsEnabled
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildSecurityHeadersConfig
});
