"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var loggingFeaturesSchema_exports = {};
__export(loggingFeaturesSchema_exports, {
  consoleAppenderSchema: () => consoleAppenderSchema,
  fileAppenderSchema: () => fileAppenderSchema,
  loggingFeaturesSchema: () => loggingFeaturesSchema,
  rollingFileAppenderSchema: () => rollingFileAppenderSchema
});
module.exports = __toCommonJS(loggingFeaturesSchema_exports);
var import_types = require("../../proxy/core/logging/appenders/layout/types");
const fileAppenderSchema = {
  type: "object",
  properties: {
    type: { type: "string", const: "file" },
    fileName: { type: "string" },
    layout: import_types.logLayoutSchema
  },
  required: ["type", "fileName"],
  additionalProperties: false
};
const consoleAppenderSchema = {
  type: "object",
  properties: {
    type: { type: "string", const: "console" },
    layout: import_types.logLayoutSchema
  },
  required: ["type"],
  additionalProperties: false
};
const rollingFileAppenderSchema = {
  type: "object",
  properties: {
    type: { type: "string", const: "rolling-file" },
    fileName: { type: "string" },
    layout: import_types.logLayoutSchema,
    policy: { oneOf: [import_types.sizeLimitPolicySchema, import_types.timeIntervalPolicySchema] },
    strategy: import_types.numericStrategySchema
  },
  required: ["type", "fileName", "policy", "strategy"],
  additionalProperties: false
};
const appenderPolicySchema = {
  type: "object",
  properties: {
    type: { type: "string" },
    size: import_types.sizeLimitPolicySchema.properties.size,
    interval: import_types.timeIntervalPolicySchema.properties.interval,
    modulate: import_types.timeIntervalPolicySchema.properties.modulate
  },
  additionalProperties: false
};
const appenderSchema = {
  type: "object",
  properties: {
    type: { type: "string" },
    fileName: { type: "string" },
    layout: import_types.logLayoutSchema,
    policy: appenderPolicySchema,
    strategy: import_types.numericStrategySchema
  },
  additionalProperties: false
};
const loggingFeaturesSchema = {
  type: "object",
  properties: {
    dest: { type: "string" },
    json: { type: "boolean" },
    root: {
      type: "object",
      properties: {
        // Intentionally permissive — accepts any value for the appenders list
        appenders: {},
        level: { type: "string" }
      },
      additionalProperties: false
    },
    appenders: {
      type: "object",
      additionalProperties: appenderSchema
    }
  },
  additionalProperties: false
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  consoleAppenderSchema,
  fileAppenderSchema,
  loggingFeaturesSchema,
  rollingFileAppenderSchema
});
