"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibanaYamlElasticsearchSSLSettingsParser_exports = {};
__export(kibanaYamlElasticsearchSSLSettingsParser_exports, {
  parseSSLSettings: () => parseSSLSettings
});
module.exports = __toCommonJS(kibanaYamlElasticsearchSSLSettingsParser_exports);
var import_rorLoggerFactory = require("../../../proxy/core/logging/rorLoggerFactory");
var import_settingsUtils = require("../settingsUtils");
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const isSSLEnabled = (esHosts) => {
  const referentialProtocol = esHosts[0].split("://")[0];
  esHosts.forEach((host) => {
    if (host.split("://")[0] !== referentialProtocol) {
      logger.error({
        message: "The Elasticsearch hosts provided use different protocols. Please use either http or https for all hosts."
      });
      (0, import_settingsUtils.exitInOneSecond)();
    }
  });
  return referentialProtocol === "https";
};
const singleToAnArray = (value) => Array.isArray(value) ? value : [value];
function parseSSLSettings(kibanaElasticsearchSettings, derivedElasticHosts) {
  var _a, _b;
  const elasticsearchSSLEnabled = isSSLEnabled(derivedElasticHosts);
  const elasticsearchSSL = kibanaElasticsearchSettings == null ? void 0 : kibanaElasticsearchSettings.ssl;
  const elasticsearchSSLCertificateAuthorities = (elasticsearchSSL == null ? void 0 : elasticsearchSSL.certificateAuthorities) && singleToAnArray(elasticsearchSSL.certificateAuthorities);
  const elasticsearchTruststorePath = (_a = elasticsearchSSL == null ? void 0 : elasticsearchSSL.truststore) == null ? void 0 : _a.path;
  const elasticsearchTruststorePassword = (_b = elasticsearchSSL == null ? void 0 : elasticsearchSSL.truststore) == null ? void 0 : _b.password;
  const elasticsearchVerificationMode = elasticsearchSSL == null ? void 0 : elasticsearchSSL.verificationMode;
  return {
    sslEnabled: elasticsearchSSLEnabled,
    certificateAuthorities: elasticsearchSSLCertificateAuthorities,
    truststorePath: elasticsearchTruststorePath,
    truststorePassword: elasticsearchTruststorePassword,
    verificationMode: elasticsearchVerificationMode
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  parseSSLSettings
});
