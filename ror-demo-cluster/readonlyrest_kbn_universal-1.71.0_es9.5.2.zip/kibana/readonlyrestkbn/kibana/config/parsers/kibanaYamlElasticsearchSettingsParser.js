"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibanaYamlElasticsearchSettingsParser_exports = {};
__export(kibanaYamlElasticsearchSettingsParser_exports, {
  parseElasticsearchSettings: () => parseElasticsearchSettings
});
module.exports = __toCommonJS(kibanaYamlElasticsearchSettingsParser_exports);
var import_rorLoggerFactory = require("../../../proxy/core/logging/rorLoggerFactory");
var import_kibanaYamlElasticsearchSSLSettingsParser = require("./kibanaYamlElasticsearchSSLSettingsParser");
var import_kibanaYamlRequestHeadersWhitelistParser = require("./kibanaYamlRequestHeadersWhitelistParser");
const DEFAULT_ELASTICSEARCH_URL = "http://localhost:9200";
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const getKibanaTechUserEsCredentialsAuthToken = (user, password) => {
  if (user && password) {
    return `Basic ${Buffer.from(`${user}:${password}`).toString("base64")}`;
  }
  const missing = [];
  if (!user) {
    missing.push("user");
  }
  if (!password) {
    missing.push("password");
  }
  throw new Error(
    `Valid values for 'elasticsearch.username' and 'elasticsearch.password' are required by ReadonlyREST. ${missing.length === 2 ? "Both are" : `'elasticsearch.${missing[0]}' is `} missing.`
  );
};
function parseElasticsearchSettings(kibanaElasticsearchSettings) {
  try {
    const originalElasticHosts = (kibanaElasticsearchSettings == null ? void 0 : kibanaElasticsearchSettings.hosts) || [DEFAULT_ELASTICSEARCH_URL];
    const derivedElasticHosts = typeof originalElasticHosts === "string" ? [originalElasticHosts] : originalElasticHosts;
    if (derivedElasticHosts.length > 1) {
      logger.warn(
        "You configured more than one Elasticsearch nodes. If you also have multiple Kibana nodes in high availability (HA), you MUST add to kibana.yml 'readonlyrest_kbn.store_sessions_in_index: true' or it won't work. "
      );
    }
    const kibanaTechUserEsAuthToken = (kibanaElasticsearchSettings == null ? void 0 : kibanaElasticsearchSettings.serviceAccountToken) ? `Bearer ${kibanaElasticsearchSettings.serviceAccountToken}` : getKibanaTechUserEsCredentialsAuthToken(
      kibanaElasticsearchSettings == null ? void 0 : kibanaElasticsearchSettings.username,
      kibanaElasticsearchSettings == null ? void 0 : kibanaElasticsearchSettings.password
    );
    const elasticsearchSSLSettings = (0, import_kibanaYamlElasticsearchSSLSettingsParser.parseSSLSettings)(kibanaElasticsearchSettings, derivedElasticHosts);
    const requestHeadersWhitelist = (0, import_kibanaYamlRequestHeadersWhitelistParser.getRequestHeadersWhitelist)(kibanaElasticsearchSettings);
    const customHeaders = kibanaElasticsearchSettings.customHeaders || {};
    return {
      sslSettings: elasticsearchSSLSettings,
      elasticsearchHosts: derivedElasticHosts,
      kibanaTechUserEsAuthToken,
      requestHeadersWhitelist,
      customHeaders
    };
  } catch (e) {
    throw new Error(e);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  parseElasticsearchSettings
});
