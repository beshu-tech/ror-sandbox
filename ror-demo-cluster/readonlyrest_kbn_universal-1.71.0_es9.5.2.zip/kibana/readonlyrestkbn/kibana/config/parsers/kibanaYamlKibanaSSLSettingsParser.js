"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibanaYamlKibanaSSLSettingsParser_exports = {};
__export(kibanaYamlKibanaSSLSettingsParser_exports, {
  parseKibanaSSLSettings: () => parseKibanaSSLSettings
});
module.exports = __toCommonJS(kibanaYamlKibanaSSLSettingsParser_exports);
var import_rorLoggerFactory = require("../../../proxy/core/logging/rorLoggerFactory");
var import_settingsUtils = require("../settingsUtils");
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
function parseKibanaSSLSettings(kibanaRawConfig) {
  var _a, _b, _c;
  const sslObject = (_a = kibanaRawConfig.server) == null ? void 0 : _a.ssl;
  if ((sslObject == null ? void 0 : sslObject.enabled) === true) {
    if ((sslObject.key === void 0 || sslObject.certificate === void 0) && (sslObject.keystore === void 0 || sslObject.keystore.path === void 0)) {
      logger.error({
        message: `Either the SSL key & certificate paths or the keystore path need to be specified! Exiting.`
      });
      (0, import_settingsUtils.exitInOneSecond)();
    }
    if (sslObject.truststore !== void 0) {
      logger.error({
        message: "Truststore is not implemented yet. If you need this feature, please ask for it in ROR forum: https://forum.readonlyrest.com"
      });
      (0, import_settingsUtils.exitInOneSecond)();
    }
    return {
      keyPath: sslObject.key,
      keyPassphrase: sslObject.keyPassphrase,
      cipherSuites: sslObject.cipherSuites,
      certificatePath: sslObject.certificate,
      keystorePath: (_b = sslObject.keystore) == null ? void 0 : _b.path,
      keystorePassword: (_c = sslObject.keystore) == null ? void 0 : _c.password,
      supportedProtocols: sslObject.supportedProtocols
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  parseKibanaSSLSettings
});
