"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibanaYamlKibanaSettingsParser_exports = {};
__export(kibanaYamlKibanaSettingsParser_exports, {
  DEFAULT_KIBANA_INDEX: () => DEFAULT_KIBANA_INDEX,
  parseKibanaSettingsForPep: () => parseKibanaSettingsForPep,
  parseKibanaSettingsForPkp: () => parseKibanaSettingsForPkp
});
module.exports = __toCommonJS(kibanaYamlKibanaSettingsParser_exports);
var import_timeUtils = require("../../../proxy/core/common/timeUtils");
var import_kibanaYamlSecurityHeadersParser = require("../kibanaYamlSecurityHeadersParser");
var import_rorPort = require("../rorPort");
var import_kibanaYamlKibanaSSLSettingsParser = require("./kibanaYamlKibanaSSLSettingsParser");
const DEFAULT_KIBANA_INDEX = ".kibana";
const DEFAULT_KIBANA_PORT = 5601;
const DEFAULT_REQUEST_TIMEOUT_MS = 3e4;
const DEFAULT_PING_TIMEOUT_MS = DEFAULT_REQUEST_TIMEOUT_MS;
function getKibanaIndex(kibanaRawConfig) {
  var _a;
  return ((_a = kibanaRawConfig.kibana) == null ? void 0 : _a.index) || DEFAULT_KIBANA_INDEX;
}
function asValidPortNumber(input) {
  if (typeof input === "string" && !/^[1-9][0-9]*$/.test(String(input))) {
    throw new Error(`The port value is invalid: ${input}`);
  }
  const port = +input;
  if (Number.isNaN(port)) {
    throw new Error(`The port value is not numeric: ${input}`);
  }
  if (Math.floor(port) !== port) {
    throw new Error(`The port number is not an integer: ${input}`);
  }
  if (port < 0 || port > import_rorPort.HIGHEST_AVAILABLE_PORT) {
    throw new Error(`The port number is  out of range: ${input}`);
  }
  return port;
}
function parseKibanaSettingsForPkp(kibanaRawConfig) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
  const serverHost = ((_a = kibanaRawConfig.server) == null ? void 0 : _a.host) || "localhost";
  const kibanaYamlServerPort = (_b = kibanaRawConfig.server) == null ? void 0 : _b.port;
  const newKibanaPort = asValidPortNumber((0, import_rorPort.getRandomPort)(1024));
  const kibanaBasePath = ((_c = kibanaRawConfig.server) == null ? void 0 : _c.basePath) || "";
  const pkpPort = kibanaYamlServerPort ? asValidPortNumber(kibanaYamlServerPort) : DEFAULT_KIBANA_PORT;
  const bindAddress = {
    host: serverHost,
    port: pkpPort
  };
  const kibanaSslSettings = (0, import_kibanaYamlKibanaSSLSettingsParser.parseKibanaSSLSettings)(kibanaRawConfig);
  const kibanaUrl = `http://localhost:${asValidPortNumber(newKibanaPort)}`;
  const rewriteBasePath = (_e = (_d = kibanaRawConfig.server) == null ? void 0 : _d.rewriteBasePath) != null ? _e : false;
  const reportingQueueTimeoutRaw = (_h = (_g = (_f = kibanaRawConfig.xpack) == null ? void 0 : _f.reporting) == null ? void 0 : _g.queue) == null ? void 0 : _h.timeout;
  const reportingQueueTimeout = reportingQueueTimeoutRaw != null ? import_timeUtils.TimeUtils.parseDurationToSeconds(reportingQueueTimeoutRaw, "xpack.reporting.queue.timeout") : 240;
  const spacesEnabled = (_k = (_j = (_i = kibanaRawConfig.xpack) == null ? void 0 : _i.spaces) == null ? void 0 : _j.enabled) != null ? _k : true;
  return {
    bindAddress,
    kibanaUrl,
    kibanaBasePath,
    kibanaIndex: getKibanaIndex(kibanaRawConfig),
    newKibanaPort,
    kibanaSslSettings,
    rewriteBasePath,
    reportingQueueTimeout,
    spacesEnabled,
    securityHeaders: (0, import_kibanaYamlSecurityHeadersParser.buildSecurityHeadersConfig)(kibanaRawConfig, kibanaSslSettings !== void 0)
  };
}
function parseKibanaSettingsForPep(kibanaRawConfig, kibanaTechUserEsAuthToken, requestHeadersWhitelist) {
  var _a, _b;
  const pepPort = asValidPortNumber((0, import_rorPort.getRandomPort)(1024));
  const pepUrl = `http://localhost:${asValidPortNumber(pepPort)}`;
  const pingTimeout = ((_a = kibanaRawConfig.elasticsearch) == null ? void 0 : _a.pingTimeout) || DEFAULT_PING_TIMEOUT_MS;
  const requestTimeout = ((_b = kibanaRawConfig.elasticsearch) == null ? void 0 : _b.requestTimeout) || DEFAULT_REQUEST_TIMEOUT_MS;
  return {
    pepPort,
    pepUrl,
    networkParameters: { pingTimeout, requestTimeout },
    kibanaIndex: getKibanaIndex(kibanaRawConfig),
    kibanaTechUserEsAuthToken,
    requestHeadersWhitelist
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DEFAULT_KIBANA_INDEX,
  parseKibanaSettingsForPep,
  parseKibanaSettingsForPkp
});
