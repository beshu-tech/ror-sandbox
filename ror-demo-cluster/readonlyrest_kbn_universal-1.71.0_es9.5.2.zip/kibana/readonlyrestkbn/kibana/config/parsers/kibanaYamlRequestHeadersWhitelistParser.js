"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibanaYamlRequestHeadersWhitelistParser_exports = {};
__export(kibanaYamlRequestHeadersWhitelistParser_exports, {
  getRequestHeadersWhitelist: () => getRequestHeadersWhitelist,
  normalizeWithDefaultsRequestHeadersWhiteList: () => normalizeWithDefaultsRequestHeadersWhiteList
});
module.exports = __toCommonJS(kibanaYamlRequestHeadersWhitelistParser_exports);
var import_defaultValues = require("../../../server/defaultValues");
function normalizeWithDefaultsRequestHeadersWhiteList(headers) {
  const defaults = import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.requestHeadersWhitelist;
  const normalized = Array.isArray(headers) ? headers.concat(defaults) : defaults;
  return Array.from(new Set(normalized)).map((h) => h.toLowerCase());
}
function getRequestHeadersWhitelist(rorConfig) {
  return normalizeWithDefaultsRequestHeadersWhiteList(rorConfig == null ? void 0 : rorConfig.requestHeadersWhitelist);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getRequestHeadersWhitelist,
  normalizeWithDefaultsRequestHeadersWhiteList
});
