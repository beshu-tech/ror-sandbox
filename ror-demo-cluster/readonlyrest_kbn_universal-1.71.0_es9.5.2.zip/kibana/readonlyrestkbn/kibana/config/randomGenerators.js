"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var randomGenerators_exports = {};
__export(randomGenerators_exports, {
  TOKEN_LENGTH: () => TOKEN_LENGTH,
  generateRandomToken: () => generateRandomToken
});
module.exports = __toCommonJS(randomGenerators_exports);
const TOKEN_LENGTH = 30;
const generateRandomString = () => Math.random().toString(36).substr(2);
function generateRandomToken() {
  return (generateRandomString() + generateRandomString() + generateRandomString() + generateRandomString()).substr(
    0,
    TOKEN_LENGTH
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TOKEN_LENGTH,
  generateRandomToken
});
