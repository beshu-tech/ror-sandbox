"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorInitialization_exports = {};
__export(rorInitialization_exports, {
  RorInitializer: () => RorInitializer,
  rorInitialization: () => rorInitialization
});
module.exports = __toCommonJS(rorInitialization_exports);
var import_authWrapper = require("../../proxy/core/api/authWrapper");
var import_esApiAdvancedClient = require("../../proxy/core/api/esApiAdvancedClient");
var import_restEsApiClient = require("../../proxy/core/api/restEsApiClient");
var import_restRorEsApiClient = require("../../proxy/core/api/restRorEsApiClient");
var import_credentialHeadersCollector = require("../../proxy/core/authorization/credentialHeadersCollector");
var import_identitySessionHeadersValidation = require("../../proxy/core/authorization/identitySessionHeadersValidation");
var import_cookieManager = require("../../proxy/core/cookieManager");
var import_esHostBalancer = require("../../proxy/core/esHostBalancer");
var import_esSSLConnectionProvider = require("../../proxy/core/esSSLConnectionProvider");
var import_rorLoggerFactory = require("../../proxy/core/logging/rorLoggerFactory");
var import_rorRequestAppender = require("../../proxy/core/rorRequest/rorRequestAppender");
var import_userRequestIdentityService = require("../../proxy/core/rorRequest/userRequestIdentityService");
var import_RorSettingsManager = require("../../proxy/core/rorSettings/RorSettingsManager");
var import_sessionManagerProvider = require("../../proxy/core/sessionManager/sessionManagerProvider");
var import_multiTenancyChecker = require("../../proxy/core/tenancy/multiTenancyChecker");
var import_TenancyContextCrypter = require("../../proxy/core/tenancy/TenancyContextCrypter");
var import_tenancyService = require("../../proxy/core/tenancy/tenancyService");
var import_userMetadataResolver = require("../../proxy/core/userMetadata/userMetadataResolver");
var import_preElasticsearchProxy = require("../../proxy/preElasticsearchProxy/preElasticsearchProxy");
var import_devReloadExtension = require("../../proxy/preKibanaProxy/devReload/devReloadExtension");
var import_preKibanaProxy = require("../../proxy/preKibanaProxy/preKibanaProxy");
var import_rorStoreInitializer = require("./rorStoreInitializer");
var import_settingsUtils = require("./settingsUtils");
class RorInitializer {
  constructor(rorSettingsStore, elasticsearchSettings, kibanaSettingsForPkp, kibanaSettingsForPep) {
    this.rorSettingsStore = rorSettingsStore;
    this.elasticsearchSettings = elasticsearchSettings;
    this.kibanaSettingsForPkp = kibanaSettingsForPkp;
    this.kibanaSettingsForPep = kibanaSettingsForPep;
    __publicField(this, "sharedServices");
    __publicField(this, "pepServer");
    __publicField(this, "pkpServer");
    __publicField(this, "getLogger", () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  /*
   * We need to mutate and return the kibanaRawConfig back to Kibana SYNCHRONOUSLY,
   * otherwise Kibana gets started on port 5601, where PKP should bind instead.
   *
   * There is no way to initialize async ROR components while
   * synchronoulsy waiting for them, and then returning kibanaRawConfig back to Kibana.
   *
   * I tried 'desync', but it's implemented in C++ and it's not portable.
   *
   * 1. Keep the bulk of ROR initialization synchronous
   * 2. When you initialize something asynchronously (like licenseService),
   * be aware you won't have it initialised during ROR init, at all.
   */
  async initialize(licenseService) {
    this.sharedServices = this.initializeSharedServices(licenseService);
    this.pepServer = this.initializePep();
    try {
      this.getLogger().debug("License service initialized");
      this.pkpServer = this.initializePkp();
    } catch (error) {
      this.getLogger().error({ message: `Error during ROR initialization: ${error.message}`, stack: error.stack });
      this.cleanup();
      throw error;
    }
  }
  cleanup() {
    this.getLogger().info("Cleaning up ROR services...");
    if (this.pkpServer) {
      try {
        this.pkpServer.close();
      } catch (e) {
        this.getLogger().error({ message: `Error closing PKP server: ${e.message}`, stack: e.stack });
      }
      this.pkpServer = void 0;
    }
    if (this.pepServer) {
      try {
        this.pepServer.close();
      } catch (e) {
        this.getLogger().error({ message: `Error closing PEP server: ${e.message}`, stack: e.stack });
      }
      this.pepServer = void 0;
    }
    if (import_RorSettingsManager.RorSettingsManager.isInitialized()) {
      (0, import_RorSettingsManager.getRorSettingsManager)().clearRorSettingsManager();
    }
    (0, import_rorStoreInitializer.clearRorStore)();
  }
  initializeSharedServices(licenseService) {
    const { cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    const esSSLConnectionProvider = new import_esSSLConnectionProvider.EsSSLConnectionProvider(this.elasticsearchSettings.sslSettings);
    const esHostBalancer = new import_esHostBalancer.EsHostBalancer(
      this.elasticsearchSettings.elasticsearchHosts,
      this.kibanaSettingsForPep.networkParameters,
      this.elasticsearchSettings.kibanaTechUserEsAuthToken,
      esSSLConnectionProvider
    );
    const restEsApiClient = new import_restEsApiClient.RestEsApiClient(esHostBalancer.getElasticsearchUrl(), esSSLConnectionProvider, {
      diskThresholdVerificationEnabled: () => this.rorSettingsStore.getLatestRorKbnSettings().diskThresholdVerificationEnabled,
      kibanaIndex: this.kibanaSettingsForPkp.kibanaIndex
    });
    const esApiClientWithAuthProvider = new import_authWrapper.AuthWrapper(
      this.elasticsearchSettings.kibanaTechUserEsAuthToken,
      restEsApiClient
    );
    const esApiAdvancedClientWithAuthProvider = new import_authWrapper.AuthWrapper(
      this.elasticsearchSettings.kibanaTechUserEsAuthToken,
      new import_esApiAdvancedClient.EsApiAdvancedClient(esHostBalancer.getElasticsearchUrl(), esSSLConnectionProvider, {
        diskThresholdVerificationEnabled: () => this.rorSettingsStore.getLatestRorKbnSettings().diskThresholdVerificationEnabled,
        kibanaIndex: this.kibanaSettingsForPkp.kibanaIndex
      })
    );
    const multiTenancyChecker = new import_multiTenancyChecker.MultiTenancyChecker(this.rorSettingsStore, licenseService);
    const restRorEsApiClient = new import_restRorEsApiClient.RestRorEsApiClient(
      esHostBalancer.getElasticsearchUrl(),
      this.elasticsearchSettings.customHeaders,
      esSSLConnectionProvider,
      this.kibanaSettingsForPkp.kibanaIndex
    );
    const rorEsApiClientWithAuthProvider = new import_authWrapper.AuthWrapper(
      this.elasticsearchSettings.kibanaTechUserEsAuthToken,
      restRorEsApiClient
    );
    const userMetadataResolver = new import_userMetadataResolver.UserMetadataResolver(
      multiTenancyChecker,
      licenseService,
      this.kibanaSettingsForPkp.kibanaIndex,
      this.rorSettingsStore.getLatestRorKbnSettings().kibanaTemplateIndex
    );
    const sessionManagerProvider = new import_sessionManagerProvider.SessionManagerProvider(
      licenseService,
      this.kibanaSettingsForPkp.reportingQueueTimeout,
      this.rorSettingsStore,
      esApiClientWithAuthProvider,
      userMetadataResolver
    ).build();
    const cookieManager = new import_cookieManager.CookieManager(this.rorSettingsStore);
    const tenancyContextCrypter = new import_TenancyContextCrypter.TenancyContextCrypter(cookieSettings.password);
    const tenancyService = new import_tenancyService.TenancyService(tenancyContextCrypter, sessionManagerProvider, multiTenancyChecker);
    const userRequestIdentityServiceFactory = (expressRorRequest) => new import_userRequestIdentityService.UserRequestIdentityService(sessionManagerProvider.get(), cookieManager, expressRorRequest, tenancyService);
    const rorRequestAppender = new import_rorRequestAppender.RorRequestAppender(sessionManagerProvider, userRequestIdentityServiceFactory);
    const credentialHeadersCollector = new import_credentialHeadersCollector.CredentialHeadersCollector(this.rorSettingsStore);
    const identitySessionHeadersValidation = new import_identitySessionHeadersValidation.IdentitySessionHeadersValidation(
      credentialHeadersCollector,
      this.elasticsearchSettings.requestHeadersWhitelist,
      multiTenancyChecker,
      restRorEsApiClient,
      sessionManagerProvider,
      licenseService
    );
    return {
      cookieManager,
      esSSLConnectionProvider,
      esHostBalancer,
      esApiClientWithAuthProvider,
      esApiAdvancedClientWithAuthProvider,
      rorEsApiClientWithAuthProvider,
      sessionManagerProvider,
      rorRequestAppender,
      licenseService,
      credentialHeadersCollector,
      identitySessionHeadersValidation,
      tenancyService,
      multiTenancyChecker,
      userMetadataResolver
    };
  }
  initializePkp() {
    if (!this.sharedServices) {
      this.getLogger().error({ message: "Shared services are not initialized, cannot create PreKibanaProxy" });
      (0, import_settingsUtils.exitInOneSecond)();
      return void 0;
    }
    try {
      return new import_preKibanaProxy.PreKibanaProxy(
        this.sharedServices.sessionManagerProvider,
        this.sharedServices.cookieManager,
        this.sharedServices.rorRequestAppender,
        this.sharedServices.esApiClientWithAuthProvider,
        this.sharedServices.esApiAdvancedClientWithAuthProvider,
        this.sharedServices.rorEsApiClientWithAuthProvider,
        this.sharedServices.credentialHeadersCollector,
        this.sharedServices.identitySessionHeadersValidation,
        this.sharedServices.licenseService,
        this.kibanaSettingsForPkp,
        this.elasticsearchSettings,
        this.rorSettingsStore,
        this.sharedServices.tenancyService,
        this.sharedServices.multiTenancyChecker,
        this.sharedServices.userMetadataResolver,
        process.env.ROR_DEV_RELOAD_ENABLED === "true" ? [new import_devReloadExtension.DevReloadExtension()] : []
      );
    } catch (e) {
      this.getLogger().error({ message: `Error initialising PKP: ${e.message}`, stack: e.stack });
      return void 0;
    }
  }
  initializePep() {
    if (!this.sharedServices) {
      this.getLogger().error({ message: "Shared services are not initialized, cannot create PreKibanaProxy" });
      (0, import_settingsUtils.exitInOneSecond)();
      return void 0;
    }
    return new import_preElasticsearchProxy.PreElasticsearchProxy(
      this.sharedServices.sessionManagerProvider,
      this.sharedServices.rorRequestAppender,
      this.sharedServices.esHostBalancer,
      this.sharedServices.esSSLConnectionProvider,
      this.kibanaSettingsForPep,
      this.sharedServices.identitySessionHeadersValidation,
      this.sharedServices.multiTenancyChecker,
      this.sharedServices.tenancyService
    );
  }
}
const ROR_INIT_MAX_RETRIES = 5;
const ROR_INIT_TOTAL_ATTEMPTS = ROR_INIT_MAX_RETRIES + 1;
const ROR_INIT_RETRY_INTERVAL_MS = 5e3;
let rorInitializerInstance = null;
let rorRetryTimer = null;
let rorInitGeneration = 0;
function rorInitializeWithRetries(rorSettingsStore, elasticsearchSettings, kibanaSettingsForPkp, kibanaSettingsForPep, licenseService, retriesLeft, generation) {
  const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
  rorInitializerInstance == null ? void 0 : rorInitializerInstance.cleanup();
  rorInitializerInstance = new RorInitializer(
    rorSettingsStore,
    elasticsearchSettings,
    kibanaSettingsForPkp,
    kibanaSettingsForPep
  );
  rorInitializerInstance.initialize(licenseService).catch((e) => {
    if (generation !== rorInitGeneration) return;
    const message = e instanceof Error ? e.message : String(e);
    const stack = e instanceof Error ? e.stack : void 0;
    logger.error({ message: `Error during ReadonlyREST Kibana plugin initialization: ${message}`, stack });
    if (retriesLeft === 0) {
      logger.error({
        message: `ReadonlyREST Kibana plugin initialization failed after ${ROR_INIT_TOTAL_ATTEMPTS} attempts.`
      });
      (0, import_settingsUtils.exitInOneSecond)();
      return;
    }
    const attemptsWord = retriesLeft === 1 ? "attempt" : "attempts";
    logger.info(
      `Retrying ReadonlyREST Kibana plugin in ${ROR_INIT_RETRY_INTERVAL_MS / 1e3}s... ${retriesLeft} ${attemptsWord} left`
    );
    rorRetryTimer = setTimeout(() => {
      rorRetryTimer = null;
      rorInitializeWithRetries(
        rorSettingsStore,
        elasticsearchSettings,
        kibanaSettingsForPkp,
        kibanaSettingsForPep,
        licenseService,
        retriesLeft - 1,
        generation
      );
    }, ROR_INIT_RETRY_INTERVAL_MS);
  });
}
function rorInitialization(rorSettingsStore, elasticsearchSettings, kibanaSettingsForPkp, kibanaSettingsForPep, licenseService) {
  rorInitGeneration += 1;
  const generation = rorInitGeneration;
  if (rorRetryTimer !== null) {
    clearTimeout(rorRetryTimer);
    rorRetryTimer = null;
  }
  rorInitializeWithRetries(
    rorSettingsStore,
    elasticsearchSettings,
    kibanaSettingsForPkp,
    kibanaSettingsForPep,
    licenseService,
    ROR_INIT_MAX_RETRIES,
    generation
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorInitializer,
  rorInitialization
});
