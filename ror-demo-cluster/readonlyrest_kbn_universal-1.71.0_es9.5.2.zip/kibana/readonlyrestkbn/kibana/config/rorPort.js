"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var rorPort_exports = {};
__export(rorPort_exports, {
  HIGHEST_AVAILABLE_PORT: () => HIGHEST_AVAILABLE_PORT,
  checkIfPortsAreFree: () => checkIfPortsAreFree,
  getRandomPort: () => getRandomPort,
  portVerification: () => portVerification
});
module.exports = __toCommonJS(rorPort_exports);
var import_versionedLibraries = require("../../proxy/core/common/versionedLibraries");
const HIGHEST_AVAILABLE_PORT = 65536;
function getRandomPort(initialPort, maxPort = HIGHEST_AVAILABLE_PORT) {
  const maximumLimitWithInitialPortCalculated = maxPort - initialPort - 1;
  const randomPort = Math.floor(Math.random() * maximumLimitWithInitialPortCalculated) + initialPort;
  if (randomPort > maxPort) {
    return maxPort;
  }
  return randomPort;
}
function portVerification(input) {
  return new Promise((resolve, reject) => {
    (0, import_versionedLibraries.detectPort)(input, (err, _port) => {
      if (err) {
        reject(err);
      }
      const portInUse = input !== _port;
      if (portInUse) {
        reject(new Error(`Port ${input} is already in use.`));
      } else {
        resolve(true);
      }
    });
  });
}
function checkIfPortsAreFree(pkpPort, pepPort) {
  return Promise.all([portVerification(pkpPort), portVerification(pepPort)]);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HIGHEST_AVAILABLE_PORT,
  checkIfPortsAreFree,
  getRandomPort,
  portVerification
});
