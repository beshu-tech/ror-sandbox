"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorRuntime_exports = {};
__export(rorRuntime_exports, {
  RorRuntime: () => RorRuntime
});
module.exports = __toCommonJS(rorRuntime_exports);
class RorRuntime {
  constructor(dependencies) {
    this.dependencies = dependencies;
    __publicField(this, "sharedServices");
    __publicField(this, "pepServer");
    __publicField(this, "pkpServer");
  }
  async start() {
    var _a, _b;
    const licenseService = this.dependencies.createLicenseService();
    this.sharedServices = this.dependencies.initializeSharedServices(licenseService);
    this.pepServer = this.dependencies.initializePep(this.sharedServices);
    const sessionManager = (_b = (_a = this.sharedServices.sessionManagerProvider) == null ? void 0 : _a.get()) != null ? _b : this.sharedServices.sessionManager;
    sessionManager == null ? void 0 : sessionManager.init();
    await licenseService.init();
    this.dependencies.validateConfiguration(licenseService);
    this.pkpServer = this.dependencies.initializePkp(this.sharedServices);
    if (!this.pkpServer) {
      throw new Error("PKP initialization failed");
    }
  }
  stop() {
    this.closeServer("PKP", this.pkpServer);
    this.pkpServer = void 0;
    this.closeServer("PEP", this.pepServer);
    this.pepServer = void 0;
    this.sharedServices = void 0;
    this.dependencies.clearStore();
  }
  closeServer(serverName, server) {
    var _a, _b;
    if (!server) return;
    try {
      server.close();
    } catch (error) {
      (_b = (_a = this.dependencies).reportCloseError) == null ? void 0 : _b.call(_a, serverName, error);
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorRuntime
});
