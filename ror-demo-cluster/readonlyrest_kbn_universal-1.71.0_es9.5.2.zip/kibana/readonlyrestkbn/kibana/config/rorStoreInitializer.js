"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var rorStoreInitializer_exports = {};
__export(rorStoreInitializer_exports, {
  clearRorStore: () => clearRorStore,
  initializeRorStorePortAndHost: () => initializeRorStorePortAndHost
});
module.exports = __toCommonJS(rorStoreInitializer_exports);
const rorStore = require("../rorStore");
function initializeRorStorePortAndHost(kibanaConfig) {
  rorStore.setOncePkpPort(kibanaConfig.bindAddress.port);
  const pkpUrl = `${kibanaConfig.kibanaSslSettings ? "https" : "http"}://${kibanaConfig.bindAddress.host}:${kibanaConfig.bindAddress.port}`;
  rorStore.setOncePkpUrl(pkpUrl);
}
function clearRorStore() {
  rorStore.clearAll();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  clearRorStore,
  initializeRorStorePortAndHost
});
