"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var settingsUtils_exports = {};
__export(settingsUtils_exports, {
  exitInOneSecond: () => exitInOneSecond
});
module.exports = __toCommonJS(settingsUtils_exports);
var import_rorLoggerFactory = require("../../proxy/core/logging/rorLoggerFactory");
const getLogger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const exitInOneSecond = () => {
  getLogger().info("ReadonlyREST terminating Kibana in 1 second...");
  setTimeout(() => process.exit(1), 1e3);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  exitInOneSecond
});
