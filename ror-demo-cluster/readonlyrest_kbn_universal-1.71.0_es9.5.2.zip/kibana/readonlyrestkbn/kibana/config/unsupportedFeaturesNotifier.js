"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var unsupportedFeaturesNotifier_exports = {};
__export(unsupportedFeaturesNotifier_exports, {
  checkLoggingFeatures: () => checkLoggingFeatures,
  verifyNoUnsupportedSettingsSupplied: () => verifyNoUnsupportedSettingsSupplied
});
module.exports = __toCommonJS(unsupportedFeaturesNotifier_exports);
var import_ajv = __toESM(require("ajv"));
var import_rorLoggerFactory = require("../../proxy/core/logging/rorLoggerFactory");
var import_loggingFeaturesSchema = require("./loggingFeaturesSchema");
var import_settingsUtils = require("./settingsUtils");
const validateLoggingFeatures = new import_ajv.default({ allErrors: true }).compile(import_loggingFeaturesSchema.loggingFeaturesSchema);
function checkLoggingFeatures(features) {
  var _a;
  const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
  validateLoggingFeatures(features);
  for (const error of (_a = validateLoggingFeatures.errors) != null ? _a : []) {
    const instancePath = error.instancePath.replace(/^\//, "").replace(/\//g, ".");
    if (error.keyword === "additionalProperties") {
      const featurePath = instancePath ? `${instancePath}.${error.params.additionalProperty}` : String(error.params.additionalProperty);
      logger.warn(
        `logging.${featurePath} setting parameter declared in kibana.yml is not supported yet. It will be ignored in the ReadonlyREST Kibana logs`
      );
    } else if (error.keyword === "enum") {
      const allowedValues = error.params.allowedValues.join(", ");
      logger.warn(
        `logging.${instancePath} setting parameter has an unsupported value. Supported values are: ${allowedValues}. It will be ignored in the ReadonlyREST Kibana logs`
      );
    }
  }
}
function verifyNoUnsupportedSettingsSupplied(kibanaRawConfig) {
  const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
  const elasticsearchObject = kibanaRawConfig.elasticsearch;
  if (elasticsearchObject == null) {
    return;
  }
  checkLoggingFeatures(kibanaRawConfig.logging);
  if (elasticsearchObject.sniffInterval) {
    logger.error(
      new Error(
        `Sniffing is not supported yet. Please set 'elasticsearch.sniffInterval' to 'false' in kibana.yml config.`
      )
    );
    (0, import_settingsUtils.exitInOneSecond)();
  }
  if (elasticsearchObject.sniffOnStart) {
    logger.error(
      new Error(
        `Sniffing is not supported yet. Please set 'elasticsearch.sniffOnStart' to 'false' in kibana.yml config.`
      )
    );
    (0, import_settingsUtils.exitInOneSecond)();
  }
  if (elasticsearchObject.sniffOnConnectionFault) {
    logger.error(
      new Error(
        `SSL is not supported yet. Please set 'elasticsearch.sniffOnConnectionFault' to 'false' in kibana.yml config.`
      )
    );
    (0, import_settingsUtils.exitInOneSecond)();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  checkLoggingFeatures,
  verifyNoUnsupportedSettingsSupplied
});
