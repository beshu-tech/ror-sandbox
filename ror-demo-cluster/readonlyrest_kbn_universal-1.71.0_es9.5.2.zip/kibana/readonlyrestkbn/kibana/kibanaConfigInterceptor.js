"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibanaConfigInterceptor_exports = {};
__export(kibanaConfigInterceptor_exports, {
  onKibanaConfigParse: () => onKibanaConfigParse
});
module.exports = __toCommonJS(kibanaConfigInterceptor_exports);
var import_lodash = require("lodash");
var import_authWrapper = require("../proxy/core/api/authWrapper");
var import_esApiAdvancedClient = require("../proxy/core/api/esApiAdvancedClient");
var import_restRorEsApiClient = require("../proxy/core/api/restRorEsApiClient");
var import_esHostBalancer = require("../proxy/core/esHostBalancer");
var import_esSSLConnectionProvider = require("../proxy/core/esSSLConnectionProvider");
var import_LicenseServiceFactory = require("../proxy/core/license/LicenseServiceFactory");
var import_rorLoggerFactory = require("../proxy/core/logging/rorLoggerFactory");
var import_buildLogLevel = require("../proxy/core/rorSettings/rorKbnSettingsBuilder/buildLogLevel");
var import_RorSettingsManager = require("../proxy/core/rorSettings/RorSettingsManager");
var import_KibanaConfigManager = require("./config/KibanaConfigManager");
var import_kibanaYamlElasticsearchSettingsParser = require("./config/parsers/kibanaYamlElasticsearchSettingsParser");
var import_kibanaYamlKibanaSettingsParser = require("./config/parsers/kibanaYamlKibanaSettingsParser");
var import_rorInitialization = require("./config/rorInitialization");
var import_RorKibanaBootstrapConfig = require("./config/RorKibanaBootstrapConfig");
var import_rorPort = require("./config/rorPort");
var import_rorStoreInitializer = require("./config/rorStoreInitializer");
var import_settingsUtils = require("./config/settingsUtils");
var import_unsupportedFeaturesNotifier = require("./config/unsupportedFeaturesNotifier");
const getLogger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
function initLogs(kibanaConfig, rorSettingsStore) {
  rorSettingsStore.observerRorKbnSettings(({ logLevel, logPrettyPrintEnabled }) => ({
    logLevel,
    logPrettyPrintEnabled
  })).subscribe(({ logLevel, logPrettyPrintEnabled }) => {
    import_rorLoggerFactory.RorLoggerFactory.configureLogging(logLevel, (0, import_buildLogLevel.getLogsDestination)(kibanaConfig.logging), logPrettyPrintEnabled);
  });
}
function onKibanaConfigParse(kibanaRawConfig) {
  if (import_KibanaConfigManager.KibanaConfigManager.isInitialized()) {
    return (0, import_KibanaConfigManager.getKibanaConfigManager)().getKibanaConfig();
  }
  if (!kibanaRawConfig || (0, import_lodash.isEmpty)(kibanaRawConfig)) {
    return kibanaRawConfig;
  }
  getLogger().trace(`Found settings object in a Kibana:`, kibanaRawConfig);
  (0, import_unsupportedFeaturesNotifier.verifyNoUnsupportedSettingsSupplied)(kibanaRawConfig);
  try {
    const elasticsearchSettings = (0, import_kibanaYamlElasticsearchSettingsParser.parseElasticsearchSettings)(kibanaRawConfig.elasticsearch);
    const kibanaSettingsForPkp = (0, import_kibanaYamlKibanaSettingsParser.parseKibanaSettingsForPkp)(kibanaRawConfig);
    const kibanaSettingsForPep = (0, import_kibanaYamlKibanaSettingsParser.parseKibanaSettingsForPep)(
      kibanaRawConfig,
      elasticsearchSettings.kibanaTechUserEsAuthToken,
      elasticsearchSettings.requestHeadersWhitelist
    );
    import_KibanaConfigManager.KibanaConfigManager.initialize(kibanaRawConfig, kibanaSettingsForPkp, kibanaSettingsForPep);
    (0, import_rorPort.checkIfPortsAreFree)(kibanaSettingsForPkp.newKibanaPort, kibanaSettingsForPep.pepPort).then((verified) => {
      const pkpPortVerified = verified[0];
      const pepPortVerified = verified[1];
      if (pkpPortVerified && pepPortVerified) {
        const esSSLConnectionProvider = new import_esSSLConnectionProvider.EsSSLConnectionProvider(elasticsearchSettings.sslSettings);
        const esHostBalancer = new import_esHostBalancer.EsHostBalancer(
          elasticsearchSettings.elasticsearchHosts,
          kibanaSettingsForPep.networkParameters,
          elasticsearchSettings.kibanaTechUserEsAuthToken,
          esSSLConnectionProvider
        );
        const restRorEsApiClient = new import_restRorEsApiClient.RestRorEsApiClient(
          esHostBalancer.getElasticsearchUrl(),
          elasticsearchSettings.customHeaders,
          esSSLConnectionProvider,
          kibanaSettingsForPkp.kibanaIndex
        );
        const rorEsApiClientWithAuthProvider = new import_authWrapper.AuthWrapper(
          elasticsearchSettings.kibanaTechUserEsAuthToken,
          restRorEsApiClient
        );
        const esApiAdvancedClient = new import_esApiAdvancedClient.EsApiAdvancedClient(
          esHostBalancer.getElasticsearchUrl(),
          esSSLConnectionProvider,
          { diskThresholdVerificationEnabled: () => false, kibanaIndex: kibanaSettingsForPkp.kibanaIndex }
        );
        const esApiAdvancedClientAuthProvider = new import_authWrapper.AuthWrapper(
          elasticsearchSettings.kibanaTechUserEsAuthToken,
          esApiAdvancedClient
        );
        (0, import_rorStoreInitializer.initializeRorStorePortAndHost)(kibanaSettingsForPkp);
        esApiAdvancedClientAuthProvider.asTechnicalUser().waitForES().then(() => {
          const licenseService = new import_LicenseServiceFactory.LicenseServiceFactory(esApiAdvancedClientAuthProvider).createLicenseService();
          licenseService.init().then(() => {
            import_RorSettingsManager.RorSettingsManager.initialize(
              (0, import_KibanaConfigManager.getKibanaConfigManager)().getKibanaConfig(),
              rorEsApiClientWithAuthProvider,
              licenseService
            ).then(() => {
              const rorSettingsStore = (0, import_RorSettingsManager.getRorSettingsManager)().rorKbnSettingsStore();
              (0, import_RorKibanaBootstrapConfig.initializeRorKibanaBootstrapConfig)(rorSettingsStore);
              initLogs(kibanaRawConfig, rorSettingsStore);
              (0, import_rorInitialization.rorInitialization)(
                rorSettingsStore,
                elasticsearchSettings,
                kibanaSettingsForPkp,
                kibanaSettingsForPep,
                licenseService
              );
            }).catch((e) => {
              getLogger().error({
                message: `ReadonlyREST Cannot initialize ReadonlyREST configuration: ${e.message}`,
                stack: e.stack
              });
              (0, import_settingsUtils.exitInOneSecond)();
            });
          }).catch((e) => {
            getLogger().error({
              message: `ReadonlyREST Cannot initialize license service: ${e.message}`,
              stack: e.stack
            });
            (0, import_settingsUtils.exitInOneSecond)();
          });
        }).catch((e) => {
          getLogger().error({
            message: `ReadonlyREST Cannot connect to Elasticsearch: ${e.message}`,
            stack: e.stack
          });
          (0, import_settingsUtils.exitInOneSecond)();
        });
      }
    }).catch((e) => {
      getLogger().error({ message: `ReadonlyREST Cannot initialize Kibana: ${e.message}`, stack: e.stack });
      (0, import_settingsUtils.exitInOneSecond)();
    });
    return (0, import_KibanaConfigManager.getKibanaConfigManager)().getKibanaConfig();
  } catch (e) {
    getLogger().error({ message: `ReadonlyREST Cannot initialize Kibana: ${e.message}`, stack: e.stack });
    (0, import_settingsUtils.exitInOneSecond)();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  onKibanaConfigParse
});
