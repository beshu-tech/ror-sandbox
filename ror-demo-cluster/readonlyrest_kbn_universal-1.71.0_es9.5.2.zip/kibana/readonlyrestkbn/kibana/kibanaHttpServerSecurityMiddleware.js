"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibanaHttpServerSecurityMiddleware_exports = {};
__export(kibanaHttpServerSecurityMiddleware_exports, {
  redirectToPkpMiddleware: () => redirectToPkpMiddleware
});
module.exports = __toCommonJS(kibanaHttpServerSecurityMiddleware_exports);
var import_RorKibanaBootstrapConfig = require("./config/RorKibanaBootstrapConfig");
const rorStore = require("./rorStore");
function getProtocol(request) {
  var _a, _b;
  if (request.headers["x-forwarded-proto"]) {
    return request.headers["x-forwarded-proto"];
  }
  if ((_b = (_a = request.connection) == null ? void 0 : _a.info) == null ? void 0 : _b.protocol) {
    return request.connection.info.protocol;
  }
  return request.server.info.protocol;
}
function buildRedirectUrl(request) {
  const path = request.url.path || request.url.pathname;
  const redirectUrl = new URL(`${getProtocol(request)}://${request.info.host}${path}`);
  redirectUrl.port = rorStore.getPkpPort().toString();
  return redirectUrl.toString();
}
function hasValidPkpKibanaToken(request) {
  return request.headers["x-ror-pkp-kibana-token"] === (0, import_RorKibanaBootstrapConfig.getRorKibanaBootstrapConfig)().pkpKibanaToken;
}
function redirectToPkpMiddleware(request, responseToolkit) {
  if (!hasValidPkpKibanaToken(request)) {
    return responseToolkit.redirect(buildRedirectUrl(request)).takeover();
  }
  return responseToolkit.continue;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  redirectToPkpMiddleware
});
