"use strict";
class KibanaVersionGateError extends Error {
  constructor(message) {
    super(message);
    this.name = "KibanaVersionGateError";
  }
}
module.exports = /* @__PURE__ */ (() => {
  let migrator;
  return {
    KibanaVersionGateError,
    setMigrator: (newMigrator) => {
      if (!migrator) {
        migrator = newMigrator;
      }
    },
    runMigration: async (kibanaIndex, logger) => {
      if (!migrator) {
        logger.debug("Automatic migration is only available for the Kibana >= 8.x. Automatic migration skipped.");
        return;
      }
      const kibanaIndexMigrator = migrator.kibanaIndexMigrator(kibanaIndex);
      kibanaIndexMigrator.prepareMigrations();
      try {
        await kibanaIndexMigrator.runMigrations();
      } catch (e) {
        if (e instanceof Error && e.message.includes("deployment detected")) {
          throw new KibanaVersionGateError(e.message);
        }
        throw e;
      }
    },
    clearMigrator: () => {
      migrator = void 0;
    }
  };
})();
