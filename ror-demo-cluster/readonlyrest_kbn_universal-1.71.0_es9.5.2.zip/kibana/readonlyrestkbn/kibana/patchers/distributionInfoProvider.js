"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var distributionInfoProvider_exports = {};
__export(distributionInfoProvider_exports, {
  DistributionInfoProvider: () => DistributionInfoProvider,
  Environment: () => Environment
});
module.exports = __toCommonJS(distributionInfoProvider_exports);
var import_fs = require("fs");
var Environment = /* @__PURE__ */ ((Environment2) => {
  Environment2[Environment2["DEV"] = 0] = "DEV";
  Environment2[Environment2["PRODUCTION"] = 1] = "PRODUCTION";
  return Environment2;
})(Environment || {});
const _DistributionInfoProvider = class _DistributionInfoProvider {
  constructor(versionString) {
    __publicField(this, "_versionString");
    __publicField(this, "_kibanaVersion");
    __publicField(this, "_rorVersion");
    __publicField(this, "environment");
    __publicField(this, "_isBuildExpired");
    try {
      this._versionString = versionString;
      this._kibanaVersion = versionString.split("_es")[1];
      this._rorVersion = versionString.substring(versionString.indexOf("-") + 1).split("_")[0];
    } catch (e) {
      throw new Error(`Error parsing version string, error in parsing: ${e.message}`);
    }
    if (!this._versionString || !this._kibanaVersion) {
      throw new Error(`Invalid version string, error in parsing: ${versionString}`);
    }
    if (!/^\d+\.\d+/.test(this._kibanaVersion)) {
      throw new Error(
        `'${this._kibanaVersion}' (from version string '${versionString}') is not a valid Kibana version`
      );
    }
    try {
      this._isBuildExpired = false;
    } catch (e) {
      if (!e.message.includes("halted")) {
        console.log("Something went wrong in build expired..", e);
      }
      this._isBuildExpired = true;
    }
    const env = _DistributionInfoProvider.readPackageJson(`${__dirname}/../../package.json`).environment;
    this.environment = env === "PRODUCTION" ? 1 /* PRODUCTION */ : 0 /* DEV */;
  }
  isBuildExpired() {
    return this._isBuildExpired;
  }
  toJsonObject() {
    return {
      versionString: this._versionString,
      kibanaVersion: this._kibanaVersion,
      rorVersion: this._rorVersion,
      isProduction: Boolean(this.environment),
      isBuildExpired: this._isBuildExpired
    };
  }
  toString() {
    return JSON.stringify(this.toJsonObject());
  }
  get kibanaVersion() {
    return this._kibanaVersion;
  }
  get kibanaBaseVersion() {
    return _DistributionInfoProvider.extractBaseVersion(this._kibanaVersion);
  }
  static extractBaseVersion(version) {
    var _a, _b;
    return (_b = (_a = version.match(/^(\d+\.\d+\.\d+)/)) == null ? void 0 : _a[1]) != null ? _b : version;
  }
  get rorVersion() {
    return this._rorVersion;
  }
  get versionString() {
    return this._versionString;
  }
  get getEnvironment() {
    return this.environment;
  }
  static isEnvironmentDev() {
    return this.getInstance().environment === 0 /* DEV */;
  }
  // For the backend
  static getInstance() {
    if (!this.instance) {
      try {
        const rorPackageJson = this.readPackageJson(`${__dirname}/../../package.json`);
        let versionString;
        if (rorPackageJson.ror_version && rorPackageJson.ror_version.includes("_es")) {
          versionString = rorPackageJson.ror_version;
        } else {
          versionString = `enterprise-${rorPackageJson.version}_es${this.readHostKibanaVersion()}`;
        }
        this.instance = new _DistributionInfoProvider(versionString);
      } catch (e) {
        console.log(e);
        throw new Error(
          `Cannot retrieve information from package.json. If this call comes from the browser, use StatusService.js instead.${e.message}`
        );
      }
    }
    return this.instance;
  }
  /**
   * The version of the Kibana distribution hosting this plugin. Only needed in development; a
   * built plugin carries its target version in ror_version. Tests have no host Kibana and must
   * declare a version explicitly via setInstance().
   */
  static readHostKibanaVersion() {
    try {
      return this.readPackageJson(`${__dirname}/../../../../package.json`).version;
    } catch (e) {
      throw new Error(
        `could not read the host Kibana version from '${__dirname}/../../../../package.json' (${e.message}). Outside a Kibana checkout, call DistributionInfoProvider.setInstance('enterprise-<ror>_es<kibana>') first`
      );
    }
  }
  // for the front end, after taking the version string from StatusAPI
  static fromVersionString(versionString) {
    return new _DistributionInfoProvider(versionString);
  }
  static resetInstance() {
    this.instance = void 0;
  }
  static setInstance(version) {
    this.instance = new _DistributionInfoProvider(version);
  }
  static readPackageJson(path) {
    const packageString = (0, import_fs.readFileSync)(path, { encoding: "utf8", flag: "r" });
    return JSON.parse(packageString);
  }
  isRorMoreAncientThan(ofWhat) {
    return this.isMoreAncientThan(this._rorVersion, ofWhat);
  }
  isKibanaMoreAncientThan(ofWhat) {
    return this.isMoreAncientThan(this._kibanaVersion, ofWhat);
  }
  isKibanaNeverOrEqualTo(ofWhat) {
    return this.isNeverOrEqualTo(this._kibanaVersion, ofWhat);
  }
  /**
   * A version segment may carry a prerelease suffix ('0-SNAPSHOT', '0-pre5'); only the leading
   * digits are significant. A segment with no leading digits is not a version at all — throw
   * rather than let parseInt's NaN propagate, because a NaN difference is falsy and would make
   * the comparison silently fall through to the segment-count tiebreak below.
   */
  static parseSegment(segment, a, b) {
    const digits = /^\d+/.exec(segment);
    if (!digits) {
      throw new Error(`Cannot compare versions '${a}' and '${b}': '${segment}' is not a numeric version segment`);
    }
    return parseInt(digits[0], 10);
  }
  cmpVersions(a, b) {
    const regExStrip0 = /(\.0+)+$/;
    const segmentsA = a.replace(regExStrip0, "").split(".");
    const segmentsB = b.replace(regExStrip0, "").split(".");
    const l = Math.min(segmentsA.length, segmentsB.length);
    for (let i = 0; i < l; i++) {
      const diff = _DistributionInfoProvider.parseSegment(segmentsA[i], a, b) - _DistributionInfoProvider.parseSegment(segmentsB[i], a, b);
      if (diff) {
        return diff;
      }
    }
    return segmentsA.length - segmentsB.length;
  }
  isMoreAncientThan(what, ofWhat) {
    return this.cmpVersions(what, ofWhat) < 0;
  }
  isNeverOrEqualTo(what, ofWhat) {
    return this.cmpVersions(what, ofWhat) >= 0;
  }
};
__publicField(_DistributionInfoProvider, "instance");
let DistributionInfoProvider = _DistributionInfoProvider;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DistributionInfoProvider,
  Environment
});
