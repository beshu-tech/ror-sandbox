"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var filePatcher_exports = {};
__export(filePatcher_exports, {
  FilePatcher: () => FilePatcher
});
module.exports = __toCommonJS(filePatcher_exports);
var import_helpers = require("./helpers");
var import_metadataPatcher = require("./metadataPatcher");
var import_messages = require("./messages");
var import_logLevel = require("../../proxy/core/logging/logLevel");
const diff = require("diff");
const fs = require("fs");
const { basename } = require("path");
class FilePatcher {
  constructor(patchFilePath, targetPatchRoot = `${__dirname}../../`, backup_suffix = ".orig") {
    __publicField(this, "patchFilePath");
    __publicField(this, "backup_suffix");
    __publicField(this, "targetPatchRoot");
    __publicField(this, "patchContent");
    __publicField(this, "sourceFile");
    __publicField(this, "destinationFile");
    __publicField(this, "metadataPatcher");
    this.patchFilePath = patchFilePath;
    this.backup_suffix = backup_suffix;
    this.targetPatchRoot = targetPatchRoot;
    this.patchContent = fs.readFileSync(patchFilePath, "utf8");
    const sourceFileMatch = /--- ([^ \n\r\t]+).*/.exec(this.patchContent);
    let sourceFile;
    if (sourceFileMatch && sourceFileMatch[1]) {
      sourceFile = sourceFileMatch[1];
    } else {
      throw Error(`Unable to find source file in '${this.patchFilePath}'`);
    }
    this.sourceFile = `${this.targetPatchRoot}/${sourceFile}`.replace("//", "/");
    const destinationFileMatch = /\+\+\+ ([^ \n\r\t]+).*/.exec(this.patchContent);
    let destinationFile;
    if (destinationFileMatch && destinationFileMatch[1]) {
      destinationFile = destinationFileMatch[1];
    } else {
      throw Error(`Unable to find destination file in '${patchFilePath}'`);
    }
    this.destinationFile = `${this.targetPatchRoot}/${destinationFile}`.replace("//", "/");
    this.metadataPatcher = new import_metadataPatcher.MetadataPatcher(this.destinationFile);
  }
  backup(pathAndFile = this.sourceFile) {
    fs.copyFileSync(pathAndFile, pathAndFile + this.backup_suffix);
    return this;
  }
  restore(pathAndFile = this.sourceFile) {
    if (!this.hasBackup(pathAndFile)) {
      throw new Error(`Cannot restore ${pathAndFile} as no backup was found`);
    }
    const backupFile = pathAndFile + this.backup_suffix;
    fs.copyFileSync(backupFile, pathAndFile);
    fs.unlinkSync(backupFile);
    this.metadataPatcher.removePatchingVersionFile();
    (0, import_helpers.log)(`Restored ${pathAndFile}`);
    return this;
  }
  hasBackup(pathAndFile = this.sourceFile) {
    return fs.existsSync(pathAndFile + this.backup_suffix);
  }
  unpatch(pathAndFile = this.sourceFile) {
    const { patchedRorVersion, isCurrentlyInstalledRorVersionPatched, displayFileMetadata } = this.metadataPatcher;
    if (patchedRorVersion) {
      displayFileMetadata();
      if (!isCurrentlyInstalledRorVersionPatched) {
        throw new Error(import_messages.messages.mismatchRorVersionInfo(patchedRorVersion, (0, import_helpers.getRunningRorVersion)()));
      }
    } else {
      throw new Error(import_messages.messages.unableToRetrieveRorVersion);
    }
    return this.restore(pathAndFile);
  }
  isPatched(logger) {
    const {
      patchedRorVersion,
      isCurrentlyInstalledRorVersionPatched,
      patchedFileChecksumFromMetadata,
      displayFileMetadata
    } = this.metadataPatcher;
    logger("Verifying patched state...", __filename);
    if (patchedRorVersion) {
      displayFileMetadata(logger);
    } else {
      throw new Error(import_messages.messages.unableToRetrieveRorVersion);
    }
    if (!this.hasBackup()) {
      throw new Error(import_messages.messages.missingBackup(this.sourceFile));
    }
    if (patchedRorVersion && !isCurrentlyInstalledRorVersionPatched) {
      throw new Error(import_messages.messages.mismatchRorVersionInfo(patchedRorVersion, (0, import_helpers.getRunningRorVersion)()));
    }
    const backupFileChecksum = (0, import_helpers.createFileChecksum)(
      fs.readFileSync(this.sourceFile + this.backup_suffix, "utf8").toString("utf-8")
    );
    const patchedFileChecksum = (0, import_helpers.createFileChecksum)(fs.readFileSync(this.sourceFile, "utf8").toString("utf-8"));
    if (backupFileChecksum === patchedFileChecksum) {
      logger(import_messages.messages.kibanaNotPatched(this.sourceFile), __filename);
      return false;
    }
    const wasSuccess = patchedFileChecksumFromMetadata == patchedFileChecksum;
    if (wasSuccess) {
      logger(import_messages.messages.patchVerified(this.sourceFile), __filename);
    } else {
      logger(import_messages.messages.patchOutdated(this.sourceFile), __filename, import_logLevel.LogLevel.ERROR);
    }
    return wasSuccess;
  }
  patch() {
    const { writeMetadataToFile, patchedRorVersion, isCurrentlyInstalledRorVersionPatched } = this.metadataPatcher;
    if (patchedRorVersion) {
      if (isCurrentlyInstalledRorVersionPatched) {
        throw new Error(import_messages.messages.kibanaAlreadyPatched);
      } else {
        throw new Error(import_messages.messages.mismatchRorVersionInfo(patchedRorVersion, (0, import_helpers.getRunningRorVersion)()));
      }
    }
    if (this.hasBackup()) {
      throw new Error(`A backup file was found: \u2018${this.sourceFile}${this.backup_suffix}\u2019. Is it already patched?`);
    }
    const originalFileContent = fs.readFileSync(this.sourceFile, "utf8").toString("utf-8");
    const patchedFileContent = diff.applyPatch(originalFileContent, this.patchContent, { fuzzFactor: 2 });
    if (patchedFileContent === false) {
      throw Error(import_messages.messages.failedToApplyPatch(this.patchFilePath, this.sourceFile));
    } else if (this.sourceFile !== this.destinationFile) {
      (0, import_helpers.log)(
        `Applied '${basename(this.patchFilePath)}' to '${this.sourceFile}' and stored it as '${this.destinationFile}'`
      );
    } else {
      (0, import_helpers.log)(`Applied '${basename(this.patchFilePath)}' to '${this.sourceFile}'`);
    }
    this.backup();
    fs.writeFileSync(this.destinationFile, patchedFileContent);
    writeMetadataToFile(patchedFileContent);
    return this;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  FilePatcher
});
