"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var handlePatchingConfirmation_exports = {};
__export(handlePatchingConfirmation_exports, {
  handlePatchingConfirmation: () => handlePatchingConfirmation,
  rl: () => rl
});
module.exports = __toCommonJS(handlePatchingConfirmation_exports);
var import_helpers = require("./helpers");
var import_readline = __toESM(require("readline"));
let rl;
function getArgValue(argName) {
  const arg = process.argv.find((arg2) => arg2.startsWith(`--${argName}=`));
  return arg ? arg.split("=")[1] : null;
}
function patchingConfirmation() {
  (0, import_helpers.log)(
    "NOTICE: This script patches Kibana to work with the ReadonlyREST plugin. The patch modifies Kibana source files\nas required by the ReadonlyREST plugin. By proceeding, you confirm understanding and acceptance of responsibility for\nmodifying Kibana in compliance with Elastic's licensing. Please read: https://docs.readonlyrest.com/kibana#patching-kibana"
  );
  return new Promise((resolve) => {
    const acceptedFromArgParameter = getArgValue("I_UNDERSTAND_AND_ACCEPT_KBN_PATCHING");
    const acceptedFromEnvVariable = process.env.I_UNDERSTAND_AND_ACCEPT_KBN_PATCHING;
    if (acceptedFromArgParameter === "yes" || acceptedFromEnvVariable === "yes") {
      (0, import_helpers.log)(
        `The script received the I_UNDERSTAND_AND_ACCEPT_KBN_PATCHING value as ${acceptedFromArgParameter ? "argument" : "environment variable"}.`
      );
      resolve("yes");
    } else {
      rl = import_readline.default.createInterface({
        input: process.stdin,
        output: process.stdout
      });
      rl.question('Type "yes" to continue: ', (choice) => {
        resolve(choice.trim());
        rl.close();
      });
    }
  });
}
async function handlePatchingConfirmation() {
  const choice = await patchingConfirmation();
  switch (choice.trim()) {
    case "yes":
      (0, import_helpers.log)("Patching process is continuing...");
      return true;
    default:
      (0, import_helpers.log)("Invalid choice. Please try again.\n");
      return await handlePatchingConfirmation();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handlePatchingConfirmation,
  rl
});
