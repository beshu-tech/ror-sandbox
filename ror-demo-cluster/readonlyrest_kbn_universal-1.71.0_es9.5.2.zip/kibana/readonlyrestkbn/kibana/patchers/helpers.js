"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var helpers_exports = {};
__export(helpers_exports, {
  createFileChecksum: () => createFileChecksum,
  formatDate: () => formatDate,
  getKbnVersion: () => getKbnVersion,
  getPatchDir: () => getPatchDir,
  getRunningRorVersion: () => getRunningRorVersion,
  log: () => log,
  targetPathRoot: () => targetPathRoot
});
module.exports = __toCommonJS(helpers_exports);
var import_crypto = require("crypto");
var import_fs = __toESM(require("fs"));
const rorPackage = JSON.parse(import_fs.default.readFileSync(`${__dirname}/../../package.json`, "utf8"));
const getKibanaPackage = () => JSON.parse(import_fs.default.readFileSync(`${__dirname}/../../../../package.json`, "utf8"));
const getRunningRorVersion = () => rorPackage.version;
const getKbnVersion = () => getKibanaPackage().version;
const targetPathRoot = () => `${__dirname}/../../../../`.replace("//", "/");
function getPatchDir() {
  return `${__dirname}/patches_for_kbn_distribution/`;
}
function log(msg, obj = null) {
  msg = `[ROR COMPAT] ${msg}`;
  if (obj) {
    console.log(msg, obj);
  } else {
    console.log(msg);
  }
}
function createFileChecksum(content) {
  if (typeof content === "string") {
    return (0, import_crypto.createHash)("sha256").update(Buffer.from(content, "utf8")).digest("hex");
  }
  return (0, import_crypto.createHash)("sha256").update(Buffer.from(content)).digest("hex");
}
function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");
  return `${year}:${month}:${day} ${hours}:${minutes}:${seconds}`;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createFileChecksum,
  formatDate,
  getKbnVersion,
  getPatchDir,
  getRunningRorVersion,
  log,
  targetPathRoot
});
