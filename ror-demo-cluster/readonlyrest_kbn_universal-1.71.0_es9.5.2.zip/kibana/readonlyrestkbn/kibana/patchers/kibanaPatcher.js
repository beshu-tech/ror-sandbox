"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibanaPatcher_exports = {};
__export(kibanaPatcher_exports, {
  isPatchedAll: () => isPatchedAll,
  main: () => main
});
module.exports = __toCommonJS(kibanaPatcher_exports);
var import_filePatcher = require("./filePatcher");
var import_helpers = require("./helpers");
var import_messages = require("./messages");
var import_handlePatchingConfirmation = require("./handlePatchingConfirmation");
var import_logLevel = require("../../proxy/core/logging/logLevel");
const fs = require("fs");
function main(command = process.argv.length >= 3 ? process.argv[2] : "help") {
  try {
    (0, import_helpers.log)(`Received command: ${command}`);
    switch (command) {
      case "unpatch":
        if (unpatchAll()) {
          process.exitCode = 0;
        } else {
          process.exitCode = -1;
        }
        break;
      case "verify":
        if (isPatchedAll()) {
          process.exitCode = 0;
        } else {
          process.exitCode = -1;
        }
        break;
      case "fix":
        if (fixAll()) {
          process.exitCode = 0;
        } else {
          process.exitCode = -1;
        }
        break;
      case "patch":
        (0, import_handlePatchingConfirmation.handlePatchingConfirmation)().then((isAccepted) => {
          if (isAccepted) {
            if (patchAll()) {
              process.exitCode = 0;
            } else {
              process.exitCode = -1;
            }
          }
        });
        break;
      default:
        help();
    }
  } catch (e) {
    (0, import_helpers.log)(
      "ReadonlyREST encountered problems with compatibility manager script, please run manually using 'ror-tools.js'  ",
      e
    );
    process.exitCode = -1;
  }
}
function patchAll() {
  try {
    if (!distroRequiresPatch()) {
      return true;
    }
    (0, import_helpers.log)("Modify a few Kibana files for ReadonlyREST...");
    return doWithPatcher((patcher) => {
      if (patcher.hasBackup()) {
        (0, import_helpers.log)(
          "Backup file found, assuming already patched. Will first unpatch and then re-patch with potentially newer code."
        );
        patcher.unpatch();
      }
      patcher.patch();
      return true;
    });
  } catch (e) {
    (0, import_helpers.log)(`ReadonlyREST encountered problems during patching: ${e.message}`);
    return false;
  }
}
function isPatchedAll(logger = (message) => (0, import_helpers.log)(message)) {
  try {
    logger("Verifying the presence of ROR hooks on Kibana files..", __filename);
    return doWithPatcher((patcher) => {
      if (!patcher.isPatched(logger)) {
        logger("This file was not patched", __filename);
        return false;
      }
      return true;
    }, logger);
  } catch (e) {
    logger(`ReadonlyREST encountered problems during patching verification: ${e.message}`, __filename, import_logLevel.LogLevel.ERROR);
    return false;
  }
}
function unpatchAll() {
  try {
    if (!distroRequiresPatch()) {
      return true;
    }
    return doWithPatcher((patcher) => {
      if (patcher.hasBackup()) {
        (0, import_helpers.log)("Backup file found!");
        patcher.unpatch();
      } else {
        (0, import_helpers.log)(import_messages.messages.backupFileNotApplied);
        return false;
      }
      return true;
    });
  } catch (e) {
    (0, import_helpers.log)(`ReadonlyREST encountered problems during unpatching: ${e.message}`);
    return false;
  }
}
function doWithPatcher(action, logger = (message) => (0, import_helpers.log)(message)) {
  const patchDir = (0, import_helpers.getPatchDir)();
  const matcher = /.*\.patch/gi;
  const patchFiles = fs.readdirSync(patchDir).filter((f) => f.match(matcher));
  for (let f of patchFiles) {
    f = patchDir + f;
    logger(`Found patch file ${f}`, __filename);
    const backupFileSuffix = `.${(0, import_helpers.getKbnVersion)()}_${(0, import_helpers.getRunningRorVersion)()}.orig`;
    const patcher = new import_filePatcher.FilePatcher(f, (0, import_helpers.targetPathRoot)(), backupFileSuffix);
    if (!action(patcher)) {
      return false;
    }
  }
  return true;
}
function distroRequiresPatch() {
  return true;
}
function fixAll() {
  try {
    (0, import_helpers.log)("Will verify and, where necessary, attempt to automatically fix patched Kibana files...");
    if (!distroRequiresPatch()) {
      return true;
    }
    let verifiedOK = false;
    try {
      verifiedOK = isPatchedAll();
    } catch (e) {
      (0, import_helpers.log)("Compatibility verification failed: ", e);
      verifiedOK = false;
    }
    if (!verifiedOK) {
      (0, import_helpers.log)("Attempting to re-patch...");
      try {
        verifiedOK = patchAll();
      } catch (e) {
        (0, import_helpers.log)(
          "Could not fix compatibility automatically. Maybe a permissions issue? See stack trace. To fix this, use './ror-tools.js unpatch' and './ror-tools.js patch' manually",
          e
        );
        verifiedOK = false;
      }
    }
    if (verifiedOK) {
      (0, import_helpers.log)("compatibility did no need fixing. All is patched OK.");
    } else {
      (0, import_helpers.log)("compatibility could not be fixed: FAILED.");
    }
    return verifiedOK;
  } catch (e) {
    (0, import_helpers.log)("ReadonlyREST encountered problems during fixing patch:", e);
    return false;
  }
}
function help() {
  (0, import_helpers.log)(
    `ReadonlyREST Kibana plugin compatibility tool

Usage: node/bin/node ${process.argv[0]} ${process.argv[1]} <command> [--I_UNDERSTAND_AND_ACCEPT_KBN_PATCHING=yes]

Commands:
  patch   - Install required ReadonlyREST code modifications in Kibana core file
  unpatch - Restore original Kibana core files (remove ROR modifications
  verify  - Check if required Kibana core files are properly modified
  fix     - Attempt to automatically fix modified Kibana files
  help    - Display this help message

Options:
  --I_UNDERSTAND_AND_ACCEPT_KBN_PATCHING=yes - Skip patching confirmation prompt (for CI/CD environments)

Environment variables:
  I_UNDERSTAND_AND_ACCEPT_KBN_PATCHING=yes - Alternative way to skip confirmation prompt

Example:
  node/bin/node ${process.argv[1]} patch --I_UNDERSTAND_AND_ACCEPT_KBN_PATCHING=yes`
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  isPatchedAll,
  main
});
