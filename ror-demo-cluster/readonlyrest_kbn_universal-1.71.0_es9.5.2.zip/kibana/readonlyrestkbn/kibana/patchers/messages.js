"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var messages_exports = {};
__export(messages_exports, {
  messages: () => messages
});
module.exports = __toCommonJS(messages_exports);
var import_helpers = require("./helpers");
var import_path = require("path");
const docsUpgradePluginUrl = "https://docs.readonlyrest.com/kibana#upgrading";
const messages = {
  unableToRetrieveRorVersion: `Unable to retrieve the ReadonlyREST plugin version for which the file was patched. Please ensure all steps in the upgrade guide have been followed: ${docsUpgradePluginUrl}.`,
  metadataInfo: (destinationFilePath, rorVersion, kibanaVersion, patchingDate) => `${destinationFilePath} was patched with the ReadonlyREST plugin version ${rorVersion} and Kibana version ${kibanaVersion} on ${(0, import_helpers.formatDate)(
    new Date(patchingDate)
  )}.`,
  mismatchRorVersionInfo: (patchedRorVersion, runningRorVersion) => `Kibana has been patched with ROR Patcher for the ReadonlyREST ${patchedRorVersion}, and you're currently running version ${runningRorVersion}. Please make sure you\u2019ve followed all the steps in the upgrade guide to ensure a successful update: ${docsUpgradePluginUrl}.`,
  kibanaAlreadyPatched: "Kibana has already been patched.",
  missingBackup: (sourceFile) => `NO_BACKUP: Unable to verify the patched status of ${sourceFile} as the backup file is missing. Please try patching Kibana again.`,
  kibanaNotPatched: (sourceFile) => `${(0, import_path.basename)(
    sourceFile
  )} patch status: NOT_PATCHED. The backup file is identical to the patched file. Please try patching Kibana again.`,
  patchOutdated: (sourceFile) => `${(0, import_path.basename)(sourceFile)} patch status: OUTDATED. It needs to be unpatched and patched again.`,
  patchVerified: (sourceFile) => `${(0, import_path.basename)(sourceFile)} patch status: VERIFIED.`,
  failedToApplyPatch: (patchFilePath, sourceFile) => `Failed to apply patch ${(0, import_path.basename)(
    patchFilePath
  )} to ${sourceFile}. Please ensure all steps in the upgrade guide have been followed: ${docsUpgradePluginUrl}. If the problem persists, try to reinstall Kibana and apply the patch again`,
  backupFileNotApplied: "Backup file not found: assuming patch was not applied. Please try patching Kibana again."
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  messages
});
