"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var metadataPatcher_exports = {};
__export(metadataPatcher_exports, {
  MetadataPatcher: () => MetadataPatcher
});
module.exports = __toCommonJS(metadataPatcher_exports);
var import_fs = __toESM(require("fs"));
var import_helpers = require("./helpers");
var import_messages = require("./messages");
class MetadataPatcher {
  constructor(destinationFilePath) {
    this.destinationFilePath = destinationFilePath;
    __publicField(this, "metadataFilePath");
    __publicField(this, "writeMetadataToFile", (patchedFileContent) => {
      try {
        const date = (/* @__PURE__ */ new Date()).toISOString();
        const fileChecksum = (0, import_helpers.createFileChecksum)(patchedFileContent);
        const metadata = {
          date,
          rorVersion: (0, import_helpers.getRunningRorVersion)(),
          kbnVersion: (0, import_helpers.getKbnVersion)(),
          fileChecksum
        };
        import_fs.default.writeFileSync(this.metadataFilePath, JSON.stringify(metadata), { encoding: "utf8", flag: "w" });
        (0, import_helpers.log)(`${this.metadataFilePath} metadata added`);
      } catch (e) {
        (0, import_helpers.log)(`Error while adding metadata to the ${this.metadataFilePath} file.`, e.message);
        throw e;
      }
    });
    __publicField(this, "displayFileMetadata", (logger = (message) => (0, import_helpers.log)(message)) => {
      logger(
        import_messages.messages.metadataInfo(this.destinationFilePath, this.patchedRorVersion, this.kibanaVersion, this.patchingDate),
        __filename
      );
    });
    __publicField(this, "removePatchingVersionFile", () => {
      try {
        import_fs.default.unlinkSync(this.metadataFilePath);
        (0, import_helpers.log)(`${this.metadataFilePath} file removed`);
      } catch (err) {
        const fileFound = err.code !== "ENOENT";
        if (fileFound) {
          (0, import_helpers.log)(`Error while removing the ${this.metadataFilePath} file.`, err.message);
          throw err;
        }
      }
    });
    this.metadataFilePath = `${this.destinationFilePath}.metadata.json`;
  }
  readMetadataFromFile() {
    let fileContents = void 0;
    try {
      fileContents = import_fs.default.readFileSync(this.metadataFilePath, "utf8");
    } catch (err) {
      const fileFound = err.code !== "ENOENT";
      if (fileFound) {
        (0, import_helpers.log)(`Error while reading the ${this.metadataFilePath} file.`, err.message);
        throw err;
      }
    }
    return fileContents ? JSON.parse(fileContents) : void 0;
  }
  get isCurrentlyInstalledRorVersionPatched() {
    const metadata = this.readMetadataFromFile();
    return (metadata == null ? void 0 : metadata.rorVersion) === (0, import_helpers.getRunningRorVersion)();
  }
  get patchedRorVersion() {
    const metadata = this.readMetadataFromFile();
    return metadata == null ? void 0 : metadata.rorVersion;
  }
  get kibanaVersion() {
    const metadata = this.readMetadataFromFile();
    return metadata == null ? void 0 : metadata.kbnVersion;
  }
  get patchingDate() {
    const metadata = this.readMetadataFromFile();
    return metadata == null ? void 0 : metadata.date;
  }
  get patchedFileChecksumFromMetadata() {
    const metadata = this.readMetadataFromFile();
    return metadata == null ? void 0 : metadata.fileChecksum;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  MetadataPatcher
});
