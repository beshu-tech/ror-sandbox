"use strict";
module.exports = /* @__PURE__ */ (() => {
  let pkpPort;
  let pkpUrl;
  return {
    setOncePkpUrl: (newPkpUrl) => {
      if (pkpUrl == null) {
        pkpUrl = newPkpUrl;
      }
    },
    setOncePkpPort: (newPkpPort) => {
      if (pkpPort == null) {
        pkpPort = newPkpPort;
      }
    },
    getPkpPort: () => pkpPort != null ? pkpPort : void 0,
    getPkpUrl: () => pkpUrl != null ? pkpUrl : void 0,
    clearAll: () => {
      pkpPort = void 0;
      pkpUrl = void 0;
    }
  };
})();
