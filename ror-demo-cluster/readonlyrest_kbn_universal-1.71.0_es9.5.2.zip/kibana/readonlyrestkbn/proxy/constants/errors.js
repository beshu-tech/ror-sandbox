"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var errors_exports = {};
__export(errors_exports, {
  default: () => errors_default
});
module.exports = __toCommonJS(errors_exports);
var errors_default = {
  wrongTypeOfIndicesSource: "Wrong type of indices source",
  notSufficientLicenseToUseFeature: (feature, licenseType = "Enterprise") => `You need a ReadonlyREST ${licenseType} license to use the ${feature}`,
  cannotSaveClusterWideSettingsOnFreeLicense: "Cannot save cluster-wide settings on Free license",
  updateSettingsViaApiEnterpriseOnly: "You need a ReadonlyREST Enterprise license to save cluster-wide settings via ReadonlyREST API",
  unsupportedMediaType: "We are unable to process your request because the provided media type is not supported. Please ensure you are using a compatible content type.",
  internalServerError: "Internal server error",
  fileExtensionOnlyYmlSupported: "The file extension is not supported. Please upload a file with the correct yml or yaml extension.",
  fileIsRequiredField: "The file is a required field.",
  fileSizeExceeds: (maxSize) => `The file size exceeds the maximum ${maxSize} allowed limit. Please upload a smaller file.`,
  cannotReloadNewSettings: "Cannot reload new settings",
  forbidByBlockWithForbidTypeMatch: 'Request was FORBIDDEN by matching a block with "forbid" type',
  testSettingsAreNotConfigured: "Request was FORBIDDEN because test settings are not configured",
  impersonationNotAllowed: "Request was FORBIDDEN because impersonation is not allowed",
  impersonationNotSupported: "Request was FORBIDDEN because impersonation is not supported",
  noAclBlockWasMatched: "No ACL block was matched",
  readonlyRestWasNotStarted: "ReadonlyREST was not started yet",
  readonlyRestFailedToStart: "ReadonlyREST failed to start",
  operationNotAllowed: `Operation not allowed`,
  activationKey: {
    cantBeVerified: "This activation key can't be verified",
    licenseKeyExpired: "The License key token provided has expired.",
    invalidJwt: "Invalid JWT. The header or payload could not be parsed.",
    licenseKeyMalformed: "License key malformed. The token does not have three components (delimited by a .).",
    invalidJtwSignature: "The provided JWT token has an incorrect or tampered signature, indicating a potential unauthorized modification of the token contents.",
    noLicenseKeyProvided: "There is no activation key provided.",
    unmodified: "License token already exists is not modified. If you want to overwrite your license key use overwrite=true query string parameter."
  },
  inSufficientPermissions: "You don't have sufficient permissions to perform this operation.",
  defaultForbiddenMessage: "Forbidden by ReadonlyREST",
  cannotAuthenticate: "Cannot authenticate. Please try again later.",
  insufficientPermissions: (configPath) => `Insufficient permissions to write to Kibana config file. Please run the following commands to fix permissions: chown kibana:kibana ${configPath} && chmod 664 ${configPath}`,
  configFileNotFound: (configPath) => `Config file not found at ${configPath}`,
  configFileUnchanged: (configPath) => `Config file located at ${configPath} unchanged. No update needed.`,
  yamlValidationError: (yamlData) => `The provided Yaml data: ${JSON.stringify(yamlData)} cannot be processed. Verify the format of the Yaml data`,
  rorSettingsManager: {
    alreadyInitialized: "RorSettingsManager is already initialized",
    notInitialized: "RorSettingsManager is not initialized. Call initialize() first.",
    errorDuringSettingsAutoRefresh: "Error during configuration auto-refresh:",
    settingsFileNotFound: (settingsPath) => `Settings file not found at ${settingsPath}`,
    failedToReadSettings: (settingsPath) => `Failed to read settings from ${settingsPath}`,
    settingsNotSet: (from) => from ? `ReadonlyREST settings are not set in a ${from} source` : "ReadonlyREST settings are not set",
    settingsAreMalformed: (from) => `ReadonlyREST settings from ${from} are malformed`,
    settingsRefreshFailed: "Failed to refresh ReadonlyREST settings",
    defaultSettingsNotAvailable: (readonlyrestYmlFilenamePath) => `ReadonlyREST settings from ${readonlyrestYmlFilenamePath} are not available`,
    emptyRorIndex: "ReadonlyREST settings index exists but is empty",
    errorFetchingFromRorIndex: "Error fetching settings from ReadonlyREST settings index",
    failedToFetchingFromRorIndex: "Failed to fetch settings from ReadonlyREST settings index",
    rorKbnSectionNotFoundInIndex: "readonlyrest_kbn section not found in ReadonlyREST settings index.",
    noValidSourceAvailable: "No valid ROR settings source available",
    deprecatedSettingsWarnings: {
      kibanaYmlDeprecated: "You are using the deprecated ReadonlyREST configuration in kibana.yml. Migrate to the new format in readonlyrest.yml. The support for ReadonlyREST configuration in a kibana.yml will be removed in the future.",
      kibanaYmlAndIndexConflict: "You have ReadonlyREST settings in both kibana.yml and .readonlyrest index. The settings from .readonlyrest index will be used.",
      kibanaYmlAndFileConflict: "You have ReadonlyREST settings in both kibana.yml and readonlyrest.yml. The settings from readonlyrest.yml will be used.",
      readonlyrest_kbnSettingsNotAvailableInAPostRequest: (pathname) => `You are using deprecated ReadonlyREST settings in the ${pathname} request without readonlyrest_kbn section defined.`
    },
    policyValidationFailed: (policyValidationError) => `Validation failed for settings, keeping previous settings: ${policyValidationError}`
  },
  notAuthorizedToPerformOperation: "You are not authorized to perform this operation",
  userRequestIdentityNotAvailable: "User request identity is not available",
  groupNotDefinedInUrl: "group is not defined in URL",
  tenancy: {
    notFoundInUrl: "Tenancy not found in the current URL.",
    switchError: "Switch tenancy error",
    selectedTenancyNotAvailableForTheUser: (tenancyName) => `Selected tenancy ${tenancyName} not available for the user`
  },
  session: {
    invalidJSON: "Saved session is not a valid JSON",
    notFound: "Session not found in index",
    fetchSessionFailed: "Failed to fetch session from index",
    fetchSessionsFailed: "Failed to fetch sessions from index"
  }
};
