"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RorMetadata_exports = {};
__export(RorMetadata_exports, {
  RorMetadata: () => RorMetadata
});
module.exports = __toCommonJS(RorMetadata_exports);
var import_types = require("./common/types");
class RorMetadata {
  constructor(metadataString) {
    __publicField(this, "metadata");
    try {
      const decodedString = Buffer.from(metadataString, "base64").toString("ascii");
      this.metadata = JSON.parse(decodedString);
    } catch (error) {
      throw new Error(`Failed to parse metadataString: ${error.message}`);
    }
  }
  static fromHeaders(headers) {
    const authHeader = headers == null ? void 0 : headers[import_types.AUTHORIZATION_HEADER];
    if (authHeader && authHeader.includes("ror_metadata=")) {
      const metadataString = authHeader.split("ror_metadata=")[1];
      return metadataString ? new RorMetadata(metadataString) : null;
    }
    return null;
  }
  static removeRorMetadata(authHeader) {
    if (!authHeader || !authHeader.includes("ror_metadata=")) {
      return authHeader;
    }
    return authHeader.replace(/,?\s*ror_metadata=[^\s,]+,?\s*/g, ", ").replace(/,\s*,/g, ",").trim().replace(/,\s*$/, "");
  }
  getKibanaRequestPath() {
    return this.getHeaderValue(import_types.X_ROR_KIBANA_REQ_PATH);
  }
  getKibanaIndex() {
    return this.getHeaderValue(import_types.X_ROR_KIBANA_INDEX);
  }
  getTenancyId() {
    return this.getHeaderValue(import_types.X_ROR_CURRENT_GROUP);
  }
  getHeaderValue(headerName) {
    var _a, _b, _c;
    const headerEntry = (_c = (_b = (_a = this.metadata) == null ? void 0 : _a.headers) == null ? void 0 : _b.find((value) => value.includes(headerName))) != null ? _c : "";
    const parts = headerEntry.split(`${headerName}:`);
    return parts.length > 1 ? parts[1] : void 0;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorMetadata
});
