"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var correlationIdWrapper_exports = {};
__export(correlationIdWrapper_exports, {
  CorrelationIdWrapper: () => CorrelationIdWrapper
});
module.exports = __toCommonJS(correlationIdWrapper_exports);
var import_types = require("../common/types");
class CorrelationIdWrapper {
  constructor(client) {
    this.client = client;
    __publicField(this, "createCorrelationHeader", (correlationId) => ({
      [import_types.X_ROR_CORRELATION_ID]: correlationId
    }));
  }
  withCorrelationIdHeader(correlationId) {
    if (!correlationId) {
      return this.client;
    }
    return this.wrapWithCorrelationHeader(this.createCorrelationHeader(correlationId));
  }
  wrapWithCorrelationHeader(correlationIdHeader) {
    return new Proxy(this.client, {
      get(target, prop) {
        const value = target[prop];
        if (typeof value === "function") {
          return (params = {}) => value.call(target, { ...params, correlationIdHeader });
        }
        return value;
      }
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CorrelationIdWrapper
});
