"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var esApiAdvancedClient_exports = {};
__export(esApiAdvancedClient_exports, {
  EsApiAdvancedClient: () => EsApiAdvancedClient
});
module.exports = __toCommonJS(esApiAdvancedClient_exports);
var import_lazyUtils = require("../lazyUtils");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_requestUtils = require("./requestUtils");
var import_restEsApiClient = require("./restEsApiClient");
var import_utils = require("./utils");
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
class EsApiAdvancedClient extends import_restEsApiClient.RestEsApiClient {
  constructor(elasticsearchUrl, esSSLConnectionProvider, diskThresholdVerificationSettings) {
    super(elasticsearchUrl, esSSLConnectionProvider, diskThresholdVerificationSettings);
    __publicField(this, "esStatusRetryInterval", 5e3);
    __publicField(this, "esStatusMaxRetries", 24);
    __publicField(this, "checkESStatus", async (authHeader, correlationIdHeader) => {
      try {
        const response = await this.getClusterHealth({ authHeader, correlationIdHeader });
        if (!response.ok) {
          throw new Error(`Elasticsearch not available. Status: ${response.status}`);
        }
        const data = await response.json();
        logger.info(`Elasticsearch is available with status: ${data.status}`);
        return { ok: true, data: void 0 };
      } catch (error) {
        if (typeof error === "object" && error !== null && "code" in error && error.code === "ECONNREFUSED") {
          logger.error({ message: `Elasticsearch hasn't been initialized yet` });
        } else if (error instanceof Error) {
          logger.error({ message: `Error: ${error.message}` });
        } else {
          logger.error({ message: `Error: ${String(error)}` });
        }
        return { ok: false, error: error instanceof Error ? error.message : String(error) };
      }
    });
    __publicField(this, "startAsyncReindex", ({
      sourceIndex,
      destIndex,
      authHeader,
      correlationIdHeader
    }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl("_reindex?wait_for_completion=false", this.elasticsearchUrl), {
      method: "POST",
      headers: { ...authHeader, ...correlationIdHeader, ...import_utils.jsonContentTypeHeader },
      body: JSON.stringify({ source: { index: sourceIndex }, dest: { index: destIndex } })
    }));
    __publicField(this, "getTask", ({ taskId, authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`_tasks/${taskId}`, this.elasticsearchUrl), {
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "cancelTask", ({ taskId, authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`_tasks/${taskId}/_cancel`, this.elasticsearchUrl), {
      method: "POST",
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "waitForES", async ({
      maxRetries = this.esStatusMaxRetries,
      authHeader,
      correlationIdHeader
    }) => {
      const result = await (0, import_lazyUtils.retryUntilOk)(
        () => this.checkESStatus(authHeader, correlationIdHeader),
        { maxRetries, retryInterval: this.esStatusRetryInterval },
        (_error, retriesLeft) => logger.info(`Retrying in ${this.esStatusRetryInterval / 1e3} seconds... ${retriesLeft} attempts left`)
      );
      if (!result.ok) {
        const message = `Failed to connect to Elasticsearch after ${maxRetries + 1} attempts. Error: ${result.error}`;
        logger.error({ message });
        throw new Error(message);
      }
      return "success";
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  EsApiAdvancedClient
});
