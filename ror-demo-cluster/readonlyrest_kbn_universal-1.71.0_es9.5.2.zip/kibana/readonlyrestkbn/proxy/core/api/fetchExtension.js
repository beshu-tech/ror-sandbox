"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fetchExtension_exports = {};
__export(fetchExtension_exports, {
  fetch: () => fetch,
  fetchWithDiskThresholdVerification: () => fetchWithDiskThresholdVerification,
  fetchWithTimeout: () => fetchWithTimeout
});
module.exports = __toCommonJS(fetchExtension_exports);
var import_node_abort_controller = require("node-abort-controller");
var import_node_fetch = __toESM(require("node-fetch"));
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
const getLogger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
async function verifyDiskThreshold(url, onAllocationExplainCallback, clusterAllocationExplainUri) {
  const isAllocationExplainBasedUrl = typeof url === "string" && url.includes(clusterAllocationExplainUri);
  if (isAllocationExplainBasedUrl) {
    return;
  }
  const response = await onAllocationExplainCallback();
  const data = await response.json();
  function getDiskAllocationDecider(nodeAllocationDecisions) {
    var _a;
    for (const nodeDecision of (_a = nodeAllocationDecisions == null ? void 0 : nodeAllocationDecisions.can_remain_decisions) != null ? _a : []) {
      if (nodeDecision.decider !== "disk_threshold") {
        continue;
      }
      const lowWatermarkDecision = nodeDecision.explanation.includes("low watermark");
      const highWatermarkDecision = nodeDecision.explanation.includes("high watermark");
      if (lowWatermarkDecision) {
        return { status: "lowWatermarkDecision", explanation: nodeDecision.explanation };
      }
      if (highWatermarkDecision) {
        return { status: "highWatermarkDecision", explanation: nodeDecision.explanation };
      }
    }
    return void 0;
  }
  const decision = getDiskAllocationDecider(data);
  if (decision) {
    const message = `${decision.explanation}. Check documentation for more information https://www.elastic.co/guide/en/elasticsearch/reference/current/fix-watermark-errors.html`;
    if (decision.status === "lowWatermarkDecision") {
      getLogger().warn(message);
    } else {
      getLogger().error({ message });
    }
  }
  return Promise.resolve();
}
async function fetch(url, init) {
  return (0, import_node_fetch.default)(url, {
    ...init,
    headers: init == null ? void 0 : init.headers,
    agent: init == null ? void 0 : init.agent
  });
}
function withDiskThresholdVerification(baseFetch) {
  return async (url, init, { enabled, onAllocationExplainCallback, clusterAllocationExplainUri }) => {
    const data = await baseFetch(url, init);
    const statusesToDiskThresholdVerification = [404, 429, 503];
    if (statusesToDiskThresholdVerification.includes(data.status)) {
      if (enabled) {
        try {
          await verifyDiskThreshold(url, onAllocationExplainCallback, clusterAllocationExplainUri);
        } catch (error) {
          getLogger().error({ message: `Disk threshold verification failed for ${url}: ${error.message}` });
        }
      } else {
        getLogger().debug(
          `Received ${data.status} response, which may be related to disk watermark issues. Disk threshold verification skipped (disabled in ReadonlyREST Kibana plugin configuration).`
        );
      }
    }
    return data;
  };
}
function withTimeout(baseFetch) {
  return (url, init, { timeout }) => {
    const controller = new import_node_abort_controller.AbortController();
    const id = setTimeout(() => {
      getLogger().warn(`Probe request timeout after ${timeout} milliseconds`);
      controller.abort();
    }, timeout);
    const response = baseFetch(url, {
      ...init,
      // node-abort-controller's AbortSignal is runtime-compatible with the one @types/node-fetch declares
      signal: controller.signal
    });
    response.finally(() => clearTimeout(id)).catch(() => void 0);
    return response;
  };
}
const fetchWithDiskThresholdVerification = withDiskThresholdVerification(fetch);
const fetchWithTimeout = withTimeout(fetch);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  fetch,
  fetchWithDiskThresholdVerification,
  fetchWithTimeout
});
