"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var requestUtils_exports = {};
__export(requestUtils_exports, {
  RequestUtils: () => RequestUtils
});
module.exports = __toCommonJS(requestUtils_exports);
var import_errors = __toESM(require("../../constants/errors"));
var import_versionedLibraries = require("../common/versionedLibraries");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
const getLogger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
class RequestUtils {
  static verifyMediaType(req, res, next, acceptedMediaTypes) {
    if (req.is(acceptedMediaTypes)) {
      return next();
    }
    return res.status(415).send({
      status: "UNSUPPORTED_MEDIA_TYPE",
      message: import_errors.default.unsupportedMediaType
    });
  }
  static validateYamlRequest(req, res, next) {
    return (data) => {
      try {
        import_versionedLibraries.yaml.parse(data);
        next();
      } catch (e) {
        getLogger().error({ message: `Could not validate ${req.url} data: ${data}`, stack: e.stack });
        const statusCode = 400;
        return res.status(statusCode).send({
          status: "VALIDATION_ERROR",
          message: import_errors.default.yamlValidationError(data),
          error: "VALIDATION_ERROR",
          statusCode
        });
      }
    };
  }
  static normalizeUrl(url, base) {
    return new URL(url, base);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RequestUtils
});
