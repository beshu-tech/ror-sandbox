"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var responseHandler_exports = {};
__export(responseHandler_exports, {
  ResponseHandler: () => ResponseHandler
});
module.exports = __toCommonJS(responseHandler_exports);
var import_errors = __toESM(require("../../constants/errors"));
class ResponseHandler {
  static success(res, { message, status, statusCode, ...data }) {
    return res.status(statusCode).json({ message, status, statusCode, ...data });
  }
  static forbidden(res, message) {
    return ResponseHandler.clientError(res, {
      error: "Failure",
      message,
      status: "FORBIDDEN",
      statusCode: 403
    });
  }
  static notSufficientAccessLevel(res) {
    return ResponseHandler.clientError(res, {
      error: "Failure",
      statusCode: 401,
      status: "UNAUTHORIZED",
      message: import_errors.default.notAuthorizedToPerformOperation
    });
  }
  static clientError(res, { message, status, statusCode, error = "Failure", ...data }) {
    return res.status(statusCode).json({
      error,
      message,
      status,
      statusCode,
      ...data
    });
  }
  static serverError(res, { message, status = "ERROR", statusCode, error = "Failure" }) {
    return res.status(statusCode).json({ error, message, status, statusCode });
  }
  static unhandledServerError(res) {
    return ResponseHandler.serverError(res, {
      error: "Failure",
      status: "ERROR",
      message: import_errors.default.internalServerError,
      statusCode: 500
    });
  }
  static mapEsResponse(res, esResponse) {
    res.statusCode = esResponse.status;
    res.statusMessage = esResponse.statusMessage;
    return res.send(esResponse.body);
  }
  static combineForbiddenErrors(messages, causeToMessageMap) {
    const matchedMessages = Object.entries(causeToMessageMap).filter(([cause]) => messages == null ? void 0 : messages.includes(cause)).map(([, msg]) => msg);
    if (matchedMessages.length > 0) {
      return matchedMessages.join("; ");
    }
  }
  static async toEsResponse(response) {
    const bodyString = await response.text();
    const body = bodyString ? JSON.parse(bodyString) : bodyString;
    return {
      status: response.status,
      statusMessage: response.statusText,
      body
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ResponseHandler
});
