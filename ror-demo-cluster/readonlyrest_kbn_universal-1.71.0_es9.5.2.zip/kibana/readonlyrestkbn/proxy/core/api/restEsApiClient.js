"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var restEsApiClient_exports = {};
__export(restEsApiClient_exports, {
  RestEsApiClient: () => RestEsApiClient
});
module.exports = __toCommonJS(restEsApiClient_exports);
var import_lodash = __toESM(require("lodash"));
var import_types = require("../common/types");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_fetchExtension = require("./fetchExtension");
var import_requestUtils = require("./requestUtils");
var import_responseHandler = require("./responseHandler");
var import_utils = require("./utils");
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const _RestEsApiClient = class _RestEsApiClient {
  constructor(elasticsearchUrl, esSSLConnectionProvider, diskThresholdVerificationSettings) {
    this.elasticsearchUrl = elasticsearchUrl;
    this.diskThresholdVerificationSettings = diskThresholdVerificationSettings;
    __publicField(this, "clusterAllocationExplainUri", "_cluster/allocation/explain");
    __publicField(this, "clusterStatisticsUri", "_cluster/stats");
    __publicField(this, "clusterHealthUri", "_cluster/health");
    __publicField(this, "deleteDocumentsUri", "_delete_by_query");
    __publicField(this, "docUri", "_doc");
    __publicField(this, "mappingUri", "_mapping");
    __publicField(this, "aliasesUri", "_alias");
    __publicField(this, "searchUri", "_search");
    __publicField(this, "reindexUri", "_reindex");
    __publicField(this, "getDefaultSpaceUrl", (kibanaIndex) => `${kibanaIndex}/_doc/space:default`);
    __publicField(this, "esSSLConnectionProvider");
    __publicField(this, "postClusterAllocationExplain", ({
      requestBody,
      authHeader,
      correlationIdHeader
    }) => this.fetch(`${this.elasticsearchUrl}/${this.clusterAllocationExplainUri}`, {
      method: "POST",
      body: JSON.stringify(requestBody),
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "verifyUserAccess", async ({
      kibanaIndex,
      identitySessionHeaders,
      whitelistedHeaders,
      correlationIdHeader
    }) => {
      const response = await this.fetch(
        import_requestUtils.RequestUtils.normalizeUrl(this.getDefaultSpaceUrl(kibanaIndex), this.elasticsearchUrl),
        {
          method: "GET",
          headers: {
            ...Object.fromEntries(identitySessionHeaders),
            ...correlationIdHeader,
            ...Object.fromEntries(whitelistedHeaders)
          }
        }
      );
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "getClusterStatistics", async ({ authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.clusterStatisticsUri, this.elasticsearchUrl), {
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "getClusterHealth", async ({ authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.clusterHealthUri, this.elasticsearchUrl), {
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "getDocumentById", async ({
      indexName,
      docId,
      authHeader,
      correlationIdHeader
    }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/${this.docUri}/${docId}`, this.elasticsearchUrl), {
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "createOrUpdateDocumentInIndex", async ({
      requestBody,
      indexName,
      docId,
      authHeader,
      correlationIdHeader
    }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/${this.docUri}/${docId}?refresh=true`, this.elasticsearchUrl), {
      method: "POST",
      headers: { ...authHeader, ...correlationIdHeader, ...import_utils.jsonContentTypeHeader },
      body: JSON.stringify(requestBody)
    }));
    __publicField(this, "deleteDocument", async ({
      indexName,
      docId,
      authHeader,
      correlationIdHeader
    }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/${this.docUri}/${docId}?refresh=true`, this.elasticsearchUrl), {
      method: "DELETE",
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "deleteDocuments", async ({
      indexName,
      documentIds,
      authHeader,
      correlationIdHeader
    }) => {
      const responses = [];
      let chunkId = 0;
      for (const chunk of import_lodash.default.chunk(documentIds, _RestEsApiClient.BATCH_DELETE_CHUNK_SIZE)) {
        logger.debug(
          `Batch-${chunkId}: deleting ${chunk.length} ids: ${JSON.stringify(import_lodash.default.take(chunk, 3))}${chunk.length > 1 ? " etc." : ""}`
        );
        const response = await this.fetch(
          import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/${this.deleteDocumentsUri}`, this.elasticsearchUrl),
          {
            method: "POST",
            headers: { ...authHeader, ...correlationIdHeader, ...import_utils.jsonContentTypeHeader },
            body: JSON.stringify({ query: { ids: { values: chunk } } })
          }
        );
        if (response.status >= 300) {
          logger.warn(`Batch-${chunkId}: delete failed with response: ${JSON.stringify(await response.json())}`);
        }
        responses.push(response);
        chunkId += 1;
      }
      return responses;
    });
    __publicField(this, "deleteIndex", async ({ indexName, authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(indexName, this.elasticsearchUrl), {
      method: "DELETE",
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "createIndex", async ({
      indexName,
      requestBody,
      authHeader,
      correlationIdHeader
    }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(indexName, this.elasticsearchUrl), {
      method: "PUT",
      headers: { ...authHeader, ...correlationIdHeader, ...import_utils.jsonContentTypeHeader },
      body: JSON.stringify(requestBody)
    }));
    __publicField(this, "getMappingDefinitions", async ({
      indexName,
      authHeader,
      correlationIdHeader
    }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/${this.mappingUri}`, this.elasticsearchUrl), {
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "putMapping", async ({ indexName, requestBody, authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/${this.mappingUri}`, this.elasticsearchUrl), {
      method: "PUT",
      headers: { ...authHeader, ...correlationIdHeader, ...import_utils.jsonContentTypeHeader },
      body: JSON.stringify(requestBody)
    }));
    __publicField(this, "getAliases", async ({ indexName, authHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/${this.aliasesUri}`, this.elasticsearchUrl), {
      headers: authHeader
    }));
    __publicField(this, "runSearch", async ({ indexName, searchParams, authHeader, correlationIdHeader }) => (
      // By default, Elasticsearch 7.x limits the number of search results returned per query to 10 documents, which in most cases is not enough for receiving all documents
      this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/${this.searchUri}?size=10000`, this.elasticsearchUrl), {
        method: "POST",
        headers: { ...authHeader, ...correlationIdHeader, ...import_utils.jsonContentTypeHeader },
        body: searchParams ? JSON.stringify(searchParams) : void 0
      })
    ));
    __publicField(this, "reindexDocuments", async ({ requestBody, authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.reindexUri, this.elasticsearchUrl), {
      method: "POST",
      headers: { ...authHeader, ...correlationIdHeader, ...import_utils.jsonContentTypeHeader },
      body: JSON.stringify(requestBody)
    }));
    __publicField(this, "checkIndices", async ({ indexName, authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(indexName, this.elasticsearchUrl), {
      method: "HEAD",
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "checkDocument", async ({ indexName, docId, authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/${this.docUri}/${docId}`, this.elasticsearchUrl), {
      method: "HEAD",
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "countDocuments", async ({ indexName, authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/_count`, this.elasticsearchUrl), {
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "getIndexSettings", async ({ indexName, authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/_settings`, this.elasticsearchUrl), {
      headers: { ...authHeader, ...correlationIdHeader }
    }));
    __publicField(this, "setIndexWriteBlock", async ({
      indexName,
      authHeader,
      correlationIdHeader
    }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/_settings`, this.elasticsearchUrl), {
      method: "PUT",
      headers: { ...authHeader, ...correlationIdHeader, ...import_utils.jsonContentTypeHeader },
      body: JSON.stringify({ "index.blocks.write": true })
    }));
    __publicField(this, "clearIndexWriteBlock", async ({
      indexName,
      authHeader,
      correlationIdHeader
    }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl(`${indexName}/_settings`, this.elasticsearchUrl), {
      method: "PUT",
      headers: { ...authHeader, ...correlationIdHeader, ...import_utils.jsonContentTypeHeader },
      body: JSON.stringify({ "index.blocks.write": null })
    }));
    __publicField(this, "updateAliases", async ({ actions, authHeader, correlationIdHeader }) => this.fetch(import_requestUtils.RequestUtils.normalizeUrl("_aliases", this.elasticsearchUrl), {
      method: "POST",
      headers: { ...authHeader, ...correlationIdHeader, ...import_utils.jsonContentTypeHeader },
      body: JSON.stringify({ actions })
    }));
    this.esSSLConnectionProvider = esSSLConnectionProvider;
  }
  async fetch(url, init) {
    const { diskThresholdVerificationEnabled, kibanaIndex } = this.diskThresholdVerificationSettings;
    return (0, import_fetchExtension.fetchWithDiskThresholdVerification)(
      url,
      { ...init, agent: this.esSSLConnectionProvider.getConnectionAgent() },
      {
        enabled: diskThresholdVerificationEnabled(),
        onAllocationExplainCallback: async () => {
          var _a, _b;
          return this.postClusterAllocationExplain({
            requestBody: {
              index: (0, import_utils.getKibanaIndexLongFormat)(kibanaIndex),
              shard: 0,
              primary: true
            },
            authHeader: (_a = init == null ? void 0 : init.headers) == null ? void 0 : _a[import_types.AUTHORIZATION_HEADER],
            correlationIdHeader: (_b = init == null ? void 0 : init.headers) == null ? void 0 : _b[import_types.X_ROR_CORRELATION_ID]
          });
        },
        kibanaIndex,
        clusterAllocationExplainUri: this.clusterAllocationExplainUri
      }
    );
  }
};
__publicField(_RestEsApiClient, "BATCH_DELETE_CHUNK_SIZE", 100);
let RestEsApiClient = _RestEsApiClient;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RestEsApiClient
});
