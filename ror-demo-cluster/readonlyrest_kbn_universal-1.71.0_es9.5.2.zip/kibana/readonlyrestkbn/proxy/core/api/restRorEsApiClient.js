"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var restRorEsApiClient_exports = {};
__export(restRorEsApiClient_exports, {
  RestRorEsApiClient: () => RestRorEsApiClient,
  checkEsAuthorizationResponseErrorStatus: () => checkEsAuthorizationResponseErrorStatus,
  checkEsAuthorizationResponseSuccessStatus: () => checkEsAuthorizationResponseSuccessStatus
});
module.exports = __toCommonJS(restRorEsApiClient_exports);
var import_ActivationKey = require("../../../shared/types/ActivationKey");
var import_errors = __toESM(require("../../constants/errors"));
var import_authorizationHeaderBuilder = require("../authorization/authorizationHeaderBuilder");
var import_types = require("../common/types");
var import_rorLogger = require("../logging/rorLogger");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_fetchExtension = require("./fetchExtension");
var import_requestUtils = require("./requestUtils");
var import_responseHandler = require("./responseHandler");
var import_utils = require("./utils");
function isErrorAuthorizationResponseData(data) {
  var _a, _b;
  return ((_a = data.error) == null ? void 0 : _a.reason) !== void 0 || ((_b = data.error) == null ? void 0 : _b.root_cause) !== void 0;
}
function checkEsAuthorizationResponseErrorStatus(status) {
  if (status.status < 300) {
    throw new Error("Not an error status");
  }
}
function checkEsAuthorizationResponseSuccessStatus(status) {
  if (status.status >= 300) {
    throw new Error("Not an success status");
  }
}
class RestRorEsApiClient {
  constructor(elasticsearchUrl, elasticsearchCustomHeaders, esSSLConnectionProvider, kibanaIndex) {
    this.elasticsearchUrl = elasticsearchUrl;
    this.elasticsearchCustomHeaders = elasticsearchCustomHeaders;
    this.esSSLConnectionProvider = esSSLConnectionProvider;
    this.kibanaIndex = kibanaIndex;
    __publicField(this, "esAuthorizeUserUri", "_readonlyrest/metadata/user");
    __publicField(this, "configUri", "_readonlyrest/admin/config");
    __publicField(this, "testConfigUri", "_readonlyrest/admin/config/test");
    __publicField(this, "authMockUri", "_readonlyrest/admin/config/test/authmock");
    __publicField(this, "localUsersUri", "_readonlyrest/admin/config/test/localusers");
    __publicField(this, "configFileUri", "_readonlyrest/admin/config/file");
    __publicField(this, "auditConfigUri", "_readonlyrest/admin/config/audit");
    __publicField(this, "auditLogEventUri", "_readonlyrest/admin/audit/event");
    __publicField(this, "getLogger", () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "authorizeUser", async ({
      correlationIdHeader,
      multiTenancyChecker,
      identitySessionHeaders,
      whitelistedHeaders,
      licenseEdition
    }) => {
      try {
        const correlationId = correlationIdHeader[import_types.X_ROR_CORRELATION_ID];
        const requestInit = await this.prepareAuthorizationRequest(
          identitySessionHeaders,
          whitelistedHeaders,
          correlationId,
          multiTenancyChecker,
          licenseEdition
        );
        import_rorLogger.RorLogger.appendCorrelationId(correlationId);
        const authorizeUserResponse = await this.fetch(
          import_requestUtils.RequestUtils.normalizeUrl(this.esAuthorizeUserUri, this.elasticsearchUrl),
          requestInit
        );
        const authorizeUserData = await authorizeUserResponse.json();
        this.getLogger().trace("Authorization attempt returned:", authorizeUserData);
        return this.validateSuccessfulAuthorizationResponse(authorizeUserResponse, authorizeUserData);
      } catch (e) {
        this.getLogger().error({
          message: `An unexpected error occurred: ${e.message}. We forbid access because of this.`,
          stack: e.stack
        });
        return { status: "ERROR", reason: "FORBIDDEN_BY_READONLYREST", message: import_errors.default.defaultForbiddenMessage };
      }
    });
    __publicField(this, "authorizeUserAttachingMetadata", async ({
      groupId,
      multiTenancyChecker,
      correlationIdHeader,
      licenseEdition,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      try {
        const authorizationHeaderBuilder = new import_authorizationHeaderBuilder.AuthorizationHeaderBuilder(multiTenancyChecker, this.kibanaIndex);
        const authHeaderWithRorMetadata = await authorizationHeaderBuilder.prepareAuthorizationHeaderFromMetadata(
          identitySessionHeaders,
          groupId,
          whitelistedHeaders
        );
        const header = {
          ...Object.fromEntries(whitelistedHeaders),
          ...this.elasticsearchCustomHeaders,
          [import_types.AUTHORIZATION_HEADER]: authHeaderWithRorMetadata,
          ...correlationIdHeader,
          [import_types.X_ROR_LICENSE_TYPE]: this.createLicenseHeaderValue(multiTenancyChecker, licenseEdition)
        };
        const authorizedUserResponse = await this.fetch(
          import_requestUtils.RequestUtils.normalizeUrl(this.esAuthorizeUserUri, this.elasticsearchUrl),
          {
            headers: header
          }
        );
        const authorizeUserData = await authorizedUserResponse.json();
        this.getLogger().trace("Authorization attempt returned:", authorizeUserData);
        return this.validateSuccessfulAuthorizationResponse(authorizedUserResponse, authorizeUserData);
      } catch (e) {
        this.getLogger().error({
          message: `An unexpected error occurred: ${e.message}. We forbid access because of this.`,
          stack: e.stack
        });
        return { status: "ERROR", reason: "SERVER_ERROR", message: import_errors.default.cannotAuthenticate };
      }
    });
    __publicField(this, "getMainSettingsFromIndex", async ({
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.configUri, this.elasticsearchUrl), {
        headers: this.prepareUserRequestHeaders(
          authHeader,
          correlationIdHeader,
          identitySessionHeaders,
          whitelistedHeaders
        )
      });
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "getFileSettings", async ({
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.configFileUri, this.elasticsearchUrl), {
        headers: this.prepareUserRequestHeaders(
          authHeader,
          correlationIdHeader,
          identitySessionHeaders,
          whitelistedHeaders
        )
      });
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "getTestSettings", async ({
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.testConfigUri, this.elasticsearchUrl), {
        headers: this.prepareUserRequestHeaders(
          authHeader,
          correlationIdHeader,
          identitySessionHeaders,
          whitelistedHeaders
        )
      });
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "postTestSettings", async ({
      requestBody,
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.testConfigUri, this.elasticsearchUrl), {
        method: "POST",
        headers: {
          ...this.prepareUserRequestHeaders(authHeader, correlationIdHeader, identitySessionHeaders, whitelistedHeaders),
          ...import_utils.jsonContentTypeHeader
        },
        body: JSON.stringify({ settings: requestBody.settings, ttl: requestBody.ttl })
      });
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "getAuthMock", async ({
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.authMockUri, this.elasticsearchUrl), {
        headers: this.prepareUserRequestHeaders(
          authHeader,
          correlationIdHeader,
          identitySessionHeaders,
          whitelistedHeaders
        )
      });
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "postAuthMock", async ({
      requestBody,
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.authMockUri, this.elasticsearchUrl), {
        method: "POST",
        headers: {
          ...this.prepareUserRequestHeaders(authHeader, correlationIdHeader, identitySessionHeaders, whitelistedHeaders),
          ...import_utils.jsonContentTypeHeader
        },
        body: JSON.stringify(requestBody)
      });
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "getLocalUsers", async ({
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.localUsersUri, this.elasticsearchUrl), {
        headers: this.prepareUserRequestHeaders(
          authHeader,
          correlationIdHeader,
          identitySessionHeaders,
          whitelistedHeaders
        )
      });
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "deleteTestSettings", async ({
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.testConfigUri, this.elasticsearchUrl), {
        method: "DELETE",
        headers: this.prepareUserRequestHeaders(
          authHeader,
          correlationIdHeader,
          identitySessionHeaders,
          whitelistedHeaders
        )
      });
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "fetchCurrentAuditConfiguration", async ({
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.auditConfigUri, this.elasticsearchUrl), {
        headers: this.prepareUserRequestHeaders(
          authHeader,
          correlationIdHeader,
          identitySessionHeaders,
          whitelistedHeaders
        )
      });
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "postAuditEvent", async ({
      requestBody,
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(
        import_requestUtils.RequestUtils.normalizeUrl(this.auditLogEventUri, this.elasticsearchUrl),
        {
          method: "POST",
          headers: {
            ...this.prepareUserRequestHeaders(
              authHeader,
              correlationIdHeader,
              identitySessionHeaders,
              whitelistedHeaders
            ),
            ...import_utils.jsonContentTypeHeader
          },
          body: JSON.stringify(requestBody)
        }
      );
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "postSettings", async ({
      requestBody,
      authHeader,
      correlationIdHeader,
      identitySessionHeaders,
      whitelistedHeaders
    }) => {
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.configUri, this.elasticsearchUrl), {
        method: "POST",
        headers: {
          ...this.prepareUserRequestHeaders(authHeader, correlationIdHeader, identitySessionHeaders, whitelistedHeaders),
          ...import_utils.jsonContentTypeHeader
        },
        body: JSON.stringify(requestBody)
      });
      return import_responseHandler.ResponseHandler.toEsResponse(response);
    });
    __publicField(this, "checkImpersonatedUser", async ({
      authHeader,
      multiTenancyChecker,
      identitySessionHeaders,
      whitelistedHeaders,
      impersonateAs,
      correlationIdHeader,
      licenseEdition
    }) => {
      const headers = {
        ...this.prepareUserRequestHeaders(authHeader, correlationIdHeader, identitySessionHeaders, whitelistedHeaders),
        [import_types.X_ROR_IMPERSONATING]: impersonateAs,
        [import_types.X_ROR_LICENSE_TYPE]: this.createLicenseHeaderValue(multiTenancyChecker, licenseEdition)
      };
      const response = await this.fetch(import_requestUtils.RequestUtils.normalizeUrl(this.esAuthorizeUserUri, this.elasticsearchUrl), {
        headers
      });
      const bodyString = await response.text();
      const authorizationResponse = bodyString ? JSON.parse(bodyString) : bodyString;
      return {
        status: response.status,
        statusMessage: response.statusText,
        body: authorizationResponse
      };
    });
  }
  prepareUserRequestHeaders(authHeader, correlationIdHeader, identitySessionHeaders, whitelistedHeaders) {
    return {
      ...authHeader,
      ...Object.fromEntries(identitySessionHeaders != null ? identitySessionHeaders : []),
      ...Object.fromEntries(whitelistedHeaders != null ? whitelistedHeaders : []),
      ...this.elasticsearchCustomHeaders,
      ...correlationIdHeader
    };
  }
  async prepareAuthorizationRequest(identitySessionHeaders, whitelistedHeaders, correlationId, multiTenancyChecker, licenseEdition) {
    const licenseHeader = this.createLicenseHeaderValue(multiTenancyChecker, licenseEdition);
    return {
      headers: {
        ...Object.fromEntries(identitySessionHeaders),
        ...Object.fromEntries(whitelistedHeaders),
        ...this.elasticsearchCustomHeaders,
        [import_types.X_ROR_CORRELATION_ID]: correlationId,
        [import_types.X_ROR_LICENSE_TYPE]: licenseHeader
      }
    };
  }
  validateSuccessfulAuthorizationResponse(response, authorizeUserData) {
    var _a;
    if (response.status === 401 || response.status === 403) {
      if (isErrorAuthorizationResponseData(authorizeUserData)) {
        return {
          status: "ERROR",
          reason: "CUSTOM_ERROR_FROM_ES",
          message: (_a = authorizeUserData.error.reason) != null ? _a : authorizeUserData.error.root_cause[0].reason
        };
      }
      this.getLogger().error({ message: `Failed to extract reason from response:` }, authorizeUserData);
      return {
        status: "ERROR",
        reason: "FORBIDDEN_BY_READONLYREST",
        message: import_errors.default.defaultForbiddenMessage
      };
    }
    if (!response.ok) {
      this.getLogger().error({
        message: `Unhandled error from Elasticsearch, status: ${response.status}, error: ${JSON.stringify(
          authorizeUserData
        )}`
      });
      return {
        status: "ERROR",
        reason: "UNHANDLED_ERROR_FROM_ES",
        message: import_errors.default.cannotAuthenticate
      };
    }
    return { status: "SUCCESS", data: authorizeUserData };
  }
  async fetch(url, init) {
    return (0, import_fetchExtension.fetch)(url, {
      ...init,
      headers: init == null ? void 0 : init.headers,
      agent: this.esSSLConnectionProvider.getConnectionAgent()
    });
  }
  createLicenseHeaderValue(multiTenancyChecker, licenseEdition) {
    if (licenseEdition === import_ActivationKey.EDITIONS_ENUM.ENTERPRISE) {
      if (multiTenancyChecker.multiTenancyFeatureAvailable()) {
        return "ent";
      }
      return "ent-disabled-multitenancy";
    }
    if (licenseEdition === import_ActivationKey.EDITIONS_ENUM.PRO) {
      return "pro";
    }
    return "free";
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RestRorEsApiClient,
  checkEsAuthorizationResponseErrorStatus,
  checkEsAuthorizationResponseSuccessStatus
});
