"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var authorizationHeaderBuilder_exports = {};
__export(authorizationHeaderBuilder_exports, {
  AuthorizationHeaderBuilder: () => AuthorizationHeaderBuilder
});
module.exports = __toCommonJS(authorizationHeaderBuilder_exports);
var import_headers = require("../../../shared/constants/headers");
var import_types = require("../common/types");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
const _AuthorizationHeaderBuilder = class _AuthorizationHeaderBuilder {
  constructor(multiTenancyChecker, defaultKibanaIndex) {
    this.multiTenancyChecker = multiTenancyChecker;
    this.defaultKibanaIndex = defaultKibanaIndex;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  deduplicateArray(array) {
    return Array.from(new Set(array));
  }
  async prepareAuthorizationHeaderFromRequest(rorRequest, userRequestIdentity) {
    const identitySessionHeaders = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata.identitySessionHeaders;
    const whitelistedHeaders = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata.whitelistedHeaders;
    const metadataToInline = await this.collectMetadataFromRequest(rorRequest, userRequestIdentity);
    return this.prepareFrom(identitySessionHeaders, whitelistedHeaders, this.deduplicateArray(metadataToInline));
  }
  async prepareAuthorizationHeaderFromMetadata(identitySessionHeaders, groupId, whitelistedHeaders) {
    return this.prepareFrom(
      identitySessionHeaders,
      whitelistedHeaders,
      groupId ? [this.inlineGroupHeader(groupId)] : []
    );
  }
  prepareFrom(identitySessionHeaders, whitelistedHeaders, metadataToInline) {
    var _a;
    const mergedInlineHeaders = /* @__PURE__ */ new Map();
    identitySessionHeaders == null ? void 0 : identitySessionHeaders.forEach((value, header) => {
      if (header !== import_types.AUTHORIZATION_HEADER) {
        mergedInlineHeaders.set(header, value);
      }
    });
    whitelistedHeaders == null ? void 0 : whitelistedHeaders.forEach((value, header) => {
      if (header.toLowerCase() !== import_types.AUTHORIZATION_HEADER) {
        mergedInlineHeaders.set(header, value);
      }
    });
    const inlineHeaders = Array.from(mergedInlineHeaders, ([header, value]) => `${header}:${value}`);
    const dataToInline = [...inlineHeaders, ...metadataToInline];
    const encodedDataToInline = _AuthorizationHeaderBuilder.encodeToBase64(JSON.stringify({ headers: dataToInline }));
    const authorization = (_a = identitySessionHeaders == null ? void 0 : identitySessionHeaders.get(import_types.AUTHORIZATION_HEADER)) != null ? _a : _AuthorizationHeaderBuilder.DUMMY_AUTHORIZATION;
    const finalAuthorizationHeaderWithMetadata = `${authorization}, ror_metadata=${encodedDataToInline}`;
    const headerSize = finalAuthorizationHeaderWithMetadata.length;
    if (headerSize >= 8e3) {
      this.logger.warn(
        `Base64 encoded metadata headers length of ${headerSize} exceeded maximum length of 8KB! Please reduce the metadata size! The sum of the following headers lengths should be less than 6000: `,
        dataToInline.map((h) => `${h.substr(0, h.indexOf(":"))}: ${Buffer.byteLength(h, "utf8")} is characters long`)
      );
    }
    return finalAuthorizationHeaderWithMetadata;
  }
  async collectMetadataFromRequest(rorRequest, userRequestIdentity) {
    var _a;
    const metadata = [
      this.inlineRequestPath(rorRequest),
      this.inlineRequestMethod(rorRequest),
      this.inlineXForwardedForHeader(rorRequest),
      this.inlineKibanaIndex((userRequestIdentity == null ? void 0 : userRequestIdentity.metadata.kibanaIndex) || this.defaultKibanaIndex),
      this.inlineTenancy((_a = rorRequest.getHeaders()) == null ? void 0 : _a[import_headers.X_ROR_TENANCY])
    ];
    if (this.multiTenancyChecker.multiTenancyFeatureAvailable() && userRequestIdentity) {
      const inlineCurrentGroupHeader = this.inlineCurrentGroupHeader(userRequestIdentity.metadata);
      if (inlineCurrentGroupHeader) {
        metadata.push(inlineCurrentGroupHeader);
      }
    }
    function notEmpty(value) {
      return value !== null && value !== void 0;
    }
    return metadata.filter(notEmpty);
  }
  inlineGroupHeader(groupId) {
    return `${import_types.X_ROR_CURRENT_GROUP}:${groupId}`;
  }
  inlineKibanaIndex(kibanaIndex) {
    return `${import_types.X_ROR_KIBANA_INDEX}:${kibanaIndex}`;
  }
  inlineTenancy(tenancyId) {
    if (!tenancyId) {
      return void 0;
    }
    return `${import_headers.X_ROR_TENANCY}:${tenancyId}`;
  }
  inlineCurrentGroupHeader(session) {
    const currentGroup = session == null ? void 0 : session.currentGroup;
    if (!currentGroup) {
      return null;
    }
    return `${import_types.X_ROR_CURRENT_GROUP}:${currentGroup.id}`;
  }
  inlineRequestPath(request) {
    return `${import_types.X_ROR_KIBANA_REQ_PATH}:${request.getPath()}`;
  }
  inlineRequestMethod(request) {
    return `${import_types.X_ROR_KIBANA_REQ_METHOD}:${request.getMethod()}`;
  }
  inlineXForwardedForHeader(request) {
    const xForwardedForHeader = request.getHeaders()[import_types.X_FORWARDED_FOR] || this.getIpFromOriginHeader(request) || request.getOriginAddress() || null;
    return `${import_types.X_FORWARDED_FOR}:${xForwardedForHeader}`;
  }
  getIpFromOriginHeader(request) {
    if (!request.getHeaders()[import_types.ORIGIN_HEADER]) {
      return void 0;
    }
    const originHeaderSplit = request.getHeaders()[import_types.ORIGIN_HEADER].split("://");
    return originHeaderSplit[1];
  }
};
__publicField(_AuthorizationHeaderBuilder, "encodeToBase64", (string) => Buffer.from(string).toString("base64"));
__publicField(_AuthorizationHeaderBuilder, "DUMMY_AUTHORIZATION", `Basic ${_AuthorizationHeaderBuilder.encodeToBase64("_:_")}`);
let AuthorizationHeaderBuilder = _AuthorizationHeaderBuilder;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AuthorizationHeaderBuilder
});
