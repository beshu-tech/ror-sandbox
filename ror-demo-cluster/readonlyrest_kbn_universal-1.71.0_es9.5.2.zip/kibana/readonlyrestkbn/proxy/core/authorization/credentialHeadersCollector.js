"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var credentialHeadersCollector_exports = {};
__export(credentialHeadersCollector_exports, {
  CredentialHeadersCollector: () => CredentialHeadersCollector
});
module.exports = __toCommonJS(credentialHeadersCollector_exports);
var import_types = require("../common/types");
var import_versionedLibraries = require("../common/versionedLibraries");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_expressRorRequest = require("../rorRequest/expressRorRequest");
var import_ssoSessionProfile = require("../ssoSessionProfile");
class CredentialHeadersCollector {
  constructor(rorSettingsStore) {
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  collectForwardAuthHeader(request) {
    const { proxyAuthSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    const headers = /* @__PURE__ */ new Map();
    if (!proxyAuthSettings.enabled) {
      return headers;
    }
    const forwardAuthHeader = proxyAuthSettings.forward_auth_header;
    const value = request.getHeaders()[forwardAuthHeader];
    if (value) {
      this.logger.debug(`Found proxy auth header ${forwardAuthHeader}: ${value}`);
      headers.set(forwardAuthHeader, value);
    }
    return headers;
  }
  static fromBasicAuth(request, credentialHeaders) {
    const basicHeaderValue = request.getHeaders()[import_types.AUTHORIZATION_HEADER];
    if (basicHeaderValue == null ? void 0 : basicHeaderValue.includes("Basic")) {
      credentialHeaders.set(import_types.AUTHORIZATION_HEADER, basicHeaderValue);
    }
    return credentialHeaders;
  }
  static buildSsoSessionProfile(claims) {
    if (!claims) return void 0;
    const origin = claims[import_types.X_ROR_ORIGIN];
    const profile = (0, import_ssoSessionProfile.parseSsoSessionProfile)(claims[import_types.SSO_SESSION_PROFILE_CLAIM]);
    if (!profile || profile.connectorName !== origin) {
      return void 0;
    }
    return profile;
  }
  // Returns the connector-service token's verified claims (when a login POST carries one) so
  // callers building the SSO session profile can reuse them instead of re-verifying the token.
  fromJWT(request, credentialHeaders) {
    const { jwtQueryParam, authSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    const token = request.getQueries()[jwtQueryParam.value];
    if (token) {
      credentialHeaders.set(import_types.AUTHORIZATION_HEADER, `Bearer ${token}`);
      return { credentialHeaders };
    }
    const authorization = request.getHeaders()[import_types.AUTHORIZATION_HEADER];
    if (authorization && authorization.indexOf("Bearer") >= 0) {
      credentialHeaders.set(import_types.AUTHORIZATION_HEADER, authorization);
      return { credentialHeaders };
    }
    const body = request.getBody();
    if (!body || !request.getPath().includes("/login") || request.getMethod() !== import_types.Method.POST) {
      return { credentialHeaders };
    }
    const postField = body[import_types.CONNECTOR_SVC_TRANSIENT_JWT];
    if (!postField) {
      this.logger.debug(`No ${import_types.CONNECTOR_SVC_TRANSIENT_JWT} field in login POST body`);
      return { credentialHeaders };
    }
    const signatureKey = authSettings == null ? void 0 : authSettings.signatureKey;
    if (!signatureKey) {
      this.logger.debug("No signature key configured, skipping JWT credential extraction");
      return { credentialHeaders };
    }
    try {
      const decodedToken = import_versionedLibraries.jsonwebtoken.verify(postField, signatureKey);
      credentialHeaders.set(import_types.AUTHORIZATION_HEADER, `Bearer ${postField}`);
      const origin = decodedToken[import_types.X_ROR_ORIGIN];
      if (origin) {
        credentialHeaders.set(import_types.X_ROR_ORIGIN, origin);
      } else {
        this.logger.debug(`No ${import_types.X_ROR_ORIGIN} claim in JWT token`);
      }
      return { credentialHeaders, connectorServiceClaims: decodedToken };
    } catch (e) {
      this.logger.debug(`JWT signature verification failed: ${e instanceof Error ? e.message : String(e)}`);
    }
    return { credentialHeaders };
  }
  static fromConnectorService(request, credentialHeaders) {
    const body = request.getBody();
    if (body && request.getMethod() === import_types.Method.POST) {
      const transientToken = body[import_types.CONNECTOR_SVC_TRANSIENT_JWT];
      if (transientToken) {
        credentialHeaders.set(import_types.AUTHORIZATION_HEADER, `Bearer ${transientToken}`);
      }
    }
    return credentialHeaders;
  }
  static fromFormJSON(request, credentialHeaders) {
    const body = request.getBody();
    if (body && (0, import_expressRorRequest.isLoginFormBody)(body)) {
      const encodedCredentials = Buffer.from(`${body.username}:${body.password}`).toString("base64");
      credentialHeaders.set(import_types.AUTHORIZATION_HEADER, `Basic ${encodedCredentials}`);
    }
    return credentialHeaders;
  }
  collectCredentialHeaders(request) {
    return this.collectCredentialHeadersAndSsoSessionProfile(request).credentialHeaders;
  }
  // Same as collectCredentialHeaders, but also returns the SSO session profile built from the
  // same connector-service token verification fromJWT already did - so callers that need both
  // (e.g. login) don't end up verifying that JWT's signature twice.
  collectCredentialHeadersAndSsoSessionProfile(request) {
    let credentialHeaders = /* @__PURE__ */ new Map();
    credentialHeaders = CredentialHeadersCollector.fromBasicAuth(request, credentialHeaders);
    const jwtResult = this.fromJWT(request, credentialHeaders);
    credentialHeaders = jwtResult.credentialHeaders;
    credentialHeaders = CredentialHeadersCollector.fromConnectorService(request, credentialHeaders);
    credentialHeaders = CredentialHeadersCollector.fromFormJSON(request, credentialHeaders);
    delete credentialHeaders.cookie;
    return {
      credentialHeaders,
      ssoSessionProfile: CredentialHeadersCollector.buildSsoSessionProfile(jwtResult.connectorServiceClaims)
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CredentialHeadersCollector
});
