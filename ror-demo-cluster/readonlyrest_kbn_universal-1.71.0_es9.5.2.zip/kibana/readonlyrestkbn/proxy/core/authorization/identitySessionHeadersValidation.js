"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var identitySessionHeadersValidation_exports = {};
__export(identitySessionHeadersValidation_exports, {
  IdentitySessionHeadersValidation: () => IdentitySessionHeadersValidation
});
module.exports = __toCommonJS(identitySessionHeadersValidation_exports);
var import_correlationIdWrapper = require("../api/correlationIdWrapper");
var import_requestHeadersWhitelistApplier = require("../common/requestHeadersWhitelistApplier");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_RorMetadata = require("../RorMetadata");
class IdentitySessionHeadersValidation {
  constructor(credentialHeadersCollector, requestHeadersWhitelist, multiTenancyChecker, rorEsApiClient, sessionManagerProvider, licenseService) {
    this.credentialHeadersCollector = credentialHeadersCollector;
    this.requestHeadersWhitelist = requestHeadersWhitelist;
    this.multiTenancyChecker = multiTenancyChecker;
    this.rorEsApiClient = rorEsApiClient;
    this.sessionManagerProvider = sessionManagerProvider;
    this.licenseService = licenseService;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  async revalidate(request) {
    try {
      const rorRequest = request.rorRequest;
      const userRequestIdentity = await rorRequest.getUserRequestIdentity();
      if (!userRequestIdentity) {
        this.logger.debug("There is no user request identity. Token revalidation aborted");
        return;
      }
      const identitySession = await this.sessionManagerProvider.get().get(userRequestIdentity.sid);
      if (!identitySession) {
        this.logger.debug("There is no identity session. Token revalidation aborted");
        return;
      }
      const credentialHeaders = this.credentialHeadersCollector.collectCredentialHeaders(rorRequest);
      const forwardAuthHeaders = this.credentialHeadersCollector.collectForwardAuthHeader(rorRequest);
      const allReqHeaders = rorRequest.getHeaders();
      const whitelistedHeaders = new Map(forwardAuthHeaders);
      import_requestHeadersWhitelistApplier.RequestHeadersWhitelistApplier.applyToMap(
        this.logger,
        this.requestHeadersWhitelist,
        allReqHeaders,
        whitelistedHeaders
      );
      const requestAuthorizationToken = import_RorMetadata.RorMetadata.removeRorMetadata(credentialHeaders.get("authorization"));
      const sessionAuthorizationToken = identitySession == null ? void 0 : identitySession.identitySessionHeaders.get("authorization");
      if (!requestAuthorizationToken) {
        this.logger.debug("There is no authorization token in the request. Token revalidation aborted");
        return;
      }
      if (requestAuthorizationToken === sessionAuthorizationToken) {
        this.logger.debug("Request token is the same as session token. Token revalidation aborted");
        return;
      }
      const response = await new import_correlationIdWrapper.CorrelationIdWrapper(this.rorEsApiClient).withCorrelationIdHeader(identitySession.correlationId).authorizeUser({
        multiTenancyChecker: this.multiTenancyChecker,
        identitySessionHeaders: credentialHeaders,
        whitelistedHeaders,
        licenseEdition: this.licenseService.getLicenseEdition()
      });
      if (response.status === "ERROR") {
        throw new Error(response.message);
      }
      const updatedIdentitySessionMetadata = {
        ...identitySession,
        identitySessionHeaders: credentialHeaders,
        whitelistedHeaders
      };
      await this.sessionManagerProvider.get().set(userRequestIdentity.sid, updatedIdentitySessionMetadata);
      this.logger.info(`Current session successfully revalidated against ES`);
    } catch (e) {
      this.logger.info(`Could not revalidate the session against ES: + ${e.message}`);
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  IdentitySessionHeadersValidation
});
