"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var Cipher_exports = {};
__export(Cipher_exports, {
  Cipher: () => Cipher
});
module.exports = __toCommonJS(Cipher_exports);
var import_crypto = require("crypto");
const SALT_PREFIX = "Salted__";
const SALT_LENGTH = 8;
const KEY_LENGTH = 32;
const IV_LENGTH = 16;
function deriveKeyAndIv(passphrase, salt) {
  let derived = Buffer.alloc(0);
  let block = Buffer.alloc(0);
  while (derived.length < KEY_LENGTH + IV_LENGTH) {
    block = (0, import_crypto.createHash)("md5").update(Buffer.concat([block, passphrase, salt])).digest();
    derived = Buffer.concat([derived, block]);
  }
  return {
    key: derived.subarray(0, KEY_LENGTH),
    iv: derived.subarray(KEY_LENGTH, KEY_LENGTH + IV_LENGTH)
  };
}
class Cipher {
  static encryptAes256(plaintext, key) {
    const salt = (0, import_crypto.randomBytes)(SALT_LENGTH);
    const { key: derivedKey, iv } = deriveKeyAndIv(Buffer.from(key, "utf8"), salt);
    const cipher = (0, import_crypto.createCipheriv)("aes-256-cbc", derivedKey, iv);
    const ciphertext = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
    return Buffer.concat([Buffer.from(SALT_PREFIX, "utf8"), salt, ciphertext]).toString("base64");
  }
  static decryptAes256(ciphertext, key) {
    const raw = Buffer.from(ciphertext, "base64");
    const prefix = raw.subarray(0, SALT_PREFIX.length).toString("utf8");
    if (prefix !== SALT_PREFIX) {
      throw new Error("Invalid ciphertext: missing salt prefix");
    }
    const salt = raw.subarray(SALT_PREFIX.length, SALT_PREFIX.length + SALT_LENGTH);
    const encrypted = raw.subarray(SALT_PREFIX.length + SALT_LENGTH);
    const { key: derivedKey, iv } = deriveKeyAndIv(Buffer.from(key, "utf8"), salt);
    const decipher = (0, import_crypto.createDecipheriv)("aes-256-cbc", derivedKey, iv);
    return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString("utf8");
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Cipher
});
