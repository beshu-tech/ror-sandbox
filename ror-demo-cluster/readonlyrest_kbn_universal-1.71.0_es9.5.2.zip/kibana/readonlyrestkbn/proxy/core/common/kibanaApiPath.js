"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var kibanaApiPath_exports = {};
__export(kibanaApiPath_exports, {
  KibanaApiPath: () => KibanaApiPath
});
module.exports = __toCommonJS(kibanaApiPath_exports);
const _KibanaApiPath = class _KibanaApiPath {
  // Captures the full path after basePath, preserving any /s/{spaceId} prefix.
  // Matches both public (/api/*) and internal (/internal/*) Kibana API paths.
  // e.g. basePath="/kibana": "/kibana/api/spaces"              → "/api/spaces"
  //                          "/kibana/s/default/api/spaces"    → "/s/default/api/spaces"
  //                          "/kibana/internal/kibana/settings" → "/internal/kibana/settings"
  static buildPathRegex(basePath) {
    const escapedBasePath = basePath.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`^${escapedBasePath}(${_KibanaApiPath.PATH_REGEX_BODY})$`);
  }
  static isApiLeadingSegment(segment) {
    return _KibanaApiPath.API_SEGMENTS.includes(segment) || segment === _KibanaApiPath.SPACE_PREFIX;
  }
};
__publicField(_KibanaApiPath, "API_SEGMENTS", ["api", "internal"]);
__publicField(_KibanaApiPath, "SPACE_PREFIX", "s");
__publicField(_KibanaApiPath, "PATH_REGEX_BODY", `(?:/${_KibanaApiPath.SPACE_PREFIX}/[^/]+)?/(?:${_KibanaApiPath.API_SEGMENTS.join("|")})/.+`);
let KibanaApiPath = _KibanaApiPath;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KibanaApiPath
});
