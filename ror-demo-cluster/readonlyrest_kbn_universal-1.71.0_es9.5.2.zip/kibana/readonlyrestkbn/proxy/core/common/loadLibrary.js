"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var loadLibrary_exports = {};
__export(loadLibrary_exports, {
  __resetVersionedLibrariesForTests: () => __resetVersionedLibrariesForTests,
  loadVersionedLibrary: () => loadVersionedLibrary
});
module.exports = __toCommonJS(loadLibrary_exports);
var import_distributionInfoProvider = require("../../../kibana/patchers/distributionInfoProvider");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
const logger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const libraryCache = /* @__PURE__ */ Object.create(null);
function loadVersionedLibrary(opts) {
  const {
    name,
    cutoffVersion = "7.16.0",
    ancientName,
    ancientSuffix = "-ancient",
    predicate,
    cacheKey = name,
    warnMessage
  } = opts;
  if (libraryCache[cacheKey]) return libraryCache[cacheKey];
  const dist = import_distributionInfoProvider.DistributionInfoProvider.getInstance();
  const isAncient = predicate ? predicate(dist) : dist.isKibanaMoreAncientThan(cutoffVersion);
  const pkg = isAncient ? ancientName != null ? ancientName : `${name}${ancientSuffix}` : name;
  try {
    const library = require(pkg);
    const returnData = { library, isAncient };
    libraryCache[cacheKey] = returnData;
    if (isAncient && warnMessage) logger().warn(warnMessage);
    return returnData;
  } catch (e) {
    logger().error({
      message: `Failed loading package '${pkg}' (cacheKey='${cacheKey}'): ${e.message}`,
      stack: e.stack
    });
    throw e;
  }
}
function __resetVersionedLibrariesForTests() {
  Object.keys(libraryCache).forEach((k) => delete libraryCache[k]);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  __resetVersionedLibrariesForTests,
  loadVersionedLibrary
});
