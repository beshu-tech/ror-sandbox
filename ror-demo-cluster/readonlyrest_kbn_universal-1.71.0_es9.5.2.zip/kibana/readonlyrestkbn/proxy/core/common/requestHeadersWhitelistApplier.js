"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var requestHeadersWhitelistApplier_exports = {};
__export(requestHeadersWhitelistApplier_exports, {
  RequestHeadersWhitelistApplier: () => RequestHeadersWhitelistApplier
});
module.exports = __toCommonJS(requestHeadersWhitelistApplier_exports);
class RequestHeadersWhitelistApplier {
  static applyToMap(logger, requestHeadersWhitelist, from, to) {
    const toAsDict = {};
    this.apply(logger, requestHeadersWhitelist, from, toAsDict);
    Object.keys(toAsDict).forEach((key) => {
      const outgoingHttpHeaders = toAsDict[key];
      if (outgoingHttpHeaders) {
        to.set(key, outgoingHttpHeaders.toString());
      }
    });
  }
  static apply(logger, requestHeadersWhitelist, from, to) {
    for (const h of requestHeadersWhitelist) {
      if (from[h]) {
        to[h] = from[h];
      }
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RequestHeadersWhitelistApplier
});
