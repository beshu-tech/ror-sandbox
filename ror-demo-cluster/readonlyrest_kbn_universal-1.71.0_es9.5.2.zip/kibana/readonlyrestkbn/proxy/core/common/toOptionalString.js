"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var toOptionalString_exports = {};
__export(toOptionalString_exports, {
  toOptionalString: () => toOptionalString
});
module.exports = __toCommonJS(toOptionalString_exports);
function toOptionalString(value) {
  if (typeof value !== "string") return void 0;
  if (value.trim() === "" || value === "null" || value === "undefined") return void 0;
  return value;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  toOptionalString
});
