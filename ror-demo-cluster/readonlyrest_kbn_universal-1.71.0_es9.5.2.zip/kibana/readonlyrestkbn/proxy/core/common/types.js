"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var types_exports = {};
__export(types_exports, {
  AUTHORIZATION_HEADER: () => AUTHORIZATION_HEADER,
  AUTOLOGIN_QUERY_PARAM: () => AUTOLOGIN_QUERY_PARAM,
  CONNECTOR_SVC_TRANSIENT_JWT: () => CONNECTOR_SVC_TRANSIENT_JWT,
  CONTENT_TYPE_HEADER: () => CONTENT_TYPE_HEADER,
  IDENTITY_SESSION_HEADER_NAMES: () => IDENTITY_SESSION_HEADER_NAMES,
  MESSAGE_QUERY_PARAM: () => MESSAGE_QUERY_PARAM,
  Method: () => Method,
  ORIGIN_HEADER: () => ORIGIN_HEADER,
  SSO_SESSION_PROFILE_CLAIM: () => SSO_SESSION_PROFILE_CLAIM,
  X_FORWARDED_FOR: () => X_FORWARDED_FOR,
  X_FORWARDED_USER: () => X_FORWARDED_USER,
  X_ROR_CORRELATION_ID: () => X_ROR_CORRELATION_ID,
  X_ROR_CURRENT_GROUP: () => X_ROR_CURRENT_GROUP,
  X_ROR_IMPERSONATING: () => X_ROR_IMPERSONATING,
  X_ROR_KIBANA_INDEX: () => X_ROR_KIBANA_INDEX,
  X_ROR_KIBANA_METADATA: () => X_ROR_KIBANA_METADATA,
  X_ROR_KIBANA_REQ_METHOD: () => X_ROR_KIBANA_REQ_METHOD,
  X_ROR_KIBANA_REQ_PATH: () => X_ROR_KIBANA_REQ_PATH,
  X_ROR_LICENSE_TYPE: () => X_ROR_LICENSE_TYPE,
  X_ROR_ORIGIN: () => X_ROR_ORIGIN,
  X_ROR_TENANCY_ID: () => X_ROR_TENANCY_ID
});
module.exports = __toCommonJS(types_exports);
const CONTENT_TYPE_HEADER = "Content-Type";
const X_ROR_ORIGIN = "x-ror-origin";
const X_FORWARDED_USER = "x-forwarded-user";
const X_FORWARDED_FOR = "x-forwarded-for";
const X_ROR_CURRENT_GROUP = "x-ror-current-group";
const X_ROR_KIBANA_REQ_PATH = "x-ror-kibana-request-path";
const X_ROR_KIBANA_REQ_METHOD = "x-ror-kibana-request-method";
const AUTHORIZATION_HEADER = "authorization";
const ORIGIN_HEADER = "origin";
const MESSAGE_QUERY_PARAM = "message";
const AUTOLOGIN_QUERY_PARAM = "autologin";
const X_ROR_IMPERSONATING = "x-ror-impersonating";
const X_ROR_CORRELATION_ID = "x-ror-correlation-id";
const X_ROR_KIBANA_METADATA = "x-ror-kibana-metadata";
const X_ROR_KIBANA_INDEX = "x-ror-kibana-index";
const X_ROR_TENANCY_ID = "x-ror-tenancy-id";
const X_ROR_LICENSE_TYPE = "x-ror-kbn-license-type";
const CONNECTOR_SVC_TRANSIENT_JWT = "conn_svc_transient_jwt";
const SSO_SESSION_PROFILE_CLAIM = "ror_sso_session_profile";
const IDENTITY_SESSION_HEADER_NAMES = [
  AUTHORIZATION_HEADER,
  X_ROR_ORIGIN,
  X_ROR_IMPERSONATING,
  X_ROR_TENANCY_ID,
  CONNECTOR_SVC_TRANSIENT_JWT,
  X_ROR_CORRELATION_ID
];
var Method = /* @__PURE__ */ ((Method2) => {
  Method2["HEAD"] = "head";
  Method2["OPTION"] = "option";
  Method2["GET"] = "get";
  Method2["PUT"] = "put";
  Method2["POST"] = "post";
  Method2["PATCH"] = "patch";
  Method2["DELETE"] = "delete";
  return Method2;
})(Method || {});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AUTHORIZATION_HEADER,
  AUTOLOGIN_QUERY_PARAM,
  CONNECTOR_SVC_TRANSIENT_JWT,
  CONTENT_TYPE_HEADER,
  IDENTITY_SESSION_HEADER_NAMES,
  MESSAGE_QUERY_PARAM,
  Method,
  ORIGIN_HEADER,
  SSO_SESSION_PROFILE_CLAIM,
  X_FORWARDED_FOR,
  X_FORWARDED_USER,
  X_ROR_CORRELATION_ID,
  X_ROR_CURRENT_GROUP,
  X_ROR_IMPERSONATING,
  X_ROR_KIBANA_INDEX,
  X_ROR_KIBANA_METADATA,
  X_ROR_KIBANA_REQ_METHOD,
  X_ROR_KIBANA_REQ_PATH,
  X_ROR_LICENSE_TYPE,
  X_ROR_ORIGIN,
  X_ROR_TENANCY_ID
});
