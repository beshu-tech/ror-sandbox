"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var urlUtils_exports = {};
__export(urlUtils_exports, {
  appendQueryParam: () => appendQueryParam,
  isSafeRelativeUrl: () => isSafeRelativeUrl,
  normalizeUrlEncoding: () => normalizeUrlEncoding
});
module.exports = __toCommonJS(urlUtils_exports);
function isSafeRelativeUrl(url) {
  if (/[\x00-\x1F\x7F]/.test(url)) return false;
  return url === "/" || /^\/[^/\\]/.test(url);
}
function appendQueryParam(url, name, value) {
  const parsed = new URL(url);
  parsed.searchParams.set(name, value);
  return parsed.toString();
}
function normalizeUrlEncoding(url) {
  let workingUrl = url;
  try {
    const decoded = decodeURIComponent(url);
    if (decoded !== url && !decoded.includes("%")) {
      workingUrl = decoded;
    }
  } catch {
  }
  const hashIdx = workingUrl.indexOf("#");
  const fragment = hashIdx === -1 ? "" : workingUrl.slice(hashIdx);
  const urlWithoutFragment = hashIdx === -1 ? workingUrl : workingUrl.slice(0, hashIdx);
  const qIdx = urlWithoutFragment.indexOf("?");
  if (qIdx === -1) return urlWithoutFragment + fragment;
  const path = urlWithoutFragment.slice(0, qIdx);
  const query = urlWithoutFragment.slice(qIdx + 1).split("&").map((pair) => {
    const eqIdx = pair.indexOf("=");
    if (eqIdx === -1) return pair;
    try {
      return pair.slice(0, eqIdx + 1) + encodeURIComponent(decodeURIComponent(pair.slice(eqIdx + 1)));
    } catch {
      return pair;
    }
  }).join("&");
  return `${path}?${query}${fragment}`;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  appendQueryParam,
  isSafeRelativeUrl,
  normalizeUrlEncoding
});
