"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var versionedLibraries_exports = {};
__export(versionedLibraries_exports, {
  HttpProxyAgent: () => HttpProxyAgent,
  HttpsProxyAgent: () => HttpsProxyAgent,
  createVersionedLibraries: () => createVersionedLibraries,
  detectPort: () => detectPort,
  jsonwebtoken: () => jsonwebtoken,
  openidClient: () => openidClient,
  passportSaml: () => passportSaml,
  reinitializeVersionedLibrariesForTests: () => reinitializeVersionedLibrariesForTests,
  yaml: () => yaml
});
module.exports = __toCommonJS(versionedLibraries_exports);
var import_loadLibrary = require("./loadLibrary");
function createVersionedLibraries() {
  const yaml2 = (0, import_loadLibrary.loadVersionedLibrary)({ name: "yaml", cutoffVersion: "7.12.0" }).library;
  const { library: detectPortLib, isAncient: detectPortIsAncient } = (0, import_loadLibrary.loadVersionedLibrary)({
    name: "detect-port",
    cutoffVersion: "7.16.0"
  });
  const detectPort2 = detectPortIsAncient ? detectPortLib : detectPortLib.detect;
  const jsonwebtoken2 = (0, import_loadLibrary.loadVersionedLibrary)({
    name: "jsonwebtoken",
    cutoffVersion: "7.11.0"
  }).library;
  const HttpProxyAgent2 = (0, import_loadLibrary.loadVersionedLibrary)({
    name: "http-proxy-agent",
    cutoffVersion: "7.11.0",
    warnMessage: "Your Kibana version ships with an obsolete Node.js version, incompatible with the most recent HTTP proxy agent. WE HIGHLY RECOMMENDED TO UPGRADE TO KIBANA >= 7.11.0 so that ROR can use the most updated, HTTP proxy agent version with all security fixes applied."
  }).library.HttpProxyAgent;
  const HttpsProxyAgent2 = (0, import_loadLibrary.loadVersionedLibrary)({
    name: "https-proxy-agent",
    cutoffVersion: "7.11.0",
    warnMessage: "Your Kibana version ships with an obsolete Node.js version, incompatible with the most recent HTTPS proxy agent. WE HIGHLY RECOMMENDED TO UPGRADE TO KIBANA >= 7.11.0 so that ROR can use the most updated, HTTPS proxy agent version with all security fixes applied."
  }).library.HttpsProxyAgent;
  const passportSaml2 = (0, import_loadLibrary.loadVersionedLibrary)({
    name: "@node-saml/passport-saml",
    cutoffVersion: "7.11.0",
    ancientName: "passport-saml-ancient",
    warnMessage: "Your Kibana version ships with an obsolete Node.js version, incompatible with the most recent SAML client. We HIGHLY RECOMMEND upgrading to Kibana >= 7.11.0 so that ReadonlyREST can use the most updated, secure, and compatible SAML client."
  });
  const openidClient2 = (0, import_loadLibrary.loadVersionedLibrary)({
    name: "openid-client",
    cutoffVersion: "7.11.0"
  }).library;
  return {
    yaml: yaml2,
    detectPort: detectPort2,
    jsonwebtoken: jsonwebtoken2,
    HttpProxyAgent: HttpProxyAgent2,
    HttpsProxyAgent: HttpsProxyAgent2,
    passportSaml: passportSaml2,
    openidClient: openidClient2
  };
}
let { yaml, detectPort, jsonwebtoken, HttpProxyAgent, HttpsProxyAgent, passportSaml, openidClient } = createVersionedLibraries();
function reinitializeVersionedLibrariesForTests() {
  const fresh = createVersionedLibraries();
  yaml = fresh.yaml;
  detectPort = fresh.detectPort;
  jsonwebtoken = fresh.jsonwebtoken;
  HttpProxyAgent = fresh.HttpProxyAgent;
  HttpsProxyAgent = fresh.HttpsProxyAgent;
  passportSaml = fresh.passportSaml;
  openidClient = fresh.openidClient;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HttpProxyAgent,
  HttpsProxyAgent,
  createVersionedLibraries,
  detectPort,
  jsonwebtoken,
  openidClient,
  passportSaml,
  reinitializeVersionedLibrariesForTests,
  yaml
});
