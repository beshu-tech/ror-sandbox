"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var yamlDocumentsMerger_exports = {};
__export(yamlDocumentsMerger_exports, {
  YamlDocumentsMerger: () => YamlDocumentsMerger
});
module.exports = __toCommonJS(yamlDocumentsMerger_exports);
const isYamlMap = (node) => {
  var _a;
  return !!node && ((_a = node.constructor) == null ? void 0 : _a.name) === "YAMLMap";
};
class YamlDocumentsMerger {
  /**
   * Merge `patch` into `base` with the following rules:
   * - If both documents have a map at the root, merge their entries by key:
   *   - For a new key found only in `patch`, add the whole key/value pair to `base`.
   *   - For an existing key present in both, replace the entire value in `base` with the value from `patch`.
   *   - For such existing keys, keep pair-level comments from `patch` and overwrite those in `base`.
   * - Root-level document comments (`commentBefore`) from `base` and `patch` are concatenated so that both are preserved.
   * - If root nodes are not both maps, replace the entire root of `base` with the root of `patch`.
   */
  mergeDocuments(base, patch) {
    const baseRoot = base.contents;
    const patchRoot = patch.contents;
    if (!this.hasMergeableRoots(baseRoot, patchRoot)) return base;
    this.mergeDocumentComments(base, patch);
    if (isYamlMap(baseRoot) && isYamlMap(patchRoot)) {
      this.applyMapPatch(baseRoot, patchRoot);
      return base;
    }
    this.replaceRoot(base, patchRoot);
    return base;
  }
  hasMergeableRoots(baseRoot, patchRoot) {
    return !!baseRoot && !!patchRoot;
  }
  mergeDocumentComments(base, patch) {
    const baseDocMeta = base;
    const patchDocMeta = patch;
    if (!patchDocMeta.commentBefore) return;
    if (baseDocMeta.commentBefore) {
      baseDocMeta.commentBefore = `${baseDocMeta.commentBefore}
${patchDocMeta.commentBefore}`;
    } else {
      baseDocMeta.commentBefore = patchDocMeta.commentBefore;
    }
  }
  replaceRoot(base, patchRoot) {
    var _a;
    const cloned = (_a = patchRoot.clone) == null ? void 0 : _a.call(patchRoot);
    if (!cloned) return;
    base.contents = cloned;
  }
  applyMapPatch(baseMap, patchMap) {
    var _a, _b;
    const patchItems = patchMap.items;
    for (const patchItem of patchItems) {
      const keyValue = this.getKeyAsString(patchItem);
      const baseItems = (_a = baseMap.items) != null ? _a : [];
      const existing = baseItems.find((p) => this.getKeyAsString(p) === keyValue);
      if (!existing) {
        const clonedPair = (_b = patchItem.clone) == null ? void 0 : _b.call(patchItem);
        baseMap.add(clonedPair || patchItem);
        continue;
      }
      this.applyPairPatch(existing, patchItem);
    }
  }
  getKeyAsString(pair) {
    const keyScalar = pair.key;
    if (keyScalar && Object.prototype.hasOwnProperty.call(keyScalar, "value") && keyScalar.value !== void 0) {
      return String(keyScalar.value);
    }
    return String(pair.key);
  }
  applyPairPatch(basePair, patchPair) {
    var _a, _b, _c;
    this.overwritePairComments(basePair, patchPair);
    const clonedValue = (_c = (_b = (_a = patchPair.value).clone) == null ? void 0 : _b.call(_a)) != null ? _c : patchPair.value;
    basePair.value = clonedValue;
  }
  overwritePairComments(basePair, patchPair) {
    const baseMeta = basePair;
    const patchMeta = patchPair;
    const baseKeyMeta = basePair.key;
    const patchKeyMeta = patchPair.key;
    if ((patchKeyMeta == null ? void 0 : patchKeyMeta.commentBefore) != null) {
      this.mergeCommentBefore(baseKeyMeta != null ? baseKeyMeta : baseMeta, patchKeyMeta);
    } else {
      this.mergeCommentBefore(baseMeta, patchMeta);
    }
    if (patchMeta.comment !== void 0 && patchMeta.comment !== null) {
      baseMeta.comment = patchMeta.comment;
    }
  }
  /**
   * Merges one canonical comment holder. YAML 1.x exposes a key comment through both the pair and
   * its key, so merging both holders would duplicate the comment.
   */
  mergeCommentBefore(baseMeta, patchMeta) {
    if (patchMeta.commentBefore == null || patchMeta.commentBefore === baseMeta.commentBefore) return;
    baseMeta.commentBefore = baseMeta.commentBefore ? `${baseMeta.commentBefore}
${patchMeta.commentBefore}` : patchMeta.commentBefore;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  YamlDocumentsMerger
});
