"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var cookieManager_exports = {};
__export(cookieManager_exports, {
  CookieManager: () => CookieManager
});
module.exports = __toCommonJS(cookieManager_exports);
var import_iron = __toESM(require("@hapi/iron"));
var import_rorLoggerFactory = require("./logging/rorLoggerFactory");
const _CookieManager = class _CookieManager {
  constructor(rorSettingsStore) {
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  async encryptRorCookie(sid) {
    const { cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    try {
      const cookieToBeEncrypted = { sid };
      return await import_iron.default.seal(cookieToBeEncrypted, cookieSettings.password, import_iron.default.defaults);
    } catch (error) {
      this.logger.error({ message: error.message, stack: error.stack });
      throw error;
    }
  }
  async decryptRorCookieFromHeader(cookieHeader) {
    const { cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    if (!cookieHeader) {
      return null;
    }
    const cookie = cookieHeader[cookieSettings.name];
    if (!cookie) {
      return null;
    }
    return this.decryptRorCookie(cookie);
  }
  async decryptRorCookie(cookie) {
    try {
      const { cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      const unsealedCookie = await import_iron.default.unseal(cookie, cookieSettings.password, import_iron.default.defaults);
      return unsealedCookie.sid;
    } catch (error) {
      this.logger.error({ message: error.message, stack: error.stack });
      this.logger.error({
        message: `"If you use more than one Kibana nodes (High availability configurations), you MUST share the same "readonlyrest_kbn.cookiePass" in ALL Kibana nodes. 
See documentation: https://docs.readonlyrest.com/kibana#session-management-with-multiple-kibana-instances`
      });
      return null;
    }
  }
  static getCookiesOptions(options) {
    var _a, _b, _c, _d;
    const maxAge = (_a = options == null ? void 0 : options.maxAge) != null ? _a : _CookieManager.INFINITE_COOKIE_DURATION_MILLIS;
    const sameSite = (_b = options == null ? void 0 : options.sameSite) != null ? _b : "lax";
    const httpOnly = (_c = options == null ? void 0 : options.httpOnly) != null ? _c : true;
    const secure = (_d = options == null ? void 0 : options.secure) != null ? _d : true;
    return { maxAge, sameSite, httpOnly, secure };
  }
  parseCookieHeader(cookieHeader) {
    if (!cookieHeader) {
      return null;
    }
    const cookies = cookieHeader.split("; ");
    const cookiesMap = /* @__PURE__ */ new Map();
    cookies.forEach((cookie) => {
      const cookieSplit = cookie.split("=");
      cookiesMap[cookieSplit[0]] = cookieSplit[1];
    });
    return cookiesMap;
  }
};
__publicField(_CookieManager, "INFINITE_COOKIE_DURATION_MILLIS", 2147483647 * 60 * 1e3);
let CookieManager = _CookieManager;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CookieManager
});
