"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var esHostBalancer_exports = {};
__export(esHostBalancer_exports, {
  EsHostBalancer: () => EsHostBalancer
});
module.exports = __toCommonJS(esHostBalancer_exports);
var import_http_errors = __toESM(require("http-errors"));
var import_distributionInfoProvider = require("../../kibana/patchers/distributionInfoProvider");
var import_authWrapper = require("./api/authWrapper");
var import_fetchExtension = require("./api/fetchExtension");
var import_rorLoggerFactory = require("./logging/rorLoggerFactory");
class EsHostBalancer {
  constructor(esHosts, networkParameters, kibanaTechUserEsAuthToken, esSSLConnectionProvider) {
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "esHosts");
    __publicField(this, "networkParameters");
    __publicField(this, "kibanaTechUserEsAuthToken");
    __publicField(this, "esSSLConnectionProvider");
    __publicField(this, "mostRecentlyActiveHostIndex");
    __publicField(this, "probe", async ({ authHeader }) => {
      const esUrl = this.getElasticsearchUrl();
      try {
        return await (0, import_fetchExtension.fetchWithTimeout)(
          esUrl,
          {
            headers: authHeader,
            agent: this.esSSLConnectionProvider.getConnectionAgent()
          },
          { timeout: this.networkParameters.pingTimeout }
        );
      } catch (error) {
        if (error.code === "ECONNREFUSED" || error.code === "ECONNRESET" || error.name === "AbortError") {
          this.circularIncrementHostsArray();
          throw (0, import_http_errors.default)(503, `Elasticsearch host ${esUrl} is unavailable`);
        }
        this.logger.error({ message: `Received unhandled error: ${error.message}`, stack: error.stack });
      }
    });
    this.esHosts = esHosts;
    this.networkParameters = networkParameters;
    this.kibanaTechUserEsAuthToken = kibanaTechUserEsAuthToken;
    this.esSSLConnectionProvider = esSSLConnectionProvider;
    this.mostRecentlyActiveHostIndex = 0;
    if (esHosts.length > 1 || import_distributionInfoProvider.DistributionInfoProvider.isEnvironmentDev()) {
      this.activateProbe();
    }
  }
  getElasticsearchUrl() {
    return this.esHosts[this.mostRecentlyActiveHostIndex];
  }
  activateProbe() {
    const probeAuthWrapper = new import_authWrapper.AuthWrapper(this.kibanaTechUserEsAuthToken, {
      probe: this.probe
    });
    setInterval(
      () => probeAuthWrapper.asTechnicalUser().probe().catch((error) => this.logger.error(error)),
      this.networkParameters.pingTimeout
    );
  }
  circularIncrementHostsArray() {
    this.mostRecentlyActiveHostIndex += 1;
    this.mostRecentlyActiveHostIndex %= this.esHosts.length;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  EsHostBalancer
});
