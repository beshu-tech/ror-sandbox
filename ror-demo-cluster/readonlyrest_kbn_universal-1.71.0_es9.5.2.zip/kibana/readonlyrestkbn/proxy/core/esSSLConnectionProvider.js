"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var esSSLConnectionProvider_exports = {};
__export(esSSLConnectionProvider_exports, {
  EsSSLConnectionProvider: () => EsSSLConnectionProvider,
  SSLCertificationType: () => SSLCertificationType,
  SSLVerificationMode: () => SSLVerificationMode
});
module.exports = __toCommonJS(esSSLConnectionProvider_exports);
var import_fs = __toESM(require("fs"));
var http = __toESM(require("http"));
var import_https = __toESM(require("https"));
var import_distributionInfoProvider = require("../../kibana/patchers/distributionInfoProvider");
var SSLCertificationType = /* @__PURE__ */ ((SSLCertificationType2) => {
  SSLCertificationType2[SSLCertificationType2["PEM"] = 0] = "PEM";
  SSLCertificationType2[SSLCertificationType2["PKC12"] = 1] = "PKC12";
  SSLCertificationType2[SSLCertificationType2["NONE"] = 2] = "NONE";
  return SSLCertificationType2;
})(SSLCertificationType || {});
var SSLVerificationMode = /* @__PURE__ */ ((SSLVerificationMode2) => {
  SSLVerificationMode2[SSLVerificationMode2["FULL"] = 0] = "FULL";
  SSLVerificationMode2[SSLVerificationMode2["CERTIFICATE"] = 1] = "CERTIFICATE";
  SSLVerificationMode2[SSLVerificationMode2["NONE"] = 2] = "NONE";
  return SSLVerificationMode2;
})(SSLVerificationMode || {});
class EsSSLConnectionProvider {
  constructor(elasticsearchSSLSettings) {
    __publicField(this, "certificateAuthorities");
    __publicField(this, "truststore");
    __publicField(this, "truststorePassword");
    __publicField(this, "verificationMode");
    __publicField(this, "connectionAgent");
    __publicField(this, "certificationType");
    this.verificationMode = elasticsearchSSLSettings.verificationMode ? SSLVerificationMode[elasticsearchSSLSettings.verificationMode.toUpperCase()] : 0 /* FULL */;
    if (!elasticsearchSSLSettings.sslEnabled) {
      this.connectionAgent = http.globalAgent;
      this.certificationType = 2 /* NONE */;
      this.verificationMode = 2 /* NONE */;
      return;
    }
    if (elasticsearchSSLSettings.certificateAuthorities) {
      this.setCertificationAuthorities(elasticsearchSSLSettings.certificateAuthorities);
      return;
    }
    if (elasticsearchSSLSettings.truststorePath) {
      this.setTruststore(elasticsearchSSLSettings.truststorePath, elasticsearchSSLSettings.truststorePassword);
      return;
    }
    this.setNoCertificationSSL();
  }
  getConnectionAgent() {
    return this.connectionAgent;
  }
  getCertificationType() {
    return this.certificationType;
  }
  getCertificateAuthorities() {
    return this.certificateAuthorities;
  }
  getTruststore() {
    return {
      truststore: this.truststore,
      password: this.truststorePassword
    };
  }
  isVerificationEnabled() {
    return !import_distributionInfoProvider.DistributionInfoProvider.isEnvironmentDev() && this.verificationMode !== 2 /* NONE */;
  }
  setCertificationAuthorities(caPaths) {
    this.certificateAuthorities = [];
    caPaths.forEach((path) => {
      var _a;
      return (_a = this.certificateAuthorities) == null ? void 0 : _a.push(import_fs.default.readFileSync(path));
    });
    const options = {
      ca: this.certificateAuthorities,
      rejectUnauthorized: this.isVerificationEnabled()
    };
    this.connectionAgent = new import_https.default.Agent(options);
    this.certificationType = 0 /* PEM */;
  }
  setTruststore(truststorePath, truststorePassword) {
    this.truststore = import_fs.default.readFileSync(truststorePath);
    this.truststorePassword = truststorePassword;
    const options = {
      pfx: this.truststore,
      passphrase: this.truststorePassword,
      rejectUnauthorized: this.isVerificationEnabled()
    };
    this.connectionAgent = new import_https.default.Agent(options);
    this.certificationType = 1 /* PKC12 */;
  }
  setNoCertificationSSL() {
    this.certificationType = 2 /* NONE */;
    const options = {
      rejectUnauthorized: this.isVerificationEnabled()
    };
    this.connectionAgent = new import_https.default.Agent(options);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  EsSSLConnectionProvider,
  SSLCertificationType,
  SSLVerificationMode
});
