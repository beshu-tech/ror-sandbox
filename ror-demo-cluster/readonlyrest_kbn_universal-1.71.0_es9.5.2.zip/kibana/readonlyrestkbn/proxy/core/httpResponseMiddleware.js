"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var httpResponseMiddleware_exports = {};
__export(httpResponseMiddleware_exports, {
  setNoCacheHeadersMiddleware: () => setNoCacheHeadersMiddleware,
  setSecurityHeadersMiddleware: () => setSecurityHeadersMiddleware
});
module.exports = __toCommonJS(httpResponseMiddleware_exports);
const CSP_BASE = "script-src 'self' 'unsafe-inline'; worker-src 'self' blob:; style-src 'self' 'unsafe-inline'; img-src * data:; object-src 'none'; base-uri 'self'; form-action 'self'";
function setSecurityHeadersMiddleware(config) {
  const csp = config.disableEmbedding ? `${CSP_BASE}; frame-ancestors 'self'` : CSP_BASE;
  return (_, res, next) => {
    res.setHeader("Content-Security-Policy", csp);
    if (config.tlsEnabled && config.strictTransportSecurity) {
      res.setHeader("Strict-Transport-Security", config.strictTransportSecurity);
    }
    if (config.xContentTypeOptions) {
      res.setHeader("X-Content-Type-Options", config.xContentTypeOptions);
    }
    if (config.referrerPolicy) {
      res.setHeader("Referrer-Policy", config.referrerPolicy);
    }
    if (config.permissionsPolicy) {
      res.setHeader("Permissions-Policy", config.permissionsPolicy);
    }
    if (config.permissionsPolicyReportOnly) {
      res.setHeader("Permissions-Policy-Report-Only", config.permissionsPolicyReportOnly);
    }
    if (config.crossOriginOpenerPolicy) {
      res.setHeader("Cross-Origin-Opener-Policy", config.crossOriginOpenerPolicy);
    }
    if (config.disableEmbedding) {
      res.setHeader("X-Frame-Options", "SAMEORIGIN");
    }
    next();
  };
}
function setNoCacheHeadersMiddleware(includeVary = true) {
  return (_, res, next) => {
    res.setHeader("Cache-Control", "no-store, max-age=0");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    if (includeVary) {
      res.setHeader("Vary", "Cookie");
    }
    next();
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  setNoCacheHeadersMiddleware,
  setSecurityHeadersMiddleware
});
