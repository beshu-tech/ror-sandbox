"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var identitySession_exports = {};
__export(identitySession_exports, {
  IdentitySessionMetadataDifferenceChecker: () => IdentitySessionMetadataDifferenceChecker,
  isIdentitySessionMetadataUserWithGroups: () => isIdentitySessionMetadataUserWithGroups
});
module.exports = __toCommonJS(identitySession_exports);
var import_lodash = require("lodash");
var import_accessLevel = require("../../shared/types/accessLevel");
function isIdentitySessionMetadataUserWithGroups(identitySessionMetadata) {
  return (identitySessionMetadata == null ? void 0 : identitySessionMetadata.type) === "USER_WITH_GROUPS";
}
class IdentitySessionMetadataDifferenceChecker {
  static isDifferent(currentUserRequestIdentityMetadata, newSession, currentlyAvailableTenancies) {
    var _a;
    const currentUserGroupId = (_a = currentUserRequestIdentityMetadata.currentGroup) == null ? void 0 : _a.id;
    if (newSession.type === "USER_WITH_GROUPS") {
      const newSessionCurrentTenancy = newSession.groups.find(({ group }) => group.id === currentUserGroupId);
      if (!newSessionCurrentTenancy) {
        return true;
      }
      const newSessionTenancies = newSession.groups.map(({ group }) => group);
      return !IdentitySessionMetadataDifferenceChecker.fieldsCompareWithGroups(
        newSessionCurrentTenancy,
        currentUserRequestIdentityMetadata,
        newSessionTenancies,
        currentlyAvailableTenancies
      );
    }
    return !IdentitySessionMetadataDifferenceChecker.fieldsCompareWithoutGroups(
      newSession,
      currentUserRequestIdentityMetadata
    );
  }
  static isMissingMetadata(currentUserRequestIdentityMetadata, newSession) {
    var _a, _b;
    const currentUserGroupId = (_a = currentUserRequestIdentityMetadata.currentGroup) == null ? void 0 : _a.id;
    if (newSession.type === "USER_WITH_GROUPS") {
      const usernameInNewSessionCurrentGroup = (_b = newSession.groups.find(
        ({ group }) => group.id === currentUserGroupId
      )) == null ? void 0 : _b.username;
      return Boolean(!usernameInNewSessionCurrentGroup);
    }
    return Boolean(!newSession.username);
  }
  static isEqual(a1, a2) {
    return (0, import_lodash.isEqual)(Array.from(a1).sort(), Array.from(a2).sort());
  }
  static areGroupsEqual(a1, a2) {
    const compareFn = (g1, g2) => g1.id.localeCompare(g2.id);
    return (0, import_lodash.isEqual)(Array.from(a1).sort(compareFn), Array.from(a2).sort(compareFn));
  }
  static fieldsCompareWithGroups(tenancy, userRequestIdentityMetadata, newSessionTenancies, currentlyAvailableTenancies) {
    var _a, _b, _c, _d, _e, _f;
    return tenancy.username === userRequestIdentityMetadata.username && ((_b = (_a = tenancy == null ? void 0 : tenancy.kibana) == null ? void 0 : _a.access) != null ? _b : import_accessLevel.AccessLevel.UNRESTRICTED) === userRequestIdentityMetadata.kibanaAccess && (0, import_lodash.isEqual)(tenancy.group, userRequestIdentityMetadata.currentGroup) && ((_c = tenancy == null ? void 0 : tenancy.kibana) == null ? void 0 : _c.index) === userRequestIdentityMetadata.kibanaIndex && IdentitySessionMetadataDifferenceChecker.areGroupsEqual(newSessionTenancies, currentlyAvailableTenancies) && IdentitySessionMetadataDifferenceChecker.isEqual(
      (_e = (_d = tenancy == null ? void 0 : tenancy.kibana) == null ? void 0 : _d.hidden_apps) != null ? _e : [],
      (_f = userRequestIdentityMetadata.kibanaHiddenApps) != null ? _f : []
    );
  }
  static fieldsCompareWithoutGroups(userGroup, userRequestIdentityMetadata) {
    var _a, _b, _c, _d, _e, _f;
    return userGroup.username === userRequestIdentityMetadata.username && ((_b = (_a = userGroup == null ? void 0 : userGroup.kibana) == null ? void 0 : _a.access) != null ? _b : import_accessLevel.AccessLevel.UNRESTRICTED) === userRequestIdentityMetadata.kibanaAccess && ((_c = userGroup == null ? void 0 : userGroup.kibana) == null ? void 0 : _c.index) === userRequestIdentityMetadata.kibanaIndex && IdentitySessionMetadataDifferenceChecker.isEqual(
      (_e = (_d = userGroup == null ? void 0 : userGroup.kibana) == null ? void 0 : _d.hidden_apps) != null ? _e : [],
      (_f = userRequestIdentityMetadata.kibanaHiddenApps) != null ? _f : []
    );
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  IdentitySessionMetadataDifferenceChecker,
  isIdentitySessionMetadataUserWithGroups
});
