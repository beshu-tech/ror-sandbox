"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var identitySessionBuilder_exports = {};
__export(identitySessionBuilder_exports, {
  IdentitySessionBuilder: () => IdentitySessionBuilder
});
module.exports = __toCommonJS(identitySessionBuilder_exports);
var import_uuid = require("uuid");
var import_userMetadataValidator = require("./userMetadata/userMetadataValidator");
class IdentitySessionBuilder {
  constructor(multiTenancyChecker, licenseService, userMetadataResolver) {
    this.userMetadataResolver = userMetadataResolver;
    __publicField(this, "userMetadataValidator");
    this.userMetadataValidator = new import_userMetadataValidator.UserMetadataValidator(multiTenancyChecker, licenseService);
  }
  async createIdentitySession(identitySessionHeaders, whitelistedHeaders, responseData, lastSessionActivityDate, expiresAt, impersonatedBy) {
    const sid = (0, import_uuid.v4)();
    const identityMetadata = this.buildIdentitySessionMetadata({
      identitySessionHeaders,
      whitelistedHeaders,
      responseData,
      lastSessionActivityDate,
      impersonatedBy,
      expiresAt
    });
    return {
      sid,
      metadata: identityMetadata
    };
  }
  buildIdentitySessionMetadata({
    identitySessionHeaders,
    whitelistedHeaders,
    responseData,
    lastSessionActivityDate,
    impersonatedBy,
    expiresAt
  }) {
    this.userMetadataValidator.validate(responseData);
    const { correlation_id, ...identitySessionFromRequest } = responseData;
    return this.userMetadataResolver.resolveSessionMetadata({
      ...identitySessionFromRequest,
      expiresAt,
      lastSessionActivityDate,
      identitySessionHeaders,
      whitelistedHeaders,
      impersonatedBy,
      correlationId: correlation_id
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  IdentitySessionBuilder
});
