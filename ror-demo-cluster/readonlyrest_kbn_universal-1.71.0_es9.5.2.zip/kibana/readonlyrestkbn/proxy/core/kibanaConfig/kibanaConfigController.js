"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var kibanaConfigController_exports = {};
__export(kibanaConfigController_exports, {
  KibanaConfigController: () => KibanaConfigController
});
module.exports = __toCommonJS(kibanaConfigController_exports);
var import_child_process = require("child_process");
var import_path = __toESM(require("path"));
var import_fs_extra = __toESM(require("fs-extra"));
var import_lodash = require("lodash");
var import_errors = __toESM(require("../../constants/errors"));
var import_versionedLibraries = require("../common/versionedLibraries");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
class KibanaConfigController {
  constructor() {
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  findKibanaProcess(kibanaPort) {
    return new Promise((resolve, reject) => {
      const commands = {
        linux: [
          `lsof -i :${kibanaPort} -sTCP:LISTEN`,
          `ss -lptn src :${kibanaPort}`,
          `netstat -tunlp | grep ${kibanaPort}`
        ],
        darwin: [`lsof -i :${kibanaPort} -sTCP:LISTEN`, `netstat -anv | grep ${kibanaPort}`],
        win32: [`netstat -ano | findstr :${kibanaPort}`]
      };
      const platformCommands = commands[process.platform] || commands.linux;
      const tryNextCommand = (index) => {
        if (index >= platformCommands.length) {
          return reject(new Error("Could not find Kibana process - required tools not available"));
        }
        (0, import_child_process.exec)(platformCommands[index], (error, stdout) => {
          var _a;
          if (error || !stdout.trim()) {
            return tryNextCommand(index + 1);
          }
          try {
            let pid;
            if (process.platform === "win32") {
              const match = /LISTENING\s+(\d+)/i.exec(stdout);
              pid = match ? match[1] : null;
            } else if (process.platform === "darwin") {
              const lines = stdout.trim().split("\n");
              const line = lines.find((l) => l.includes("node") && !l.includes("grep"));
              pid = line ? line.split(/\s+/)[1] : null;
            } else {
              const lines = stdout.trim().split("\n");
              let line;
              if (platformCommands[index].startsWith("lsof")) {
                line = lines.find((l) => l.includes("node") && !l.includes("grep"));
                pid = line ? line.split(/\s+/)[1] : null;
              } else if (platformCommands[index].startsWith("ss")) {
                line = lines.find((l) => l.includes("node") && l.includes(kibanaPort.toString()));
                pid = line ? (_a = /pid=(\d+)/.exec(line)) == null ? void 0 : _a[1] : null;
              } else {
                line = lines.find((l) => l.includes("node") && l.includes(kibanaPort.toString()));
                pid = line ? line.split(/\s+/)[6].split("/")[0] : null;
              }
            }
            if (pid) {
              resolve(pid);
            } else {
              tryNextCommand(index + 1);
            }
          } catch {
            tryNextCommand(index + 1);
          }
        });
      };
      tryNextCommand(0);
    });
  }
  restartKibanaProcess(pid) {
    return new Promise((resolve, reject) => {
      try {
        process.kill(Number(pid), "SIGINT");
        this.logger.info(`Successfully sent SIGINT to Kibana process ${pid}`);
        resolve();
      } catch (error) {
        reject(new Error(`Failed to restart Kibana: ${error.message}`));
      }
    });
  }
  async getKibanaRootDir() {
    var _a;
    const pluginRootDir = import_path.default.resolve(__dirname, "../../../");
    const relativeRootDir = import_path.default.resolve(pluginRootDir, "../..");
    try {
      const packageJsonPath = import_path.default.join(relativeRootDir, "package.json");
      if (await import_fs_extra.default.pathExists(packageJsonPath)) {
        const packageJson = await import_fs_extra.default.readJson(packageJsonPath);
        if (packageJson.name === "kibana" || ((_a = packageJson.description) == null ? void 0 : _a.includes("Kibana"))) {
          this.logger.info(`Found Kibana root at relative path: ${relativeRootDir}`);
          return relativeRootDir;
        }
      }
    } catch (error) {
      this.logger.debug(`Could not verify Kibana root at relative path: ${error.message}`);
    }
    throw new Error("Could not locate Kibana root directory");
  }
  getParsedKibanaConfig(newConfigContent) {
    const tempParsedConfigContent = import_versionedLibraries.yaml.parse(newConfigContent);
    return (0, import_lodash.isObject)(tempParsedConfigContent) ? import_versionedLibraries.yaml.stringify(tempParsedConfigContent) : tempParsedConfigContent;
  }
  async createConfigBackup(configPath) {
    try {
      const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
      const backupPath = `${configPath}.backup-${timestamp}`;
      await import_fs_extra.default.copyFile(configPath, backupPath);
      this.logger.info(`Created backup of Kibana config at: ${backupPath}`);
      return backupPath;
    } catch (error) {
      this.logger.error({ message: `Failed to create config backup: ${error.message}`, stack: error.stack });
      throw error;
    }
  }
  async updateKibanaConfigFile(newConfigContent) {
    try {
      const parsedNewConfigContent = this.getParsedKibanaConfig(newConfigContent);
      const rootDir = await this.getKibanaRootDir();
      const configFolderPath = import_path.default.join(rootDir, "config");
      const configFilePath = import_path.default.join(configFolderPath, "kibana.yml");
      if (await import_fs_extra.default.pathExists(configFolderPath)) {
        try {
          await import_fs_extra.default.access(configFolderPath, import_fs_extra.default.constants.W_OK);
        } catch (accessError) {
          const errorMsg = import_errors.default.insufficientPermissions(configFolderPath);
          this.logger.error({ message: errorMsg, stack: accessError.stack });
          return { error: "Failure", message: errorMsg, status: "INSUFFICIENT_PERMISSIONS", statusCode: 500 };
        }
        const existingConfig = await import_fs_extra.default.readFile(configFilePath, { encoding: "utf8" });
        if (existingConfig === parsedNewConfigContent) {
          this.logger.info(`Kibana config unchanged at: ${configFilePath}`);
          return {
            error: "Failure",
            message: import_errors.default.configFileUnchanged(configFilePath),
            status: "CONFIG_UNCHANGED",
            statusCode: 200
          };
        }
        await this.createConfigBackup(configFilePath);
        await import_fs_extra.default.writeFile(configFilePath, parsedNewConfigContent, { encoding: "utf8" });
        this.logger.info(`Successfully updated Kibana config at: ${configFilePath}`);
        return { status: "SUCCESS", message: "ok", statusCode: 200 };
      }
      return {
        error: "Failure",
        message: import_errors.default.configFileNotFound(configFilePath),
        status: "CONFIG_FILE_NOT_FOUND",
        statusCode: 500
      };
    } catch (error) {
      this.logger.error({ message: `Failed to update Kibana config: ${error.message}`, stack: error.stack });
      throw error;
    }
  }
  isErrorResponse(response) {
    return response && typeof response === "object" && "error" in response && "message" in response && "statusCode" in response;
  }
  async handleUpdateKibanaConfig(req, res, kibanaPort) {
    try {
      const response = await this.updateKibanaConfigFile(req.body);
      if (this.isErrorResponse(response)) {
        return res.status(response.statusCode).json(response);
      }
      const pid = await this.findKibanaProcess(kibanaPort);
      await this.restartKibanaProcess(pid);
      const successStatusCode = 200;
      return res.status(successStatusCode).json({
        status: "SUCCESS",
        statusCode: successStatusCode,
        message: "ok"
      });
    } catch (e) {
      this.logger.error({ message: `Process error: ${e.message}`, stack: e.stack });
      const errorStatusCode = 500;
      res.status(errorStatusCode);
      return res.json({
        status: "INTERNAL_SERVER_ERROR",
        error: "Failure",
        statusCode: errorStatusCode,
        message: e.message
      });
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KibanaConfigController
});
