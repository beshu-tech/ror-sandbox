"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var lazyUtils_exports = {};
__export(lazyUtils_exports, {
  executeWithInterval: () => executeWithInterval,
  retryUntilOk: () => retryUntilOk
});
module.exports = __toCommonJS(lazyUtils_exports);
var import_rorLoggerFactory = require("./logging/rorLoggerFactory");
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const executeWithInterval = async (fn, interval) => {
  let stopped = false;
  let timeoutId;
  const run = async () => {
    if (stopped) {
      return;
    }
    try {
      await fn();
    } catch (e) {
      logger.error({
        message: "Caught an error in executeWithInterval",
        stack: e == null ? void 0 : e.stack
      });
    }
    if (!stopped) {
      timeoutId = setTimeout(run, interval);
    }
  };
  await run();
  return {
    stop: () => {
      stopped = true;
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    }
  };
};
const retryUntilOk = async (fn, { maxRetries, retryInterval }, onRetry, shouldRetry = () => true) => {
  const result = await fn();
  if (result.ok || maxRetries === 0 || !shouldRetry(result.error)) {
    return result;
  }
  onRetry == null ? void 0 : onRetry(result.error, maxRetries);
  await new Promise((resolve) => {
    setTimeout(resolve, retryInterval);
  });
  return retryUntilOk(fn, { maxRetries: maxRetries - 1, retryInterval }, onRetry, shouldRetry);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  executeWithInterval,
  retryUntilOk
});
