"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var FeaturesCompliance_exports = {};
__export(FeaturesCompliance_exports, {
  FeaturesCompliance: () => FeaturesCompliance
});
module.exports = __toCommonJS(FeaturesCompliance_exports);
var import_ActivationKey = require("../../../shared/types/ActivationKey");
class FeaturesCompliance {
  constructor(license) {
    __publicField(this, "isFree");
    __publicField(this, "isEnterprise");
    this.isFree = (0, import_ActivationKey.isFreeLicense)(license);
    this.isEnterprise = (0, import_ActivationKey.isEnterpriseLicense)(license);
  }
  verify(enterpriseOnly, nonFreeOnly) {
    const errors = [];
    enterpriseOnly.forEach((rule) => {
      const error = this.enterpriseOnly(rule.message, rule.value);
      if (error) {
        errors.push(error);
      }
    });
    nonFreeOnly.forEach((rule) => {
      const error = this.nonFreeOnly(rule.message, rule.value);
      if (error) {
        errors.push(error);
      }
    });
    return errors;
  }
  enterpriseOnly(featureName, value) {
    if (this.isEnterprise) {
      return null;
    }
    return this.hasValue(value, `"${featureName}" is only available for Enterprise subscribers.`);
  }
  hasValue(value, message) {
    const err = `\u274C ${message}`;
    if (Array.isArray(value)) {
      return value.length > 0 ? err : null;
    }
    return value ? err : null;
  }
  nonFreeOnly(featureName, value) {
    if (!this.isFree) {
      return null;
    }
    return this.hasValue(value, `"${featureName}" is only available for PRO and Enterprise subscribers.`);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  FeaturesCompliance
});
