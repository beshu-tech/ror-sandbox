"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var LicenseController_exports = {};
__export(LicenseController_exports, {
  LicenseController: () => LicenseController
});
module.exports = __toCommonJS(LicenseController_exports);
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
class LicenseController {
  constructor(licenseService, rorSettingsStore) {
    this.licenseService = licenseService;
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  async handleGetClusterUUID(req, res) {
    this.logger.info("Received GET CLUSTER UUID request");
    return res.json({ status_code: 200, status: "ok", cluster_uuid: await this.licenseService.getClusterUUID() });
  }
  handleGet(req, res) {
    const activationKey = this.licenseService.getActivationKey();
    if (!activationKey) {
      res.status(404);
      return res.json({ status_code: 404, status: "not found", message: "empty license, please add a license." });
    }
    return res.json(activationKey);
  }
  async handleDelete(req, res, onSuccess) {
    this.logger.info("Received token delete request");
    try {
      const existing = this.licenseService.getActivationKey();
      const {
        licenseSettings,
        cookieSettings: { password: storeEncryptionKey }
      } = this.rorSettingsStore.getLatestRorKbnSettings();
      const info = await this.licenseService.deleteAndReloadLicense(licenseSettings, storeEncryptionKey);
      res.status(200);
      onSuccess(existing.license.edition !== info.license.edition);
      return res.json({ status_code: 200, status: "ok" });
    } catch (e) {
      this.logger.error({ message: `Failed to delete license token: ${e.message}`, stack: e.stack });
      res.status(500);
      return res.json({ status_code: 500, status: "ko", message: e.message });
    }
  }
  async handleAdd(req, res, onSuccess) {
    this.logger.info("Received token add request. Local cluster_uuid is: ", this.licenseService.getClusterUUID());
    const token = req.body.token;
    if (!token) {
      this.logger.error({ message: "Called add token, but no token received: " }, req.body);
      res.status(400);
      return res.json({ status_code: 400, status: "bad request", message: "empty input" });
    }
    try {
      const existing = this.licenseService.getActivationKey();
      if (!existing || existing && req.query.overwrite) {
        const {
          cookieSettings: { password: storeEncryptionKey }
        } = this.rorSettingsStore.getLatestRorKbnSettings();
        this.logger.info(`Adding activation key ${token.substring(0, 10)}...`);
        const info = await this.licenseService.saveToken(token, storeEncryptionKey);
        this.logger.info(`Found valid activation key: ID=${info.jti}`);
        res.status(200);
        onSuccess(existing.license.edition !== info.license.edition);
        return res.json({ status_code: 200, status: "saved", license: info });
      }
      this.logger.info("License token already exists, but overwrite not requested");
      res.status(304);
      return res.json({ status_code: 304, status: "unmodified", license: existing });
    } catch (e) {
      this.logger.error({ message: `Failed to add license token: ${e.message}`, stack: e.stack });
      const reason = ["LICENSE_KEY_EXPIRED", "LICENSE_KEY_MALFORMED", "INVALID_JWT", "INVALID_JWT_SIGNATURE"];
      if (reason.includes(e.name)) {
        res.status(400);
        return res.json({ status_code: 400, status: e.name, message: e.message });
      }
      res.status(500);
      return res.json({ status_code: 500, status: e.name, message: e.message });
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LicenseController
});
