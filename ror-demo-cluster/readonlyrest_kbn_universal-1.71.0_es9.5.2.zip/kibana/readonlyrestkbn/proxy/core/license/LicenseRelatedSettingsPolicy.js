"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var LicenseRelatedSettingsPolicy_exports = {};
__export(LicenseRelatedSettingsPolicy_exports, {
  LicenseRelatedSettingsPolicy: () => LicenseRelatedSettingsPolicy
});
module.exports = __toCommonJS(LicenseRelatedSettingsPolicy_exports);
var import_lodash = require("lodash");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_FeaturesCompliance = require("./FeaturesCompliance");
class LicenseRelatedSettingsPolicy {
  constructor(license) {
    this.license = license;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  validate(rorKbnSettings) {
    const errors = this.validateCompliance(rorKbnSettings, this.license);
    if ((0, import_lodash.isEmpty)(errors)) {
      return { ok: true, data: void 0 };
    }
    return { ok: false, error: errors };
  }
  validateCompliance(rorKbnSettings, license) {
    var _a, _b;
    const featuresCompliance = new import_FeaturesCompliance.FeaturesCompliance(license);
    const errors = featuresCompliance.verify(
      [
        { message: "SAML authentication", value: (_a = rorKbnSettings.authSettings) == null ? void 0 : _a.samlRawSettingsList },
        { message: "OIDC authentication", value: (_b = rorKbnSettings.authSettings) == null ? void 0 : _b.oidcRawSettingsList },
        { message: "Tenancy Templating", value: rorKbnSettings.kibanaTemplateIndex },
        { message: "Custom CSS/JS Injections", value: rorKbnSettings.customUXCodeInjection },
        {
          message: "Custom middleware",
          value: rorKbnSettings.customMiddlewareInject || rorKbnSettings.customMiddlewareInjectFile
        }
      ],
      [{ message: "Login page customizations", value: rorKbnSettings.loginPageCustomizations }]
    );
    if (errors.length > 0) {
      this.logger.error({
        message: `FATAL: Current Activation Key is for a "${license.edition_name}" license. Your kibana.yml enables features that are not available at this subscription level. You can upgrade to an Enterprise license at https://readonlyrest.com`
      });
      return errors;
    }
    return [];
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LicenseRelatedSettingsPolicy
});
