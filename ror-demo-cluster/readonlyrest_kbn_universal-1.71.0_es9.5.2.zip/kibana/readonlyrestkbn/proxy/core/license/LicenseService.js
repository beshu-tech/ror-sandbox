"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var LicenseService_exports = {};
__export(LicenseService_exports, {
  LicenseService: () => LicenseService
});
module.exports = __toCommonJS(LicenseService_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_ms = __toESM(require("ms"));
var import_rxjs = require("rxjs");
var import_uuid = require("uuid");
var import_ActivationKey = require("../../../shared/types/ActivationKey");
var import_errors = __toESM(require("../../constants/errors"));
var import_versionedLibraries = require("../common/versionedLibraries");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_ActivationKeyCipher = require("./ActivationKeyCipher");
var import_LicenseRelatedSettingsPolicy = require("./LicenseRelatedSettingsPolicy");
class LicenseService {
  constructor(esApiClientWithAuthProvider, tokenPublicKey) {
    this.esApiClientWithAuthProvider = esApiClientWithAuthProvider;
    this.tokenPublicKey = tokenPublicKey;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "refreshSub");
    __publicField(this, "activationKey$", new import_rxjs.BehaviorSubject(null));
    __publicField(this, "onLicenseChanged$", this.activationKey$.pipe(
      (0, import_rxjs.map)((key) => key == null ? void 0 : key.license),
      (0, import_rxjs.filter)((license) => license != null),
      (0, import_rxjs.distinctUntilChanged)((a, b) => a.edition === b.edition)
    ));
    __publicField(this, "DEFAULT_ACTIVATION_KEY", "eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzUxMiJ9.eyJleHAiOjg4MDYxMjEyODAwLCJpc3MiOiJodHRwczovL2FwaS5iZXNodS50ZWNoIiwiaWF0IjoxNjYxMzU2MTAxLCJqdGkiOiJyb3JfbGljXzI1YjJhYWE4LTE0MDEtNGI4Zi04ZDBmLTZjMzE3ZjliYTY3MCIsImF1ZCI6InJlYWRvbmx5cmVzdF9rYm4iLCJzdWIiOiIxMTExMTExMS0xMTExLTExMTEtMTExMS0xMTExMTExMSIsImxpY2Vuc29yIjp7Im5hbWUiOiJCZXNodSBMaW1pdGVkIHQvYSBSZWFkb25seVJFU1QgU2VjdXJpdHkiLCJjb250YWN0IjpbInN1cHBvcnRAcmVhZG9ubHlyZXN0LmNvbSIsImZpbmFuY2VAcmVhZG9ubHlyZXN0LmNvbSJdLCJpc3N1ZXIiOiJzdXBwb3J0QHJlYWRvbmx5cmVzdC5jb20ifSwibGljZW5zZWUiOnsibmFtZSI6IkFub255bW91cyBGcmVlIFVzZXIiLCJidXlpbmdfZm9yIjpudWxsLCJiaWxsaW5nX2VtYWlsIjoidW5rbm93bkByb3JmcmVlLmNvbSIsImFsdF9lbWFpbHMiOltdLCJhZGRyZXNzIjpbIlVua25vd24iXX0sImxpY2Vuc2UiOnsiY2x1c3Rlcl91dWlkIjoiKiIsImVkaXRpb24iOiJrYm5fZnJlZSIsImVkaXRpb25fbmFtZSI6IkZyZWUiLCJpc1RyaWFsIjpmYWxzZX19.AUpJKXec7Ed7z6v9SsK3ingQIN8WGZDEMXC5cDn2cLeWsPopwtcfXncptYUXfFUV6diJG-pFpVC41xKHBrZetVIlAcH5OJCEWIlxzMho-WrwDn8rjpTcVDE8tW_JCoE0uteTOLXy97V8vDdyW5pmJQjb7pUd2zvECxGjwFxVsrdsBDkg");
    __publicField(this, "LICENSE_INDEX_NAME", ".readonlyrest_license");
    __publicField(this, "CLUSTER_READY_POLL_INTERVAL", 4e3);
    __publicField(this, "ACTIVATION_KEY_ENV_VAR", "ROR_ACTIVATION_KEY");
    __publicField(this, "clusterUuid", "");
  }
  toString() {
    return "< LicenseService instance >";
  }
  static toLoggableActivationKey(info) {
    var _a, _b, _c, _d, _e;
    const clone = JSON.parse(JSON.stringify(info));
    (_a = clone.licensee) == null ? true : delete _a.billing_email;
    (_b = clone.licensee) == null ? true : delete _b.alt_emails;
    (_c = clone.licensee) == null ? true : delete _c.address;
    (_d = clone.licensor) == null ? true : delete _d.issuer;
    (_e = clone.licensor) == null ? true : delete _e.contact;
    delete clone.iss;
    delete clone.aud;
    return clone;
  }
  isInitialisedOrDie() {
    if (!this.clusterUuid) {
      throw new Error("LicenseService is not initialised yet: empty clusterUuid");
    }
    if (!this.activationKey$.getValue()) {
      throw new Error("LicenseService is not initialised yet: empty ActivationKey");
    }
  }
  async init() {
    if (this.clusterUuid) {
      return;
    }
    const wait = function(ms2 = 1e3) {
      return new Promise((resolve) => {
        setTimeout(resolve, ms2);
      });
    };
    const poll = async function(fn, fnCondition, ms2) {
      let result = await fn();
      while (!fnCondition(result)) {
        await wait(ms2);
        result = await fn();
      }
      return result;
    };
    const attempt = async () => {
      this.logger.debug("Trying to get cluster UUID");
      try {
        const res = await this.esApiClientWithAuthProvider.asTechnicalUser().getClusterStatistics();
        if (res.status !== 200) {
          this.logger.info(`>> Cannot get the cluster stats. Got status: ${res.status}`);
          return;
        }
        const body = await res.json();
        this.clusterUuid = body.cluster_uuid;
        return this.clusterUuid;
      } catch (e) {
        this.logger.error({ message: e.message, stack: e.stack });
      }
    };
    await poll(attempt, () => !!this.clusterUuid, this.CLUSTER_READY_POLL_INTERVAL);
    this.logger.info(`Found ES cluster with UUID=${this.clusterUuid}`);
  }
  getClusterUUID() {
    this.isInitialisedOrDie();
    return this.clusterUuid;
  }
  getActivationKey() {
    this.isInitialisedOrDie();
    return this.activationKey$.getValue();
  }
  getLicenseEdition() {
    return this.getLicenseInfo().license.edition;
  }
  getLicenseInfo() {
    this.isInitialisedOrDie();
    const activationKey = this.activationKey$.getValue();
    return {
      license: { edition: activationKey.license.edition, edition_name: activationKey.license.edition_name },
      exp: activationKey.exp
    };
  }
  configureRorSettings(licenseSettings, storeEncryptionKey) {
    var _a;
    (_a = this.refreshSub) == null ? void 0 : _a.unsubscribe();
    this.refreshSub = (0, import_rxjs.timer)(0, (0, import_ms.default)(licenseSettings.activationKeyRefreshInterval)).pipe(
      (0, import_rxjs.switchMap)(async () => {
        var _a2;
        const previousEdition = (_a2 = this.activationKey$.getValue()) == null ? void 0 : _a2.license.edition;
        const newActivationKey = await this.retrieveActivationKey(
          licenseSettings,
          storeEncryptionKey,
          (message) => this.logger.debug(message)
        );
        this.logger.trace(
          `Activation key refreshed. Previous edition ${previousEdition}, new license ${newActivationKey.license.edition}`
        );
        return newActivationKey;
      })
    ).subscribe((activationKey) => {
      this.activationKey$.next(activationKey);
    });
  }
  async getLicenseRelatedSettingsPolicy(licenseSettings, storeEncryptionKey) {
    try {
      const activationKey = await this.retrieveActivationKey(licenseSettings, storeEncryptionKey);
      this.logger.debug("Activation key retrieving:", activationKey);
      return {
        ok: true,
        data: {
          licenseRelatedSettingsPolicy: new import_LicenseRelatedSettingsPolicy.LicenseRelatedSettingsPolicy(activationKey.license),
          license: activationKey.license
        }
      };
    } catch (e) {
      this.logger.error({ message: `Failed to retrieve activation key: ${e.message}`, stack: e.stack });
      return { ok: false, error: e.message };
    }
  }
  async retrieveActivationKey(licenseSettings, storeEncryptionKey, defaultActivationKeyLogLevel = (message) => this.logger.info(message)) {
    const conditionalLoaders = [
      ["index", () => this.loadAndReconcileKeyFromIndex(licenseSettings, storeEncryptionKey)],
      ["env", () => this.loadKeyFromEnv()],
      ["file", () => this.loadKeyFromFile(licenseSettings)]
    ];
    const loaders = [
      ...conditionalLoaders.filter(([mode]) => this.canRetrieveFrom(mode, licenseSettings)).map(([, loader]) => loader),
      () => this.loadDefaultKey(defaultActivationKeyLogLevel)
    ];
    try {
      const key = await loaders.reduce(
        (acc, load) => acc.then((found) => found != null ? found : load()),
        Promise.resolve(null)
      );
      if (key === null) throw new Error("No activation key available");
      return key;
    } catch (e) {
      this.logger.warn("Error retrieving license info: ", e.message);
      throw e;
    }
  }
  async loadAndReconcileKeyFromIndex(licenseSettings, storeEncryptionKey) {
    const tokenResult = await this.getTokenFromIndex(licenseSettings, storeEncryptionKey);
    if (tokenResult.status !== "found") return null;
    const validationResult = this.validateToken(tokenResult.token);
    if (!validationResult.isValid) {
      this.logger.error({ message: "The Activation Key found in index, but was not valid. Will delete it." });
      await this.deleteTokenFromIndex();
      return null;
    }
    this.logger.debug(
      "Found valid activation key in index: ",
      LicenseService.toLoggableActivationKey(validationResult.token)
    );
    const key = this.sanitizeActivationKey(validationResult.token);
    key.origin = "index";
    return key;
  }
  async loadKeyFromEnv() {
    var _a;
    const token = (_a = process.env[this.ACTIVATION_KEY_ENV_VAR]) != null ? _a : null;
    const validationResult = this.validateToken(token);
    if (!validationResult.isValid) return null;
    this.logger.info(
      "Found valid activation key in env var: ",
      LicenseService.toLoggableActivationKey(validationResult.token)
    );
    const key = this.sanitizeActivationKey(validationResult.token);
    key.origin = "env";
    return key;
  }
  async loadKeyFromFile(licenseSettings) {
    const token = this.readActivationKeyFromFilesystem(licenseSettings);
    const validationResult = this.validateToken(token);
    if (!validationResult.isValid) return null;
    this.logger.info(
      `Found valid activation key in file ${this.getActivationKeyFilePathWithFallback(
        licenseSettings.activationKeyFilePath
      )}: `,
      LicenseService.toLoggableActivationKey(validationResult.token)
    );
    const key = this.sanitizeActivationKey(validationResult.token);
    key.origin = "filesystem";
    return key;
  }
  async loadDefaultKey(logLevel) {
    const validationResult = this.validateToken(this.DEFAULT_ACTIVATION_KEY);
    if (!validationResult.isValid) throw new Error("The default Activation key is not valid.");
    logLevel(
      `No Activation Key found. That's OK. Defaulting to Free license.You can add your own Activation Key later.`
    );
    logLevel("Visit ReadonlyREST Customer Portal at https://readonlyrest.com to get a trial Activation Key.");
    const key = this.sanitizeActivationKey(validationResult.token);
    key.origin = "default_key";
    return key;
  }
  readActivationKeyFromFilesystem(licenseSettings) {
    const path2 = this.getActivationKeyFilePathWithFallback(licenseSettings.activationKeyFilePath);
    this.logger.debug("Trying to read the activation key from file (activationKeyFilePath): ", path2);
    if (import_fs.default.existsSync(path2)) {
      const content = import_fs.default.readFileSync(path2, "utf8");
      if (content) {
        return content.trim();
      }
      this.logger.trace(`File was empty: ${path2}`);
    } else {
      this.logger.trace(`File not found: ${path2}`);
    }
    return null;
  }
  canRetrieveFrom(origin, licenseSettings, enableLogging = true) {
    const modes = licenseSettings.activationKeyRetrievalModes;
    if (modes.includes(origin) || modes.includes("all")) {
      return true;
    }
    if (enableLogging) {
      this.logger.trace(
        `Will not try to retrieve from ${origin} because it is not in the list of allowed origins: ${modes}`
      );
    }
    return false;
  }
  async getTokenFromIndex(licenseSettings, storeEncryptionKey) {
    var _a, _b;
    if (!this.canRetrieveFrom("index", licenseSettings)) {
      return { status: "not_found" };
    }
    const searchRes = await this.esApiClientWithAuthProvider.asTechnicalUser().runSearch({ indexName: this.LICENSE_INDEX_NAME });
    if (searchRes.status !== 200) {
      this.logger.info(`Cannot get the encrypted activation key from Kibana... Status code: ${searchRes.status}`);
      if (searchRes.status === 404) {
        return { status: "not_found" };
      }
      return { status: "read_error", httpStatus: searchRes.status };
    }
    const body = await searchRes.json();
    const hits = (_b = (_a = body == null ? void 0 : body.hits) == null ? void 0 : _a.hits) != null ? _b : [];
    if (hits.length === 0) {
      return { status: "not_found" };
    }
    const { validEntry, staleDocIds } = this.decryptFirstValidHit(hits, storeEncryptionKey);
    if (!validEntry) {
      return { status: "decrypt_error", error: "No index entry could be decrypted with the current key" };
    }
    this.logger.trace("Decrypted token from doc:", validEntry.docId);
    return { status: "found", token: validEntry.token, docId: validEntry.docId, staleDocIds };
  }
  decryptFirstValidHit(hits, storeEncryptionKey) {
    let validEntry = null;
    const staleDocIds = [];
    const cipher = new import_ActivationKeyCipher.ActivationKeyCipher(storeEncryptionKey);
    for (const hit of hits) {
      if (validEntry) {
        staleDocIds.push(hit._id);
        continue;
      }
      try {
        const decrypted = cipher.decrypt(hit._source.encrypted);
        if (decrypted) {
          validEntry = { token: decrypted, docId: hit._id };
        } else {
          staleDocIds.push(hit._id);
        }
      } catch (e) {
        this.logger.trace(`Skipping doc ${hit._id}: decryption error \u2014 ${e.message}`);
        staleDocIds.push(hit._id);
      }
    }
    return { validEntry, staleDocIds };
  }
  async deleteAndReloadLicense(licenseSettings, storeEncryptionKey) {
    const validateToken = this.validateToken(this.DEFAULT_ACTIVATION_KEY);
    if (!validateToken.isValid) {
      throw new Error(
        `Cannot delete the encrypted activation key from Kibana, default activation key is not available`
      );
    }
    await this.deleteTokenFromIndex();
    const key = await this.retrieveActivationKey(licenseSettings, storeEncryptionKey);
    this.activationKey$.next(key);
    return key;
  }
  async deleteTokenFromIndex() {
    const deleteRes = await this.esApiClientWithAuthProvider.asTechnicalUser().deleteIndex({ indexName: this.LICENSE_INDEX_NAME });
    if (!deleteRes.ok && deleteRes.status !== 404) {
      throw new Error(
        `Cannot delete the encrypted activation key from Kibana... Got status: ${deleteRes.status} ${await deleteRes.text()}`
      );
    }
  }
  async saveToken(token, storeEncryptionKey) {
    const newActivationKey = this.validateToken(token);
    if (!newActivationKey.isValid) {
      const error = new Error(newActivationKey.message);
      error.name = newActivationKey.reason;
      throw error;
    }
    const existingDocIds = await this.fetchAllDocIdsFromIndex();
    await this.persistEncryptedToken(token, storeEncryptionKey);
    await this.clearStaleDocs(existingDocIds);
    const savedKey = this.sanitizeActivationKey(newActivationKey.token);
    savedKey.origin = "index";
    this.activationKey$.next(savedKey);
    return savedKey;
  }
  async reEncryptActivationKey(licenseSettings, previousStoreEncryptionKey, newStoreEncryptionKey) {
    const tokenResult = await this.getTokenFromIndex(licenseSettings, previousStoreEncryptionKey);
    if (tokenResult.status === "not_found") {
      this.logger.debug("No activation key found in index to re-encrypt");
      return { ok: true, data: null };
    }
    if (tokenResult.status === "decrypt_error") {
      const error = `Cannot re-encrypt activation key: decryption with current key failed \u2014 ${tokenResult.error}`;
      this.logger.error({ message: error });
      return { ok: false, error };
    }
    if (tokenResult.status === "read_error") {
      const error = `Cannot re-encrypt activation key: index read failed with HTTP ${tokenResult.httpStatus}`;
      this.logger.error({ message: error });
      return { ok: false, error };
    }
    try {
      const { docId: oldDocId, staleDocIds } = tokenResult;
      const newDocId = await this.persistEncryptedToken(tokenResult.token, newStoreEncryptionKey);
      this.logger.info("Activation key re-encrypted with new store encryption key");
      return {
        ok: true,
        data: {
          cleanup: async (success) => {
            if (success) {
              await this.clearStaleDocs([oldDocId, ...staleDocIds]);
            } else {
              await this.deleteDocFromIndex(newDocId);
            }
          }
        }
      };
    } catch (e) {
      this.logger.error({ message: `Failed to re-encrypt activation key: ${e.message}`, stack: e.stack });
      return { ok: false, error: e.message };
    }
  }
  async deleteDocFromIndex(docId) {
    const res = await this.esApiClientWithAuthProvider.asTechnicalUser().deleteDocument({ indexName: this.LICENSE_INDEX_NAME, docId });
    if (!res.ok && res.status !== 404) {
      this.logger.warn(`Failed to delete activation key doc '${docId}': HTTP ${res.status}`);
    }
  }
  async fetchAllDocIdsFromIndex() {
    var _a, _b;
    const res = await this.esApiClientWithAuthProvider.asTechnicalUser().runSearch({ indexName: this.LICENSE_INDEX_NAME });
    if (res.status !== 200) return [];
    const body = await res.json();
    const hits = (_b = (_a = body == null ? void 0 : body.hits) == null ? void 0 : _a.hits) != null ? _b : [];
    return hits.map((h) => h._id);
  }
  async clearStaleDocs(staleDocIds) {
    if (staleDocIds.length === 0) return;
    this.logger.debug(`Cleaning up ${staleDocIds.length} stale doc(s)`);
    await Promise.all(staleDocIds.map((id) => this.deleteDocFromIndex(id)));
  }
  async persistEncryptedToken(token, storeEncryptionKey) {
    const docId = (0, import_uuid.v4)();
    const cipher = new import_ActivationKeyCipher.ActivationKeyCipher(storeEncryptionKey);
    const encrypted = cipher.encrypt(token);
    const res = await this.esApiClientWithAuthProvider.asTechnicalUser().createOrUpdateDocumentInIndex({
      requestBody: { encrypted },
      indexName: this.LICENSE_INDEX_NAME,
      docId
    });
    if (!res.ok) {
      throw new Error(
        `Cannot write the encrypted activation key to Kibana... got status: ${res.status} ${await res.text()}`
      );
    }
    return docId;
  }
  nonFreeLicenseRequired(res, next, message) {
    if ((0, import_ActivationKey.isFreeLicense)(this.getActivationKey().license)) {
      this.logger.warn(`FORBIDDEN: ${message}`);
      return res.status(403).send({ status: "FORBIDDEN", message });
    }
    next();
  }
  enterpriseLicenseRequired(res, next, message) {
    if (!(0, import_ActivationKey.isEnterpriseLicense)(this.getActivationKey().license)) {
      this.logger.warn(`FORBIDDEN: ${message}`);
      return res.status(403).send({ status: "FORBIDDEN", message });
    }
    next();
  }
  destroy() {
    var _a;
    (_a = this.refreshSub) == null ? void 0 : _a.unsubscribe();
  }
  validateToken(token) {
    try {
      if (!token) {
        return { isValid: false, reason: "CANNOT_BE_VERIFIED", message: import_errors.default.activationKey.cantBeVerified };
      }
      const decoded = import_versionedLibraries.jsonwebtoken.verify(token, Buffer.from(this.tokenPublicKey), {
        algorithms: ["ES512"]
      });
      if (!decoded) {
        this.logger.error({ message: `\u274C ${import_errors.default.activationKey.cantBeVerified} ${token}` });
        return { isValid: false, reason: "CANNOT_BE_VERIFIED", message: import_errors.default.activationKey.cantBeVerified };
      }
      if (!this.clusterUuid) {
        throw Error(`${import_path.default.basename(__filename)} not properly initialised. Please run init()`);
      }
      const clusterUUidInToken = decoded.license.cluster_uuid;
      if (this.clusterUuid === clusterUUidInToken || clusterUUidInToken === "*") {
        this.logger.trace("\u2705 Checked ES cluster_uuid in license activation key matches");
        return { isValid: true, token: decoded };
      }
      this.logger.error({
        message: `Activation Key REJECTED: This ES cluster UUID (${this.clusterUuid}) differs from the ClusterUUID in the activation key (${clusterUUidInToken})`
      });
    } catch (e) {
      this.logger.trace(`\u274C ${import_errors.default.activationKey.cantBeVerified} ${token}`);
      this.logger.error({ message: `\u274C Invalid Activation key: ${e.message}`, stack: e.stack });
      const jsonWebTokenError = this.getJsonWebTokenErrorsMapping(e.message);
      if (jsonWebTokenError) {
        return jsonWebTokenError;
      }
    }
    return { isValid: false, reason: "CANNOT_BE_VERIFIED", message: import_errors.default.activationKey.cantBeVerified };
  }
  getJsonWebTokenErrorsMapping(message) {
    if (message === "jwt expired") {
      return { isValid: false, reason: "LICENSE_KEY_EXPIRED", message: import_errors.default.activationKey.licenseKeyExpired };
    }
    if (message === "invalid token") {
      return {
        isValid: false,
        reason: "INVALID_JWT",
        message: import_errors.default.activationKey.invalidJwt
      };
    }
    if (message === "jwt malformed") {
      return {
        isValid: false,
        reason: "LICENSE_KEY_MALFORMED",
        message: import_errors.default.activationKey.licenseKeyMalformed
      };
    }
    if (message === "invalid signature") {
      return {
        isValid: false,
        reason: "INVALID_JWT_SIGNATURE",
        message: import_errors.default.activationKey.invalidJtwSignature
      };
    }
  }
  sanitizeActivationKey(rawActivationKey) {
    const validEditions = Object.values(import_ActivationKey.EDITIONS_ENUM);
    const edition = rawActivationKey.license.edition;
    const isValidEdition = validEditions.includes(edition);
    const safeEdition = isValidEdition ? edition : import_ActivationKey.EDITIONS_ENUM.FREE;
    if (!isValidEdition) {
      this.logger.warn(
        `Unknown license edition: ${edition}. Free license edition will be used instead. Valid editions are: ${Object.values(
          import_ActivationKey.EDITIONS_ENUM
        ).join(", ")}`
      );
    }
    return {
      ...rawActivationKey,
      license: {
        ...rawActivationKey.license,
        edition: safeEdition
      }
    };
  }
  getActivationKeyFilePathWithFallback(activationKeyFilePath) {
    return activationKeyFilePath || import_path.default.resolve(import_path.default.join(__dirname, "..", "..", "..", "..", "..", "ROR_ACTIVATION_KEY.txt"));
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LicenseService
});
