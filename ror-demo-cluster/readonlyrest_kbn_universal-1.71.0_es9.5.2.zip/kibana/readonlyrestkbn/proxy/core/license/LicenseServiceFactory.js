"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var LicenseServiceFactory_exports = {};
__export(LicenseServiceFactory_exports, {
  LicenseServiceFactory: () => LicenseServiceFactory
});
module.exports = __toCommonJS(LicenseServiceFactory_exports);
var import_LicenseService = require("./LicenseService");
class LicenseServiceFactory {
  constructor(esApiClientWithAuthProvider) {
    this.esApiClientWithAuthProvider = esApiClientWithAuthProvider;
  }
  createLicenseService() {
    const decode = (token) => Buffer.from(token, "base64").toString("binary");
    const tokenPubKey = decode(
      "LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlHYk1CQUdCeXFHU000OUFnRUdCU3VCQkFBakE0R0dBQVFCZW9UZTF1UDhCaFRSdFdDR2hNTThJWUFwSElKRgppTWJXcEJFa0M2ZHJoMlpXSzVkSTFxL25ENzltU1laVjBzWlFjTTROclVZQ0J3YkpDWlZLTHlIWlh0Y0E4Vld0CmlqN05NWlkrUEJDemtvQVJDbUlKZHprQkI5a1RxRFB6U29aZkRqQW54ZzF5OGxoUVR1dFJ2Z09jTUhKRDgrd3kKV3hLYlU2L1JCVFU2d2pJZE5pND0KLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0t"
    );
    return new import_LicenseService.LicenseService(this.esApiClientWithAuthProvider, tokenPubKey);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LicenseServiceFactory
});
