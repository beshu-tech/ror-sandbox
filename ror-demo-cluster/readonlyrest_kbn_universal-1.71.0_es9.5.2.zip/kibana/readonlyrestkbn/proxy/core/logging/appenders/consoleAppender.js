"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var consoleAppender_exports = {};
__export(consoleAppender_exports, {
  ConsoleAppender: () => ConsoleAppender
});
module.exports = __toCommonJS(consoleAppender_exports);
var import_rorLoggerFactory = require("../rorLoggerFactory");
var import_logAppender = require("./logAppender");
class ConsoleAppender extends import_logAppender.LogAppender {
  constructor(fileName, layout, prettyPrintEnabled = false) {
    super(layout);
    this.fileName = fileName;
    this.prettyPrintEnabled = prettyPrintEnabled;
  }
  log(logLevel, message, impersonatedBy, correlationId, stackTrace, ...optionalParams) {
    if (!import_rorLoggerFactory.RorLoggerFactory.isLoggingEnabled(logLevel)) {
      return;
    }
    const formattedMessage = this.logPattern(
      logLevel,
      this.fileName,
      message,
      impersonatedBy,
      correlationId,
      optionalParams,
      this.prettyPrintEnabled,
      stackTrace
    );
    console.log(formattedMessage);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ConsoleAppender
});
