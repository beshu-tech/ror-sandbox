"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fileAppender_exports = {};
__export(fileAppender_exports, {
  FileAppender: () => FileAppender
});
module.exports = __toCommonJS(fileAppender_exports);
var import_fs_extra = __toESM(require("fs-extra"));
var import_rorLogger = require("../rorLogger");
var import_rorLoggerFactory = require("../rorLoggerFactory");
var import_consoleAppender = require("./consoleAppender");
var import_logAppender = require("./logAppender");
class FileAppender extends import_logAppender.LogAppender {
  constructor(fileName, logFileDestination, layout, prettyPrintEnabled = false) {
    super(layout);
    this.fileName = fileName;
    this.logFileDestination = logFileDestination;
    this.prettyPrintEnabled = prettyPrintEnabled;
  }
  log(logLevel, message, impersonatedBy, correlationId, stackTrace, ...optionalParams) {
    if (!import_rorLoggerFactory.RorLoggerFactory.isLoggingEnabled(logLevel)) {
      return;
    }
    const logLine = this.logPattern(
      logLevel,
      this.fileName,
      message,
      impersonatedBy,
      correlationId,
      optionalParams,
      this.prettyPrintEnabled,
      stackTrace
    );
    import_fs_extra.default.outputFile(this.logFileDestination, `${logLine}
`, { flag: "a" }, (err) => {
      if (err) {
        const logger = new import_rorLogger.RorLogger([new import_consoleAppender.ConsoleAppender("LoggerFactory|FileAppender")]);
        return logger.error(err);
      }
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  FileAppender
});
