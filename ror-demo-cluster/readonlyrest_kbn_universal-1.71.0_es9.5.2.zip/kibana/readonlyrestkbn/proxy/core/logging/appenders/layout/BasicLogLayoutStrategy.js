"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var BasicLogLayoutStrategy_exports = {};
__export(BasicLogLayoutStrategy_exports, {
  BasicLogLayoutStrategy: () => BasicLogLayoutStrategy
});
module.exports = __toCommonJS(BasicLogLayoutStrategy_exports);
var import_util = require("util");
var import_types = require("../../../common/types");
var import_logLevel = require("../../logLevel");
var import_utils = require("./utils");
class BasicLogLayoutStrategy {
  format(logLevel, fileName, message, impersonating, correlationId, optionalParams, prettyPrintEnabled, stackTrace) {
    const time = (0, import_logLevel.getLogFormattedTime)();
    const level = (0, import_logLevel.getLogLevelDescription)(logLevel);
    let prefixes = `[${time}][${level}][plugins][ReadonlyREST][${fileName}]`;
    if (impersonating) {
      prefixes = `${prefixes}[impersonating ${impersonating}]`;
    }
    if (correlationId) {
      prefixes = `${prefixes}[${import_types.X_ROR_CORRELATION_ID}=${correlationId}]`;
    }
    const stackTraceStr = stackTrace ? `
${stackTrace}` : "";
    return `${prefixes} ${message}${this.formatOptionalParams(prettyPrintEnabled, optionalParams)}${stackTraceStr}`;
  }
  formatOptionalParams(prettyPrintEnabled, params) {
    if (!params || params.length === 0) return "";
    if (prettyPrintEnabled) {
      return (0, import_utils.processBuffers)(params).map(
        (param) => `
${(0, import_util.inspect)(param, {
          depth: 5,
          breakLength: 80,
          maxArrayLength: Infinity,
          maxStringLength: Infinity,
          compact: 3
        })}`
      ).join("");
    }
    return (0, import_utils.processBuffers)(params).map(
      (param) => ` ${(0, import_util.inspect)(param, {
        depth: 5,
        breakLength: Infinity,
        maxArrayLength: Infinity,
        maxStringLength: Infinity,
        compact: true
      })}`
    ).join("");
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  BasicLogLayoutStrategy
});
