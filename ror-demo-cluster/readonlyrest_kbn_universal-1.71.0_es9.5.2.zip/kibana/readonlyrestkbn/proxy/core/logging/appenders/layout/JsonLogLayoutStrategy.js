"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var JsonLogLayoutStrategy_exports = {};
__export(JsonLogLayoutStrategy_exports, {
  JsonLogLayoutStrategy: () => JsonLogLayoutStrategy
});
module.exports = __toCommonJS(JsonLogLayoutStrategy_exports);
var import_util = require("util");
var import_lodash = require("lodash");
var import_types = require("../../../common/types");
var import_logLevel = require("../../logLevel");
var import_utils = require("./utils");
class JsonLogLayoutStrategy {
  format(logLevel, fileName, message, impersonating, correlationId, optionalParams, prettyPrintEnabled, stackTrace) {
    const logObject = {
      "@timestamp": (0, import_logLevel.getLogFormattedTime)(),
      log: {
        level: (0, import_logLevel.getLogLevelDescription)(logLevel).toUpperCase(),
        logger: `plugins.ReadonlyREST.${fileName}`
      },
      message: this.formatMessage(message, (0, import_utils.processBuffers)(optionalParams), prettyPrintEnabled),
      ...impersonating ? { impersonating } : {},
      ...correlationId ? { [import_types.X_ROR_CORRELATION_ID]: correlationId } : {},
      ...stackTrace ? { stackTrace } : {}
    };
    return prettyPrintEnabled ? (0, import_util.inspect)(logObject, {
      depth: 5,
      breakLength: 40,
      maxArrayLength: Infinity,
      maxStringLength: Infinity,
      compact: 3
    }) : JSON.stringify(logObject);
  }
  formatMessage(message, optionalParams, prettyPrintEnabled) {
    if (prettyPrintEnabled) {
      return optionalParams.length > 0 ? {
        text: message,
        params: optionalParams
      } : message;
    }
    return optionalParams.length > 0 ? `${message} ${optionalParams.map(
      (optionalParam) => (0, import_lodash.isObjectLike)(optionalParam) ? (0, import_util.inspect)(optionalParam, {
        depth: 5,
        breakLength: Infinity,
        maxArrayLength: Infinity,
        maxStringLength: Infinity,
        compact: true
      }) : optionalParam
    )}` : message;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  JsonLogLayoutStrategy
});
