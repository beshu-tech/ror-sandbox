"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var LogLayoutFactory_exports = {};
__export(LogLayoutFactory_exports, {
  LogLayoutFactory: () => LogLayoutFactory
});
module.exports = __toCommonJS(LogLayoutFactory_exports);
var import_BasicLogLayoutStrategy = require("./BasicLogLayoutStrategy");
var import_JsonLogLayoutStrategy = require("./JsonLogLayoutStrategy");
class LogLayoutFactory {
  static createStrategy(layout) {
    if (!layout || layout.type === "basic") {
      return new import_BasicLogLayoutStrategy.BasicLogLayoutStrategy();
    }
    if (layout.type === "json") {
      return new import_JsonLogLayoutStrategy.JsonLogLayoutStrategy();
    }
    return new import_BasicLogLayoutStrategy.BasicLogLayoutStrategy();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LogLayoutFactory
});
