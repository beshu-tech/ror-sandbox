"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var types_exports = {};
__export(types_exports, {
  logLayoutSchema: () => logLayoutSchema,
  numericStrategySchema: () => numericStrategySchema,
  sizeLimitPolicySchema: () => sizeLimitPolicySchema,
  timeIntervalPolicySchema: () => timeIntervalPolicySchema
});
module.exports = __toCommonJS(types_exports);
const logLayoutSchema = {
  type: "object",
  properties: {
    type: { type: "string", enum: ["basic", "json"] }
  },
  required: ["type"],
  additionalProperties: false
};
const sizeLimitPolicySchema = {
  type: "object",
  properties: {
    type: { type: "string", const: "size-limit" },
    size: { type: "string" }
  },
  required: ["type"],
  additionalProperties: false
};
const timeIntervalPolicySchema = {
  type: "object",
  properties: {
    type: { type: "string", const: "time-interval" },
    interval: { type: "string" },
    modulate: { type: "boolean" }
  },
  required: ["type"],
  additionalProperties: false
};
const numericStrategySchema = {
  type: "object",
  properties: {
    type: { type: "string", const: "numeric" },
    pattern: { type: "string" },
    max: { type: "number" }
  },
  required: ["type"],
  additionalProperties: false
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  logLayoutSchema,
  numericStrategySchema,
  sizeLimitPolicySchema,
  timeIntervalPolicySchema
});
