"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var logAppender_exports = {};
__export(logAppender_exports, {
  LogAppender: () => LogAppender
});
module.exports = __toCommonJS(logAppender_exports);
var import_lodash = require("lodash");
var import_LogLayoutFactory = require("./layout/LogLayoutFactory");
class LogAppender {
  constructor(layout) {
    __publicField(this, "layoutStrategy");
    this.layoutStrategy = import_LogLayoutFactory.LogLayoutFactory.createStrategy(layout);
  }
  logPattern(logLevel, fileName, message, impersonating, correlationId, optionalParams = [], prettyPrintEnabled = false, stackTrace) {
    const sanitizedMessage = this.obfuscate(message);
    const sanitizedOptionalParams = (0, import_lodash.map)(optionalParams, (param) => this.obfuscate(param));
    return this.layoutStrategy.format(
      logLevel,
      fileName,
      sanitizedMessage,
      impersonating,
      correlationId,
      sanitizedOptionalParams,
      prettyPrintEnabled,
      stackTrace
    );
  }
  obfuscate(value) {
    const obfuscateValue = "<OMITTED>";
    const sensitiveKeys = ["authorization"];
    if (value == null) {
      return value;
    }
    if ((0, import_lodash.isString)(value)) {
      let result = value;
      sensitiveKeys.forEach((key) => {
        const pattern = new RegExp(`("${key}"\\s*:\\s*")[^"]+(")`, "gi");
        result = result.replace(pattern, `$1${obfuscateValue}$2`);
      });
      return result;
    }
    if (Buffer.isBuffer(value)) {
      return value;
    }
    if ((0, import_lodash.isArray)(value)) {
      return (0, import_lodash.map)(value, (item) => this.obfuscate(item));
    }
    if ((0, import_lodash.isObjectLike)(value)) {
      return (0, import_lodash.mapValues)(value, (propValue, key) => {
        if (sensitiveKeys.includes(key.toLowerCase())) {
          return obfuscateValue;
        }
        return this.obfuscate(propValue);
      });
    }
    return value;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LogAppender
});
