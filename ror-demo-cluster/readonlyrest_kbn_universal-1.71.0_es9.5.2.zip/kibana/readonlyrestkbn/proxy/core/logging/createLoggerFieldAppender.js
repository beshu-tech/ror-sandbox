"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var createLoggerFieldAppender_exports = {};
__export(createLoggerFieldAppender_exports, {
  createLoggerFieldAppender: () => createLoggerFieldAppender
});
module.exports = __toCommonJS(createLoggerFieldAppender_exports);
function createLoggerFieldAppender(getField, appendFn, clearFn) {
  return async (req, _res, next) => {
    var _a;
    try {
      const userRequestIdentity = await ((_a = req == null ? void 0 : req.rorRequest) == null ? void 0 : _a.getUserRequestIdentity());
      const field = getField(userRequestIdentity != null ? userRequestIdentity : null);
      if (field) {
        appendFn(field);
      } else {
        clearFn();
      }
    } catch {
      clearFn();
    }
    next();
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createLoggerFieldAppender
});
