"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var logLevel_exports = {};
__export(logLevel_exports, {
  LogLevel: () => LogLevel,
  getAcceptedLogLevelValues: () => getAcceptedLogLevelValues,
  getLogFormattedTime: () => getLogFormattedTime,
  getLogLevelDescription: () => getLogLevelDescription,
  toLoggerMethodName: () => toLoggerMethodName
});
module.exports = __toCommonJS(logLevel_exports);
var LogLevel = /* @__PURE__ */ ((LogLevel2) => {
  LogLevel2[LogLevel2["ERROR"] = 0] = "ERROR";
  LogLevel2[LogLevel2["WARN"] = 1] = "WARN";
  LogLevel2[LogLevel2["INFO"] = 2] = "INFO";
  LogLevel2[LogLevel2["DEBUG"] = 3] = "DEBUG";
  LogLevel2[LogLevel2["TRACE"] = 4] = "TRACE";
  return LogLevel2;
})(LogLevel || {});
function getAcceptedLogLevelValues() {
  return Object.keys(LogLevel).filter((key) => !Number.isNaN(Number(LogLevel[key]))).map((key) => key.toString().toLowerCase());
}
function toLoggerMethodName(key) {
  return LogLevel[key].toString().toLowerCase();
}
function getLogLevelDescription(logLevel) {
  switch (logLevel) {
    case 1 /* WARN */:
      return "warning";
    default:
      return LogLevel[logLevel].toString().toLowerCase();
  }
}
function formatDateWithOffset(date) {
  const pad = (n, z = 2) => `00${n}`.slice(-z);
  const offset = -date.getTimezoneOffset();
  const sign = offset >= 0 ? "+" : "-";
  const absOffset = Math.abs(offset);
  const hours = pad(Math.floor(absOffset / 60));
  const minutes = pad(absOffset % 60);
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(
    date.getMinutes()
  )}:${pad(date.getSeconds())}.${pad(date.getMilliseconds(), 3)}${sign}${hours}:${minutes}`;
}
function getLogFormattedTime() {
  return formatDateWithOffset(/* @__PURE__ */ new Date());
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LogLevel,
  getAcceptedLogLevelValues,
  getLogFormattedTime,
  getLogLevelDescription,
  toLoggerMethodName
});
