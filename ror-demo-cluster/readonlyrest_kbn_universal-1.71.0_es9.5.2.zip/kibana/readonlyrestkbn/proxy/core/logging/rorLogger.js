"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorLogger_exports = {};
__export(rorLogger_exports, {
  RorLogger: () => RorLogger
});
module.exports = __toCommonJS(rorLogger_exports);
var import_logLevel = require("./logLevel");
const _RorLogger = class _RorLogger {
  constructor(logAppenders) {
    __publicField(this, "logAppenders", []);
    this.logAppenders = logAppenders;
  }
  static clearImpersonatingInfo() {
    _RorLogger.impersonating = void 0;
  }
  static clearCorrelationId() {
    _RorLogger.correlationId = void 0;
  }
  static appendImpersonatingInfo(impersonating) {
    _RorLogger.impersonating = impersonating;
  }
  static appendCorrelationId(correlationId) {
    _RorLogger.correlationId = correlationId;
  }
  error({ message, stack }, ...optionalParams) {
    this.logAppenders.forEach((logAppender) => {
      logAppender.log(
        import_logLevel.LogLevel.ERROR,
        message,
        _RorLogger.impersonating,
        _RorLogger.correlationId,
        stack ? this.removeErrorHeaderFromStackTrace(stack) : void 0,
        ...optionalParams
      );
    });
  }
  warn(message, ...optionalParams) {
    this.logAppenders.forEach((logAppender) => {
      logAppender.log(
        import_logLevel.LogLevel.WARN,
        message,
        _RorLogger.impersonating,
        _RorLogger.correlationId,
        void 0,
        ...optionalParams
      );
    });
  }
  info(message, ...optionalParams) {
    this.logAppenders.forEach((logAppender) => {
      logAppender.log(
        import_logLevel.LogLevel.INFO,
        message,
        _RorLogger.impersonating,
        _RorLogger.correlationId,
        void 0,
        ...optionalParams
      );
    });
  }
  debug(message, ...optionalParams) {
    this.logAppenders.forEach((logAppender) => {
      logAppender.log(
        import_logLevel.LogLevel.DEBUG,
        message,
        _RorLogger.impersonating,
        _RorLogger.correlationId,
        void 0,
        ...optionalParams
      );
    });
  }
  trace(message, ...optionalParams) {
    this.logAppenders.forEach((logAppender) => {
      logAppender.log(
        import_logLevel.LogLevel.TRACE,
        message,
        _RorLogger.impersonating,
        _RorLogger.correlationId,
        void 0,
        ...optionalParams
      );
    });
  }
  removeErrorHeaderFromStackTrace(stackTrace) {
    const lines = stackTrace.split("\n");
    if (lines[0].startsWith("Error:")) {
      return lines.slice(1).join("\n");
    }
    return stackTrace;
  }
};
__publicField(_RorLogger, "impersonating");
__publicField(_RorLogger, "correlationId");
let RorLogger = _RorLogger;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorLogger
});
