"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorLoggerFactory_exports = {};
__export(rorLoggerFactory_exports, {
  RorLoggerFactory: () => RorLoggerFactory
});
module.exports = __toCommonJS(rorLoggerFactory_exports);
var import_path = __toESM(require("path"));
var import_consoleAppender = require("./appenders/consoleAppender");
var import_fileAppender = require("./appenders/fileAppender");
var import_logLevel = require("./logLevel");
var import_rorLogger = require("./rorLogger");
const _RorLoggerFactory = class _RorLoggerFactory {
  static getLoggerForFile(filePath) {
    return _RorLoggerFactory.getLogger(import_path.default.parse(filePath).name);
  }
  static setAppender(logDestinations, fileName) {
    const appenders = [];
    logDestinations == null ? void 0 : logDestinations.forEach((logDestination) => {
      switch (logDestination == null ? void 0 : logDestination.type) {
        case "rolling-file":
        case "file": {
          appenders.push(new import_fileAppender.FileAppender(fileName, logDestination.path, logDestination.layout));
          break;
        }
        default: {
          appenders.push(new import_consoleAppender.ConsoleAppender(fileName, logDestination.layout, _RorLoggerFactory.PRETTY_PRINT_ENABLED));
        }
      }
    });
    return appenders;
  }
  static getLogger(fileName) {
    return new import_rorLogger.RorLogger(this.setAppender(_RorLoggerFactory.destinations, fileName));
  }
  static configureLogging(logLevel, logDestinations, prettyPrintEnabled = false) {
    _RorLoggerFactory.CURRENT_LOG_LEVEL = logLevel;
    _RorLoggerFactory.destinations = logDestinations;
    _RorLoggerFactory.PRETTY_PRINT_ENABLED = prettyPrintEnabled;
    _RorLoggerFactory.logger.debug(`Setting logLevel to: ${import_logLevel.LogLevel[logLevel]}`);
  }
  static isLoggingEnabled(logLevel) {
    return _RorLoggerFactory.CURRENT_LOG_LEVEL.valueOf() >= logLevel.valueOf();
  }
};
__publicField(_RorLoggerFactory, "DEFAULT_LOG_LEVEL", import_logLevel.LogLevel.INFO);
__publicField(_RorLoggerFactory, "CURRENT_LOG_LEVEL", _RorLoggerFactory.DEFAULT_LOG_LEVEL);
__publicField(_RorLoggerFactory, "logger", _RorLoggerFactory.getLogger("LoggerFactory"));
__publicField(_RorLoggerFactory, "destinations", [{ type: "console" }]);
__publicField(_RorLoggerFactory, "PRETTY_PRINT_ENABLED", false);
let RorLoggerFactory = _RorLoggerFactory;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorLoggerFactory
});
