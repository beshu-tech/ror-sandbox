"use strict";
var ReportingIndex;
((ReportingIndex2) => {
  const randomIndex = `.reporting-${Math.random().toString(36).slice(2)}`;
  const DEFAULT_REPORTING_INDEX = ".reporting";
  const randomStreamIndex = `.kibana-reporting-${Math.random().toString(36).slice(2)}`;
  const DEFAULT_STREAM_REPORTING_INDEX = ".kibana-reporting";
  let xpackReportingIndex;
  function getTemporaryReportingIndex() {
    return randomIndex;
  }
  ReportingIndex2.getTemporaryReportingIndex = getTemporaryReportingIndex;
  function getTemporaryStreamReportingIndex() {
    return randomStreamIndex;
  }
  ReportingIndex2.getTemporaryStreamReportingIndex = getTemporaryStreamReportingIndex;
  function getFinalReportingIndex() {
    return xpackReportingIndex || DEFAULT_REPORTING_INDEX;
  }
  ReportingIndex2.getFinalReportingIndex = getFinalReportingIndex;
  function getFinalStreamReportingIndex() {
    return xpackReportingIndex || DEFAULT_STREAM_REPORTING_INDEX;
  }
  ReportingIndex2.getFinalStreamReportingIndex = getFinalStreamReportingIndex;
  function setXpackReportingIndex(reportingIndex) {
    xpackReportingIndex = reportingIndex;
  }
  ReportingIndex2.setXpackReportingIndex = setXpackReportingIndex;
})(ReportingIndex || (ReportingIndex = {}));
module.exports = ReportingIndex;
