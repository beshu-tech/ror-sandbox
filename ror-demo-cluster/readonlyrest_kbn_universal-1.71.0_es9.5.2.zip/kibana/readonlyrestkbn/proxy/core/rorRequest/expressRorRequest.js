"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var expressRorRequest_exports = {};
__export(expressRorRequest_exports, {
  ExpressRorRequest: () => ExpressRorRequest,
  isLoginFormBody: () => isLoginFormBody
});
module.exports = __toCommonJS(expressRorRequest_exports);
var import_lodash = require("lodash");
var import_types = require("../common/types");
function isLoginFormBody(body) {
  return (body == null ? void 0 : body.username) !== void 0;
}
class ExpressRorRequest {
  constructor(request) {
    this.request = request;
  }
  getCookies() {
    return this.request.cookies;
  }
  getMethod() {
    return import_types.Method[this.request.method];
  }
  getPath() {
    return this.request.path;
  }
  getUrl() {
    return this.request.url;
  }
  getBody() {
    return this.request.body;
  }
  getParams() {
    return this.request.params;
  }
  getQueries() {
    return this.request.query;
  }
  setQuery(key, value) {
    this.request.query[key] = value;
    const FAKE_URL = "http://localhost";
    const url = new URL(this.request.url, FAKE_URL);
    url.searchParams.set(key, value);
    this.request.url = url.pathname + url.search;
  }
  getOriginAddress() {
    var _a;
    return this.request.ip || ((_a = this.request.socket) == null ? void 0 : _a.remoteAddress) || void 0;
  }
  getHeaders() {
    return (0, import_lodash.mapKeys)(this.request.headers, (_v, k) => k.toLowerCase());
  }
  isCookiePresent(cookieName) {
    return cookieName in this.request.cookies;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ExpressRorRequest,
  isLoginFormBody
});
