"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var requestScopedIdentityCache_exports = {};
__export(requestScopedIdentityCache_exports, {
  RequestScopedIdentityCache: () => RequestScopedIdentityCache
});
module.exports = __toCommonJS(requestScopedIdentityCache_exports);
class RequestScopedIdentityCache {
  constructor() {
    __publicField(this, "cache", /* @__PURE__ */ new Map());
  }
  get(cacheKey) {
    return this.cache.get(cacheKey);
  }
  set(cacheKey, value) {
    this.cache.set(cacheKey, value);
  }
  getLastCached() {
    const values = Array.from(this.cache.values());
    return values.length > 0 ? values[values.length - 1] : void 0;
  }
  buildCacheKey(input) {
    return `${(input == null ? void 0 : input.sid) || "default"}:${(input == null ? void 0 : input.predefinedTenancyId) || "default"}`;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RequestScopedIdentityCache
});
