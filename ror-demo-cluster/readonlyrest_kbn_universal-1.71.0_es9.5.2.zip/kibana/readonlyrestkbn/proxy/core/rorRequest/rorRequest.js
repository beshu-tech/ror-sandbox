"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorRequest_exports = {};
__export(rorRequest_exports, {
  RorRequest: () => RorRequest
});
module.exports = __toCommonJS(rorRequest_exports);
var import_withErrorFallback = require("../common/withErrorFallback");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_expressRorRequest = require("./expressRorRequest");
var import_requestScopedIdentityCache = require("./requestScopedIdentityCache");
class RorRequest extends import_expressRorRequest.ExpressRorRequest {
  constructor(request, sessionManager, userRequestIdentityServiceFactory) {
    super(request);
    this.sessionManager = sessionManager;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "customIdentitySessionMetadata", {});
    __publicField(this, "userRequestIdentityService");
    __publicField(this, "identityCache", new import_requestScopedIdentityCache.RequestScopedIdentityCache());
    this.userRequestIdentityService = userRequestIdentityServiceFactory(this);
  }
  async getIdentitySessionHeaders() {
    return this.buildAndExtract(
      (userRequestIdentityMetadata) => userRequestIdentityMetadata.identitySessionHeaders,
      /* @__PURE__ */ new Map(),
      "Failed to get identity session headers"
    );
  }
  async getWhitelistedHeaders() {
    return this.buildAndExtract(
      (userRequestIdentityMetadata) => userRequestIdentityMetadata.whitelistedHeaders,
      /* @__PURE__ */ new Map(),
      "Failed to get whitelisted headers"
    );
  }
  async isAuthenticated(input) {
    return (0, import_withErrorFallback.withErrorFallback)(
      async () => {
        const sid = (input == null ? void 0 : input.sid) || await this.userRequestIdentityService.getSid();
        if (!sid) {
          return false;
        }
        const sessionIdentityExists = await this.sessionManager.exists(sid);
        if (!sessionIdentityExists) {
          return false;
        }
        return !await this.sessionManager.isSessionExpired(sid);
      },
      false,
      "Failed to check authentication status",
      this.logger
    );
  }
  async getUserRequestIdentity(input) {
    return (0, import_withErrorFallback.withErrorFallback)(
      async () => {
        const isAuthenticated = await this.isAuthenticated({ sid: input == null ? void 0 : input.sid });
        if (!isAuthenticated) {
          return null;
        }
        const result = await this.userRequestIdentityService.buildUserRequestIdentity(
          this.customIdentitySessionMetadata,
          input
        );
        if (!result.ok) {
          this.logger.error({ message: `Failed to get user request identity: ${this.getUrl()}, ${result.reason}` });
          return null;
        }
        const cacheKey = this.identityCache.buildCacheKey(input);
        this.identityCache.set(cacheKey, result.identity);
        return result.identity;
      },
      null,
      `Failed to get user request identity: ${this.getUrl()}`,
      this.logger
    );
  }
  async ensuredIdentityAvailability() {
    const result = await this.userRequestIdentityService.buildUserRequestIdentity(this.customIdentitySessionMetadata);
    return result.ok ? { ok: true } : { ok: false, reason: result.reason };
  }
  /**
   * @deprecated Use {@link getUserRequestIdentity} instead.
   * The result is cached within the request scope, not globally.
   */
  getIdentitySession() {
    this.logger.warn("getIdentitySession is deprecated, use getUserRequestIdentity instead");
    return this.identityCache.getLastCached();
  }
  /**
   * @deprecated Use {@link getIdentitySessionHeaders} and {@link getWhitelistedHeaders} instead.
   * Returns merged identity session headers and whitelisted headers from the last cached identity.
   * The result is based on the cached identity within the request scope.
   */
  getAuthorizationHeaders() {
    this.logger.warn(
      "getAuthorizationHeaders is deprecated, use getIdentitySessionHeaders and getWhitelistedHeaders instead"
    );
    const cached = this.identityCache.getLastCached();
    if (!cached) {
      return /* @__PURE__ */ new Map();
    }
    const merged = /* @__PURE__ */ new Map();
    cached.metadata.identitySessionHeaders.forEach((value, key) => merged.set(key, value));
    cached.metadata.whitelistedHeaders.forEach((value, key) => merged.set(key, value));
    return merged;
  }
  enrichIdentitySessionMetadata(customMetadata) {
    if (!customMetadata || typeof customMetadata !== "object") {
      this.logger.warn("Invalid custom metadata provided to enrichIdentitySessionMetadata", {
        type: typeof customMetadata
      });
      return;
    }
    this.customIdentitySessionMetadata = { ...this.customIdentitySessionMetadata, ...customMetadata };
  }
  async lastSessionActivityDate() {
    return (0, import_withErrorFallback.withErrorFallback)(
      async () => {
        const result = await this.userRequestIdentityService.buildUserRequestIdentity(
          this.customIdentitySessionMetadata
        );
        if (!result.ok) {
          this.logger.debug("User request identity not available for last session activity date");
          return void 0;
        }
        return result.identity.metadata.lastSessionActivityDate;
      },
      void 0,
      "Failed to get last session activity date",
      this.logger
    );
  }
  async extractHiddenAppsNames() {
    return (0, import_withErrorFallback.withErrorFallback)(
      async () => {
        var _a;
        const result = await this.userRequestIdentityService.buildUserRequestIdentity(
          this.customIdentitySessionMetadata
        );
        if (!result.ok) {
          this.logger.debug("User request identity not available for extracting hidden apps names");
          return [];
        }
        return (_a = result.identity.metadata.kibanaHiddenApps) != null ? _a : [];
      },
      [],
      "Failed to extract hidden apps names",
      this.logger
    );
  }
  async getTenancyId(sid) {
    if (!sid) {
      this.logger.debug("getTenancyId called with undefined SID");
      return void 0;
    }
    return (0, import_withErrorFallback.withErrorFallback)(
      async () => this.userRequestIdentityService.getTenancyId(sid),
      void 0,
      "Failed to get tenancy ID",
      this.logger
    );
  }
  async getSid() {
    return this.userRequestIdentityService.getSid();
  }
  async buildAndExtract(extractor, fallback, errorMessage) {
    return (0, import_withErrorFallback.withErrorFallback)(
      async () => {
        const result = await this.userRequestIdentityService.buildUserRequestIdentity(
          this.customIdentitySessionMetadata
        );
        return result.ok ? extractor(result.identity.metadata) : fallback;
      },
      fallback,
      errorMessage,
      this.logger
    );
  }
  async getCorrelationId() {
    const userRequestIdentity = await this.userRequestIdentityService.buildUserRequestIdentity(
      this.customIdentitySessionMetadata
    );
    if (!userRequestIdentity.ok) {
      this.logger.debug("User request identity not available for get correlation id");
      return void 0;
    }
    return userRequestIdentity.identity.metadata.correlationId;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorRequest
});
