"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorRequestAppender_exports = {};
__export(rorRequestAppender_exports, {
  RorRequestAppender: () => RorRequestAppender
});
module.exports = __toCommonJS(rorRequestAppender_exports);
var import_rorRequest = require("./rorRequest");
class RorRequestAppender {
  constructor(sessionManagerProvider, userRequestIdentityServiceFactory) {
    this.sessionManagerProvider = sessionManagerProvider;
    this.userRequestIdentityServiceFactory = userRequestIdentityServiceFactory;
    __publicField(this, "appendRorRequest", (req, res, next) => {
      req.rorRequest = new import_rorRequest.RorRequest(req, this.sessionManagerProvider.get(), this.userRequestIdentityServiceFactory);
      next();
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorRequestAppender
});
