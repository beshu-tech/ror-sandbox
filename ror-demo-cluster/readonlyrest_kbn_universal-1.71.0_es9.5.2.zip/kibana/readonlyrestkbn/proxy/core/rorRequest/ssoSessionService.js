"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ssoSessionService_exports = {};
__export(ssoSessionService_exports, {
  SsoSessionService: () => SsoSessionService
});
module.exports = __toCommonJS(ssoSessionService_exports);
var import_types = require("../common/types");
class SsoSessionService {
  // Takes the provider (not a resolved SessionManager) and resolves lazily on each call, since
  // the provider's session manager isn't ready until its init() resolves - see the startup race
  // documented in SessionManagerProvider.build().
  constructor(sessionManagerProvider) {
    this.sessionManagerProvider = sessionManagerProvider;
  }
  async getSsoSessionProfile(rorRequest) {
    var _a;
    const sid = await rorRequest.getSid();
    if (!sid) return void 0;
    return (_a = await this.sessionManagerProvider.get().get(sid)) == null ? void 0 : _a.ssoSessionProfile;
  }
  async getSsoConnectorName(rorRequest) {
    var _a, _b;
    const sid = await rorRequest.getSid();
    if (!sid) return void 0;
    const session = await this.sessionManagerProvider.get().get(sid);
    return (_b = (_a = session == null ? void 0 : session.ssoSessionProfile) == null ? void 0 : _a.connectorName) != null ? _b : session == null ? void 0 : session.identitySessionHeaders.get(import_types.X_ROR_ORIGIN);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SsoSessionService
});
