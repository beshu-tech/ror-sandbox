"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var userRequestIdentityService_exports = {};
__export(userRequestIdentityService_exports, {
  UserRequestIdentityService: () => UserRequestIdentityService
});
module.exports = __toCommonJS(userRequestIdentityService_exports);
var import_accessLevel = require("../../../shared/types/accessLevel");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
class UserRequestIdentityService {
  constructor(sessionManager, cookieManager, expressRorRequest, tenancyService) {
    this.sessionManager = sessionManager;
    this.cookieManager = cookieManager;
    this.expressRorRequest = expressRorRequest;
    this.tenancyService = tenancyService;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  async buildUserRequestIdentity(customIdentitySessionMetadata, input) {
    const sid = (input == null ? void 0 : input.sid) || await this.getSid();
    if (sid == null) {
      return { ok: false, reason: "sid_not_available" };
    }
    const identitySessionMetadata = await this.sessionManager.get(sid);
    if (identitySessionMetadata == null) {
      return { ok: false, reason: "identity_session_not_available_for_provided_sid" };
    }
    if (identitySessionMetadata.type === "USER_WITHOUT_GROUPS") {
      return {
        ok: true,
        identity: {
          sid,
          metadata: {
            ...this.getUserRequestIdentityMetadataFromSessionWithoutGroups(identitySessionMetadata),
            ...customIdentitySessionMetadata
          }
        }
      };
    }
    const tenancyResolution = await this.tenancyService.getAndRememberTenancyForUserRequestIdentity(
      this.expressRorRequest.request,
      sid,
      identitySessionMetadata,
      input == null ? void 0 : input.predefinedTenancyId,
      this.expressRorRequest.getUrl()
    );
    if (!tenancyResolution.ok) {
      return { ok: false, reason: tenancyResolution.reason };
    }
    const tenancyBasedRequestIdentityMetadata = this.getUserRequestIdentityMetadataFromSessionWithGroups(
      identitySessionMetadata,
      tenancyResolution.data
    );
    return {
      ok: true,
      identity: {
        sid,
        metadata: { ...tenancyBasedRequestIdentityMetadata, ...customIdentitySessionMetadata }
      }
    };
  }
  async getTenancyId(sid) {
    if (!sid) {
      return;
    }
    const context = await this.tenancyService.getAndRememberTenancyContext(this.expressRorRequest.request, sid);
    return context == null ? void 0 : context.tenancyId;
  }
  async getSid() {
    try {
      return await this.cookieManager.decryptRorCookieFromHeader(this.expressRorRequest.getCookies());
    } catch (error) {
      this.logger.error({
        message: "Failed to decrypt SID from cookie",
        stack: error instanceof Error ? error.stack : String(error)
      });
      return null;
    }
  }
  getUserRequestIdentityMetadataFromSessionWithGroups(identitySessionMetadata, tenancy) {
    const { username, kibana, ror_origin, group } = tenancy;
    return this.buildUserRequestIdentityMetadata(
      identitySessionMetadata,
      { username, kibana, ror_origin, group },
      identitySessionMetadata.groups.map(({ group: group2 }) => group2)
    );
  }
  getUserRequestIdentityMetadataFromSessionWithoutGroups(identitySessionMetadata) {
    const { username, kibana, ror_origin } = identitySessionMetadata;
    return this.buildUserRequestIdentityMetadata(identitySessionMetadata, { username, kibana, ror_origin }, []);
  }
  buildUserRequestIdentityMetadata(sessionMetadata, kibanaFields, availableGroups) {
    var _a, _b, _c;
    const {
      correlationId,
      lastSessionActivityDate,
      impersonatedBy,
      expiresAt,
      identitySessionHeaders,
      whitelistedHeaders
    } = sessionMetadata;
    const { username, kibana, ror_origin, group } = kibanaFields;
    return {
      lastSessionActivityDate,
      correlationId,
      expiresAt,
      identitySessionHeaders,
      whitelistedHeaders,
      impersonatedBy,
      username,
      currentGroup: group,
      origin: ror_origin,
      customMetadata: (_a = kibana == null ? void 0 : kibana.metadata) != null ? _a : {},
      kibanaAccess: (_b = kibana == null ? void 0 : kibana.access) != null ? _b : import_accessLevel.AccessLevel.UNRESTRICTED,
      allowedApiPaths: kibana == null ? void 0 : kibana.allowed_api_paths,
      kibanaHiddenApps: (_c = kibana == null ? void 0 : kibana.hidden_apps) != null ? _c : [],
      kibanaIndex: kibana.index,
      kibanaTemplateIndex: kibana == null ? void 0 : kibana.template_index,
      availableGroups
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  UserRequestIdentityService
});
