"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var RorKbnSettingsPolicy_exports = {};
__export(RorKbnSettingsPolicy_exports, {
  RorKbnSettingsPolicy: () => RorKbnSettingsPolicy
});
module.exports = __toCommonJS(RorKbnSettingsPolicy_exports);
var import_lodash = require("lodash");
var import_kibanaYamlKibanaSettingsParser = require("../../../kibana/config/parsers/kibanaYamlKibanaSettingsParser");
var import_ActivationKey = require("../../../shared/types/ActivationKey");
class RorKbnSettingsPolicy {
  constructor(kibanaConfig) {
    this.kibanaConfig = kibanaConfig;
  }
  validate(rorKbnSettings, license) {
    const errors = this.validateKibanaProperties(rorKbnSettings, license);
    if ((0, import_lodash.isEmpty)(errors)) {
      return { ok: true, data: void 0 };
    }
    return { ok: false, error: errors };
  }
  validateKibanaProperties(rorKbnSettings, license) {
    var _a, _b;
    const kibanaIndex = (_b = (_a = this.kibanaConfig) == null ? void 0 : _a.kibana) == null ? void 0 : _b.index;
    if (kibanaIndex && kibanaIndex !== import_kibanaYamlKibanaSettingsParser.DEFAULT_KIBANA_INDEX && (0, import_ActivationKey.isEnterpriseLicense)(license) && rorKbnSettings.multiTenancyEnabled) {
      return [
        "A custom `kibana.index` value is not allowed when `readonlyrest_kbn.multiTenancyEnabled` is set to true (default: true)! This is to prevent inconsistent behaviour. Disable multi-tenancy if you really need a non standard `kibana index`. Questions? Please use the Forum https://forum.readonlyrest.com."
      ];
    }
    return [];
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorKbnSettingsPolicy
});
