"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var RorSettings_exports = {};
__export(RorSettings_exports, {
  RorSettings: () => RorSettings
});
module.exports = __toCommonJS(RorSettings_exports);
class RorSettings {
  constructor(_rorKbnSettings, _parsedRawRorSettings, _source) {
    this._rorKbnSettings = _rorKbnSettings;
    this._parsedRawRorSettings = _parsedRawRorSettings;
    this._source = _source;
  }
  get rorKbnSettings() {
    return this._rorKbnSettings;
  }
  get settingsSource() {
    return this._source;
  }
  get parsedRawRorSettings() {
    return this._parsedRawRorSettings;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorSettings
});
