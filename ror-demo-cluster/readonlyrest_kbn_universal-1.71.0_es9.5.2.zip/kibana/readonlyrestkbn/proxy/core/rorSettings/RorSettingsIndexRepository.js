"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var RorSettingsIndexRepository_exports = {};
__export(RorSettingsIndexRepository_exports, {
  EsRorSettingsIndexRepository: () => EsRorSettingsIndexRepository
});
module.exports = __toCommonJS(RorSettingsIndexRepository_exports);
var import_correlationIdWrapper = require("../api/correlationIdWrapper");
class EsRorSettingsIndexRepository {
  constructor(rorEsApiClientWithAuthProvider) {
    this.rorEsApiClientWithAuthProvider = rorEsApiClientWithAuthProvider;
  }
  async getSettings(identityHeaders, whitelistedHeaders, correlationId) {
    return this.scopedClient(identityHeaders).withCorrelationIdHeader(correlationId).getMainSettingsFromIndex({ identitySessionHeaders: identityHeaders, whitelistedHeaders });
  }
  async getFileSettings(identityHeaders, whitelistedHeaders, correlationId) {
    return this.scopedClient(identityHeaders).withCorrelationIdHeader(correlationId).getFileSettings({ identitySessionHeaders: identityHeaders, whitelistedHeaders });
  }
  async saveSettings(raw, identityHeaders, whitelistedHeaders, correlationId) {
    return this.scopedClient(identityHeaders).withCorrelationIdHeader(correlationId).postSettings({
      requestBody: { settings: raw },
      identitySessionHeaders: identityHeaders,
      whitelistedHeaders
    });
  }
  scopedClient(identityHeaders) {
    return new import_correlationIdWrapper.CorrelationIdWrapper(this.rorEsApiClientWithAuthProvider.asScoped(identityHeaders));
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  EsRorSettingsIndexRepository
});
