"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RorSettingsManager_exports = {};
__export(RorSettingsManager_exports, {
  RorSettingsManager: () => RorSettingsManager,
  getRorSettingsManager: () => getRorSettingsManager
});
module.exports = __toCommonJS(RorSettingsManager_exports);
var import_lodash = require("lodash");
var import_settingsTypes = require("../../../shared/types/api/es/settingsTypes");
var import_errors = __toESM(require("../../constants/errors"));
var import_lazyUtils = require("../lazyUtils");
var import_LicenseRelatedSettingsPolicy = require("../license/LicenseRelatedSettingsPolicy");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_RawRorSettingsParser = require("./rawRorSettingsParser/RawRorSettingsParser");
var import_RorKbnSettingsBuilder = require("./rorKbnSettingsBuilder/RorKbnSettingsBuilder");
var import_RorKbnSettingsPolicy = require("./RorKbnSettingsPolicy");
var import_RorSettingsFactory = require("./RorSettingsFactory");
var import_RorSettingsIndexRepository = require("./RorSettingsIndexRepository");
var import_RorSettingsMerger = require("./RorSettingsMerger");
var import_RorSettingsProvider = require("./RorSettingsProvider");
var import_RorSettingsStore = require("./RorSettingsStore");
const _RorSettingsManager = class _RorSettingsManager {
  constructor(kibanaConfig, settingsIndexRepository, rorKbnSettingsPolicy, rorSettingsProvider, rorSettingsStore, licenseService) {
    this.kibanaConfig = kibanaConfig;
    this.settingsIndexRepository = settingsIndexRepository;
    this.rorKbnSettingsPolicy = rorKbnSettingsPolicy;
    this.rorSettingsProvider = rorSettingsProvider;
    this.rorSettingsStore = rorSettingsStore;
    this.licenseService = licenseService;
    __publicField(this, "SETTINGS_REFRESH_INTERVAL", 5e3);
    // 6 * 5s = 30s total budget
    __publicField(this, "refreshIntervalId");
    __publicField(this, "getMergedRorKbnAndEsSettings", async (parsedRawRorEsSettings) => {
      _RorSettingsManager.assertInitialized(_RorSettingsManager.instance);
      const rorKbnSettingsFromFile = (await _RorSettingsManager.instance.rorSettingsProvider.getRorKbnSettingsWithSourceInfo()).result;
      if (!rorKbnSettingsFromFile.ok) {
        return rorKbnSettingsFromFile;
      }
      const rorSettingsMerger = new import_RorSettingsMerger.RorSettingsMerger();
      return rorSettingsMerger.mergePluginsSettings(
        parsedRawRorEsSettings,
        rorKbnSettingsFromFile.data.parsedRawRorSettings
      );
    });
  }
  static async initialize(kibanaConfig, rorEsApiClientWithAuthProvider, licenseService) {
    if (_RorSettingsManager.instance) {
      throw new Error(import_errors.default.rorSettingsManager.alreadyInitialized);
    }
    const instance = new _RorSettingsManager(
      kibanaConfig,
      new import_RorSettingsIndexRepository.EsRorSettingsIndexRepository(rorEsApiClientWithAuthProvider),
      new import_RorKbnSettingsPolicy.RorKbnSettingsPolicy(kibanaConfig),
      new import_RorSettingsProvider.RorSettingsProvider(kibanaConfig, rorEsApiClientWithAuthProvider),
      new import_RorSettingsStore.RorSettingsStore(),
      licenseService
    );
    const loadRorSettingsResponse = await instance.loadRorSettingsFromIndexOrFileFallback();
    if (!loadRorSettingsResponse.ok) {
      this.getLogger().error({ message: loadRorSettingsResponse.error });
      throw new Error(loadRorSettingsResponse.error);
    }
    instance.startPeriodicSettingsRefresh();
    instance.subscribeToLicenseChange(instance.licenseService, instance.rorSettingsStore);
    instance.subscribeToRorSettingsChange(instance.licenseService, instance.rorSettingsStore);
    _RorSettingsManager.instance = instance;
    return instance;
  }
  static getInstance() {
    _RorSettingsManager.assertInitialized(_RorSettingsManager.instance);
    return _RorSettingsManager.instance;
  }
  static isInitialized() {
    return Boolean(_RorSettingsManager.instance);
  }
  clearRorSettingsManager() {
    if (this.refreshIntervalId !== void 0) {
      clearInterval(this.refreshIntervalId);
    }
    this.refreshIntervalId = void 0;
    _RorSettingsManager.instance = null;
    _RorSettingsManager.getLogger().info("RorSettingsManager cleared successfully");
  }
  rorKbnSettingsStore() {
    return this.rorSettingsStore;
  }
  async getMainSettingsFromIndex({
    identityHeaders,
    whitelistedHeaders,
    correlationId
  }) {
    return this.settingsIndexRepository.getSettings(identityHeaders, whitelistedHeaders, correlationId);
  }
  async getMainSettingsFromFile({
    identityHeaders,
    whitelistedHeaders,
    correlationId
  }) {
    const esResponse = await this.settingsIndexRepository.getFileSettings(
      identityHeaders,
      whitelistedHeaders,
      correlationId
    );
    if (esResponse.body.status !== "ok") {
      return { ok: false, esFailureResponse: esResponse.body };
    }
    const parseToRawRorEsSettingsResult = (0, import_RawRorSettingsParser.parseToRawRorEsSettings)(esResponse.body.message);
    if (!parseToRawRorEsSettingsResult.ok) {
      return { ok: false, error: parseToRawRorEsSettingsResult.error };
    }
    const mergedRorKbnAndEsSettings = await this.getMergedRorKbnAndEsSettings(parseToRawRorEsSettingsResult.data);
    if (!mergedRorKbnAndEsSettings.ok) {
      return { ok: false, error: mergedRorKbnAndEsSettings.error };
    }
    return { ok: true, data: mergedRorKbnAndEsSettings.data };
  }
  async saveSettings({
    parsedToRawRorKbnAndEsSettings,
    identityHeaders,
    whitelistedHeaders,
    correlationId
  }) {
    var _a, _b;
    const newRorSettings = await new import_RorSettingsFactory.RorSettingsFactory(new import_RorKbnSettingsBuilder.RorKbnSettingsBuilder()).create(
      this.kibanaConfig,
      parsedToRawRorKbnAndEsSettings,
      "index"
    );
    const { rorKbnSettings } = newRorSettings;
    const prevSettings = this.rorSettingsStore.getLatestRorSettings();
    const currentCookiePass = prevSettings == null ? void 0 : prevSettings.rorKbnSettings.cookieSettings.password;
    const newCookiePass = rorKbnSettings.cookieSettings.password;
    const cookiePassChanged = currentCookiePass !== void 0 && currentCookiePass !== newCookiePass;
    const decryptionKey = cookiePassChanged ? currentCookiePass : newCookiePass;
    const validateSettingsResult = await this.resolveLicenseAndValidateSettingsPolicy(rorKbnSettings, decryptionKey);
    if (!validateSettingsResult.ok) {
      const policyValidationError = validateSettingsResult.error.join("\n");
      _RorSettingsManager.getLogger().error({
        message: import_errors.default.rorSettingsManager.policyValidationFailed(policyValidationError)
      });
      return { ok: false, error: policyValidationError };
    }
    const reEncryptResult = cookiePassChanged ? await this.licenseService.reEncryptActivationKey(
      rorKbnSettings.licenseSettings,
      currentCookiePass,
      newCookiePass
    ) : null;
    if (reEncryptResult && !reEncryptResult.ok) {
      return { ok: false, error: reEncryptResult.error };
    }
    const cleanup = (_b = (_a = reEncryptResult == null ? void 0 : reEncryptResult.data) == null ? void 0 : _a.cleanup) != null ? _b : null;
    let settingsSaved = false;
    const esResponse = await this.settingsIndexRepository.saveSettings(parsedToRawRorKbnAndEsSettings.raw, identityHeaders, whitelistedHeaders, correlationId).then((response) => {
      settingsSaved = (0, import_settingsTypes.isUpdateMainSettingsSuccessfully)(response.body);
      return response;
    }).finally(
      () => cleanup == null ? void 0 : cleanup(settingsSaved).catch(
        (e) => _RorSettingsManager.getLogger().warn(
          `Failed to clean up stale activation key entry \u2014 it will be removed automatically on next read: ${e.message}`
        )
      )
    );
    if (cleanup && !settingsSaved) {
      return {
        ok: false,
        error: "Settings save failed. The activation key has been restored to its previous state."
      };
    }
    if (settingsSaved) {
      this.updateLatestRorSettingsIfNeeded(prevSettings, newRorSettings);
    }
    return { ok: true, data: esResponse };
  }
  // getFromIndexUsingApi distinguishes "reached ES, got a well-formed non-answer" (empty index,
  // malformed content) from "the request failed or ES isn't ready to answer yet" (transport
  // error, or a non-empty non-ok status - e.g. the startup race where ES is up but the ROR
  // settings index isn't ready yet) - a retry can only help the latter, so that's the case worth
  // spending the retry budget on.
  // TODO: this matches on the formatted error *message* because getFromIndexUsingApi only ever
  // returns a Result<T, string> - the actual HTTP/ES response status never survives to here.
  // Rework to propagate the real status (or an error-kind enum) through the Result so this can
  // check it directly instead of pattern-matching strings.
  static isTransportFailure(error) {
    return error.includes(import_errors.default.rorSettingsManager.failedToFetchingFromRorIndex) || error.includes(import_errors.default.rorSettingsManager.errorFetchingFromRorIndex);
  }
  startPeriodicSettingsRefresh() {
    _RorSettingsManager.getLogger().info(`Starting settings auto-refresh every ${this.SETTINGS_REFRESH_INTERVAL}ms`);
    this.refreshIntervalId = setInterval(async () => {
      try {
        _RorSettingsManager.getLogger().debug("Auto-refreshing ROR settings...");
        await this.loadRorSettingsFromIndex();
      } catch (error) {
        _RorSettingsManager.getLogger().error({
          message: `${import_errors.default.rorSettingsManager.settingsRefreshFailed}: ${error.message}`,
          stack: error.stack
        });
      }
    }, this.SETTINGS_REFRESH_INTERVAL);
  }
  async loadRorSettingsFromIndex() {
    const prevSettings = this.rorSettingsStore.getLatestRorSettings();
    const rorKbnAndEsSettingsFromIndex = await this.rorSettingsProvider.getFromIndexUsingApi();
    if (!rorKbnAndEsSettingsFromIndex.ok) {
      return { ok: false, error: rorKbnAndEsSettingsFromIndex.error };
    }
    const newSettings = rorKbnAndEsSettingsFromIndex.data;
    const validateSettingsResult = await this.resolveLicenseAndValidateSettingsPolicy(
      newSettings.rorKbnSettings,
      newSettings.rorKbnSettings.cookieSettings.password
    );
    if (!validateSettingsResult.ok) {
      const policyValidationError = validateSettingsResult.error.join("\n");
      _RorSettingsManager.getLogger().error({
        message: import_errors.default.rorSettingsManager.policyValidationFailed(policyValidationError)
      });
      return { ok: false, error: policyValidationError };
    }
    _RorSettingsManager.getLogger().info("Successfully loaded ReadonlyREST settings from index");
    this.updateLatestRorSettingsIfNeeded(prevSettings, newSettings);
    return { ok: true, data: newSettings.rorKbnSettings };
  }
  async loadRorSettingsFromIndexOrFileFallback() {
    const prevSettings = this.rorSettingsStore.getLatestRorSettings();
    const rorKbnSettingsFromFileWithSourceInfo = await this.rorSettingsProvider.getRorKbnSettingsWithSourceInfo();
    const rorKbnSettingsFromFile = rorKbnSettingsFromFileWithSourceInfo.result;
    const rorKbnAndEsSettingsFromIndex = await (0, import_lazyUtils.retryUntilOk)(
      () => this.rorSettingsProvider.getFromIndexUsingApi(),
      {
        maxRetries: _RorSettingsManager.SETTINGS_LOAD_MAX_RETRIES,
        retryInterval: _RorSettingsManager.SETTINGS_LOAD_RETRY_INTERVAL
      },
      (error, retriesLeft) => _RorSettingsManager.getLogger().info(
        `Cannot fetch ReadonlyREST settings from index yet (${error}). Retrying in ${_RorSettingsManager.SETTINGS_LOAD_RETRY_INTERVAL / 1e3} seconds... ${retriesLeft} attempts left`
      ),
      _RorSettingsManager.isTransportFailure
    );
    if (!rorKbnAndEsSettingsFromIndex.ok && !rorKbnSettingsFromFile.ok) {
      _RorSettingsManager.getLogger().error({ message: "Cannot get ReadonlyREST settings" });
      return { ok: false, error: `${rorKbnAndEsSettingsFromIndex.error}, ${rorKbnSettingsFromFile.error}` };
    }
    const proposedRorKbnSettings = rorKbnAndEsSettingsFromIndex.ok ? rorKbnAndEsSettingsFromIndex.data : rorKbnSettingsFromFile.ok ? rorKbnSettingsFromFile.data : void 0;
    if (!proposedRorKbnSettings) {
      return { ok: false, error: import_errors.default.rorSettingsManager.noValidSourceAvailable };
    }
    const validateSettingsResult = await this.resolveLicenseAndValidateSettingsPolicy(
      proposedRorKbnSettings.rorKbnSettings,
      proposedRorKbnSettings.rorKbnSettings.cookieSettings.password
    );
    if (!validateSettingsResult.ok) {
      const policyValidationError = validateSettingsResult.error.join("\n");
      _RorSettingsManager.getLogger().error({
        message: import_errors.default.rorSettingsManager.policyValidationFailed(policyValidationError)
      });
      return { ok: false, error: policyValidationError };
    }
    this.updateLatestRorSettingsIfNeeded(prevSettings, proposedRorKbnSettings);
    const latestRorSettings = this.rorSettingsStore.getLatestRorSettings();
    if (!latestRorSettings) {
      return { ok: false, error: import_errors.default.rorSettingsManager.notInitialized };
    }
    this.deprecatedRorSettingsWarning(
      rorKbnAndEsSettingsFromIndex.ok,
      rorKbnSettingsFromFileWithSourceInfo.sources.readonlyRestAvailable,
      rorKbnSettingsFromFileWithSourceInfo.sources.kibanaConfigAvailable,
      latestRorSettings.settingsSource
    );
    const latestRorKbnSettings = this.rorKbnSettingsStore().getLatestRorKbnSettings();
    return { ok: true, data: latestRorKbnSettings };
  }
  updateLatestRorSettingsIfNeeded(prevSettings, newSettings) {
    if (!prevSettings || newSettings && !(0, import_lodash.isEqual)(prevSettings.parsedRawRorSettings, newSettings.parsedRawRorSettings)) {
      this.rorSettingsStore.setRorSettings(newSettings);
      _RorSettingsManager.getLogger().info(
        "Successfully loaded ReadonlyREST Kibana plugin settings:",
        newSettings == null ? void 0 : newSettings.rorKbnSettings
      );
    } else {
      _RorSettingsManager.getLogger().debug("Settings have not changed, no need to refresh");
    }
  }
  deprecatedRorSettingsWarning(hasSettingsFromIndex, hasSettingsFromReadonlyRestYaml, hasSettingsFromKibanaYaml, settingsSource) {
    if (settingsSource === "kibana.yml") {
      _RorSettingsManager.getLogger().warn(import_errors.default.rorSettingsManager.deprecatedSettingsWarnings.kibanaYmlDeprecated);
    }
    if (hasSettingsFromKibanaYaml) {
      if (hasSettingsFromIndex) {
        _RorSettingsManager.getLogger().warn(
          import_errors.default.rorSettingsManager.deprecatedSettingsWarnings.kibanaYmlAndIndexConflict
        );
      } else if (hasSettingsFromReadonlyRestYaml) {
        _RorSettingsManager.getLogger().warn(
          import_errors.default.rorSettingsManager.deprecatedSettingsWarnings.kibanaYmlAndFileConflict
        );
      }
    }
  }
  async resolveLicenseAndValidateSettingsPolicy(rorKbnSettings, decryptionKey) {
    const { licenseSettings } = rorKbnSettings;
    const licenseSettingsRelatedPolicyResult = await this.licenseService.getLicenseRelatedSettingsPolicy(
      licenseSettings,
      decryptionKey
    );
    if (!licenseSettingsRelatedPolicyResult.ok) {
      return { ok: false, error: [licenseSettingsRelatedPolicyResult.error] };
    }
    const { licenseRelatedSettingsPolicy, license } = licenseSettingsRelatedPolicyResult.data;
    return this.validateSettingsPolicy(rorKbnSettings, licenseRelatedSettingsPolicy, license);
  }
  async validateSettingsPolicy(rorKbnSettings, licenseRelatedSettingsPolicy, license) {
    const licenseRelatedSettingsPolicyResult = licenseRelatedSettingsPolicy.validate(rorKbnSettings);
    if (!licenseRelatedSettingsPolicyResult.ok) {
      return { ok: false, error: licenseRelatedSettingsPolicyResult.error };
    }
    const rorKbnSettingsPolicyResult = this.rorKbnSettingsPolicy.validate(rorKbnSettings, license);
    if (!rorKbnSettingsPolicyResult.ok) {
      return { ok: false, error: rorKbnSettingsPolicyResult.error };
    }
    return { ok: true, data: void 0 };
  }
  subscribeToLicenseChange(licenseService, rorKbnSettingsStore) {
    licenseService.onLicenseChanged$.subscribe(async (license) => {
      const currentRorKbnSettings = rorKbnSettingsStore.getLatestRorKbnSettings();
      const licenseRelatedSettingsPolicy = new import_LicenseRelatedSettingsPolicy.LicenseRelatedSettingsPolicy(license);
      const validateSettingsResult = await this.validateSettingsPolicy(
        currentRorKbnSettings,
        licenseRelatedSettingsPolicy,
        license
      );
      if (!validateSettingsResult.ok) {
        validateSettingsResult.error.forEach((error) => _RorSettingsManager.getLogger().error({ message: error }));
      }
    });
  }
  subscribeToRorSettingsChange(licenseService, rorSettingsStore) {
    rorSettingsStore.observerRorKbnSettings(({ licenseSettings, cookieSettings }) => ({
      licenseSettings,
      cookieSettings
    })).subscribe(({ licenseSettings, cookieSettings: { password: storeEncryptionKey } }) => {
      licenseService.configureRorSettings(licenseSettings, storeEncryptionKey);
    });
  }
  static assertInitialized(instance) {
    if (!instance) {
      throw new Error(import_errors.default.rorSettingsManager.notInitialized);
    }
  }
};
// eslint-disable-next-line no-use-before-define
__publicField(_RorSettingsManager, "instance", null);
__publicField(_RorSettingsManager, "getLogger", () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
// 5 seconds
__publicField(_RorSettingsManager, "SETTINGS_LOAD_RETRY_INTERVAL", 5e3);
// 5 seconds
__publicField(_RorSettingsManager, "SETTINGS_LOAD_MAX_RETRIES", 6);
let RorSettingsManager = _RorSettingsManager;
const getRorSettingsManager = () => RorSettingsManager.getInstance();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorSettingsManager,
  getRorSettingsManager
});
