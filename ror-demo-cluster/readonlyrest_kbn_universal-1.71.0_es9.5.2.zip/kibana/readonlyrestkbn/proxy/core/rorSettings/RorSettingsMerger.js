"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RorSettingsMerger_exports = {};
__export(RorSettingsMerger_exports, {
  RorSettingsMerger: () => RorSettingsMerger
});
module.exports = __toCommonJS(RorSettingsMerger_exports);
var import_yamlDocumentsMerger = require("../common/yamlDocumentsMerger");
var import_RawRorSettingsParser = require("./rawRorSettingsParser/RawRorSettingsParser");
class RorSettingsMerger {
  constructor() {
    __publicField(this, "yamlMerger", new import_yamlDocumentsMerger.YamlDocumentsMerger());
  }
  mergePluginsSettings(parsedRawRorEsSettings, parsedRawRorKbnSettings) {
    const rorSettings = this.mergedYamlSettings(parsedRawRorEsSettings.parsed, parsedRawRorKbnSettings.parsed);
    const parseToRawRorKbnAndEsSettingsResult = (0, import_RawRorSettingsParser.parseToRawRorKbnAndEsSettings)(rorSettings.toString({ lineWidth: -1 }));
    if (!parseToRawRorKbnAndEsSettingsResult.ok) {
      return {
        ok: false,
        error: parseToRawRorKbnAndEsSettingsResult.error
      };
    }
    return {
      data: parseToRawRorKbnAndEsSettingsResult.data,
      ok: true
    };
  }
  mergedYamlSettings(rorEsSettingsYaml, rorKbnSettingsYaml) {
    return this.yamlMerger.mergeDocuments(rorEsSettingsYaml, rorKbnSettingsYaml);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorSettingsMerger
});
