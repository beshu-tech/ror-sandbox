"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RorSettingsProvider_exports = {};
__export(RorSettingsProvider_exports, {
  RorSettingsProvider: () => RorSettingsProvider
});
module.exports = __toCommonJS(RorSettingsProvider_exports);
var import_path = __toESM(require("path"));
var import_fs_extra = __toESM(require("fs-extra"));
var import_errors = __toESM(require("../../constants/errors"));
var import_versionedLibraries = require("../common/versionedLibraries");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_RawRorSettingsParser = require("./rawRorSettingsParser/RawRorSettingsParser");
var import_RorKbnSettingsBuilder = require("./rorKbnSettingsBuilder/RorKbnSettingsBuilder");
var import_RorSettingsFactory = require("./RorSettingsFactory");
class RorSettingsProvider {
  constructor(kibanaConfig, rorEsApiClientWithAuthProvider) {
    this.kibanaConfig = kibanaConfig;
    this.rorEsApiClientWithAuthProvider = rorEsApiClientWithAuthProvider;
    __publicField(this, "settingsKibanaYamlFilename", "kibana.yml");
    __publicField(this, "settingsReadonlyRestYmlFilename", "readonlyrest.yml");
    __publicField(this, "builder");
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    this.builder = new import_RorKbnSettingsBuilder.RorKbnSettingsBuilder();
  }
  async getFromIndexUsingApi() {
    try {
      const response = await this.rorEsApiClientWithAuthProvider.asTechnicalUser().getMainSettingsFromIndex();
      const data = response.body;
      if (data.status === "empty") {
        this.logger.debug(import_errors.default.rorSettingsManager.emptyRorIndex);
        return { ok: false, error: import_errors.default.rorSettingsManager.emptyRorIndex };
      }
      if (data.status !== "ok") {
        this.logger.debug(`${import_errors.default.rorSettingsManager.errorFetchingFromRorIndex}:`, data);
        return { ok: false, error: import_errors.default.rorSettingsManager.errorFetchingFromRorIndex };
      }
      const rawRorSettings = data.message;
      const parseToRawRorKbnAndEsSettingsOrRawEsSettingsResult = (0, import_RawRorSettingsParser.parseToRawRorKbnAndEsSettingsOrRawEsSettings)(rawRorSettings);
      if (!parseToRawRorKbnAndEsSettingsOrRawEsSettingsResult.ok) {
        this.logger.debug(parseToRawRorKbnAndEsSettingsOrRawEsSettingsResult.error);
        return { ok: false, error: parseToRawRorKbnAndEsSettingsOrRawEsSettingsResult.error };
      }
      if (parseToRawRorKbnAndEsSettingsOrRawEsSettingsResult.data.type === "parsedRawRorEsSettings") {
        return { ok: false, error: import_errors.default.rorSettingsManager.rorKbnSectionNotFoundInIndex };
      }
      const rorSettings = await new import_RorSettingsFactory.RorSettingsFactory(this.builder).create(
        this.kibanaConfig,
        parseToRawRorKbnAndEsSettingsOrRawEsSettingsResult.data,
        "index"
      );
      this.logger.debug(`Successfully get settings from ReadonlyREST settings index`);
      return {
        ok: true,
        data: rorSettings
      };
    } catch (error) {
      const err = error;
      this.logger.error(
        { message: `${import_errors.default.rorSettingsManager.failedToFetchingFromRorIndex}:`, stack: err.stack },
        err.message
      );
      return {
        ok: false,
        error: `${import_errors.default.rorSettingsManager.failedToFetchingFromRorIndex}. Check. For more information, consult the Kibana logs.`
      };
    }
  }
  async getRorKbnSettingsWithSourceInfo() {
    const fromReadonlyRest = await this.getRorKbnSettingsFromKbnReadonlyrestFile();
    const fromKibana = await this.getRorKbnSettingsFromKibanaConfigFile();
    const readonlyRestAvailable = fromReadonlyRest.ok;
    const kibanaConfigAvailable = fromKibana.ok;
    if (readonlyRestAvailable) {
      return {
        result: fromReadonlyRest,
        sources: {
          readonlyRestAvailable,
          kibanaConfigAvailable
        }
      };
    }
    return {
      result: fromKibana,
      sources: {
        readonlyRestAvailable,
        kibanaConfigAvailable
      }
    };
  }
  async getRorKbnSettingsFromKbnReadonlyrestFile() {
    const settingsFilePath = import_path.default.resolve(process.cwd(), `config/${this.settingsReadonlyRestYmlFilename}`);
    try {
      if (!import_fs_extra.default.existsSync(settingsFilePath)) {
        return { ok: false, error: import_errors.default.rorSettingsManager.settingsFileNotFound(settingsFilePath) };
      }
      const data = await import_fs_extra.default.readFile(settingsFilePath, "utf8");
      const parseToRawRorKbnSettingsResult = (0, import_RawRorSettingsParser.parseToRawRorKbnSettings)(data);
      if (!parseToRawRorKbnSettingsResult.ok) {
        return { ok: false, error: parseToRawRorKbnSettingsResult.error };
      }
      const rorSettings = await new import_RorSettingsFactory.RorSettingsFactory(this.builder).create(
        this.kibanaConfig,
        parseToRawRorKbnSettingsResult.data,
        "file"
      );
      this.logger.debug(`Successfully got settings from ${this.settingsReadonlyRestYmlFilename} config file`);
      return {
        ok: true,
        data: rorSettings
      };
    } catch (error) {
      this.logger.error({ message: "Failed to read settings from file:", stack: error.stack }, error.message);
      return {
        ok: false,
        error: import_errors.default.rorSettingsManager.failedToReadSettings(settingsFilePath)
      };
    }
  }
  async getRorKbnSettingsFromKibanaConfigFile() {
    if (!this.kibanaConfig.readonlyrest_kbn) {
      return {
        ok: false,
        error: import_errors.default.rorSettingsManager.settingsNotSet("kibana.yml")
      };
    }
    const stringSettings = import_versionedLibraries.yaml.stringify({
      readonlyrest_kbn: this.kibanaConfig.readonlyrest_kbn
    });
    const parseToRawRorKbnSettingsResult = (0, import_RawRorSettingsParser.parseToRawRorKbnSettings)(stringSettings);
    if (!parseToRawRorKbnSettingsResult.ok) {
      return { ok: false, error: parseToRawRorKbnSettingsResult.error };
    }
    const rorSettings = await new import_RorSettingsFactory.RorSettingsFactory(this.builder).create(
      this.kibanaConfig,
      parseToRawRorKbnSettingsResult.data,
      "kibana.yml"
    );
    this.logger.debug(`Successfully got settings from ${this.settingsKibanaYamlFilename} file`);
    return {
      ok: true,
      data: rorSettings
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorSettingsProvider
});
