"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RorSettingsStore_exports = {};
__export(RorSettingsStore_exports, {
  RorSettingsStore: () => RorSettingsStore
});
module.exports = __toCommonJS(RorSettingsStore_exports);
var import_lodash = require("lodash");
var import_rxjs = require("rxjs");
class RorSettingsStore {
  constructor() {
    __publicField(this, "rorKbnSettings$");
    __publicField(this, "rorSettingsState$", new import_rxjs.BehaviorSubject(null));
    this.rorKbnSettings$ = this.rorSettingsState$.pipe(
      (0, import_rxjs.filter)((s) => s !== null),
      (0, import_rxjs.map)((s) => s.rorKbnSettings),
      (0, import_rxjs.distinctUntilChanged)(import_lodash.isEqual),
      (0, import_rxjs.shareReplay)({ bufferSize: 1, refCount: true })
    );
  }
  getLatestRorSettings() {
    return this.rorSettingsState$.value;
  }
  getLatestRorKbnSettings() {
    const value = this.rorSettingsState$.value;
    if (!value) {
      throw new Error("RorKbnSettings not initialized yet");
    }
    return value.rorKbnSettings;
  }
  observerRorKbnSettings(selector, compare = import_lodash.isEqual) {
    return this.rorKbnSettings$.pipe((0, import_rxjs.map)(selector), (0, import_rxjs.distinctUntilChanged)(compare));
  }
  setRorSettings(rorSettings) {
    this.rorSettingsState$.next(rorSettings);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorSettingsStore
});
