"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RawRorSettingsCleaner_exports = {};
__export(RawRorSettingsCleaner_exports, {
  RawRorSettingsCleaner: () => RawRorSettingsCleaner
});
module.exports = __toCommonJS(RawRorSettingsCleaner_exports);
var import_versionedLibraries = require("../../common/versionedLibraries");
var import_rorLoggerFactory = require("../../logging/rorLoggerFactory");
class RawRorSettingsCleaner {
  constructor(sectionsToRemove) {
    this.sectionsToRemove = sectionsToRemove;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  removeSectionFrom(s) {
    var _a, _b;
    let parsedYaml;
    try {
      parsedYaml = import_versionedLibraries.yaml.parseDocument(s);
    } catch (e) {
      this.logger.error({ message: `Failed to parse YAML input: ${e.message}` });
      throw new Error(`Failed to parse YAML input: ${e == null ? void 0 : e.message}`);
    }
    try {
      for (const section of this.sectionsToRemove) {
        try {
          parsedYaml.delete(section);
        } catch (e) {
          (_b = (_a = this.logger).warn) == null ? void 0 : _b.call(_a, `Failed to delete section from YAML: ${section}`, { message: e == null ? void 0 : e.message });
        }
      }
      return parsedYaml.toString({ lineWidth: -1 });
    } catch (e) {
      const message = `Failed to serialize cleaned YAML: ${e == null ? void 0 : e.message}`;
      this.logger.error({ message });
      throw new Error(message);
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RawRorSettingsCleaner
});
