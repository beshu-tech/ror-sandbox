"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RawRorSettingsParser_exports = {};
__export(RawRorSettingsParser_exports, {
  RawRorEsSettingsParser: () => RawRorEsSettingsParser,
  RawRorKbnAndEsSettingsParser: () => RawRorKbnAndEsSettingsParser,
  RawRorKbnSettingsParser: () => RawRorKbnSettingsParser,
  parseToRawRorEsSettings: () => parseToRawRorEsSettings,
  parseToRawRorKbnAndEsSettings: () => parseToRawRorKbnAndEsSettings,
  parseToRawRorKbnAndEsSettingsOrRawEsSettings: () => parseToRawRorKbnAndEsSettingsOrRawEsSettings,
  parseToRawRorKbnSettings: () => parseToRawRorKbnSettings
});
module.exports = __toCommonJS(RawRorSettingsParser_exports);
var import_versionedLibraries = require("../../common/versionedLibraries");
var import_rorLoggerFactory = require("../../logging/rorLoggerFactory");
var import_constants = require("./constants");
var import_RawRorSettingsCleaner = require("./RawRorSettingsCleaner");
var import_RawRorSettingsValidators = require("./RawRorSettingsValidators");
class RawRorSettingsParserBase {
  constructor(validators) {
    this.validators = validators;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  fromString(s) {
    let parsedYaml;
    try {
      parsedYaml = import_versionedLibraries.yaml.parseDocument(s);
    } catch (e) {
      const error2 = `Failed to parse YAML input: ${e.message}`;
      this.logger.error({ message: error2 });
      return { ok: false, error: error2 };
    }
    const validators = new import_RawRorSettingsValidators.ValidatorsRunner(this.validators);
    const validationResult = validators.validate(parsedYaml);
    if (validationResult.ok) {
      return { ok: true, data: { type: this.type, parsed: parsedYaml, raw: s } };
    }
    const error = `Validation error while parsing YAML input: ${validationResult.error}`;
    this.logger.error({ message: error });
    return { ok: false, error };
  }
}
class RawRorEsSettingsParser extends RawRorSettingsParserBase {
  constructor() {
    super(...arguments);
    __publicField(this, "type", "parsedRawRorEsSettings");
  }
}
class RawRorKbnSettingsParser extends RawRorSettingsParserBase {
  constructor() {
    super(...arguments);
    __publicField(this, "type", "parsedRawRorKbnSettings");
  }
}
class RawRorKbnAndEsSettingsParser extends RawRorSettingsParserBase {
  constructor() {
    super(...arguments);
    __publicField(this, "type", "parsedRawRorKbnAnEsSettings");
  }
}
const parseToRawRorEsSettings = (s) => new RawRorEsSettingsParser([
  // forbiddenSections is unreachable here: RawRorSettingsCleaner below already strips KBN_SECTIONS
  // before this validator runs. Kept as defense-in-depth in case this wiring ever changes.
  new import_RawRorSettingsValidators.SectionValidator({ expectedSections: import_constants.ES_SECTIONS, forbiddenSections: import_constants.KBN_SECTIONS })
]).fromString(new import_RawRorSettingsCleaner.RawRorSettingsCleaner(import_constants.KBN_SECTIONS).removeSectionFrom(s));
const parseToRawRorKbnSettings = (s) => new RawRorKbnSettingsParser([
  // forbiddenSections is unreachable here: RawRorSettingsCleaner below already strips ES_SECTIONS
  // before this validator runs. Kept as defense-in-depth in case this wiring ever changes.
  new import_RawRorSettingsValidators.SectionValidator({ expectedSections: import_constants.KBN_SECTIONS, forbiddenSections: import_constants.ES_SECTIONS }),
  new import_RawRorSettingsValidators.RorKbnSchemaValidator()
]).fromString(new import_RawRorSettingsCleaner.RawRorSettingsCleaner(import_constants.ES_SECTIONS).removeSectionFrom(s));
const parseToRawRorKbnAndEsSettings = (s) => new RawRorKbnAndEsSettingsParser([
  new import_RawRorSettingsValidators.CombinedValidator([
    new import_RawRorSettingsValidators.SectionValidator({ expectedSections: import_constants.KBN_SECTIONS, forbiddenSections: [] }),
    new import_RawRorSettingsValidators.SectionValidator({ expectedSections: import_constants.ES_SECTIONS, forbiddenSections: [] })
  ]),
  new import_RawRorSettingsValidators.RorKbnSchemaValidator()
]).fromString(s);
const parseToRawRorKbnAndEsSettingsOrRawEsSettings = (s) => {
  const parseToRawRorKbnAndEsSettingsResult = parseToRawRorKbnAndEsSettings(s);
  return parseToRawRorKbnAndEsSettingsResult.ok ? parseToRawRorKbnAndEsSettingsResult : parseToRawRorEsSettings(s);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RawRorEsSettingsParser,
  RawRorKbnAndEsSettingsParser,
  RawRorKbnSettingsParser,
  parseToRawRorEsSettings,
  parseToRawRorKbnAndEsSettings,
  parseToRawRorKbnAndEsSettingsOrRawEsSettings,
  parseToRawRorKbnSettings
});
