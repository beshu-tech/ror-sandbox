"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RawRorSettingsValidators_exports = {};
__export(RawRorSettingsValidators_exports, {
  CombinedValidator: () => CombinedValidator,
  RorKbnSchemaValidator: () => RorKbnSchemaValidator,
  SectionValidator: () => SectionValidator,
  ValidatorsRunner: () => ValidatorsRunner
});
module.exports = __toCommonJS(RawRorSettingsValidators_exports);
var import_JsonSchemaValidator = require("../../../../kibana/config/JsonSchemaValidator");
var import_hasAnyTopLevelKey = require("./hasAnyTopLevelKey");
const readonlyrest_kbnSchema = require("../../../../kibana/config/readonlyrest_kbn.schema.json");
class SectionValidator {
  constructor(sectionRules) {
    this.sectionRules = sectionRules;
  }
  validate(parsed) {
    const errors = [];
    if (!(0, import_hasAnyTopLevelKey.hasAnyTopLevelKey)(parsed, this.sectionRules.expectedSections)) {
      errors.push(
        `Validation error: Missing required sections in the ReadonlyREST Settings. Expected one of: ${this.sectionRules.expectedSections.join(
          ", "
        )}`
      );
    }
    if ((0, import_hasAnyTopLevelKey.hasAnyTopLevelKey)(parsed, this.sectionRules.forbiddenSections)) {
      errors.push(
        `Validation error: Forbidden sections in ReadonlyREST Settings: ${this.sectionRules.forbiddenSections.join(
          ", "
        )}`
      );
    }
    if (errors.length > 0) {
      return {
        ok: false,
        error: errors.join(", ")
      };
    }
    return { ok: true, data: parsed };
  }
}
class ValidatorsRunner {
  constructor(validators) {
    this.validators = validators;
  }
  validate(parsed) {
    for (const v of this.validators) {
      const result = v.validate(parsed);
      if (!result.ok) {
        return { ok: false, error: result.error };
      }
    }
    return { ok: true, data: parsed };
  }
}
class RorKbnSchemaValidator {
  constructor() {
    __publicField(this, "rorKbnJsonSchemaValidator", new import_JsonSchemaValidator.JsonSchemaValidator(readonlyrest_kbnSchema));
  }
  validate(parsed) {
    const json = parsed.toJSON();
    const validationResult = this.rorKbnJsonSchemaValidator.validateJsonSchema(json);
    if (!validationResult.ok) {
      return { ok: false, error: validationResult.error };
    }
    return { ok: true, data: parsed };
  }
}
class CombinedValidator {
  constructor(validators) {
    this.validators = validators;
  }
  validate(parsed) {
    const errors = [];
    for (const v of this.validators) {
      const result = v.validate(parsed);
      if (!result.ok && result.error) {
        errors.push(result.error);
      }
    }
    if (errors.length === 0) {
      return { ok: true, data: parsed };
    }
    return {
      ok: false,
      error: errors.join(", ")
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CombinedValidator,
  RorKbnSchemaValidator,
  SectionValidator,
  ValidatorsRunner
});
