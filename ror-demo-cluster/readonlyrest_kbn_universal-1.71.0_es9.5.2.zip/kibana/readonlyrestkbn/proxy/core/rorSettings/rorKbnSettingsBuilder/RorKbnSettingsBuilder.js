"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var RorKbnSettingsBuilder_exports = {};
__export(RorKbnSettingsBuilder_exports, {
  RorKbnSettingsBuilder: () => RorKbnSettingsBuilder
});
module.exports = __toCommonJS(RorKbnSettingsBuilder_exports);
var import_randomGenerators = require("../../../../kibana/config/randomGenerators");
var import_defaultValues = require("../../../../server/defaultValues");
var import_types = require("../../common/types");
var import_buildAuthSettings = require("./buildAuthSettings");
var import_buildCustomUxCodeInjectionSettings = require("./buildCustomUxCodeInjectionSettings");
var import_buildLicenseSettings = require("./buildLicenseSettings");
var import_buildLoginPageCustomizations = require("./buildLoginPageCustomizations");
var import_buildLogLevel = require("./buildLogLevel");
var import_buildSessionManagerSettings = require("./buildSessionManagerSettings");
var import_buildSessionSettings = require("./buildSessionSettings");
var import_getWhiteListedPaths = require("./getWhiteListedPaths");
var import_memoryDiagnosticsBuilder = require("./memoryDiagnosticsBuilder");
const _RorKbnSettingsBuilder = class _RorKbnSettingsBuilder {
  async buildRorKbnSettings(kibanaConfig, rorKbnSettingsRawObject) {
    var _a, _b, _c, _d;
    const cookiePassword = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.cookiePass;
    const pkpKibanaToken = (rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.pkpKibanaToken) || _RorKbnSettingsBuilder.generatedPkpKibanaToken;
    const authSettings = (rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.auth) ? (0, import_buildAuthSettings.buildAuthSettings)(rorKbnSettingsRawObject.auth) : null;
    const sessionSettings = (0, import_buildSessionSettings.buildSessionConfig)(rorKbnSettingsRawObject);
    const customUXCodeInjection = await (0, import_buildCustomUxCodeInjectionSettings.buildCustomUxCodeInjectionSettings)(rorKbnSettingsRawObject);
    const customLogoutLink = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.custom_logout_link;
    const customLoginLink = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.custom_login_link;
    const proxyAuthSettings = {
      enabled: (rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.proxy_auth_passthrough) && !!rorKbnSettingsRawObject.proxy_auth_passthrough || false,
      forward_auth_header: (rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.forward_auth_header) || import_types.X_FORWARDED_USER
    };
    const jwtQueryParam = { value: (rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.jwt_query_param) || "jwt" };
    const whitelistedPaths = (0, import_getWhiteListedPaths.getWhiteListedPaths)(rorKbnSettingsRawObject);
    const loginPageCustomizations = await (0, import_buildLoginPageCustomizations.buildLoginPageCustomizations)(rorKbnSettingsRawObject);
    const cookieSettings = this.getCookieSettings(kibanaConfig, rorKbnSettingsRawObject);
    const kibanaTemplateIndex = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.kibanaIndexTemplate;
    const resetKibanaIndexToTemplate = (rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.resetKibanaIndexToTemplate) || false;
    const clearSessionOnEvents = (_a = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.clearSessionOnEvents) != null ? _a : [];
    const licenseSettings = (0, import_buildLicenseSettings.buildLicenseSettings)(rorKbnSettingsRawObject);
    const multiTenancyEnabled = (_b = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.multiTenancyEnabled) != null ? _b : true;
    const customMiddlewareInjectFile = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.custom_middleware_inject_file;
    const customMiddlewareInject = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.custom_middleware_inject;
    const tenantIndex = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.tenantIndex;
    const logLevel = (0, import_buildLogLevel.buildLogLevel)(rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.logLevel);
    const logPrettyPrintEnabled = (_c = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.logPrettyPrintEnabled) != null ? _c : false;
    const diskThresholdVerificationEnabled = (_d = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.diskThresholdVerificationEnabled) != null ? _d : false;
    const memoryDiagnostics = (0, import_memoryDiagnosticsBuilder.buildMemoryDiagnostics)(rorKbnSettingsRawObject);
    return {
      sessionManagerSettings: (0, import_buildSessionManagerSettings.buildSessionManagerSettings)(rorKbnSettingsRawObject),
      cookiePassword,
      pkpKibanaToken,
      authSettings,
      sessionSettings,
      customUXCodeInjection,
      customLogoutLink,
      customLoginLink,
      proxyAuthSettings,
      jwtQueryParam,
      whitelistedPaths,
      loginPageCustomizations,
      cookieSettings,
      kibanaTemplateIndex,
      resetKibanaIndexToTemplate,
      clearSessionOnEvents,
      licenseSettings,
      multiTenancyEnabled,
      customMiddlewareInjectFile,
      customMiddlewareInject,
      tenantIndex,
      logLevel,
      logPrettyPrintEnabled,
      diskThresholdVerificationEnabled,
      memoryDiagnostics
    };
  }
  getCookieSettings({ server, xpack }, rorKbnSettingsRawObject) {
    var _a, _b, _c, _d;
    const cookieName = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.cookieName;
    const password = rorKbnSettingsRawObject.cookiePass;
    const sslEnabled = ((_a = server == null ? void 0 : server.ssl) == null ? void 0 : _a.enabled) || ((_b = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.cookies) == null ? void 0 : _b.secure);
    const secureCookies = (_c = xpack == null ? void 0 : xpack.security) == null ? void 0 : _c.secureCookies;
    const sameSite = (_d = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.cookies) == null ? void 0 : _d.sameSite;
    const baseName = cookieName || import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.cookieName;
    const withSecureSuffix = secureCookies || sslEnabled;
    if (withSecureSuffix) {
      return { name: `${baseName}_secure`, password, secure: true, sameSite };
    }
    return { name: baseName, password, secure: false, sameSite };
  }
};
__publicField(_RorKbnSettingsBuilder, "generatedPkpKibanaToken", (0, import_randomGenerators.generateRandomToken)());
let RorKbnSettingsBuilder = _RorKbnSettingsBuilder;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorKbnSettingsBuilder
});
