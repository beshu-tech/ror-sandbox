"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var buildAuthSettings_exports = {};
__export(buildAuthSettings_exports, {
  buildAuthSettings: () => buildAuthSettings
});
module.exports = __toCommonJS(buildAuthSettings_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_rorLoggerFactory = require("../../logging/rorLoggerFactory");
const getLogger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const AUTH_SIGNATURE_KEY = "signature_key";
function hasUndefinedValues(pathToObject, objectToValidate) {
  let containsUndefinedKeyValues = false;
  Object.entries(objectToValidate).forEach(([key, value]) => {
    if (value == null) {
      getLogger().warn(`Missing value for ${pathToObject}.${key}: ${value}`);
      containsUndefinedKeyValues = true;
    }
  });
  return containsUndefinedKeyValues;
}
function readFileFromAbsolutePath(configKey, filePath) {
  if (!filePath) {
    const message = `${configKey} parameter is not configured`;
    getLogger().error({ message });
    throw new Error(message);
  }
  if (!filePath.startsWith("/")) {
    const message = `${configKey} should be configured as an absolute path`;
    getLogger().error({ message });
    throw new Error(message);
  }
  if (!import_fs.default.existsSync(filePath)) {
    const message = `File not found ${filePath} for configuration parameter ${configKey}`;
    getLogger().error({ message });
    throw new Error(message);
  }
  let content;
  try {
    content = import_fs.default.readFileSync(filePath).toString();
  } catch (e) {
    getLogger().error({ message: `Error reading from file: ${filePath}, message: ${e.message}`, stack: e.stack });
    throw e;
  }
  return content;
}
function stringBasedCertType(cert) {
  if (cert && !import_path.default.isAbsolute(cert)) {
    getLogger().info("Cert parameter is reading as a string value");
    return true;
  }
  return false;
}
function buildSAMLSettings(settingsName, rorSamlSettings) {
  const samlRawSettings = {
    name: settingsName,
    enabled: rorSamlSettings.enabled == null ? true : !!rorSamlSettings.enabled,
    buttonName: rorSamlSettings.buttonName == null ? "" : rorSamlSettings.buttonName,
    issuer: rorSamlSettings.issuer == null ? "ror" : rorSamlSettings.issuer,
    entryPoint: rorSamlSettings.entryPoint,
    logoutUrl: rorSamlSettings.logoutUrl,
    kibanaExternalHost: rorSamlSettings.kibanaExternalHost,
    protocol: rorSamlSettings.protocol == null ? "http" : rorSamlSettings.protocol,
    usernameParameter: rorSamlSettings.usernameParameter == null ? "nameID" : rorSamlSettings.usernameParameter,
    groupsParameter: rorSamlSettings.groupsParameter == null ? "memberOf" : rorSamlSettings.groupsParameter,
    // To keep backward compatibility, cert can be a string or file
    cert: stringBasedCertType(rorSamlSettings.cert) ? rorSamlSettings.cert : readFileFromAbsolutePath("cert", rorSamlSettings.cert)
  };
  if (hasUndefinedValues(`readonlyrest_kbn.auth.${settingsName}`, samlRawSettings)) {
    getLogger().warn(`Missing SAML settings for ${settingsName}`, rorSamlSettings);
    return null;
  }
  if (rorSamlSettings.authnContext) {
    samlRawSettings.authnContext = rorSamlSettings.authnContext;
  }
  if (rorSamlSettings.disableRequestedAuthnContext) {
    samlRawSettings.disableRequestedAuthnContext = rorSamlSettings.disableRequestedAuthnContext;
  }
  if (rorSamlSettings.identifierFormat || rorSamlSettings.identifierFormat === null) {
    samlRawSettings.identifierFormat = rorSamlSettings.identifierFormat;
  }
  ["decryptionPvk", "privateCert"].filter((optionalParameter) => rorSamlSettings[optionalParameter]).forEach((optionalParameter) => {
    samlRawSettings[optionalParameter] = readFileFromAbsolutePath(
      optionalParameter,
      rorSamlSettings[optionalParameter]
    );
  });
  samlRawSettings.extraSettings = Object.keys(rorSamlSettings).filter((key) => !Object.prototype.hasOwnProperty.call(samlRawSettings, key)).reduce((accumulator, key) => {
    accumulator[key] = rorSamlSettings[key];
    return accumulator;
  }, {});
  return samlRawSettings;
}
function buildOIDCSettings(settingsName, rorOidcSettings) {
  var _a, _b;
  const oidcSettings = {
    name: settingsName,
    enabled: rorOidcSettings.enabled == null ? true : !!rorOidcSettings.enabled,
    buttonName: rorOidcSettings.buttonName == null ? "" : rorOidcSettings.buttonName,
    issuer: rorOidcSettings.issuer == null ? "ror" : rorOidcSettings.issuer,
    kibanaExternalHost: rorOidcSettings.kibanaExternalHost,
    protocol: rorOidcSettings.protocol == null ? "http" : rorOidcSettings.protocol,
    tokenURL: rorOidcSettings.tokenURL,
    authorizationURL: rorOidcSettings.authorizationURL,
    userInfoURL: rorOidcSettings.userInfoURL,
    logoutUrl: rorOidcSettings.logoutUrl,
    clientId: rorOidcSettings.clientID,
    clientSecret: rorOidcSettings.clientSecret,
    scope: rorOidcSettings.scope,
    usernameParameter: rorOidcSettings.usernameParameter == null ? "nameID" : rorOidcSettings.usernameParameter,
    groupsParameter: rorOidcSettings.groupsParameter == null ? "memberOf" : rorOidcSettings.groupsParameter,
    jwksURL: rorOidcSettings.jwksURL,
    tokenEndpointAuthMethod: rorOidcSettings.tokenEndpointAuthMethod == null ? "client_secret_basic" : rorOidcSettings.tokenEndpointAuthMethod,
    userInfoSource: rorOidcSettings.userInfoSource == null ? "user_info_endpoint" : rorOidcSettings.userInfoSource,
    issuerAdditionalParameters: (_a = rorOidcSettings == null ? void 0 : rorOidcSettings.issuerAdditionalParameters) != null ? _a : {},
    clientAdditionalParameters: (_b = rorOidcSettings == null ? void 0 : rorOidcSettings.clientAdditionalParameters) != null ? _b : {}
  };
  const containsUndefined = hasUndefinedValues(`readonlyrest_kbn.auth.${settingsName}`, oidcSettings);
  oidcSettings.proxyURL = rorOidcSettings.proxyURL;
  oidcSettings.clockToleranceSeconds = rorOidcSettings.clockToleranceSeconds;
  return containsUndefined ? null : oidcSettings;
}
function buildAuthSettings(rorKbnAuthSettingsObject) {
  const signatureKey = rorKbnAuthSettingsObject[AUTH_SIGNATURE_KEY];
  const samlRawSettingsList = [];
  const oidcRawSettingsList = [];
  Object.entries(rorKbnAuthSettingsObject).filter(([key]) => key !== AUTH_SIGNATURE_KEY).forEach(([configName, rawSettings]) => {
    if (!rawSettings || typeof rawSettings === "string" || !rawSettings.type) {
      getLogger().warn(`Missing config type for readonlyrest_kbn.auth.${configName}`);
      return;
    }
    const ssoType = rawSettings.type;
    getLogger().info(`parsing auth settings: ${configName} of SSO_TYPE: ${ssoType}`);
    if (ssoType === void 0) {
      getLogger().warn(`Unknown settings type "${ssoType}" for readonlyrest_kbn.auth.${configName}`);
      return;
    }
    if (ssoType === "saml") {
      const samlRawSettings = buildSAMLSettings(configName, rawSettings);
      if (samlRawSettings) {
        samlRawSettingsList.push(samlRawSettings);
        return;
      }
    }
    if (ssoType === "oidc") {
      const oidcRawConfig = buildOIDCSettings(configName, rawSettings);
      if (oidcRawConfig) {
        oidcRawSettingsList.push(oidcRawConfig);
      }
    }
  });
  return {
    signatureKey,
    samlRawSettingsList,
    oidcRawSettingsList
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildAuthSettings
});
