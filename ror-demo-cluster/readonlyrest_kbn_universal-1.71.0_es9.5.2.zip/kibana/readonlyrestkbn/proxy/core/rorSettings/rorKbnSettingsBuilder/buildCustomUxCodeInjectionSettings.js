"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var buildCustomUxCodeInjectionSettings_exports = {};
__export(buildCustomUxCodeInjectionSettings_exports, {
  buildCustomUxCodeInjectionSettings: () => buildCustomUxCodeInjectionSettings,
  parseCssFile: () => parseCssFile,
  parseJsFile: () => parseJsFile
});
module.exports = __toCommonJS(buildCustomUxCodeInjectionSettings_exports);
var import_fs_extra = __toESM(require("fs-extra"));
var import_rorLoggerFactory = require("../../logging/rorLoggerFactory");
const getLogger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
function isCustomCodeInjectionConfigPresent(rorObject) {
  return rorObject.kibana_custom_css_inject != null || rorObject.kibana_custom_css_inject_file != null || rorObject.kibana_custom_js_inject != null || rorObject.kibana_custom_js_inject_file != null;
}
async function parseCssFile(customUserCssFilePath) {
  let customUserCssFileContent;
  try {
    getLogger().trace(`Reading css file from file ${customUserCssFilePath}`);
    customUserCssFileContent = (await import_fs_extra.default.readFile(customUserCssFilePath)).toString();
  } catch (error) {
    if (error.code === "ENOENT") {
      getLogger().error({
        message: `Custom CSS file not found in the path ${customUserCssFilePath}!`,
        stack: error.stack
      });
    }
    throw error;
  }
  return customUserCssFileContent;
}
async function parseJsFile(customUserJsFilePath) {
  let customUserJSFileContent;
  try {
    getLogger().trace(`Reading js file from file ${customUserJsFilePath}`);
    customUserJSFileContent = (await import_fs_extra.default.readFile(customUserJsFilePath)).toString();
  } catch (error) {
    if (error.code === "ENOENT") {
      getLogger().error({
        message: `Custom JS file not found in the path ${customUserJsFilePath}!`,
        stack: error.stack
      });
    }
    throw error;
  }
  return customUserJSFileContent;
}
async function buildCustomUxCodeInjectionSettings(rorKbnSettingsRawObject) {
  if (rorKbnSettingsRawObject == null || !isCustomCodeInjectionConfigPresent(rorKbnSettingsRawObject)) {
    return void 0;
  }
  const customUserCssFileContent = rorKbnSettingsRawObject.kibana_custom_css_inject_file ? await parseCssFile(rorKbnSettingsRawObject.kibana_custom_css_inject_file) : void 0;
  const customUserJsFileContent = rorKbnSettingsRawObject.kibana_custom_js_inject_file ? await parseJsFile(rorKbnSettingsRawObject.kibana_custom_js_inject_file) : void 0;
  return {
    css: rorKbnSettingsRawObject.kibana_custom_css_inject,
    cssFileContent: customUserCssFileContent,
    js: rorKbnSettingsRawObject.kibana_custom_js_inject,
    jsFileContent: customUserJsFileContent
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildCustomUxCodeInjectionSettings,
  parseCssFile,
  parseJsFile
});
