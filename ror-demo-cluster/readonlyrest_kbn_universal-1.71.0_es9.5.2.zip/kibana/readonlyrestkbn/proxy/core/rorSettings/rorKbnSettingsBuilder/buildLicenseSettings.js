"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var buildLicenseSettings_exports = {};
__export(buildLicenseSettings_exports, {
  buildLicenseSettings: () => buildLicenseSettings
});
module.exports = __toCommonJS(buildLicenseSettings_exports);
function buildLicenseSettings(rorKbnSettingsRawObject) {
  var _a, _b;
  function getRetrieval() {
    var _a2;
    const retrievalMode = (_a2 = rorKbnSettingsRawObject.license) == null ? void 0 : _a2.activationKeyRetrievalMode;
    if (typeof retrievalMode === "string") {
      if (retrievalMode === "all" || retrievalMode === "none" || retrievalMode === "file" || retrievalMode === "env") {
        return [retrievalMode];
      }
    }
    if (Array.isArray(retrievalMode)) {
      const hasAll = retrievalMode.includes("all");
      const hasNone = retrievalMode.includes("none");
      if (hasAll && hasNone) {
        throw new Error('Invalid activation key retrieval mode: "all" and "none" cannot be used together');
      }
      if (hasAll) return ["all"];
      if (hasNone) return ["none"];
    }
    return ["all"];
  }
  return {
    activationKeyRetrievalModes: getRetrieval(),
    activationKeyFilePath: (_a = rorKbnSettingsRawObject.license) == null ? void 0 : _a.activationKeyFilePath,
    activationKeyRefreshInterval: ((_b = rorKbnSettingsRawObject.license) == null ? void 0 : _b.activationKeyRefreshInterval) || "10m"
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildLicenseSettings
});
