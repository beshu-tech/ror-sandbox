"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var buildLogLevel_exports = {};
__export(buildLogLevel_exports, {
  buildLogLevel: () => buildLogLevel,
  getLogsDestination: () => getLogsDestination
});
module.exports = __toCommonJS(buildLogLevel_exports);
var import_lodash = require("lodash");
var import_logLevel = require("../../logging/logLevel");
var import_rorLoggerFactory = require("../../logging/rorLoggerFactory");
function buildLogLevel(rawLogLevel) {
  if (rawLogLevel == null) {
    return import_rorLoggerFactory.RorLoggerFactory.DEFAULT_LOG_LEVEL;
  }
  const derivedLogLevel = import_logLevel.LogLevel[rawLogLevel.toString().toUpperCase()];
  if (derivedLogLevel == null) {
    return import_rorLoggerFactory.RorLoggerFactory.DEFAULT_LOG_LEVEL;
  }
  return derivedLogLevel;
}
function addLegacyKibanaDestinations(logging, destinations) {
  if ((logging == null ? void 0 : logging.dest) === "stdout") {
    destinations.push({ type: "console" });
  } else if (logging == null ? void 0 : logging.dest) {
    destinations.push({ type: "file", path: logging.dest });
  }
}
function addDestinationFromAppender(appender, destinations) {
  if (appender.type === "file" || appender.type === "rolling-file") {
    destinations.push({
      type: "file",
      path: appender.fileName,
      layout: appender.layout
    });
  } else if (appender.type === "console") {
    destinations.push({
      type: "console",
      layout: appender.layout
    });
  }
}
function processAppenderReferences(logging, destinations) {
  var _a;
  if (!(logging == null ? void 0 : logging.appenders) || !((_a = logging == null ? void 0 : logging.root) == null ? void 0 : _a.appenders)) return;
  for (const appenderRef of logging.root.appenders) {
    if (appenderRef === "default") {
      destinations.push({ type: "console" });
      continue;
    }
    const appender = logging.appenders[appenderRef];
    if (!appender) continue;
    addDestinationFromAppender(appender, destinations);
  }
}
function ensureDefaultDestination(destinations) {
  if (destinations.length === 0) {
    destinations.push({ type: "console" });
  }
}
function getLogsDestination(logging) {
  const destinations = [];
  addLegacyKibanaDestinations(logging, destinations);
  processAppenderReferences(logging, destinations);
  ensureDefaultDestination(destinations);
  return (0, import_lodash.uniqBy)(destinations, "type");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildLogLevel,
  getLogsDestination
});
