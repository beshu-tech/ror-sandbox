"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var buildLoginPageCustomizations_exports = {};
__export(buildLoginPageCustomizations_exports, {
  buildLoginPageCustomizations: () => buildLoginPageCustomizations
});
module.exports = __toCommonJS(buildLoginPageCustomizations_exports);
var import_buildCustomUxCodeInjectionSettings = require("./buildCustomUxCodeInjectionSettings");
function isLoginPageCustomizationsConfigPresent(rorKbnSettingsRawObject) {
  return rorKbnSettingsRawObject.login_title != null || rorKbnSettingsRawObject.login_subtitle != null || rorKbnSettingsRawObject.login_custom_logo != null || rorKbnSettingsRawObject.login_html_head_inject != null || rorKbnSettingsRawObject.login_custom_js_inject_file != null || rorKbnSettingsRawObject.login_custom_css_inject_file != null;
}
async function buildLoginPageCustomizations(rorKbnSettingsRawObject) {
  if (rorKbnSettingsRawObject == null || !isLoginPageCustomizationsConfigPresent(rorKbnSettingsRawObject)) {
    return void 0;
  }
  return {
    title: rorKbnSettingsRawObject.login_title,
    subtitle: rorKbnSettingsRawObject.login_subtitle,
    logoPath: rorKbnSettingsRawObject.login_custom_logo,
    htmlHeadInject: rorKbnSettingsRawObject.login_html_head_inject,
    customCSSInjectFile: rorKbnSettingsRawObject.login_custom_css_inject_file ? await (0, import_buildCustomUxCodeInjectionSettings.parseCssFile)(rorKbnSettingsRawObject.login_custom_css_inject_file) : void 0,
    customJSInjectFile: rorKbnSettingsRawObject.login_custom_js_inject_file ? await (0, import_buildCustomUxCodeInjectionSettings.parseJsFile)(rorKbnSettingsRawObject.login_custom_js_inject_file) : void 0
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildLoginPageCustomizations
});
