"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var buildSessionManagerSettings_exports = {};
__export(buildSessionManagerSettings_exports, {
  buildSessionManagerSettings: () => buildSessionManagerSettings
});
module.exports = __toCommonJS(buildSessionManagerSettings_exports);
var import_defaultValues = require("../../../../server/defaultValues");
var import_rorLoggerFactory = require("../../logging/rorLoggerFactory");
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
function buildSessionManagerSettings(rorKbnSettingsRawObject) {
  const sessionManagerSettings = {
    storeInIndex: (rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.store_sessions_in_index) || false,
    indexName: (rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.sessions_index_name) || import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.sessions_index_name,
    refreshAfter: (rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.sessions_refresh_after) || import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.sessions_refresh_after,
    sessionKey: rorKbnSettingsRawObject.cookiePass,
    cleanupInterval: (rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.sessions_cleanup_interval) || import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.sessions_cleanup_interval
  };
  if (!sessionManagerSettings.storeInIndex) {
    logger.info(`"readonlyrest_kbn.store_sessions_in_index" is not enabled.
If you use more than one Kibana nodes (High availability configurations), you MUST enable both "readonlyrest_kbn.store_sessions_in_index" and share the same "readonlyrest.cookiePass" in ALL Kibana nodes.
See documentation: https://docs.readonlyrest.com/kibana#session-management-with-multiple-kibana-instances`);
  }
  return sessionManagerSettings;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildSessionManagerSettings
});
