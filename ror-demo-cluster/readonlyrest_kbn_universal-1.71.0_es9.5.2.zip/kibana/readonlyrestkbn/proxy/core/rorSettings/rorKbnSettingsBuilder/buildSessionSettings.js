"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var buildSessionSettings_exports = {};
__export(buildSessionSettings_exports, {
  buildSessionConfig: () => buildSessionConfig
});
module.exports = __toCommonJS(buildSessionSettings_exports);
var import_defaultValues = require("../../../../server/defaultValues");
function buildSessionConfig(rorKbnSettingsRawObject) {
  var _a, _b;
  const probeIntervalSeconds = (_a = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.sessions_probe_interval_seconds) != null ? _a : import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.sessions_probe_interval_seconds;
  return {
    timeoutMinutes: (_b = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.session_timeout_minutes) != null ? _b : import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.session_timeout_minutes,
    probeIntervalMillis: probeIntervalSeconds * 1e3
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildSessionConfig
});
