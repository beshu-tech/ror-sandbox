"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var getWhiteListedPaths_exports = {};
__export(getWhiteListedPaths_exports, {
  getWhiteListedPaths: () => getWhiteListedPaths
});
module.exports = __toCommonJS(getWhiteListedPaths_exports);
var import_defaultValues = require("../../../../server/defaultValues");
function getWhiteListedPaths(rorKbnSettingsRawObject) {
  const paths = rorKbnSettingsRawObject == null ? void 0 : rorKbnSettingsRawObject.whitelistedPaths;
  return Array.isArray(paths) ? paths : import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.whitelistedPaths;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getWhiteListedPaths
});
