"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var memoryDiagnosticsBuilder_exports = {};
__export(memoryDiagnosticsBuilder_exports, {
  buildMemoryDiagnostics: () => buildMemoryDiagnostics
});
module.exports = __toCommonJS(memoryDiagnosticsBuilder_exports);
const buildMemoryDiagnostics = (rorConfig) => {
  var _a, _b, _c, _d;
  return {
    enabled: (_b = (_a = rorConfig == null ? void 0 : rorConfig.memoryDiagnostics) == null ? void 0 : _a.enabled) != null ? _b : false,
    interval: (_d = (_c = rorConfig == null ? void 0 : rorConfig.memoryDiagnostics) == null ? void 0 : _c.interval) != null ? _d : "1d"
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildMemoryDiagnostics
});
