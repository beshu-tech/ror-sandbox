"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorUserSettings_exports = {};
__export(rorUserSettings_exports, {
  RorUserSettings: () => RorUserSettings
});
module.exports = __toCommonJS(rorUserSettings_exports);
const _RorUserSettings = class _RorUserSettings {
  static getSettings(cookies) {
    const userSettings = (cookies == null ? void 0 : cookies.rorUserSettings) ? JSON.parse(cookies.rorUserSettings) : {};
    return Object.keys(userSettings).reduce(
      _RorUserSettings.convertBooleanStringToBoolean(userSettings),
      {}
    );
  }
  static mixRorSettingsWithKibanaSettings(userSettings, parsedData) {
    const mappedSettings = Object.keys(userSettings).reduce(
      _RorUserSettings.convertBooleanStringToBoolean(userSettings),
      {}
    );
    parsedData._source.config = {
      ...parsedData._source.config,
      ...mappedSettings
    };
    return parsedData;
  }
  static parseSettingsToBuffer(userSettings) {
    return Buffer.from(JSON.stringify(userSettings));
  }
};
__publicField(_RorUserSettings, "convertBooleanStringToBoolean", (userSettings) => (object, key) => {
  const trimmedKey = key.trim();
  object[trimmedKey] = userSettings[trimmedKey];
  if (object[trimmedKey] === "true") {
    object[trimmedKey] = true;
  }
  if (object[trimmedKey] === "false") {
    object[trimmedKey] = false;
  }
  return object;
});
let RorUserSettings = _RorUserSettings;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorUserSettings
});
