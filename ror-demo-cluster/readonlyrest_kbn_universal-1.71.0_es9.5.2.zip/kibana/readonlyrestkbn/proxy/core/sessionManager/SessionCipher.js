"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var SessionCipher_exports = {};
__export(SessionCipher_exports, {
  SessionCipher: () => SessionCipher
});
module.exports = __toCommonJS(SessionCipher_exports);
var import_Cipher = require("../common/Cipher");
class SessionCipher {
  constructor(key) {
    this.key = key;
  }
  encrypt(plaintext) {
    return import_Cipher.Cipher.encryptAes256(plaintext, this.key);
  }
  /**
   * Returns null when the ciphertext cannot be decrypted. The input is
   * untrusted (a client-held cookie or an index document), so a failed
   * decrypt is an expected outcome, not an exception.
   */
  decrypt(ciphertext) {
    try {
      return import_Cipher.Cipher.decryptAes256(ciphertext, this.key);
    } catch {
      return null;
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SessionCipher
});
