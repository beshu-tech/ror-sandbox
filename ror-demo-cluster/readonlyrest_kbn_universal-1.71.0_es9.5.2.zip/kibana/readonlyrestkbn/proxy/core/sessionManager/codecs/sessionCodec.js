"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var sessionCodec_exports = {};
__export(sessionCodec_exports, {
  SessionSchemaVersion: () => SessionSchemaVersion
});
module.exports = __toCommonJS(sessionCodec_exports);
var SessionSchemaVersion = /* @__PURE__ */ ((SessionSchemaVersion2) => {
  SessionSchemaVersion2["V1"] = "1";
  SessionSchemaVersion2["V2"] = "2";
  return SessionSchemaVersion2;
})(SessionSchemaVersion || {});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SessionSchemaVersion
});
