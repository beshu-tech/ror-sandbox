"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var baseSessionCodec_exports = {};
__export(baseSessionCodec_exports, {
  BaseSessionCodec: () => BaseSessionCodec
});
module.exports = __toCommonJS(baseSessionCodec_exports);
var import_SessionCipher = require("../../SessionCipher");
class BaseSessionCodec {
  constructor(encryptionKey, validator) {
    this.validator = validator;
    __publicField(this, "cipher");
    this.cipher = new import_SessionCipher.SessionCipher(encryptionKey);
  }
  encode(session) {
    const payload = this.buildPayload(session);
    const plaintext = JSON.stringify(payload);
    try {
      const encoded = this.cipher.encrypt(plaintext);
      return { success: true, value: encoded };
    } catch {
      return { success: false, failure: { kind: "encrypt_failed" } };
    }
  }
  decode(payload) {
    var _a, _b;
    const decrypted = this.cipher.decrypt(payload);
    if (!decrypted) {
      return { success: false, failure: { kind: "decrypt_failed" } };
    }
    let rawObject;
    try {
      rawObject = JSON.parse(decrypted);
    } catch {
      return { success: false, failure: { kind: "invalid_json" } };
    }
    if (!this.validator(rawObject)) {
      const reason = (_b = (_a = this.validator.errors) == null ? void 0 : _a.map((e) => `${e.instancePath} ${e.message}`).join(", ")) != null ? _b : "Invalid session schema";
      return { success: false, failure: { kind: "invalid_schema", reason } };
    }
    return { success: true, value: this.buildValue(rawObject) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  BaseSessionCodec
});
