"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var v1SessionCodec_exports = {};
__export(v1SessionCodec_exports, {
  V1SessionCodec: () => V1SessionCodec
});
module.exports = __toCommonJS(v1SessionCodec_exports);
var import_ajv = __toESM(require("ajv"));
var import_exhaustiveCheck = require("../../../common/exhaustiveCheck");
var import_types = require("../../../common/types");
var import_sessionCodec = require("../sessionCodec");
var import_baseSessionCodec = require("./baseSessionCodec");
const ajv = new import_ajv.default();
const groupSchema = {
  type: "object",
  required: ["id", "name"],
  properties: {
    id: { type: "string" },
    name: { type: "string" }
  }
};
const kibanaRelatedMetadataSchema = {
  type: "object",
  required: ["access"],
  properties: {
    access: { type: "string" },
    index: { type: "string" },
    template_index: { type: "string" },
    hidden_apps: { type: "array", items: { type: "string" } },
    allowed_api_paths: {
      type: "array",
      items: {
        type: "object",
        required: ["http_method", "path_regex"],
        properties: {
          http_method: { type: "string" },
          path_regex: { type: "string" }
        }
      }
    },
    metadata: { type: "object", additionalProperties: true }
  }
};
const esResponseUserGroupSchema = {
  type: "object",
  required: ["group", "username", "kibana"],
  properties: {
    group: groupSchema,
    username: { type: "string" },
    ror_origin: { type: "string" },
    kibana: kibanaRelatedMetadataSchema
  }
};
const userWithGroupsSchema = {
  type: "object",
  required: ["type", "correlationId", "expiresAt", "identitySessionHeaders", "groups"],
  properties: {
    type: { type: "string", const: "USER_WITH_GROUPS" },
    correlationId: { type: "string", minLength: 1 },
    expiresAt: { type: "number" },
    lastSessionActivityDate: { type: "number" },
    identitySessionHeaders: {
      type: "array",
      items: {
        type: "array",
        items: [{ type: "string", enum: import_types.IDENTITY_SESSION_HEADER_NAMES }, { type: "string" }],
        additionalItems: false,
        minItems: 2
      }
    },
    whitelistedHeaders: {
      type: "array",
      items: {
        type: "array",
        items: [{ type: "string" }, { type: "string" }],
        additionalItems: false,
        minItems: 2
      }
    },
    impersonatedBy: { type: "string" },
    groups: {
      type: "array",
      minItems: 1,
      items: esResponseUserGroupSchema
    }
  }
};
const userWithoutGroupsSchema = {
  type: "object",
  required: ["type", "correlationId", "expiresAt", "identitySessionHeaders", "username", "kibana"],
  properties: {
    type: { type: "string", const: "USER_WITHOUT_GROUPS" },
    correlationId: { type: "string", minLength: 1 },
    expiresAt: { type: "number" },
    lastSessionActivityDate: { type: "number" },
    identitySessionHeaders: {
      type: "array",
      items: {
        type: "array",
        items: [{ type: "string", enum: import_types.IDENTITY_SESSION_HEADER_NAMES }, { type: "string" }],
        additionalItems: false,
        minItems: 2
      }
    },
    whitelistedHeaders: {
      type: "array",
      items: {
        type: "array",
        items: [{ type: "string" }, { type: "string" }],
        additionalItems: false,
        minItems: 2
      }
    },
    impersonatedBy: { type: "string" },
    username: { type: "string", minLength: 1 },
    ror_origin: { type: "string" },
    kibana: kibanaRelatedMetadataSchema
  }
};
const v1Schema = {
  oneOf: [userWithGroupsSchema, userWithoutGroupsSchema]
};
const validateV1Session = ajv.compile(v1Schema);
class V1SessionCodec extends import_baseSessionCodec.BaseSessionCodec {
  constructor(encryptionKey) {
    super(encryptionKey, validateV1Session);
    __publicField(this, "schemaVersion", import_sessionCodec.SessionSchemaVersion.V1);
  }
  buildPayload(session) {
    return session.type === "USER_WITH_GROUPS" ? this.encodeUserWithGroups(session) : this.encodeUserWithoutGroups(session);
  }
  buildValue(dto) {
    return {
      ...dto,
      expiresAt: new Date(dto.expiresAt),
      lastSessionActivityDate: dto.lastSessionActivityDate ? new Date(dto.lastSessionActivityDate) : void 0,
      identitySessionHeaders: new Map(dto.identitySessionHeaders),
      whitelistedHeaders: new Map(dto.whitelistedHeaders)
    };
  }
  encodeUserWithGroups(session) {
    const {
      type,
      correlationId,
      expiresAt,
      lastSessionActivityDate,
      identitySessionHeaders,
      whitelistedHeaders,
      impersonatedBy,
      groups,
      ...rest
    } = session;
    (0, import_exhaustiveCheck.assertNoRemainingFields)(rest);
    return {
      type,
      correlationId,
      expiresAt: expiresAt.getTime(),
      lastSessionActivityDate: lastSessionActivityDate == null ? void 0 : lastSessionActivityDate.getTime(),
      identitySessionHeaders: Array.from(identitySessionHeaders.entries()),
      whitelistedHeaders: Array.from(whitelistedHeaders.entries()),
      impersonatedBy,
      groups
    };
  }
  encodeUserWithoutGroups(session) {
    const {
      type,
      correlationId,
      expiresAt,
      lastSessionActivityDate,
      identitySessionHeaders,
      whitelistedHeaders,
      impersonatedBy,
      username,
      ror_origin,
      kibana,
      ...rest
    } = session;
    (0, import_exhaustiveCheck.assertNoRemainingFields)(rest);
    return {
      type,
      correlationId,
      expiresAt: expiresAt.getTime(),
      lastSessionActivityDate: lastSessionActivityDate == null ? void 0 : lastSessionActivityDate.getTime(),
      identitySessionHeaders: Array.from(identitySessionHeaders.entries()),
      whitelistedHeaders: Array.from(whitelistedHeaders.entries()),
      impersonatedBy,
      username,
      ror_origin,
      kibana
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  V1SessionCodec
});
