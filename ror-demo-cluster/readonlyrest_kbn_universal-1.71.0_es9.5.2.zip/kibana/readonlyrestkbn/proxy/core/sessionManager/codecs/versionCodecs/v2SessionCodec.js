"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var v2SessionCodec_exports = {};
__export(v2SessionCodec_exports, {
  V2SessionCodec: () => V2SessionCodec
});
module.exports = __toCommonJS(v2SessionCodec_exports);
var import_rorLoggerFactory = require("../../../logging/rorLoggerFactory");
var import_ssoSessionProfile = require("../../../ssoSessionProfile");
var import_sessionCodec = require("../sessionCodec");
var import_v1SessionCodec = require("./v1SessionCodec");
class V2PayloadCodec extends import_v1SessionCodec.V1SessionCodec {
  buildPayload(session) {
    return {
      ...super.buildPayload(session),
      ...session.ssoSessionProfile ? { ssoSessionProfile: session.ssoSessionProfile } : {}
    };
  }
}
class V2SessionCodec {
  constructor(encryptionKey) {
    __publicField(this, "schemaVersion", import_sessionCodec.SessionSchemaVersion.V2);
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "payloadCodec");
    this.payloadCodec = new V2PayloadCodec(encryptionKey);
  }
  encode(session) {
    return this.payloadCodec.encode(session);
  }
  decode(payload) {
    const decodedSession = this.payloadCodec.decode(payload);
    if (!decodedSession.success || !decodedSession.value.ssoSessionProfile) {
      return decodedSession;
    }
    const ssoSessionProfile = (0, import_ssoSessionProfile.parseSsoSessionProfile)(decodedSession.value.ssoSessionProfile);
    if (!ssoSessionProfile) {
      this.logger.warn("Dropping unparseable SSO session profile; session remains valid without it.");
      const { ssoSessionProfile: _dropped, ...rest } = decodedSession.value;
      return { success: true, value: rest };
    }
    return { success: true, value: { ...decodedSession.value, ssoSessionProfile } };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  V2SessionCodec
});
