"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var inMemorySessionManager_exports = {};
__export(inMemorySessionManager_exports, {
  InMemorySessionManager: () => InMemorySessionManager
});
module.exports = __toCommonJS(inMemorySessionManager_exports);
var import_timestring = __toESM(require("timestring"));
var import_lazyUtils = require("../lazyUtils");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_sessionManager = require("./sessionManager");
class InMemorySessionManager extends import_sessionManager.SessionManager {
  constructor(licenseService, shortLivedSessionTimeout, rorSettingsStore, userMetadataResolver) {
    super();
    this.licenseService = licenseService;
    this.shortLivedSessionTimeout = shortLivedSessionTimeout;
    this.rorSettingsStore = rorSettingsStore;
    this.userMetadataResolver = userMetadataResolver;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "sessionsInMemory", /* @__PURE__ */ new Map());
    __publicField(this, "sessionCleanupJob");
    __publicField(this, "init", () => {
      this.rorSettingsStore.observerRorKbnSettings(({ sessionManagerSettings }) => ({
        cleanupInterval: sessionManagerSettings.cleanupInterval
      })).subscribe(async ({ cleanupInterval }) => {
        await this.startCleanupJob(cleanupInterval);
      });
    });
    __publicField(this, "cleanup", () => {
      var _a, _b;
      this.logger.debug("Cleaning InMemorySessionManager");
      (_b = (_a = this.sessionCleanupJob) == null ? void 0 : _a.stop) == null ? void 0 : _b.call(_a);
    });
    __publicField(this, "set", async (sid, session) => {
      this.sessionsInMemory.set(sid, session);
    });
    __publicField(this, "setShortLivedSessionInMemory", async (sid, session) => {
      const date = /* @__PURE__ */ new Date();
      const secondsToClearSession = this.shortLivedSessionTimeout;
      date.setSeconds(date.getSeconds() + secondsToClearSession);
      await this.set(sid, { ...session, expiresAt: date });
      setTimeout(() => {
        this.checkIfSessionTimeout(sid);
      }, secondsToClearSession * 1e3);
    });
    __publicField(this, "get", async (sid) => {
      const session = this.sessionsInMemory.get(sid);
      if (session == null) {
        return null;
      }
      const resolvedSession = this.userMetadataResolver.resolveSessionMetadata(session);
      this.mostRecentlyAccessed = { sid, metadata: resolvedSession };
      return resolvedSession;
    });
    __publicField(this, "delete", (sid) => {
      this.sessionsInMemory.delete(sid);
    });
    __publicField(this, "checkIfSessionTimeout", async (sid) => {
      if (sid && await this.isSessionTimeout(sid)) {
        this.sessionsInMemory.delete(sid);
        return true;
      }
      return false;
    });
    __publicField(this, "clearStaleSessions", async () => {
      const promises = [];
      for (const sid of this.sessionsInMemory.keys()) {
        promises.push(this.checkIfSessionTimeout(sid));
      }
      Promise.all(promises).then((numberOfDeletes) => {
        this.logger.debug(
          `Number of deleted stale In-memory sessions: ${numberOfDeletes.filter((numberOfDelete) => numberOfDelete).length}`
        );
      });
    });
  }
  async deleteAllSessions() {
    this.sessionsInMemory.clear();
    this.mostRecentlyAccessed = void 0;
  }
  reloadSessions(sessions) {
    this.sessionsInMemory = sessions;
  }
  async startCleanupJob(cleanupInterval) {
    const interval = (0, import_timestring.default)(cleanupInterval, "ms");
    if (this.sessionCleanupJob) {
      this.sessionCleanupJob.stop();
      this.logger.debug(`Restarting InMemorySessionManager cleanup job with interval ${interval}ms`);
    } else {
      this.logger.debug(`Starting InMemorySessionManager cleanup job with interval ${interval}ms`);
    }
    this.sessionCleanupJob = await (0, import_lazyUtils.executeWithInterval)(this.clearStaleSessions, interval);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  InMemorySessionManager
});
