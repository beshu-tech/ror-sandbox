"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var indexBasedSessionManager_exports = {};
__export(indexBasedSessionManager_exports, {
  IndexBasedSessionManager: () => IndexBasedSessionManager
});
module.exports = __toCommonJS(indexBasedSessionManager_exports);
var import_lazyUtils = require("../../lazyUtils");
var import_rorLoggerFactory = require("../../logging/rorLoggerFactory");
var import_sessionManager = require("../sessionManager");
class IndexBasedSessionManager extends import_sessionManager.SessionManager {
  constructor(inMemorySessionManager, indexSessionRepository, rorSettingsStore, userMetadataResolver) {
    super();
    this.inMemorySessionManager = inMemorySessionManager;
    this.indexSessionRepository = indexSessionRepository;
    this.rorSettingsStore = rorSettingsStore;
    this.userMetadataResolver = userMetadataResolver;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "sessionsFromIndex", /* @__PURE__ */ new Map());
    __publicField(this, "sessionReloadFromIndexJob");
    __publicField(this, "stopSessionIndexProvisioning");
    __publicField(this, "set", async (sid, session) => {
      const response = await this.indexSessionRepository.saveSession(sid, session);
      const saveIndexResponseData = await response.json();
      if (saveIndexResponseData.error) {
        this.logger.debug(`Index session SID: ${sid} save attempt returned:`, JSON.stringify(saveIndexResponseData));
        await this.clearSessionIndexIfOldMappingFormat(saveIndexResponseData.error, sid, session);
      }
      await this.inMemorySessionManager.set(sid, session);
    });
    __publicField(this, "setShortLivedSessionInMemory", async (sid, session) => {
      await this.inMemorySessionManager.setShortLivedSessionInMemory(sid, session);
    });
    __publicField(this, "get", async (sid) => {
      const fromLocal = await this.getFromLocalStorage(sid);
      if (fromLocal) {
        const resolvedSession = this.userMetadataResolver.resolveSessionMetadata(fromLocal);
        this.mostRecentlyAccessed = { sid, metadata: resolvedSession };
        return resolvedSession;
      }
      const fromIndex = await this.getFromIndex(sid);
      if (fromIndex) {
        this.logger.debug(`SID ${sid} found in in-index session storage.`);
        const resolvedSession = this.userMetadataResolver.resolveSessionMetadata(fromIndex);
        this.mostRecentlyAccessed = { sid, metadata: resolvedSession };
        return resolvedSession;
      }
      this.logger.debug(`SID ${sid} not found in in-index session storage either: giving up.`);
      return null;
    });
    __publicField(this, "delete", async (sid) => {
      await this.indexSessionRepository.deleteSession(sid);
      await this.inMemorySessionManager.delete(sid);
    });
    __publicField(this, "reloadSessionsFromIndex", async () => {
      this.sessionsFromIndex = await this.indexSessionRepository.getAllSessions();
    });
    __publicField(this, "checkIfSessionTimeout", async (sid) => {
      if (await this.isSessionTimeout(sid)) {
        this.delete(sid);
        return true;
      }
      return false;
    });
    __publicField(this, "getFromLocalStorage", async (sid) => {
      const fromMemory = await this.inMemorySessionManager.get(sid);
      if (fromMemory) return fromMemory;
      const thunk = this.sessionsFromIndex.get(sid);
      if (!thunk) return void 0;
      try {
        return await thunk();
      } catch (e) {
        this.logger.warn(`Failed to resolve session for SID ${sid} from index cache:`, e.message);
        return void 0;
      }
    });
    __publicField(this, "getFromIndex", async (sid) => {
      const result = await this.indexSessionRepository.getSession(sid);
      if (!result.ok) {
        this.logger.warn(`Failed to decode session for SID ${sid}: ${result.message}`);
        return void 0;
      }
      await this.inMemorySessionManager.set(sid, result.session);
      return result.session;
    });
    __publicField(this, "init", async () => {
      this.logger.debug("IndexBasedSessionManager initializing");
      this.inMemorySessionManager.init();
      this.stopSessionIndexProvisioning = await this.indexSessionRepository.startSessionIndexProvisioning();
      this.rorSettingsStore.observerRorKbnSettings(({ sessionManagerSettings }) => ({ refreshAfter: sessionManagerSettings.refreshAfter })).subscribe(async ({ refreshAfter }) => {
        await this.startOrRestartReloadSessionsFromIndex(refreshAfter);
      });
    });
    __publicField(this, "cleanup", () => {
      var _a, _b, _c;
      this.logger.debug("Cleaning IndexBasedSessionManager");
      (_b = (_a = this.sessionReloadFromIndexJob) == null ? void 0 : _a.stop) == null ? void 0 : _b.call(_a);
      (_c = this.stopSessionIndexProvisioning) == null ? void 0 : _c.call(this);
      this.inMemorySessionManager.cleanup();
    });
  }
  async deleteAllSessions() {
    await this.indexSessionRepository.deleteSessionIndex();
    await this.inMemorySessionManager.deleteAllSessions();
    this.mostRecentlyAccessed = void 0;
  }
  async startOrRestartReloadSessionsFromIndex(refreshAfter) {
    if (this.sessionReloadFromIndexJob) {
      this.sessionReloadFromIndexJob.stop();
      this.logger.debug(
        `Restarting IndexBasedSessionManager reload sessions from index job with interval ${refreshAfter}ms`
      );
    } else {
      this.logger.debug(
        `Starting IndexBasedSessionManager reload sessions from index  job with interval ${refreshAfter}ms`
      );
    }
    this.sessionReloadFromIndexJob = await (0, import_lazyUtils.executeWithInterval)(() => this.reloadSessionsFromIndex(), refreshAfter);
  }
  async clearSessionIndexIfOldMappingFormat(error, sid, session) {
    var _a;
    if ((_a = error == null ? void 0 : error.root_cause) == null ? void 0 : _a.some((rootCause) => rootCause.type === "mapper_parsing_exception")) {
      await this.deleteAllSessions();
      this.logger.debug(`Sessions deleted and session index recreated after mapper_parsing_exception error`);
      const nextSaveAttemptResponse = await this.indexSessionRepository.saveSession(sid, session);
      const nextSaveAttemptResponseData = await nextSaveAttemptResponse.json();
      this.logger.debug(
        `Index session SID: ${sid} next save attempt returned:`,
        JSON.stringify(nextSaveAttemptResponseData)
      );
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  IndexBasedSessionManager
});
