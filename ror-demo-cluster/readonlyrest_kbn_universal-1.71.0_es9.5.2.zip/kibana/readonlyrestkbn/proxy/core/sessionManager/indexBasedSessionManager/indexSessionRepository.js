"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from2, except, desc) => {
  if (from2 && typeof from2 === "object" || typeof from2 === "function") {
    for (let key of __getOwnPropNames(from2))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from2[key], enumerable: !(desc = __getOwnPropDesc(from2, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var indexSessionRepository_exports = {};
__export(indexSessionRepository_exports, {
  IndexSessionRepository: () => IndexSessionRepository
});
module.exports = __toCommonJS(indexSessionRepository_exports);
var import_rxjs = require("rxjs");
var import_errors = __toESM(require("../../../constants/errors"));
var import_rorLoggerFactory = require("../../logging/rorLoggerFactory");
const maxResults = 1e3;
const searchParams = {
  size: maxResults,
  sort: [{ expiresAt: { order: "desc", unmapped_type: "long" } }]
};
const SESSION_INDEX_MAPPINGS = {
  properties: {
    session: {
      type: "binary"
    },
    schemaVersion: {
      type: "keyword"
    }
  }
};
class IndexSessionRepository {
  constructor(rorSettingsStore, esApiClientWithAuthProvider, sessionEnvelopeCodec) {
    this.rorSettingsStore = rorSettingsStore;
    this.esApiClientWithAuthProvider = esApiClientWithAuthProvider;
    this.sessionEnvelopeCodec = sessionEnvelopeCodec;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "startSessionIndexProvisioning", async () => {
      const provisioning$ = this.rorSettingsStore.observerRorKbnSettings(({ sessionManagerSettings }) => ({
        indexName: sessionManagerSettings.indexName
      })).pipe(
        (0, import_rxjs.concatMap)(({ indexName }) => (0, import_rxjs.from)(this.createSessionIndexIfNotExists(indexName))),
        (0, import_rxjs.share)()
      );
      const subscription = provisioning$.subscribe();
      await (0, import_rxjs.firstValueFrom)(provisioning$);
      return () => subscription.unsubscribe();
    });
    __publicField(this, "getAllSessions", async () => {
      var _a, _b;
      const { sessionManagerSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      const response = await this.esApiClientWithAuthProvider.asTechnicalUser().runSearch({ indexName: sessionManagerSettings.indexName, searchParams });
      const body = await response.json();
      if (!response.ok) {
        this.logger.warn(`Failed fetching sessions:`, body);
        return /* @__PURE__ */ new Map();
      }
      const hits = (_b = (_a = body == null ? void 0 : body.hits) == null ? void 0 : _a.hits) != null ? _b : [];
      this.logger.debug(`Fetched all sessions from index, found: ${hits.length}`);
      return this.buildLazySessionMap(hits);
    });
    __publicField(this, "saveSession", async (sid, session) => {
      const serializedSession = this.sessionEnvelopeCodec.serialize(session);
      if (!serializedSession.success) {
        throw new Error(`Failed to serialize session: ${serializedSession.failure.kind}`);
      }
      const { sessionManagerSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      return this.esApiClientWithAuthProvider.asTechnicalUser().createOrUpdateDocumentInIndex({
        requestBody: serializedSession.value,
        indexName: sessionManagerSettings.indexName,
        docId: sid
      });
    });
    __publicField(this, "getSession", async (sid) => {
      const { sessionManagerSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      const response = await this.esApiClientWithAuthProvider.asTechnicalUser().getDocumentById({ indexName: sessionManagerSettings.indexName, docId: sid });
      const responseBody = await response.json();
      if (response.status === 404) {
        return { ok: false, message: import_errors.default.session.notFound };
      }
      if (response.status >= 400) {
        this.logger.warn(`Failed fetching session: ${JSON.stringify(responseBody)}`);
        return { ok: false, message: import_errors.default.session.fetchSessionFailed };
      }
      try {
        const session = await this.deserializeSession(responseBody);
        return { ok: true, session };
      } catch (e) {
        this.logger.debug(`Failed to parse session for SID ${responseBody._id}: ${e.message}`);
        return { ok: false, message: e.message };
      }
    });
    __publicField(this, "deleteSession", async (sid) => {
      const { sessionManagerSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      this.logger.debug(`Deleting session with SID:${sid} from index`);
      await this.esApiClientWithAuthProvider.asTechnicalUser().deleteDocument({ indexName: sessionManagerSettings.indexName, docId: sid });
    });
    __publicField(this, "createSessionIndexIfNotExists", async (indexName) => {
      const requestBody = {
        settings: {
          number_of_shards: 1,
          auto_expand_replicas: "0-1"
        },
        mappings: SESSION_INDEX_MAPPINGS
      };
      try {
        const response = await this.esApiClientWithAuthProvider.asTechnicalUser().createIndex({ indexName, requestBody });
        const createIndexResponseData = await response.json();
        if (response.status === 200) {
          this.logger.debug(`The index ${indexName} was created.`);
        } else if (response.status === 400 && createIndexResponseData.error.type.includes("resource_already_exists_exception")) {
          this.logger.debug(`The index ${indexName} already exists.`);
        } else {
          this.logger.error(
            {
              message: `Unexpected status code creating the in-index session: status=${response.status}`
            },
            createIndexResponseData
          );
        }
      } catch (e) {
        this.logger.error({
          message: `Unexpected error creating the in-index session: ${e.message}`,
          stack: e.stack
        });
      }
    });
    __publicField(this, "deleteSessionIndex", async () => {
      const { sessionManagerSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      await this.esApiClientWithAuthProvider.asTechnicalUser().deleteIndex({ indexName: sessionManagerSettings.indexName });
    });
    __publicField(this, "buildLazySessionMap", (hits) => {
      const memo = /* @__PURE__ */ new Map();
      return new Map(
        hits.map((hit) => [
          hit._id,
          () => {
            const sid = hit._id;
            if (!memo.has(sid)) {
              memo.set(sid, this.deserializeSession(hit));
            }
            return memo.get(sid);
          }
        ])
      );
    });
    __publicField(this, "deserializeSession", async (hit) => {
      const result = this.sessionEnvelopeCodec.deserialize(hit._source);
      if (!result.success) {
        const { failure } = result;
        const message = failure.kind === "invalid_json" || failure.kind === "decrypt_failed" ? import_errors.default.session.invalidJSON : failure.reason;
        throw new Error(message);
      }
      return result.value;
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  IndexSessionRepository
});
