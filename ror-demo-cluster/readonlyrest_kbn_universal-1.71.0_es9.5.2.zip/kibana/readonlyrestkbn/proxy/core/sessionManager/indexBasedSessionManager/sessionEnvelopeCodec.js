"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var sessionEnvelopeCodec_exports = {};
__export(sessionEnvelopeCodec_exports, {
  SessionEnvelopeCodec: () => SessionEnvelopeCodec
});
module.exports = __toCommonJS(sessionEnvelopeCodec_exports);
class SessionEnvelopeCodec {
  constructor(codecs) {
    __publicField(this, "sessionEncoder");
    __publicField(this, "sessionDecoders");
    __publicField(this, "serialize", (session) => {
      const encoded = this.sessionEncoder.encode(session);
      if (!encoded.success) {
        return encoded;
      }
      return {
        success: true,
        value: {
          session: encoded.value,
          schemaVersion: this.sessionEncoder.schemaVersion
        }
      };
    });
    __publicField(this, "deserialize", ({ schemaVersion, session }) => {
      var _a;
      const resolvedCodec = (_a = this.sessionDecoders.get(schemaVersion)) != null ? _a : this.sessionEncoder;
      return resolvedCodec.decode(session);
    });
    codecs.forEach((c) => {
      if (Number.isNaN(Number(c.schemaVersion))) {
        throw new Error(`SessionCodec schemaVersion must be a numeric string; got '${c.schemaVersion}'`);
      }
    });
    this.sessionDecoders = new Map(codecs.map((c) => [c.schemaVersion, c]));
    this.sessionEncoder = codecs.reduce(
      (latest, codec) => Number(codec.schemaVersion) > Number(latest.schemaVersion) ? codec : latest
    );
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SessionEnvelopeCodec
});
