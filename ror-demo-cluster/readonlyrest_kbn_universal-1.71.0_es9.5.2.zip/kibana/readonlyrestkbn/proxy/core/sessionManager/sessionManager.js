"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var sessionManager_exports = {};
__export(sessionManager_exports, {
  SessionManager: () => SessionManager
});
module.exports = __toCommonJS(sessionManager_exports);
var import_uuid = require("uuid");
var import_ActivationKey = require("../../../shared/types/ActivationKey");
var import_timeUtils = require("../common/timeUtils");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
const EXCLUDED_SESSION_TIMEOUT_REFRESH_PATHS = ["/api/ui_counters/_report", "/api/licensing/info"];
const getLogger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
class SessionManager {
  constructor() {
    __publicField(this, "mostRecentlyAccessed", null);
    __publicField(this, "createNewSessionExpirationDate", () => new Date(Date.now() + this.getSessionTimeoutMillis()));
    __publicField(this, "clearMostRecentlyAccessed", () => {
      this.mostRecentlyAccessed = void 0;
    });
    __publicField(this, "refreshSession", async (sid, currentUrl, nextRefreshAfterInSeconds = 2) => {
      const oldSession = await this.get(sid);
      const correlationId = oldSession == null ? void 0 : oldSession.correlationId;
      if (!oldSession) {
        throw new Error("The previous session cannot be accessed.");
      }
      if (!correlationId) {
        getLogger().trace("The previous correlationId cannot be retrieved.");
      }
      const lastSessionActivityDate = this.refreshLastSessionActivityDate(oldSession, sid, currentUrl);
      const oldSessionLastActivityDate = oldSession.lastSessionActivityDate;
      const differenceInSeconds = !lastSessionActivityDate || !oldSessionLastActivityDate ? void 0 : (lastSessionActivityDate.getTime() - oldSessionLastActivityDate.getTime()) / 1e3;
      if (differenceInSeconds && differenceInSeconds <= nextRefreshAfterInSeconds) {
        getLogger().trace(
          `The time since the last activity is ${differenceInSeconds} second, which is less than the required ${nextRefreshAfterInSeconds} seconds for the next refresh. Returning the old session.\u201D`
        );
        return oldSession;
      }
      const newSession = {
        ...oldSession,
        expiresAt: this.createNewSessionExpirationDate(),
        lastSessionActivityDate,
        identitySessionHeaders: new Map([...Array.from(oldSession.identitySessionHeaders.entries())]),
        correlationId: correlationId || (0, import_uuid.v4)()
      };
      await this.set(sid, newSession);
      getLogger().trace(`Session refreshed successfully after ${differenceInSeconds} seconds.`);
      return newSession;
    });
    __publicField(this, "getSessionTimeoutMillis", () => {
      const rorKbnSettings = this.rorSettingsStore.getLatestRorKbnSettings();
      return import_timeUtils.TimeUtils.minutesToMillis(rorKbnSettings.sessionSettings.timeoutMinutes);
    });
  }
  cleanAfterGet(licenseService, session) {
    const metadata = session;
    const license = licenseService.getActivationKey().license;
    const isEnt = (0, import_ActivationKey.isEnterpriseLicense)(license);
    return {
      ...metadata,
      impersonatedBy: isEnt ? metadata.impersonatedBy : void 0
    };
  }
  getMostRecentlyAccessed() {
    return this.mostRecentlyAccessed;
  }
  async exists(sid) {
    return await this.get(sid) != null;
  }
  async isSessionExpired(sid) {
    const session = await this.get(sid);
    if (!(session == null ? void 0 : session.expiresAt)) {
      return true;
    }
    return session.expiresAt.getTime() < Date.now();
  }
  refreshLastSessionActivityDate(session, sid, currentUrl) {
    if (EXCLUDED_SESSION_TIMEOUT_REFRESH_PATHS.includes(currentUrl)) {
      return session.lastSessionActivityDate;
    }
    return /* @__PURE__ */ new Date();
  }
  async lastSessionActivityDate(sid) {
    const session = await this.get(sid);
    if (!session) {
      return;
    }
    return session.lastSessionActivityDate;
  }
  async isSessionTimeout(sid) {
    const currentTimeInMillis = (/* @__PURE__ */ new Date()).getTime();
    const lastSessionActivityDate = await this.lastSessionActivityDate(sid);
    if (!lastSessionActivityDate) {
      return true;
    }
    const lastSessionActivityTimeInMillis = currentTimeInMillis - lastSessionActivityDate.getTime();
    return this.getSessionTimeoutMillis() < lastSessionActivityTimeInMillis;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SessionManager
});
