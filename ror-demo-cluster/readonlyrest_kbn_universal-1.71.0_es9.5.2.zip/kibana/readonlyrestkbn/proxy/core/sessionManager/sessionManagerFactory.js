"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var sessionManagerFactory_exports = {};
__export(sessionManagerFactory_exports, {
  SessionManagerFactory: () => SessionManagerFactory
});
module.exports = __toCommonJS(sessionManagerFactory_exports);
var import_v1SessionCodec = require("./codecs/versionCodecs/v1SessionCodec");
var import_v2SessionCodec = require("./codecs/versionCodecs/v2SessionCodec");
var import_indexBasedSessionManager = require("./indexBasedSessionManager/indexBasedSessionManager");
var import_indexSessionRepository = require("./indexBasedSessionManager/indexSessionRepository");
var import_sessionEnvelopeCodec = require("./indexBasedSessionManager/sessionEnvelopeCodec");
var import_inMemorySessionManager = require("./inMemorySessionManager");
const _SessionManagerFactory = class _SessionManagerFactory {
  static clearInstance() {
    _SessionManagerFactory.sessionManager = void 0;
  }
  static build(esApiClientWithAuthProvider, rorSettingsStore, licenseService, reportingQueueTimeout, userMetadataResolver) {
    const { sessionManagerSettings } = rorSettingsStore.getLatestRorKbnSettings();
    const shortLivedSessionTimeout = reportingQueueTimeout + _SessionManagerFactory.SHORT_LIVED_SESSION_SAFETY_BUFFER_SECONDS;
    const inMemorySessionManager = new import_inMemorySessionManager.InMemorySessionManager(
      licenseService,
      shortLivedSessionTimeout,
      rorSettingsStore,
      userMetadataResolver
    );
    if (!sessionManagerSettings.storeInIndex) {
      return inMemorySessionManager;
    }
    const sessionEnvelopeCodec = new import_sessionEnvelopeCodec.SessionEnvelopeCodec([
      new import_v1SessionCodec.V1SessionCodec(sessionManagerSettings.sessionKey),
      new import_v2SessionCodec.V2SessionCodec(sessionManagerSettings.sessionKey)
    ]);
    const indexSessionRepository = new import_indexSessionRepository.IndexSessionRepository(
      rorSettingsStore,
      esApiClientWithAuthProvider,
      sessionEnvelopeCodec
    );
    if (!_SessionManagerFactory.sessionManager) {
      _SessionManagerFactory.sessionManager = new import_indexBasedSessionManager.IndexBasedSessionManager(
        inMemorySessionManager,
        indexSessionRepository,
        rorSettingsStore,
        userMetadataResolver
      );
    }
    return _SessionManagerFactory.sessionManager;
  }
};
// Short-lived sessions (used for direct API requests authenticated via Basic Auth, e.g. reporting jobs)
// must outlive the longest reporting job the queue allows, plus a safety buffer.
__publicField(_SessionManagerFactory, "SHORT_LIVED_SESSION_SAFETY_BUFFER_SECONDS", 60);
__publicField(_SessionManagerFactory, "sessionManager");
let SessionManagerFactory = _SessionManagerFactory;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SessionManagerFactory
});
