"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var sessionManagerProvider_exports = {};
__export(sessionManagerProvider_exports, {
  SessionManagerProvider: () => SessionManagerProvider
});
module.exports = __toCommonJS(sessionManagerProvider_exports);
var import_rxjs = require("rxjs");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_v1SessionCodec = require("./codecs/versionCodecs/v1SessionCodec");
var import_v2SessionCodec = require("./codecs/versionCodecs/v2SessionCodec");
var import_indexBasedSessionManager = require("./indexBasedSessionManager/indexBasedSessionManager");
var import_indexSessionRepository = require("./indexBasedSessionManager/indexSessionRepository");
var import_sessionEnvelopeCodec = require("./indexBasedSessionManager/sessionEnvelopeCodec");
var import_inMemorySessionManager = require("./inMemorySessionManager");
const _SessionManagerProvider = class _SessionManagerProvider {
  constructor(licenseService, reportingQueueTimeout, rorSettingsStore, esApiClientWithAuthProvider, userMetadataResolver) {
    this.licenseService = licenseService;
    this.reportingQueueTimeout = reportingQueueTimeout;
    this.rorSettingsStore = rorSettingsStore;
    this.esApiClientWithAuthProvider = esApiClientWithAuthProvider;
    this.userMetadataResolver = userMetadataResolver;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "currentSessionManager");
    __publicField(this, "settingsSubscription");
  }
  get() {
    if (!this.currentSessionManager) {
      throw new Error("SessionManager does not exist");
    }
    return this.currentSessionManager;
  }
  build() {
    const shortLivedSessionTimeout = this.reportingQueueTimeout + _SessionManagerProvider.SHORT_LIVED_SESSION_SAFETY_BUFFER_SECONDS;
    const inMemorySessionManager = new import_inMemorySessionManager.InMemorySessionManager(
      this.licenseService,
      shortLivedSessionTimeout,
      this.rorSettingsStore,
      this.userMetadataResolver
    );
    this.settingsSubscription = this.rorSettingsStore.observerRorKbnSettings(({ sessionManagerSettings }) => ({
      storeInIndex: sessionManagerSettings.storeInIndex,
      sessionKey: sessionManagerSettings.sessionKey
    })).pipe(
      (0, import_rxjs.concatMap)(async ({ storeInIndex, sessionKey }) => {
        var _a;
        try {
          (_a = this.currentSessionManager) == null ? void 0 : _a.cleanup();
          const sessionEnvelopeCodec = new import_sessionEnvelopeCodec.SessionEnvelopeCodec([
            new import_v1SessionCodec.V1SessionCodec(sessionKey),
            new import_v2SessionCodec.V2SessionCodec(sessionKey)
          ]);
          const indexSessionRepository = new import_indexSessionRepository.IndexSessionRepository(
            this.rorSettingsStore,
            this.esApiClientWithAuthProvider,
            sessionEnvelopeCodec
          );
          const indexBasedSessionManager = new import_indexBasedSessionManager.IndexBasedSessionManager(
            inMemorySessionManager,
            indexSessionRepository,
            this.rorSettingsStore,
            this.userMetadataResolver
          );
          const newSessionManager = storeInIndex ? indexBasedSessionManager : inMemorySessionManager;
          await newSessionManager.init();
          this.setCurrentSessionManager(newSessionManager);
        } catch (e) {
          this.logger.error({
            message: `Failed to apply session manager settings update: ${e.message}. Keeping the previous session manager.`,
            stack: e.stack
          });
        }
      })
    ).subscribe();
    return this;
  }
  destroy() {
    var _a, _b;
    (_a = this.settingsSubscription) == null ? void 0 : _a.unsubscribe();
    this.settingsSubscription = void 0;
    (_b = this.currentSessionManager) == null ? void 0 : _b.cleanup();
    this.currentSessionManager = void 0;
  }
  setCurrentSessionManager(sessionManager) {
    this.currentSessionManager = sessionManager;
  }
};
// Short-lived sessions (used for direct API requests authenticated via Basic Auth, e.g. reporting jobs)
// must outlive the longest reporting job the queue allows, plus a safety buffer.
__publicField(_SessionManagerProvider, "SHORT_LIVED_SESSION_SAFETY_BUFFER_SECONDS", 60);
let SessionManagerProvider = _SessionManagerProvider;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SessionManagerProvider
});
