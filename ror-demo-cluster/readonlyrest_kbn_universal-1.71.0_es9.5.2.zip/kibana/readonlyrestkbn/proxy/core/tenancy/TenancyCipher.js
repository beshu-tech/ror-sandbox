"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var TenancyCipher_exports = {};
__export(TenancyCipher_exports, {
  TenancyCipher: () => TenancyCipher
});
module.exports = __toCommonJS(TenancyCipher_exports);
var import_Cipher = require("../common/Cipher");
class TenancyCipher {
  constructor(key) {
    this.key = key;
  }
  encrypt(plaintext) {
    return import_Cipher.Cipher.encryptAes256(plaintext, this.key);
  }
  decrypt(ciphertext) {
    return import_Cipher.Cipher.decryptAes256(ciphertext, this.key);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TenancyCipher
});
