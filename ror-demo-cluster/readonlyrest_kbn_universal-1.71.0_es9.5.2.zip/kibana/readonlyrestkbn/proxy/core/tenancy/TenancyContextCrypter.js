"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var TenancyContextCrypter_exports = {};
__export(TenancyContextCrypter_exports, {
  TenancyContextCrypter: () => TenancyContextCrypter
});
module.exports = __toCommonJS(TenancyContextCrypter_exports);
var import_TenancyCipher = require("./TenancyCipher");
var import_TenancyContext = require("./TenancyContext");
class TenancyContextCrypter {
  constructor(storeEncryptionKey) {
    __publicField(this, "cipher");
    this.cipher = new import_TenancyCipher.TenancyCipher(storeEncryptionKey);
  }
  encryptTenancy({ tenancyId, kibanaIndex }) {
    return this.cipher.encrypt(JSON.stringify({ tenancyId, kibanaIndex }, null, 0));
  }
  decryptTenancy(encryptedTenancy) {
    try {
      const decryptedText = this.cipher.decrypt(encryptedTenancy);
      if (!decryptedText) {
        return null;
      }
      return this.parseTenancyContext(JSON.parse(decryptedText));
    } catch {
      return null;
    }
  }
  parseTenancyContext(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      return null;
    }
    const { tenancyId: rawTenancyId, kibanaIndex: rawKibanaIndex } = value;
    if (rawTenancyId != null && typeof rawTenancyId !== "string" || rawKibanaIndex != null && typeof rawKibanaIndex !== "string") {
      return null;
    }
    const tenancyId = rawTenancyId != null ? rawTenancyId : void 0;
    const kibanaIndex = rawKibanaIndex != null ? rawKibanaIndex : void 0;
    if (tenancyId) return (0, import_TenancyContext.tenancyFromId)(tenancyId, kibanaIndex);
    return kibanaIndex ? (0, import_TenancyContext.tenancyFromKibanaIndex)(void 0, kibanaIndex) : null;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TenancyContextCrypter
});
