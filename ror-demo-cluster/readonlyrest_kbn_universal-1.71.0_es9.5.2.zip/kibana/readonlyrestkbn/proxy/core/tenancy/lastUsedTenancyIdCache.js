"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var lastUsedTenancyIdCache_exports = {};
__export(lastUsedTenancyIdCache_exports, {
  LastUsedTenancyIdCache: () => LastUsedTenancyIdCache
});
module.exports = __toCommonJS(lastUsedTenancyIdCache_exports);
class LastUsedTenancyIdCache {
  constructor(ttlMs = 2 * 60 * 1e3) {
    __publicField(this, "cache", /* @__PURE__ */ new Map());
    __publicField(this, "ttlMs");
    __publicField(this, "cleanupTimer");
    this.ttlMs = ttlMs;
    this.startCleanup();
  }
  set(sid, tenancyId) {
    if (!sid || !tenancyId) return;
    this.cache.set(sid, { tenancyId, updatedAt: Date.now() });
  }
  get(sid) {
    if (!sid) return void 0;
    const entry = this.cache.get(sid);
    if (!entry) return void 0;
    if (Date.now() - entry.updatedAt > this.ttlMs) {
      this.cache.delete(sid);
      return void 0;
    }
    return entry.tenancyId;
  }
  delete(sid) {
    this.cache.delete(sid);
  }
  clear() {
    this.cache.clear();
  }
  stopCleanup() {
    if (this.cleanupTimer) {
      clearInterval(this.cleanupTimer);
      this.cleanupTimer = void 0;
    }
  }
  startCleanup() {
    this.cleanupTimer = setInterval(() => {
      const now = Date.now();
      for (const [sid, entry] of this.cache) {
        if (now - entry.updatedAt > this.ttlMs) {
          this.cache.delete(sid);
        }
      }
    }, this.ttlMs);
    if (this.cleanupTimer.unref) this.cleanupTimer.unref();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LastUsedTenancyIdCache
});
