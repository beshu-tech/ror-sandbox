"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var multiTenancyChecker_exports = {};
__export(multiTenancyChecker_exports, {
  MultiTenancyChecker: () => MultiTenancyChecker
});
module.exports = __toCommonJS(multiTenancyChecker_exports);
var import_ActivationKey = require("../../../shared/types/ActivationKey");
class MultiTenancyChecker {
  constructor(rorSettingsStore, license) {
    this.rorSettingsStore = rorSettingsStore;
    this.license = license;
  }
  multiTenancyFeatureAvailable() {
    const { multiTenancyEnabled } = this.rorSettingsStore.getLatestRorKbnSettings();
    return (0, import_ActivationKey.isEnterpriseLicense)(this.license.getActivationKey().license) && multiTenancyEnabled;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  MultiTenancyChecker
});
