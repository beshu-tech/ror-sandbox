"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tenancyAccessPolicy_exports = {};
__export(tenancyAccessPolicy_exports, {
  TenancyAccessPolicy: () => TenancyAccessPolicy
});
module.exports = __toCommonJS(tenancyAccessPolicy_exports);
var import_kibanaIndexDependentUrls = require("../../../shared/constants/kibanaIndexDependentUrls");
var import_errors = __toESM(require("../../constants/errors"));
var import_tenancyMatcher = require("./tenancyMatcher");
class TenancyAccessPolicy {
  constructor(tenancyContextResolver, multiTenancyChecker, tenancyService) {
    this.tenancyContextResolver = tenancyContextResolver;
    this.multiTenancyChecker = multiTenancyChecker;
    this.tenancyService = tenancyService;
  }
  async hasUserAccessToTenancyFromUrl(request) {
    const isKibanaIndexDependentUrl = (0, import_kibanaIndexDependentUrls.isSavedObjectDependentUrl)(request.rorRequest.getUrl());
    if (!isKibanaIndexDependentUrl) {
      return true;
    }
    if (!this.multiTenancyChecker.multiTenancyFeatureAvailable()) {
      return true;
    }
    const urlTenancyContext = this.tenancyContextResolver.resolveFromUrl(request);
    if (!urlTenancyContext) {
      return true;
    }
    const userRequestIdentity = await request.rorRequest.getUserRequestIdentity();
    if (!userRequestIdentity) {
      return false;
    }
    const availableTenancies = await this.tenancyService.getAvailableTenanciesForUser(userRequestIdentity.sid);
    return availableTenancies.length === 0 ? this.resolveAccessForUserWithoutGroups(urlTenancyContext.kibanaIndex, userRequestIdentity.metadata.kibanaIndex) : Boolean(
      await this.findTenancyByContext(urlTenancyContext, userRequestIdentity.sid, request.rorRequest.getUrl())
    );
  }
  async switchTenancyPermitted(request) {
    try {
      const userRequestIdentity = await request.rorRequest.getUserRequestIdentity();
      if (!userRequestIdentity) {
        return { ok: false, message: import_errors.default.userRequestIdentityNotAvailable };
      }
      const newGroupId = new URL(request.rorRequest.getUrl(), "http://localhost:5601").searchParams.get("group");
      if (!newGroupId) {
        return { ok: false, message: import_errors.default.groupNotDefinedInUrl };
      }
      const availableTenancies = await this.tenancyService.getAvailableTenanciesForUser(userRequestIdentity.sid);
      if (!availableTenancies.some(({ group }) => group.id === newGroupId)) {
        return { ok: false, message: import_errors.default.tenancy.selectedTenancyNotAvailableForTheUser(newGroupId) };
      }
      return { ok: true, message: "tenancy switch permitted" };
    } catch (e) {
      return { ok: false, message: import_errors.default.tenancy.switchError, stack: e.stack };
    }
  }
  resolveAccessForUserWithoutGroups(urlKibanaIndex, userKibanaIndex) {
    return !urlKibanaIndex || urlKibanaIndex === userKibanaIndex;
  }
  async findTenancyByContext(urlTenancyContext, sid, url) {
    const tenancies = await this.tenancyService.getAvailableTenanciesForUser(sid);
    return (0, import_tenancyMatcher.findMatchingTenancy)(tenancies, urlTenancyContext, { url });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TenancyAccessPolicy
});
