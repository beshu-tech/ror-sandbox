"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tenancyContextResolver_exports = {};
__export(tenancyContextResolver_exports, {
  TenancyContextResolver: () => TenancyContextResolver
});
module.exports = __toCommonJS(tenancyContextResolver_exports);
var import_headers = require("../../../shared/constants/headers");
var import_queryStringKeys = require("../../../shared/constants/queryStringKeys");
var import_types = require("../common/types");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_RorMetadata = require("../RorMetadata");
var import_TenancyContext = require("./TenancyContext");
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
class TenancyContextResolver {
  constructor(tenancyContextCrypter) {
    this.tenancyContextCrypter = tenancyContextCrypter;
  }
  resolve(req) {
    var _a, _b, _c, _d, _e, _f;
    const resolved = (_f = (_e = (_d = (_c = (_b = (_a = this.fromHeader(req)) != null ? _a : this.fromQueryString(req)) != null ? _b : this.fromRorMetadata(req)) != null ? _c : this.fromGroupParam(req)) != null ? _d : this.fromDefaultGroupParam(req)) != null ? _e : this.fromReferer(req)) != null ? _f : this.fromCurrentGroupHeader(req);
    if (resolved) {
      return resolved;
    }
    return this.isLoginPath(req) ? this.resolveFromNextUrl(req) : null;
  }
  /**
   * Reads the tenancy encoded in the URL's own query string only — deliberately not the full
   * priority chain used by `resolve()`. Used by access-control checks that must verify what a
   * URL itself claims, not the tenancy the proxy has otherwise inferred for the request (e.g.
   * from headers reflecting the user's already-granted session tenancy).
   */
  resolveFromUrl(req) {
    const encrypted = this.getRawTenancyContextFromQueryString(req);
    if (!encrypted) {
      return null;
    }
    return this.tenancyContextCrypter.decryptTenancy(encrypted);
  }
  resolveFromNextUrl(req) {
    return this.decryptTenancyContext(this.extractFromNextUrl(req));
  }
  isLoginPath(req) {
    return req.path.includes("/login");
  }
  fromHeader(req) {
    return this.decryptTenancyContext(this.getRawTenancyContextFromHeader(req));
  }
  fromQueryString(req) {
    return this.decryptTenancyContext(this.getRawTenancyContextFromQueryString(req));
  }
  fromRorMetadata(req) {
    var _a;
    const tenancyId = (_a = import_RorMetadata.RorMetadata.fromHeaders(req.headers)) == null ? void 0 : _a.getTenancyId();
    return tenancyId ? (0, import_TenancyContext.tenancyFromId)(tenancyId) : null;
  }
  fromGroupParam(req) {
    const tenancyId = this.getRawTenancyContextFromGroupParam(req);
    return tenancyId ? (0, import_TenancyContext.tenancyFromId)(tenancyId) : null;
  }
  fromDefaultGroupParam(req) {
    const tenancyId = this.getRawTenancyContextFromDefaultGroupParam(req);
    return tenancyId ? (0, import_TenancyContext.tenancyFromId)(tenancyId) : null;
  }
  fromReferer(req) {
    return this.decryptTenancyContext(this.getRawTenancyContextFromRefererHeader(req));
  }
  fromCurrentGroupHeader(req) {
    const tenancyId = this.getRawTenancyIdFromHeader(req);
    return tenancyId ? (0, import_TenancyContext.tenancyFromId)(tenancyId) : null;
  }
  getRawTenancyContextFromQueryString(req) {
    const tenancyFromQueryString = req.query[import_queryStringKeys.TENANCY_QUERY_STRING_KEY];
    if (typeof tenancyFromQueryString === "string") {
      return tenancyFromQueryString;
    }
    return null;
  }
  getRawTenancyContextFromHeader(req) {
    return req.header(import_headers.X_ROR_TENANCY);
  }
  getRawTenancyIdFromHeader(req) {
    return req.header(import_types.X_ROR_CURRENT_GROUP) || req.header(import_types.X_ROR_TENANCY_ID);
  }
  getRawTenancyContextFromGroupParam(req) {
    return typeof req.query.group === "string" ? req.query.group : void 0;
  }
  getRawTenancyContextFromDefaultGroupParam(req) {
    return typeof req.query.defaultGroup === "string" ? req.query.defaultGroup : void 0;
  }
  getRawTenancyContextFromRefererHeader(req) {
    const refererHeader = req.get("referer") || req.get("referrer");
    if (refererHeader) {
      try {
        const refererHeaderUrl = new URL(refererHeader);
        return refererHeaderUrl.searchParams.get(import_queryStringKeys.TENANCY_QUERY_STRING_KEY) || void 0;
      } catch {
        return void 0;
      }
    }
    return void 0;
  }
  decryptTenancyContext(encrypted) {
    if (!encrypted) return null;
    return this.tenancyContextCrypter.decryptTenancy(encrypted);
  }
  extractFromNextUrl(req) {
    const nextUrl = req.query.nextUrl;
    if (typeof nextUrl !== "string") {
      return void 0;
    }
    try {
      const match = nextUrl.match(new RegExp(`[?&]${import_queryStringKeys.TENANCY_QUERY_STRING_KEY}=([^&#]*)`));
      if (!match) {
        return void 0;
      }
      return decodeURIComponent(match[1]);
    } catch (error) {
      logger.debug("Failed to extract tenancy from nextUrl", {
        nextUrl,
        error: error instanceof Error ? error.message : String(error)
      });
      return void 0;
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TenancyContextResolver
});
