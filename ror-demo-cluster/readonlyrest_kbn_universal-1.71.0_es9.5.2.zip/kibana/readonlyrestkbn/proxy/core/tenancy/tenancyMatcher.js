"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tenancyMatcher_exports = {};
__export(tenancyMatcher_exports, {
  findMatchingTenancy: () => findMatchingTenancy
});
module.exports = __toCommonJS(tenancyMatcher_exports);
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const findMatchingTenancy = (tenancies, tenancyContext, logContext) => {
  const matchedByTenancyIdAndKibanaIndex = matchByTenancyIdAndKibanaIndex(tenancies, tenancyContext, logContext);
  if (matchedByTenancyIdAndKibanaIndex) return matchedByTenancyIdAndKibanaIndex;
  const matchedByKibanaIndexOnly = matchByKibanaIndexOnly(tenancies, tenancyContext, logContext);
  if (matchedByKibanaIndexOnly) return matchedByKibanaIndexOnly;
  logger.trace("No matching tenancy found for tenancy context", {
    ...logContext,
    tenancyId: tenancyContext.tenancyId,
    kibanaIndex: tenancyContext.kibanaIndex
  });
  return void 0;
};
function matchByTenancyIdAndKibanaIndex(tenancies, tenancyContext, logContext) {
  const { tenancyId, kibanaIndex } = tenancyContext;
  if (!tenancyId) return void 0;
  const matches = tenancies.filter(
    ({ group, kibana }) => group.id === tenancyId && (!kibanaIndex || (kibana == null ? void 0 : kibana.index) === kibanaIndex)
  );
  if (matches.length > 1) {
    logger.debug("Multiple tenancies matched by tenancyId (and kibanaIndex, when provided); picking the first one", {
      ...logContext,
      tenancyId,
      kibanaIndex,
      candidates: matches,
      picked: matches[0]
    });
  }
  return matches[0];
}
function matchByKibanaIndexOnly(tenancies, tenancyContext, logContext) {
  const { kibanaIndex } = tenancyContext;
  if (!kibanaIndex) {
    logger.trace("No kibanaIndex available, kibanaIndex fallback skipped", logContext);
    return void 0;
  }
  const matches = tenancies.filter(({ kibana }) => (kibana == null ? void 0 : kibana.index) === kibanaIndex);
  if (matches.length > 1) {
    logger.debug("Multiple tenancies matched by kibanaIndex; picking the first one", {
      ...logContext,
      kibanaIndex,
      candidates: matches,
      picked: matches[0]
    });
  } else if (matches.length === 1) {
    logger.debug("Resolved tenancy by kibanaIndex fallback", {
      ...logContext,
      kibanaIndex,
      resolvedTenancyId: matches[0].group.id
    });
  }
  return matches[0];
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  findMatchingTenancy
});
