"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var tenancyService_exports = {};
__export(tenancyService_exports, {
  TenancyService: () => TenancyService
});
module.exports = __toCommonJS(tenancyService_exports);
var import_exhaustiveCheck = require("../common/exhaustiveCheck");
var import_types = require("../common/types");
var import_identitySession = require("../identitySession");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
var import_lastUsedTenancyIdCache = require("./lastUsedTenancyIdCache");
var import_tenancyAccessPolicy = require("./tenancyAccessPolicy");
var import_TenancyContext = require("./TenancyContext");
var import_tenancyContextResolver = require("./tenancyContextResolver");
var import_tenancyMatcher = require("./tenancyMatcher");
var import_tenancyUrl = require("./tenancyUrl");
class TenancyService {
  constructor(tenancyContextCrypter, sessionManagerProvider, multiTenancyChecker) {
    this.tenancyContextCrypter = tenancyContextCrypter;
    this.sessionManagerProvider = sessionManagerProvider;
    this.multiTenancyChecker = multiTenancyChecker;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "tenancyContextResolver");
    __publicField(this, "lastUsedTenancyIdCache", new import_lastUsedTenancyIdCache.LastUsedTenancyIdCache());
    __publicField(this, "accessPolicy");
    this.tenancyContextResolver = new import_tenancyContextResolver.TenancyContextResolver(tenancyContextCrypter);
    this.accessPolicy = new import_tenancyAccessPolicy.TenancyAccessPolicy(this.tenancyContextResolver, multiTenancyChecker, this);
  }
  async getAndRememberTenancyContext(req, sid) {
    const context = await this.resolveTenancyContextFromRequest(req, sid);
    this.lastUsedTenancyIdCache.set(sid, context == null ? void 0 : context.tenancyId);
    return context;
  }
  /**
   * Resolves the effective tenancy for a USER_WITH_GROUPS identity session and matches it against
   * that user's available tenancies. See TenancyResolutionResult for why the two failure kinds
   * are kept distinct.
   */
  async getAndRememberTenancyForUserRequestIdentity(req, sid, identitySessionMetadata, predefinedTenancyId, url) {
    const tenancyContext = await this.resolveTenancyContextForUserRequestIdentity(
      req,
      sid,
      identitySessionMetadata,
      predefinedTenancyId
    );
    if (!tenancyContext) {
      this.logger.error({
        message: "No tenancy context available (neither tenancyId nor kibanaIndex found in request)"
      });
      return { ok: false, reason: "no_tenancy_context_provided" };
    }
    const tenancy = this.matchTenancyAgainstUserTenancies(tenancyContext, identitySessionMetadata.groups, url);
    if (!tenancy) {
      return { ok: false, reason: "no_group_matching_tenancy_context" };
    }
    this.lastUsedTenancyIdCache.set(sid, tenancy.group.id);
    return { ok: true, data: tenancy };
  }
  getLastUsedTenancyId(sid) {
    return this.lastUsedTenancyIdCache.get(sid);
  }
  persistTenancyContextInUrl(url, tenancyContext, origin) {
    return (0, import_tenancyUrl.addTenancyIfAbsent)(url, this.buildEncryptedTenancyContext(tenancyContext), origin);
  }
  buildEncryptedTenancyContext(tenancyContext) {
    return this.tenancyContextCrypter.encryptTenancy(tenancyContext);
  }
  async getAvailableTenanciesForUser(sid) {
    const userSession = await this.sessionManagerProvider.get().get(sid);
    if (!(0, import_identitySession.isIdentitySessionMetadataUserWithGroups)(userSession)) {
      return [];
    }
    return userSession.groups;
  }
  /**
   * Weighs four tenancy sources in priority order: an explicitly predefined tenancyId, the
   * current request, the X_ROR_TENANCY_ID identity session header, and (only if nothing else
   * resolved) the user's first available tenancy. These sources are mutually exclusive by
   * construction (see resolveTenancyContextFromSessionHeaders's and the initialContext guard
   * below, and predefinedContext's independent priority), so the result always comes from exactly
   * one of them — never a blend.
   */
  async resolveTenancyContextForUserRequestIdentity(req, sid, identitySessionMetadata, predefinedTenancyId) {
    var _a, _b;
    const contextFromRequest = await this.getAndRememberTenancyContext(req, sid);
    const identityHeaderContext = this.resolveTenancyContextFromSessionHeaders(
      identitySessionMetadata,
      contextFromRequest
    );
    const noTenancyResolved = !contextFromRequest && !identityHeaderContext;
    const initialContext = noTenancyResolved ? await this.getInitialTenancyContext(sid) : void 0;
    const predefinedContext = predefinedTenancyId ? this.buildTenancyContextFromId(predefinedTenancyId, identitySessionMetadata.groups) : void 0;
    return (_b = (_a = predefinedContext != null ? predefinedContext : contextFromRequest) != null ? _a : identityHeaderContext) != null ? _b : initialContext;
  }
  async resolveTenancyContextFromRequest(req, sid) {
    const resolved = this.tenancyContextResolver.resolve(req);
    if (!resolved) return void 0;
    switch (resolved.kind) {
      case "FULL_TENANCY":
        return resolved;
      case "TENANCY_ID_ONLY":
      case "KIBANA_INDEX_ONLY": {
        const tenancies = await this.getAvailableTenanciesForUser(sid);
        return tenancies.length > 0 ? this.matchTenancyContextAgainstUserTenancies(resolved, tenancies, req.url) : resolved;
      }
      default: {
        throw new import_exhaustiveCheck.ExhaustiveCheck(resolved);
      }
    }
  }
  matchTenancyContextAgainstUserTenancies(partialTenancyContext, tenancies, url) {
    const matched = (0, import_tenancyMatcher.findMatchingTenancy)(tenancies, partialTenancyContext, { url });
    return matched ? (0, import_TenancyContext.tenancyFromId)(matched.group.id, matched.kibana.index) : void 0;
  }
  matchTenancyAgainstUserTenancies(tenancyContext, tenancies, url) {
    var _a, _b;
    const matched = (0, import_tenancyMatcher.findMatchingTenancy)(tenancies, tenancyContext, { url });
    if (!matched) {
      this.logger.debug(
        `No matching tenancy found for tenancyId "${(_a = tenancyContext.tenancyId) != null ? _a : null}" / kibanaIndex "${(_b = tenancyContext.kibanaIndex) != null ? _b : null}" for request url ${url}`
      );
    }
    return matched;
  }
  async getInitialTenancyContext(sid) {
    var _a;
    const availableTenancies = this.multiTenancyChecker.multiTenancyFeatureAvailable() ? await this.getAvailableTenanciesForUser(sid) : [];
    const firstTenancy = availableTenancies[0];
    return firstTenancy ? (0, import_TenancyContext.tenancyFromId)(firstTenancy.group.id, (_a = firstTenancy.kibana) == null ? void 0 : _a.index) : void 0;
  }
  resolveTenancyContextFromSessionHeaders(identitySessionMetadata, contextFromRequest) {
    if (contextFromRequest) return void 0;
    const tenancyId = identitySessionMetadata.identitySessionHeaders.get(import_types.X_ROR_TENANCY_ID);
    return tenancyId ? this.buildTenancyContextFromId(tenancyId, identitySessionMetadata.groups) : void 0;
  }
  buildTenancyContextFromId(tenancyId, tenancies) {
    const matchingTenancy = tenancies.find((g) => g.group.id === tenancyId);
    return (0, import_TenancyContext.tenancyFromId)(tenancyId, matchingTenancy == null ? void 0 : matchingTenancy.kibana.index);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TenancyService
});
