"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tenancyUrl_exports = {};
__export(tenancyUrl_exports, {
  addTenancyIfAbsent: () => addTenancyIfAbsent,
  stripTenancyFromUrl: () => stripTenancyFromUrl
});
module.exports = __toCommonJS(tenancyUrl_exports);
var import_queryStringKeys = require("../../../shared/constants/queryStringKeys");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const PLACEHOLDER_ORIGIN = "http://placeholder-origin";
const addTenancyIfAbsent = (url, tenancy, baseUrl = PLACEHOLDER_ORIGIN) => {
  try {
    const originalIsAbsolute = isAbsoluteUrl(url);
    const urlObject = new URL(url, baseUrl);
    if (typeof tenancy === "string" && tenancy.length > 0 && !urlObject.searchParams.has(import_queryStringKeys.TENANCY_QUERY_STRING_KEY)) {
      urlObject.searchParams.set(import_queryStringKeys.TENANCY_QUERY_STRING_KEY, tenancy);
      logger.trace("Added tenancy to URL", { original: url, result: urlObject.toString() });
    }
    return toRelativeOrAbsolute(urlObject, originalIsAbsolute);
  } catch (e) {
    logger.debug("Failed to add tenancy to URL, returning original", { url, err: e });
    return url;
  }
};
const stripTenancyFromUrl = (url, baseUrl) => {
  try {
    const originalIsAbsolute = isAbsoluteUrl(url);
    const urlObject = new URL(url, baseUrl);
    urlObject.searchParams.delete(import_queryStringKeys.TENANCY_QUERY_STRING_KEY);
    return toRelativeOrAbsolute(urlObject, originalIsAbsolute);
  } catch (e) {
    logger.debug("Failed to strip tenancy from URL", { url, err: e });
    return null;
  }
};
function isAbsoluteUrl(url) {
  return /^(https?:)?\/\//i.test(url);
}
function toRelativeOrAbsolute(urlObject, originalIsAbsolute) {
  return originalIsAbsolute ? urlObject.toString() : urlObject.pathname + urlObject.search + urlObject.hash;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  addTenancyIfAbsent,
  stripTenancyFromUrl
});
