"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var userMetadataResolver_exports = {};
__export(userMetadataResolver_exports, {
  UserMetadataResolver: () => UserMetadataResolver
});
module.exports = __toCommonJS(userMetadataResolver_exports);
var import_ActivationKey = require("../../../shared/types/ActivationKey");
class UserMetadataResolver {
  constructor(multiTenancyChecker, licenseService, defaultKibanaIndex, defaultKibanaTemplateIndex) {
    this.multiTenancyChecker = multiTenancyChecker;
    this.licenseService = licenseService;
    this.defaultKibanaIndex = defaultKibanaIndex;
    this.defaultKibanaTemplateIndex = defaultKibanaTemplateIndex;
    __publicField(this, "resolveSessionMetadata", (session) => {
      var _a, _b, _c, _d;
      const isEnt = (0, import_ActivationKey.isEnterpriseLicense)(this.licenseService.getActivationKey().license);
      const impersonatedBy = isEnt ? session.impersonatedBy : void 0;
      if (session.type === "USER_WITH_GROUPS") {
        return {
          ...session,
          impersonatedBy,
          groups: session.groups.map((group) => {
            var _a2, _b2, _c2, _d2;
            return {
              ...group,
              kibana: {
                ...group.kibana,
                index: this.resolveKibanaIndex((_a2 = group.kibana) == null ? void 0 : _a2.index),
                template_index: this.resolveKibanaTemplateIndex((_b2 = group.kibana) == null ? void 0 : _b2.template_index),
                hidden_apps: this.resolveHiddenApps((_c2 = group.kibana) == null ? void 0 : _c2.hidden_apps),
                metadata: this.resolveKibanaCustomMetadata((_d2 = group.kibana) == null ? void 0 : _d2.metadata)
              }
            };
          })
        };
      }
      return {
        ...session,
        impersonatedBy,
        kibana: {
          ...session.kibana,
          index: this.resolveKibanaIndex((_a = session.kibana) == null ? void 0 : _a.index),
          template_index: this.resolveKibanaTemplateIndex((_b = session.kibana) == null ? void 0 : _b.template_index),
          hidden_apps: this.resolveHiddenApps((_c = session.kibana) == null ? void 0 : _c.hidden_apps),
          metadata: this.resolveKibanaCustomMetadata((_d = session.kibana) == null ? void 0 : _d.metadata)
        }
      };
    });
  }
  resolveKibanaIndex(kibanaIndex) {
    return kibanaIndex && this.multiTenancyChecker.multiTenancyFeatureAvailable() ? kibanaIndex : this.defaultKibanaIndex;
  }
  resolveKibanaTemplateIndex(kibanaTemplateIndex) {
    return kibanaTemplateIndex && (0, import_ActivationKey.isEnterpriseLicense)(this.licenseService.getActivationKey().license) ? kibanaTemplateIndex : this.defaultKibanaTemplateIndex;
  }
  resolveHiddenApps(hiddenApps) {
    const license = this.licenseService.getActivationKey().license;
    return hiddenApps && ((0, import_ActivationKey.isPROLicense)(license) || (0, import_ActivationKey.isEnterpriseLicense)(license)) ? hiddenApps : void 0;
  }
  resolveKibanaCustomMetadata(metadata) {
    return metadata && (0, import_ActivationKey.isEnterpriseLicense)(this.licenseService.getActivationKey().license) ? metadata : void 0;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  UserMetadataResolver
});
