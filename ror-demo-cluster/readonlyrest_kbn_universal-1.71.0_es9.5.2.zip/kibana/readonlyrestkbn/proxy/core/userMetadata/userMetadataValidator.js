"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var userMetadataValidator_exports = {};
__export(userMetadataValidator_exports, {
  UserMetadataValidator: () => UserMetadataValidator
});
module.exports = __toCommonJS(userMetadataValidator_exports);
var import_xregexp = __toESM(require("xregexp"));
var import_accessLevel = require("../../../shared/types/accessLevel");
var import_ActivationKey = require("../../../shared/types/ActivationKey");
var import_hiddenAppsChecker = require("../../../shared/utils/hiddenAppsChecker");
var import_kibanaApiPath = require("../common/kibanaApiPath");
var import_rorLoggerFactory = require("../logging/rorLoggerFactory");
class UserMetadataValidator {
  constructor(multiTenancyChecker, licenseService, knownAppIdsProvider) {
    this.multiTenancyChecker = multiTenancyChecker;
    this.licenseService = licenseService;
    this.knownAppIdsProvider = knownAppIdsProvider;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  validate(data) {
    if (data.type === "USER_WITH_GROUPS") {
      if (!this.multiTenancyChecker.multiTenancyFeatureAvailable() && data.groups.length > 1) {
        this.logger.warn("There is more than one group available, however, the multi-tenancy feature is disabled.");
      }
      for (const { username, kibana, group } of data.groups) {
        if (!username) continue;
        this.validateKibanaMetadata(kibana, UserMetadataValidator.describeUserContext(username, group));
      }
    } else {
      if (!data.username) return;
      this.validateKibanaMetadata(data.kibana, UserMetadataValidator.describeUserContext(data.username));
    }
  }
  validateKibanaMetadata(kibana, userContext) {
    if (!kibana) return;
    const { access, allowed_api_paths, hidden_apps, index, template_index, metadata } = kibana;
    if (index) {
      this.validateKibanaIndex(index, userContext);
    }
    if (template_index) {
      this.validateKibanaTemplateIndex(template_index, userContext);
    }
    if (metadata && Object.keys(metadata).length) {
      this.validateKibanaCustomMetadata(userContext);
    }
    if (allowed_api_paths == null ? void 0 : allowed_api_paths.length) {
      this.validateAllowedApiPaths(allowed_api_paths, access, userContext);
    }
    if (hidden_apps == null ? void 0 : hidden_apps.length) {
      this.validateHiddenApps(hidden_apps, userContext);
    }
  }
  validateAllowedApiPaths(allowedApiPaths, access, userContext) {
    if (access !== import_accessLevel.AccessLevel.API_ONLY) {
      this.logger.warn(
        `${userContext} has allowedApiPaths configured but kibana_access is "${access}", not "api_only" \u2014 allowedApiPaths will be ignored.`
      );
    }
    this.validateAllowedApiPathEntries(allowedApiPaths, userContext);
  }
  validateHiddenApps(hiddenApps, userContext) {
    this.validateHiddenAppsLicense(userContext);
    this.validateHiddenAppsEntries(hiddenApps, userContext);
  }
  validateHiddenAppsLicense(userContext) {
    const license = this.licenseService.getActivationKey().license;
    if ((0, import_ActivationKey.isPROLicense)(license) || (0, import_ActivationKey.isEnterpriseLicense)(license)) return;
    this.logger.warn(
      `${userContext} has hiddenApps configured, but a PRO or Enterprise license is required \u2014 hiddenApps will be ignored.`
    );
  }
  validateKibanaCustomMetadata(userContext) {
    if ((0, import_ActivationKey.isEnterpriseLicense)(this.licenseService.getActivationKey().license)) return;
    this.logger.warn(
      `${userContext} has kibana.metadata configured, but an Enterprise license is required \u2014 kibana.metadata will be ignored.`
    );
  }
  validateKibanaIndex(index, userContext) {
    if (this.multiTenancyChecker.multiTenancyFeatureAvailable()) return;
    this.logger.warn(
      `${userContext} has kibana.index "${UserMetadataValidator.sanitize(
        index
      )}" configured, but the multi-tenancy feature is not available (requires an Enterprise license and multiTenancyEnabled config) \u2014 kibana.index will be ignored.`
    );
  }
  validateKibanaTemplateIndex(templateIndex, userContext) {
    if ((0, import_ActivationKey.isEnterpriseLicense)(this.licenseService.getActivationKey().license)) return;
    this.logger.warn(
      `${userContext} has kibana.template_index "${UserMetadataValidator.sanitize(
        templateIndex
      )}" configured, but an Enterprise license is required \u2014 kibana.template_index will be ignored.`
    );
  }
  validateAllowedApiPathEntries(allowedApiPaths, userContext) {
    for (const entry of allowedApiPaths) {
      const safePath = UserMetadataValidator.sanitize(entry.path_regex);
      if (!UserMetadataValidator.isValidRegex(entry.path_regex)) {
        this.logger.warn(
          `${userContext} has an allowedApiPaths entry with http_path "${safePath}" that is not a valid regular expression \u2014 it will be ignored.`
        );
      } else if (UserMetadataValidator.hasNonApiLeadingSegment(entry.path_regex)) {
        this.logger.warn(
          `${userContext} has an allowedApiPaths entry with http_path "${safePath}" that does not obviously target a Kibana /api/ or /internal/ path \u2014 verify it matches the intended API-only request paths.`
        );
      }
    }
  }
  validateHiddenAppsEntries(hiddenApps, userContext) {
    var _a;
    const knownAppIds = (_a = this.knownAppIdsProvider) == null ? void 0 : _a.call(this);
    for (const entry of hiddenApps) {
      const safeEntry = UserMetadataValidator.sanitize(entry);
      if (!UserMetadataValidator.isValidRegex(entry)) {
        this.logger.warn(
          `${userContext} has a hiddenApps entry "${safeEntry}" that is not a valid regular expression \u2014 it will be ignored.`
        );
      } else if (knownAppIds && !knownAppIds.some((appId) => (0, import_hiddenAppsChecker.hiddenAppsChecker)(entry, appId, this.logger))) {
        this.logger.warn(
          `${userContext} has a hiddenApps entry "${safeEntry}" that does not match any known Kibana app \u2014 it will have no effect.`
        );
      }
    }
  }
  static describeUserContext(username, group) {
    const safeUser = UserMetadataValidator.sanitize(username);
    if (!group) {
      return `User "${safeUser}"`;
    }
    return `User "${safeUser}" (group "${UserMetadataValidator.sanitize(group.name)}")`;
  }
  static isValidRegex(pathRegex) {
    try {
      import_xregexp.default.cache(pathRegex, "");
      return true;
    } catch {
      return false;
    }
  }
  static hasNonApiLeadingSegment(pathRegex) {
    const firstSegmentMatch = pathRegex.match(/^\^?\/([^/]+)/);
    if (!firstSegmentMatch) {
      return false;
    }
    const firstSegment = firstSegmentMatch[1];
    if (import_kibanaApiPath.KibanaApiPath.isApiLeadingSegment(firstSegment)) {
      return false;
    }
    return !/[()[\]{}?+*|\\.^$]/.test(firstSegment);
  }
  static sanitize(value) {
    return value.replace(/[\r\n]/g, " ");
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  UserMetadataValidator
});
