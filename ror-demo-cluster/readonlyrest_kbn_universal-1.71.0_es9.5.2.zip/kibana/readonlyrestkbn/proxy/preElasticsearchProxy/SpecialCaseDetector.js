"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var SpecialCaseDetector_exports = {};
__export(SpecialCaseDetector_exports, {
  SpecialCaseDetector: () => SpecialCaseDetector
});
module.exports = __toCommonJS(SpecialCaseDetector_exports);
var import_distributionInfoProvider = require("../../kibana/patchers/distributionInfoProvider");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
var import_RorMetadata = require("../core/RorMetadata");
const _SpecialCaseDetector = class _SpecialCaseDetector {
  // Reporting and other features make use of saved_objects API
  // if we manage to patch/wrap savedObjectClient we can get rid of this fallible
  // time-locality based hack in favour of a deterministic solution (mostRecentlyAccessedSession)!
  static shouldAttachMostRecentSessionKibanaIndex(originalUrl) {
    const { getTemporaryReportingIndex, getTemporaryStreamReportingIndex } = require("../core/reportingIndex");
    const temporaryStreamReportingIndex = getTemporaryStreamReportingIndex();
    const temporaryReportingIndex = getTemporaryReportingIndex();
    if (originalUrl.includes(temporaryReportingIndex) || originalUrl.includes(temporaryStreamReportingIndex)) {
      return "isReportingRequest";
    }
    if (originalUrl.match(/\b\/alert\b/gi)) {
      return "isAlertingRequest";
    }
    if (originalUrl.match(/\b\/action\b/gi)) {
      return "isActionRequest";
    }
    if (originalUrl.includes("_usage_counters")) {
      return "isUsageCounterRequest";
    }
    return null;
  }
  // Since 7.11.x some Kibana -> ES requests lack the kibana tech user authorization headers
  // This set of rules pinpoints those requests, while limiting the chance of potential breaches to a minimum
  static shouldAttachTechUserCredentialsWhenMissing(proxyRequestOptions) {
    var _a;
    if (proxyRequestOptions.path.includes("/_search") && proxyRequestOptions.method === "POST") {
      return "search in indexes";
    }
    const userAgent = (_a = proxyRequestOptions.headers["user-agent"]) == null ? void 0 : _a.toString();
    if (userAgent == null ? void 0 : userAgent.includes("elasticsearch-js")) {
      return "es client direct";
    }
    if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaNeverOrEqualTo("8.0.0") && import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("8.5.0") && (userAgent == null ? void 0 : userAgent.includes("elastic-transport-js"))) {
      return "elastic transport direct";
    }
    if (userAgent == null ? void 0 : userAgent.includes("Kibana")) {
      return "kibana client direct";
    }
    return null;
  }
  static shouldUseSystemCredentials(proxyRequestOptions) {
    return _SpecialCaseDetector.isTenantIndexInitRequest(proxyRequestOptions) || _SpecialCaseDetector.isApmOrFleetInitRequest(proxyRequestOptions) || _SpecialCaseDetector.isKibanaBulkWrite(proxyRequestOptions) || _SpecialCaseDetector.isCoreUsageStatsUpdate(proxyRequestOptions);
  }
  static isTenantIndexInitRequest(proxyRequestOptions) {
    var _a, _b, _c, _d, _e, _f;
    const userAgent = (_b = (_a = proxyRequestOptions.headers) == null ? void 0 : _a["user-agent"]) == null ? void 0 : _b.toString();
    return ((_c = proxyRequestOptions == null ? void 0 : proxyRequestOptions.method) == null ? void 0 : _c.toLowerCase()) === "put" && ((_e = (_d = proxyRequestOptions == null ? void 0 : proxyRequestOptions.path) == null ? void 0 : _d.includes("/_create/config")) != null ? _e : false) && ((_f = userAgent == null ? void 0 : userAgent.includes("Kibana")) != null ? _f : false);
  }
  static isApmOrFleetInitRequest(proxyRequestOptions) {
    var _a, _b, _c;
    const apmValidRoutes = [
      { url: "/_index_template/metrics", method: "PUT" },
      { url: "/_index_template/logs", method: "PUT" },
      { url: "/_index_template/.logs", method: "PUT" },
      // For Kibana 7.12.x
      { url: "/_transform/endpoint.metadata_current", method: "PUT" },
      // For Kibana 7.12.x
      { url: "/_transform/endpoint.metadata_current", method: "POST" },
      // For Kibana 7.12.x
      { url: "/_index_template/traces", method: "PUT" },
      { url: "/.fleet-enrollment-api-keys/_create", method: "PUT" }
      // For Kibana 7.14.x
    ];
    const rorMetadata = import_RorMetadata.RorMetadata.fromHeaders((_a = proxyRequestOptions.headers) != null ? _a : {});
    return apmValidRoutes.some(
      (route) => {
        var _a2, _b2;
        return ((_a2 = proxyRequestOptions == null ? void 0 : proxyRequestOptions.path) == null ? void 0 : _a2.includes(route.url)) && ((_b2 = proxyRequestOptions == null ? void 0 : proxyRequestOptions.method) == null ? void 0 : _b2.toLowerCase()) === route.method.toLowerCase();
      }
    ) && import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("8.0.0") && ((_c = (_b = rorMetadata == null ? void 0 : rorMetadata.getKibanaRequestPath()) == null ? void 0 : _b.includes("/api/fleet")) != null ? _c : false);
  }
  static isKibanaBulkWrite(proxyRequestOptions) {
    var _a, _b;
    const pathWithoutQuery = ((_a = proxyRequestOptions.path) != null ? _a : "").split("?")[0];
    if (!pathWithoutQuery.endsWith("/_bulk") || ((_b = proxyRequestOptions.method) == null ? void 0 : _b.toUpperCase()) !== "POST") {
      return false;
    }
    const { kibanaRequestPath, isWhitelisted } = _SpecialCaseDetector.getWhitelistedKibanaRequestPathCheck(proxyRequestOptions);
    if (!isWhitelisted && kibanaRequestPath) {
      _SpecialCaseDetector.logger.trace(
        `_bulk request with Kibana request path "${kibanaRequestPath}" is not whitelisted, tech user credentials won't be attached`
      );
    }
    return isWhitelisted;
  }
  static isCoreUsageStatsUpdate(proxyRequestOptions) {
    var _a, _b;
    if (((_a = proxyRequestOptions.method) == null ? void 0 : _a.toUpperCase()) !== "POST") {
      return false;
    }
    const path = (_b = proxyRequestOptions.path) != null ? _b : "";
    const isCoreUsageStatsPath = path.endsWith("_update/core-usage-stats%3Acore-usage-stats") || path.endsWith("_update/core-usage-stats:core-usage-stats");
    if (!isCoreUsageStatsPath) {
      return false;
    }
    const { kibanaRequestPath, isWhitelisted } = _SpecialCaseDetector.getWhitelistedKibanaRequestPathCheck(proxyRequestOptions);
    if (!isWhitelisted && kibanaRequestPath) {
      _SpecialCaseDetector.logger.trace(
        `core-usage-stats update with Kibana request path "${kibanaRequestPath}" is not whitelisted, tech user credentials won't be attached`
      );
    }
    return isWhitelisted;
  }
  static getWhitelistedKibanaRequestPathCheck(proxyRequestOptions) {
    var _a, _b;
    const whitelistedKibanaRequestPaths = [
      "api/canvas/workpad/resolve",
      "internal/canvas/workpad/resolve",
      "api/saved_objects/_bulk_resolve",
      "api/timelion/run",
      "internal/timelion/run",
      //  >= Kibana 9.x (Timelion moved from api/ to internal/)
      "api/metrics/vis/data",
      "internal/metrics/vis/data",
      //  >= Kibana 9.x (TSVB moved from api/ to internal/)
      "api/lens/existing_fields",
      "api/lens/stats",
      "internal/lens/visualizations",
      //  >= Kibana 9.x (Lens viz from library, LENS_INTERNAL_VIS_API_PATH)
      "api/content_management/rpc/get",
      "api/dashboards",
      "internal/dashboards/app",
      //  >= Kibana 9.4.0,
      "internal/reporting/generate/csv_searchsource"
    ];
    const rorMetadata = import_RorMetadata.RorMetadata.fromHeaders((_a = proxyRequestOptions.headers) != null ? _a : {});
    const kibanaRequestPath = (_b = rorMetadata == null ? void 0 : rorMetadata.getKibanaRequestPath()) != null ? _b : "";
    const isWhitelisted = whitelistedKibanaRequestPaths.some((path) => kibanaRequestPath.includes(path));
    return { kibanaRequestPath, isWhitelisted };
  }
};
__publicField(_SpecialCaseDetector, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let SpecialCaseDetector = _SpecialCaseDetector;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SpecialCaseDetector
});
