"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var kibanaIndexTweaker_exports = {};
__export(kibanaIndexTweaker_exports, {
  KibanaIndexTweaker: () => KibanaIndexTweaker
});
module.exports = __toCommonJS(kibanaIndexTweaker_exports);
const _KibanaIndexTweaker = class _KibanaIndexTweaker {
  static replaceSubstringIfNotAlreadyPresent(original, substringToBeReplaced, replacement) {
    if (original.includes(replacement)) {
      return original;
    }
    return original.split(substringToBeReplaced).join(replacement);
  }
};
__publicField(_KibanaIndexTweaker, "normalizeKibanaIndex", (input, kibanaIndex) => {
  if (!input.includes(kibanaIndex)) {
    return input;
  }
  const escapedKibanaIndexForRegex = kibanaIndex.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const longFormatMatcher = new RegExp(
    `${escapedKibanaIndexForRegex}_((\\d){1,2}).((\\d){1,2})\\.(\\d){1,2}_(\\d){3}`,
    "gm"
  );
  const shortFormatMatcher = new RegExp(`${escapedKibanaIndexForRegex}_((\\d){1,2}).((\\d){1,2})\\.(\\d){1,2}`, "gm");
  const taskManagerIndexMatcher = new RegExp(
    `${escapedKibanaIndexForRegex}_task_manager_((\\d){1,2}).((\\d){1,2})\\.(\\d){1,2}`,
    "gm"
  );
  if (new RegExp(taskManagerIndexMatcher).test(input)) {
    return input.replace(shortFormatMatcher, kibanaIndex).replace(taskManagerIndexMatcher, `${kibanaIndex}_task_manager`);
  }
  if (new RegExp(longFormatMatcher).test(input)) {
    return input.replace(longFormatMatcher, kibanaIndex);
  }
  if (new RegExp(shortFormatMatcher).test(input)) {
    return input.replace(shortFormatMatcher, kibanaIndex);
  }
  return input;
});
__publicField(_KibanaIndexTweaker, "replaceKibanaIndexWithTenantIndexAndNormalize", (baseString, kibanaIndexFromSession, kibanaIndex) => {
  const {
    getTemporaryReportingIndex,
    getFinalReportingIndex,
    getTemporaryStreamReportingIndex,
    getFinalStreamReportingIndex
    // eslint-disable-next-line @typescript-eslint/no-var-requires,global-require
  } = require("../core/reportingIndex");
  const temporaryReportingIndex = getTemporaryReportingIndex();
  const temporaryStreamReportingIndex = getTemporaryStreamReportingIndex();
  const finalReportingIndex = getFinalReportingIndex();
  const finalStreamReportingIndex = getFinalStreamReportingIndex();
  const baseStringWithReplacedKibanaIndex = baseString.includes(temporaryStreamReportingIndex) ? baseString : _KibanaIndexTweaker.replaceSubstringIfNotAlreadyPresent(baseString, kibanaIndex, kibanaIndexFromSession);
  const withReplacedReporting = _KibanaIndexTweaker.replaceSubstringIfNotAlreadyPresent(
    baseStringWithReplacedKibanaIndex,
    temporaryReportingIndex,
    `${finalReportingIndex}${kibanaIndexFromSession}`
  );
  const withReplacedStreamReporting = _KibanaIndexTweaker.replaceSubstringIfNotAlreadyPresent(
    withReplacedReporting,
    temporaryStreamReportingIndex,
    `${finalStreamReportingIndex}-${kibanaIndexFromSession}`
  );
  return _KibanaIndexTweaker.normalizeKibanaIndex(withReplacedStreamReporting, kibanaIndexFromSession);
});
let KibanaIndexTweaker = _KibanaIndexTweaker;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KibanaIndexTweaker
});
