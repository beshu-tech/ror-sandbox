"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var preElasticsearchProxy_exports = {};
__export(preElasticsearchProxy_exports, {
  PreElasticsearchProxy: () => PreElasticsearchProxy
});
module.exports = __toCommonJS(preElasticsearchProxy_exports);
var import_cookie_parser = __toESM(require("cookie-parser"));
var import_express = __toESM(require("express"));
var import_express_http_proxy = __toESM(require("express-http-proxy"));
var import_morgan = __toESM(require("morgan"));
var import_tcp_port_used = __toESM(require("tcp-port-used"));
var import_distributionInfoProvider = require("../../kibana/patchers/distributionInfoProvider");
var import_proxyRequestHeaders = require("../core/common/proxyRequestHeaders");
var import_types = require("../core/common/types");
var import_esSSLConnectionProvider = require("../core/esSSLConnectionProvider");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
var import_requestInterceptor = require("./requestInterceptor");
var import_SpecialCaseDetector = require("./SpecialCaseDetector");
class PreElasticsearchProxy {
  constructor(sessionManagerProvider, rorRequestAppender, esHostBalancer, esSSLConnectionProvider, params, identitySessionHeadersValidation, multiTenancyChecker, tenancyService) {
    this.rorRequestAppender = rorRequestAppender;
    this.esHostBalancer = esHostBalancer;
    this.esSSLConnectionProvider = esSSLConnectionProvider;
    __publicField(this, "app");
    __publicField(this, "server");
    __publicField(this, "interceptor");
    __publicField(this, "networkParameters");
    __publicField(this, "kibanaTechUserEsAuthToken");
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "requestHeadersWhitelist");
    __publicField(this, "identitySessionHeadersValidation");
    __publicField(this, "getElasticsearchUrl", () => this.esHostBalancer.getElasticsearchUrl());
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    __publicField(this, "proxyErrorHandler", (error, res, next) => {
      if ((error == null ? void 0 : error.code) === "ECONNREFUSED") {
        res.status(503).send(`Elasticsearch host ${this.getElasticsearchUrl()} is unavailable`);
        return;
      }
      next(error);
    });
    __publicField(this, "proxyReqOptDecorator", async (proxyRequestOptions, sourceRequest) => {
      if (!proxyRequestOptions.headers) {
        proxyRequestOptions.headers = {};
      }
      const headers = proxyRequestOptions.headers;
      (0, import_proxyRequestHeaders.prepareProxyRequestHeaders)(this.logger, this.requestHeadersWhitelist, sourceRequest.headers, headers);
      const userRequestIdentity = await sourceRequest.rorRequest.getUserRequestIdentity();
      if (userRequestIdentity == null ? void 0 : userRequestIdentity.metadata.correlationId) {
        headers[import_types.X_ROR_CORRELATION_ID] = userRequestIdentity.metadata.correlationId;
      }
      this.resolveCredentials(proxyRequestOptions, sourceRequest);
      this.applySSLConfig(proxyRequestOptions);
      delete headers.cookie;
      return proxyRequestOptions;
    });
    this.app = (0, import_express.default)();
    this.interceptor = new import_requestInterceptor.RequestInterceptor(
      sessionManagerProvider,
      params.kibanaIndex,
      multiTenancyChecker,
      tenancyService
    );
    this.esHostBalancer = esHostBalancer;
    this.kibanaTechUserEsAuthToken = params.kibanaTechUserEsAuthToken;
    this.networkParameters = params.networkParameters;
    this.requestHeadersWhitelist = params.requestHeadersWhitelist;
    this.identitySessionHeadersValidation = identitySessionHeadersValidation;
    this.init(params.pepPort);
  }
  close() {
    var _a, _b;
    (_a = this.server) == null ? void 0 : _a.removeAllListeners();
    (_b = this.server) == null ? void 0 : _b.close();
  }
  init(proxyPort) {
    this.app.use((0, import_cookie_parser.default)());
    this.app.disable("x-powered-by");
    this.app.use((req, res, next) => {
      res.on("finish", async () => {
        if (res.statusCode === 401 || res.statusCode === 403) {
          await this.identitySessionHeadersValidation.revalidate(req);
        }
      });
      next();
    });
    this.app.use(this.rorRequestAppender.appendRorRequest);
    this.initDevInterceptors();
    this.app.use((0, import_express_http_proxy.default)(this.getElasticsearchUrl, this.getProxyOptions()));
    this.launchProxyServer(proxyPort);
  }
  initDevInterceptors() {
    if (import_distributionInfoProvider.DistributionInfoProvider.isEnvironmentDev()) {
      this.app.use((0, import_morgan.default)("PEP :method :url :status :response-time ms - :res[content-length]"));
    }
  }
  getProxyOptions() {
    return {
      https: false,
      timeout: this.networkParameters.requestTimeout,
      preserveHostHdr: false,
      // RORDEV-463 - avoid ERR_TLS_CERT_ALTNAME_INVALID when elasticsearch.ssl.verificationMode: full
      parseReqBody: true,
      limit: "500gb",
      memoizeHost: false,
      proxyReqOptDecorator: this.proxyReqOptDecorator,
      proxyReqPathResolver: async (req) => this.interceptor.replaceIdxInPath(req.rorRequest),
      proxyReqBodyDecorator: (body, req) => this.interceptor.replaceIdxInBody(body, req.rorRequest),
      userResDecorator: this.interceptor.userResDecorator,
      proxyErrorHandler: this.proxyErrorHandler
    };
  }
  resolveCredentials(proxyRequestOptions, sourceRequest) {
    if (!proxyRequestOptions.headers) return;
    const headers = proxyRequestOptions.headers;
    this.forwardIncomingAuthorization(headers, sourceRequest);
    this.applyTechUserCredentialsIfNeeded(headers, proxyRequestOptions);
  }
  forwardIncomingAuthorization(headers, sourceRequest) {
    if (sourceRequest.headers.authorization) {
      headers.authorization = sourceRequest.headers.authorization;
    }
  }
  applyTechUserCredentialsIfNeeded(headers, proxyRequestOptions) {
    if (import_SpecialCaseDetector.SpecialCaseDetector.shouldUseSystemCredentials(proxyRequestOptions)) {
      headers.authorization = this.kibanaTechUserEsAuthToken;
      return;
    }
    if (!headers.authorization) {
      const reason = import_SpecialCaseDetector.SpecialCaseDetector.shouldAttachTechUserCredentialsWhenMissing(proxyRequestOptions);
      if (reason) {
        this.logger.trace(
          `No auth headers found: attaching tech user creds for "${reason}" request: ${proxyRequestOptions.method} ${proxyRequestOptions.path}`
        );
        headers.authorization = this.kibanaTechUserEsAuthToken;
      }
    }
  }
  applySSLConfig(proxyRequestOptions) {
    const certType = this.esSSLConnectionProvider.getCertificationType();
    if (certType === import_esSSLConnectionProvider.SSLCertificationType.PEM) {
      proxyRequestOptions.ca = this.esSSLConnectionProvider.getCertificateAuthorities();
    } else if (certType === import_esSSLConnectionProvider.SSLCertificationType.PKC12) {
      proxyRequestOptions.pfx = this.esSSLConnectionProvider.getTruststore().truststore;
      proxyRequestOptions.passphrase = this.esSSLConnectionProvider.getTruststore().password;
    }
    proxyRequestOptions.rejectUnauthorized = this.esSSLConnectionProvider.isVerificationEnabled();
  }
  launchProxyServer(port) {
    const host = "127.0.0.1";
    import_tcp_port_used.default.check(port, host).then(async (inUse) => {
      if (!inUse) {
        this.logger.info(`Pre-Elasticsearch-proxy will listen on ${host}:${port}`);
        this.server = await this.app.listen(port, host);
      }
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PreElasticsearchProxy
});
