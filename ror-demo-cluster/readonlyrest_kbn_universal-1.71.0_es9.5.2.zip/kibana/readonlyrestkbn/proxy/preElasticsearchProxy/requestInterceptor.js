"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var requestInterceptor_exports = {};
__export(requestInterceptor_exports, {
  RequestInterceptor: () => RequestInterceptor
});
module.exports = __toCommonJS(requestInterceptor_exports);
var import_errors = __toESM(require("../constants/errors"));
var import_types = require("../core/common/types");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
var import_RorMetadata = require("../core/RorMetadata");
var import_rorUserSettings = require("../core/rorUserSettings");
var import_kibanaIndexTweaker = require("./kibanaIndexTweaker");
var import_SpecialCaseDetector = require("./SpecialCaseDetector");
class RequestInterceptor {
  constructor(sessionManagerProvider, kibanaIndex, multiTenancyChecker, tenancyService) {
    this.sessionManagerProvider = sessionManagerProvider;
    this.kibanaIndex = kibanaIndex;
    this.multiTenancyChecker = multiTenancyChecker;
    this.tenancyService = tenancyService;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "DUMMY_ORIGIN", "http://dummy-origin");
    __publicField(this, "userResDecorator", (_, proxyResData, userReq, userRes) => {
      var _a, _b;
      const anySpaceConfigRegexp = /(.*\/[^/]*\.\.\/|.*\/_doc\/[^/]*config%3A.*)/;
      if (userReq.method === "GET" && anySpaceConfigRegexp.test(userReq.url)) {
        const parsedData = proxyResData.length > 0 ? JSON.parse(proxyResData.toString()) : proxyResData;
        if (parsedData.found) {
          const userSettings = import_rorUserSettings.RorUserSettings.getSettings(userReq.cookies);
          this.logger.debug("ReadonlyREST user settings from rorUserSettings cookies:", userSettings);
          return import_rorUserSettings.RorUserSettings.parseSettingsToBuffer(
            import_rorUserSettings.RorUserSettings.mixRorSettingsWithKibanaSettings(userSettings, parsedData)
          );
        }
      }
      if (userRes.statusCode === 404) {
        const parsedData = proxyResData.length > 0 ? JSON.parse(proxyResData.toString()) : proxyResData;
        if ((_b = (_a = parsedData == null ? void 0 : parsedData.error) == null ? void 0 : _a.root_cause) == null ? void 0 : _b.some((rootCause) => rootCause.type === "no_such_remote_cluster_exception")) {
          userRes.statusCode = 200;
          this.logger.warn(proxyResData.toString());
        }
      }
      return proxyResData;
    });
    __publicField(this, "whitelistedSource", (kibanaRequestPath, esRequestUrl) => {
      const whitelistedUrls = [
        "/_mapping?expand_wildcards=none",
        "/_settings",
        "/_security/user/_has_privileges",
        "_reindex",
        "_index_template"
      ];
      const indexManagementKibanaRequestPath = ["/internal/index_management", "/api/index_management"];
      const discoverKibanaRequestPath = [
        "/internal/search/ese",
        // For Kibana 9.x.x
        "/internal/data_views/fields",
        "/internal/bsearch"
        // For Kibana 7.x and 8.x
      ];
      const devToolsKibanaRequestPath = ["/api/console/proxy"];
      return this.whitelistedSourceCheck({
        esRequestUrl,
        kibanaRequestPath,
        whitelistedUrls,
        kibanaRequestWhitelistedPathsSettings: {
          whitelistedPathsFromKibanaUi: [
            indexManagementKibanaRequestPath,
            discoverKibanaRequestPath,
            devToolsKibanaRequestPath
          ],
          forceIndexOverrideForEsRequestPaths: ["/_doc/config", "/_doc/search-session"]
        }
      });
    });
    __publicField(this, "whitelistedSourceCheck", ({
      kibanaRequestPath,
      esRequestUrl,
      whitelistedUrls,
      kibanaRequestWhitelistedPathsSettings: { whitelistedPathsFromKibanaUi, forceIndexOverrideForEsRequestPaths }
    }) => {
      const esRequestPathNeedOverride = forceIndexOverrideForEsRequestPaths.some(
        (forceIndexOverrideForEsRequestPath) => esRequestUrl.includes(forceIndexOverrideForEsRequestPath)
      );
      const requestFromKibanaIsWhitelisted = kibanaRequestPath ? whitelistedPathsFromKibanaUi.some(
        (whitelistedPathFromKibanaUi) => whitelistedPathFromKibanaUi.some((path) => kibanaRequestPath.includes(path))
      ) : false;
      if (requestFromKibanaIsWhitelisted && !esRequestPathNeedOverride) {
        return { ok: true, source: { source: "whitelistedUrl", kibanaIndex: void 0 } };
      }
      const esRequestPathIsWhitelisted = whitelistedUrls.some((whitelistedUrl) => esRequestUrl.includes(whitelistedUrl));
      if (esRequestPathIsWhitelisted) {
        return { ok: true, source: { source: "whitelistedUrl", kibanaIndex: void 0 } };
      }
      return { ok: false, reason: "skipped" };
    });
  }
  async replaceIdxInPath(request) {
    const { source, kibanaIndex } = await this.getKibanaIndexForReplacement(request);
    switch (source) {
      case "kibanaIndexFromSession":
      case "kibanaIndexFromMetadata":
      case "kibanaIndexFromMostRecentlyAccessedSession":
      case "kibanaIndexFromHeaders": {
        return import_kibanaIndexTweaker.KibanaIndexTweaker.replaceKibanaIndexWithTenantIndexAndNormalize(
          request.getUrl(),
          kibanaIndex,
          this.kibanaIndex
        );
      }
      case "kibanaIndexFromQuery": {
        const url = new URL(`${this.DUMMY_ORIGIN}${request.getUrl()}`);
        url.searchParams.delete(import_types.X_ROR_KIBANA_INDEX);
        return import_kibanaIndexTweaker.KibanaIndexTweaker.replaceKibanaIndexWithTenantIndexAndNormalize(
          `${url.pathname}${url.search}`,
          kibanaIndex,
          this.kibanaIndex
        );
      }
      case "PreElasticsearchProxyParams": {
        return import_kibanaIndexTweaker.KibanaIndexTweaker.normalizeKibanaIndex(request.getUrl(), kibanaIndex);
      }
      case "whitelistedUrl":
      case "noKibanaIndexToReplace": {
        return request.getUrl();
      }
      default: {
        throw new Error(import_errors.default.wrongTypeOfIndicesSource);
      }
    }
  }
  async replaceIdxInBody(bodyContent, request) {
    const { source, kibanaIndex } = await this.getKibanaIndexForReplacement(request);
    switch (source) {
      case "kibanaIndexFromSession":
      case "kibanaIndexFromMetadata":
      case "kibanaIndexFromQuery":
      case "kibanaIndexFromMostRecentlyAccessedSession":
      case "kibanaIndexFromHeaders": {
        return Buffer.from(
          import_kibanaIndexTweaker.KibanaIndexTweaker.replaceKibanaIndexWithTenantIndexAndNormalize(
            bodyContent.toString(),
            kibanaIndex,
            this.kibanaIndex
          )
        );
      }
      case "PreElasticsearchProxyParams": {
        return Buffer.from(import_kibanaIndexTweaker.KibanaIndexTweaker.normalizeKibanaIndex(bodyContent.toString(), kibanaIndex));
      }
      case "whitelistedUrl":
      case "noKibanaIndexToReplace": {
        return bodyContent;
      }
      default: {
        throw new Error(import_errors.default.wrongTypeOfIndicesSource);
      }
    }
  }
  async getKibanaIndexForReplacement(rorRequest) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    const kibanaIndexFromSession = (_a = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata) == null ? void 0 : _a.kibanaIndex;
    const rorMetadata = import_RorMetadata.RorMetadata.fromHeaders(rorRequest.getHeaders());
    const kibanaRequestPath = rorMetadata == null ? void 0 : rorMetadata.getKibanaRequestPath();
    const whitelistedSource = this.whitelistedSource(kibanaRequestPath, rorRequest.getUrl());
    if (whitelistedSource.ok) {
      return whitelistedSource.source;
    }
    if (kibanaIndexFromSession && this.multiTenancyChecker.multiTenancyFeatureAvailable()) {
      return { source: "kibanaIndexFromSession", kibanaIndex: kibanaIndexFromSession };
    }
    if (userRequestIdentity == null ? void 0 : userRequestIdentity.metadata) {
      return { source: "PreElasticsearchProxyParams", kibanaIndex: this.kibanaIndex };
    }
    const reason = import_SpecialCaseDetector.SpecialCaseDetector.shouldAttachMostRecentSessionKibanaIndex(rorRequest.getUrl());
    if (reason) {
      if (reason === "isReportingRequest") {
        const url = new URL(`${this.DUMMY_ORIGIN}${rorRequest.getUrl()}`);
        const params = new URLSearchParams(url.search);
        const kibanaIndexFromQuery = params.get(import_types.X_ROR_KIBANA_INDEX);
        if (kibanaIndexFromQuery) {
          return {
            source: "kibanaIndexFromQuery",
            kibanaIndex: kibanaIndexFromQuery
          };
        }
        const kibanaIndexFromHeaders = (_b = rorRequest.getHeaders()) == null ? void 0 : _b[import_types.X_ROR_KIBANA_INDEX];
        if (kibanaIndexFromHeaders) {
          return {
            source: "kibanaIndexFromHeaders",
            kibanaIndex: kibanaIndexFromHeaders
          };
        }
      }
      const tenancyId = await rorRequest.getTenancyId(userRequestIdentity == null ? void 0 : userRequestIdentity.sid);
      const mostRecentlyAccessed = this.sessionManagerProvider.get().getMostRecentlyAccessed();
      const mostRecentlyAccessedMetadata = mostRecentlyAccessed == null ? void 0 : mostRecentlyAccessed.metadata;
      const resolvedTenancyId = tenancyId != null ? tenancyId : (mostRecentlyAccessed == null ? void 0 : mostRecentlyAccessed.sid) ? this.tenancyService.getLastUsedTenancyId(mostRecentlyAccessed.sid) : void 0;
      const kibanaIndexFromMostRecentlyAccessedSession = (mostRecentlyAccessedMetadata == null ? void 0 : mostRecentlyAccessedMetadata.type) === "USER_WITH_GROUPS" ? (_i = (_e = (_d = (_c = mostRecentlyAccessedMetadata == null ? void 0 : mostRecentlyAccessedMetadata.groups) == null ? void 0 : _c.find(({ group }) => group.id === resolvedTenancyId)) == null ? void 0 : _d.kibana) == null ? void 0 : _e.index) != null ? _i : (_h = (_g = (_f = mostRecentlyAccessedMetadata == null ? void 0 : mostRecentlyAccessedMetadata.groups) == null ? void 0 : _f[0]) == null ? void 0 : _g.kibana) == null ? void 0 : _h.index : (_j = mostRecentlyAccessedMetadata == null ? void 0 : mostRecentlyAccessedMetadata.kibana) == null ? void 0 : _j.index;
      if (kibanaIndexFromMostRecentlyAccessedSession) {
        return {
          source: "kibanaIndexFromMostRecentlyAccessedSession",
          kibanaIndex: kibanaIndexFromMostRecentlyAccessedSession
        };
      }
      this.logger.trace(`Could not access most recently accessed session's kibanaIndex for ${reason}`);
      return { source: "noKibanaIndexToReplace", kibanaIndex: void 0 };
    }
    if (rorMetadata == null ? void 0 : rorMetadata.getKibanaIndex()) {
      const kibanaIndexFromMetadata = rorMetadata.getKibanaIndex();
      if (kibanaIndexFromMetadata) {
        return {
          source: "kibanaIndexFromMetadata",
          kibanaIndex: kibanaIndexFromMetadata
        };
      }
    }
    return { source: "noKibanaIndexToReplace", kibanaIndex: void 0 };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RequestInterceptor
});
