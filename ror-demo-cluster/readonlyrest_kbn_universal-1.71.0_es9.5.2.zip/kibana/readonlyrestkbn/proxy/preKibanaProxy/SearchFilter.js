"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var SearchFilter_exports = {};
__export(SearchFilter_exports, {
  SearchFilter: () => SearchFilter
});
module.exports = __toCommonJS(SearchFilter_exports);
var import_json_stable_stringify = __toESM(require("json-stable-stringify"));
var import_hiddenAppsChecker = require("../../shared/utils/hiddenAppsChecker");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
const _SearchFilter = class _SearchFilter {
  static filterCustomIntegrations(searchResults, hiddenApps) {
    if (hiddenApps.some((hiddenApp) => (0, import_hiddenAppsChecker.hiddenAppsChecker)(hiddenApp, "Management|Integrations", _SearchFilter.logger))) {
      return [];
    }
    return searchResults;
  }
  static filterGlobalSearchResults(searchResults, hiddenApps) {
    return searchResults.filter(
      (searchResult) => hiddenApps.every((hiddenApp) => {
        if (searchResult.type === "Index") {
          const indexBasedApps = ["Search|Content", "Elasticsearch|Content"];
          return !indexBasedApps.some(
            (indexBasedApp) => (0, import_hiddenAppsChecker.hiddenAppsChecker)(hiddenApp, indexBasedApp, _SearchFilter.logger)
          );
        }
        return !(0, import_hiddenAppsChecker.hiddenAppsChecker)(hiddenApp, searchResult.type, _SearchFilter.logger);
      })
    );
  }
  static toBuffer(data) {
    return Buffer.from((0, import_json_stable_stringify.default)(data, { space: "  " }));
  }
};
__publicField(_SearchFilter, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let SearchFilter = _SearchFilter;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SearchFilter
});
