"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var impersonateController_exports = {};
__export(impersonateController_exports, {
  ImpersonateController: () => ImpersonateController
});
module.exports = __toCommonJS(impersonateController_exports);
var import_responseHandler = require("../../../core/api/responseHandler");
class ImpersonateController {
  constructor(authenticationFacade) {
    this.authenticationFacade = authenticationFacade;
    __publicField(this, "handleImpersonateUser", async (req, res) => {
      const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
      const userRequestIdentityMetadata = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata;
      if (!this.sufficientAccessLevel(userRequestIdentityMetadata == null ? void 0 : userRequestIdentityMetadata.kibanaAccess)) {
        return import_responseHandler.ResponseHandler.notSufficientAccessLevel(res);
      }
      await this.authenticationFacade.impersonateUser(req.rorRequest, res, userRequestIdentity);
    });
    __publicField(this, "handleFinishImpersonation", async (req, res) => {
      try {
        const identitySession = await this.authenticationFacade.finishImpersonation(req.rorRequest, res);
        const newUserRequestIdentity = await req.rorRequest.getUserRequestIdentity({
          sid: identitySession.sid,
          predefinedTenancyId: identitySession.metadata.type === "USER_WITH_GROUPS" ? identitySession.metadata.groups[0].group.id : void 0
        });
        return import_responseHandler.ResponseHandler.success(res, {
          message: "ok",
          status: "SUCCESS",
          statusCode: 200,
          redirectUrl: await this.authenticationFacade.buildRedirectUrlForImpersonation(newUserRequestIdentity.metadata)
        });
      } catch (e) {
        import_responseHandler.ResponseHandler.serverError(res, { error: "Failure", status: "ERROR", message: e.message, statusCode: 500 });
      }
    });
  }
  sufficientAccessLevel(accessLevel) {
    return accessLevel === "unrestricted" || accessLevel === "admin";
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ImpersonateController
});
