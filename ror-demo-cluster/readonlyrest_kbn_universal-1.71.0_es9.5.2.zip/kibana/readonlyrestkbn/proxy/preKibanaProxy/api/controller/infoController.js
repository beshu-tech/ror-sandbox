"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var infoController_exports = {};
__export(infoController_exports, {
  InfoController: () => InfoController
});
module.exports = __toCommonJS(infoController_exports);
var import_distributionInfoProvider = require("../../../../kibana/patchers/distributionInfoProvider");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
class InfoController {
  constructor(licenseService, logoutLinkProvider, rorSettingsStore) {
    this.licenseService = licenseService;
    this.logoutLinkProvider = logoutLinkProvider;
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  async handleGet(rorRequest, res) {
    var _a;
    try {
      const userRequestIdentity = await rorRequest.getUserRequestIdentity();
      const metadata = userRequestIdentity.metadata;
      const identity = {
        username: metadata.username,
        kibanaHiddenApps: (_a = metadata.kibanaHiddenApps) != null ? _a : [],
        correlationId: metadata.correlationId,
        kibanaAccess: metadata.kibanaAccess,
        impersonatedBy: metadata.impersonatedBy,
        currentGroup: metadata.currentGroup,
        availableGroups: metadata.availableGroups
      };
      const rorSettings = this.rorSettingsStore.getLatestRorKbnSettings();
      this.logger.trace("returning identity metadata:", identity);
      return res.json({
        identity,
        licenseInfo: this.licenseService.getLicenseInfo(),
        distribution: import_distributionInfoProvider.DistributionInfoProvider.getInstance().toJsonObject(),
        cluster_uuid: this.licenseService.getClusterUUID(),
        config: {
          clearSessionOnEvents: rorSettings.clearSessionOnEvents,
          logoutLink: this.logoutLinkProvider.resolveLogoutLink(metadata)
        }
      });
    } catch (error) {
      this.logger.error({
        message: `Failed to handle info request: ${error instanceof Error ? error.message : String(error)}`,
        stack: error instanceof Error ? error.stack : void 0
      });
      return res.status(500).json({
        status_code: 500,
        status: "error",
        message: "Failed to retrieve identity information"
      });
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  InfoController
});
