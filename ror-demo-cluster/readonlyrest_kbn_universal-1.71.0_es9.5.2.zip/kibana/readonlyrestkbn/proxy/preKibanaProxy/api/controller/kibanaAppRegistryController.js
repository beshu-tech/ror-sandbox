"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var kibanaAppRegistryController_exports = {};
__export(kibanaAppRegistryController_exports, {
  KibanaAppRegistryController: () => KibanaAppRegistryController
});
module.exports = __toCommonJS(kibanaAppRegistryController_exports);
var import_responseHandler = require("../../../core/api/responseHandler");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_kibanaAppsRegistry = require("../../kibana_apps/kibanaAppsRegistry");
class KibanaAppRegistryController {
  constructor() {
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  async handleGetHiddenApps(req, res) {
    this.logger.trace("Handling hidden apps GET request");
    const hiddenAppNames = await req.extractHiddenAppsNames();
    return import_responseHandler.ResponseHandler.success(res, {
      message: "ok",
      statusCode: 200,
      status: "SUCCESS",
      hiddenApps: import_kibanaAppsRegistry.KibanaAppsRegistry.getPathsOfAppsToHide(hiddenAppNames)
    });
  }
  async handleGetAllApps(req, res) {
    this.logger.trace("Handling all registry apps GET request");
    return import_responseHandler.ResponseHandler.success(res, {
      message: "ok",
      statusCode: 200,
      status: "SUCCESS",
      allAppsFromRegistry: import_kibanaAppsRegistry.KibanaAppsRegistry.allAppsFromRegistry
    });
  }
  async handlePost(req, res) {
    try {
      this.logger.trace(`Received app registry payload of length ${req.body.length}`);
      import_kibanaAppsRegistry.KibanaAppsRegistry.enrichRegistry(req.body);
      return import_responseHandler.ResponseHandler.success(res, {
        message: "ok",
        statusCode: 200,
        status: "SUCCESS"
      });
    } catch (e) {
      this.logger.error({
        message: `Error enriching kibana app registry from request: ${e.name}: ${e.message}`,
        stack: e.stack
      });
      return import_responseHandler.ResponseHandler.serverError(res, {
        error: "Failure",
        status: "ERROR",
        message: e.message,
        statusCode: 500
      });
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KibanaAppRegistryController
});
