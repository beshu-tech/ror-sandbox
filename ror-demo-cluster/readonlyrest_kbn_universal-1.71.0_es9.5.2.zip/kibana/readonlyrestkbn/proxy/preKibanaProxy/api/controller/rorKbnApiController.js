"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorKbnApiController_exports = {};
__export(rorKbnApiController_exports, {
  RorKbnApiController: () => RorKbnApiController,
  isSuccessInResponse: () => isSuccessInResponse
});
module.exports = __toCommonJS(rorKbnApiController_exports);
var import_lodash = require("lodash");
var import_errors = __toESM(require("../../../constants/errors"));
var import_responseHandler = require("../../../core/api/responseHandler");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_RawRorSettingsParser = require("../../../core/rorSettings/rawRorSettingsParser/RawRorSettingsParser");
var import_RorSettingsManager = require("../../../core/rorSettings/RorSettingsManager");
function isErrorInResponse(value) {
  if (!("error" in value)) throw new Error("Response body has no error response defined");
}
function isSuccessInResponse(value) {
  if (!("status" in value)) throw new Error("Response body has no success response defined");
}
class RorKbnApiController {
  constructor(licenseService, rorSettingsStore) {
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "licenseService");
    this.licenseService = licenseService;
  }
  async handlePostSettings(rorRequest, res) {
    try {
      const parseToRawRorKbnAndEsSettingsResult = (0, import_RawRorSettingsParser.parseToRawRorKbnAndEsSettings)(rorRequest.getBody());
      if (!parseToRawRorKbnAndEsSettingsResult.ok) {
        return import_responseHandler.ResponseHandler.success(res, {
          statusCode: 200,
          status: "FAILURE",
          message: parseToRawRorKbnAndEsSettingsResult.error
        });
      }
      const saveResult = await (0, import_RorSettingsManager.getRorSettingsManager)().saveSettings({
        parsedToRawRorKbnAndEsSettings: parseToRawRorKbnAndEsSettingsResult.data,
        correlationId: await rorRequest.getCorrelationId(),
        identityHeaders: await rorRequest.getIdentitySessionHeaders(),
        whitelistedHeaders: await rorRequest.getWhitelistedHeaders()
      });
      if (!saveResult.ok) {
        return import_responseHandler.ResponseHandler.success(res, {
          statusCode: 200,
          status: "FAILURE",
          message: saveResult.error
        });
      }
      return this.postEsResponseHandling(res, saveResult.data);
    } catch (e) {
      res.status(500);
      this.logger.error({
        message: `Error handle post configuration request: ${e.name}: ${e.message}`,
        stack: e.stack
      });
      return res.json({ message: import_errors.default.internalServerError, status: "INTERNAL_SERVER_ERROR" });
    }
  }
  async handleUploadConfiguration(request, res, settings) {
    try {
      const rorRequest = request.rorRequest;
      const parseToRawRorKbnAndEsSettingsResult = (0, import_RawRorSettingsParser.parseToRawRorKbnAndEsSettings)(settings);
      if (!parseToRawRorKbnAndEsSettingsResult.ok) {
        return import_responseHandler.ResponseHandler.success(res, {
          statusCode: 200,
          status: "FAILURE",
          message: parseToRawRorKbnAndEsSettingsResult.error
        });
      }
      const saveResult = await (0, import_RorSettingsManager.getRorSettingsManager)().saveSettings({
        parsedToRawRorKbnAndEsSettings: parseToRawRorKbnAndEsSettingsResult.data,
        correlationId: await rorRequest.getCorrelationId(),
        identityHeaders: await rorRequest.getIdentitySessionHeaders(),
        whitelistedHeaders: await rorRequest.getWhitelistedHeaders()
      });
      if (!saveResult.ok) {
        return import_responseHandler.ResponseHandler.success(res, {
          statusCode: 200,
          status: "FAILURE",
          message: saveResult.error
        });
      }
      return this.postEsResponseHandling(res, saveResult.data);
    } catch (e) {
      res.status(500);
      this.logger.error({
        message: `Error handle upload configuration request: ${e.name}: ${e.message}`,
        stack: e.stack
      });
      return res.json({ message: import_errors.default.internalServerError, status: "INTERNAL_SERVER_ERROR" });
    }
  }
  async handleAddLicenseKey(req, res, onSuccess) {
    this.logger.info(
      "Received add activation key request. Local cluster_uuid is: ",
      this.licenseService.getClusterUUID()
    );
    const license = req.body.license;
    if (!license) {
      this.logger.error({ message: "Called add activation key, but no license received: " }, req.body);
      res.status(400);
      return res.json({ status: "NO_LICENSE_KEY_PROVIDED", message: import_errors.default.activationKey.noLicenseKeyProvided });
    }
    try {
      const existing = this.licenseService.getActivationKey();
      if (!existing || existing && req.query.overwrite) {
        const {
          cookieSettings: { password: storeEncryptionKey }
        } = this.rorSettingsStore.getLatestRorKbnSettings();
        this.logger.info(`Adding activation key ${license.substring(0, 10)}...`);
        const info = await this.licenseService.saveToken(license, storeEncryptionKey);
        this.logger.info(`Found valid activation key: ID=${info.jti}`);
        onSuccess(existing ? existing.license.edition !== info.license.edition : false);
        return import_responseHandler.ResponseHandler.success(res, {
          statusCode: 200,
          status: "SUCCESS",
          message: "ok",
          license: info
        });
      }
      this.logger.info("Activation key already exists, but overwrite not requested");
      return import_responseHandler.ResponseHandler.success(res, {
        statusCode: 200,
        status: "UNMODIFIED",
        message: import_errors.default.activationKey.unmodified,
        license: existing
      });
    } catch (e) {
      this.logger.error({ message: `Failed to add activation key ${e.name}: ${e.message}`, stack: e.stack });
      const reason = ["LICENSE_KEY_EXPIRED", "LICENSE_KEY_MALFORMED"];
      if (reason.includes(e.name)) {
        res.status(400);
        return res.json({ status: e.name, message: e.message });
      }
      res.status(500);
      return res.json({ status: "INTERNAL_SERVER_ERROR", message: import_errors.default.internalServerError });
    }
  }
  async handleGetUserTenants(request, res) {
    try {
      const userRequestIdentity = await request.rorRequest.getUserRequestIdentity();
      return import_responseHandler.ResponseHandler.success(res, {
        message: "ok",
        statusCode: 200,
        status: "SUCCESS",
        tenants: userRequestIdentity.metadata.availableGroups
      });
    } catch (e) {
      res.status(500);
      this.logger.error({
        message: `Error handle get user's tenants request: ${e.name}: ${e.message}`,
        stack: e.stack
      });
      return res.json({ message: import_errors.default.internalServerError, status: "INTERNAL_SERVER_ERROR" });
    }
  }
  postEsResponseHandling(res, esResponse) {
    switch (esResponse.status) {
      case 200: {
        isSuccessInResponse(esResponse.body);
        switch (esResponse.body.status) {
          case "ok": {
            return import_responseHandler.ResponseHandler.success(res, {
              statusCode: 200,
              status: "SUCCESS",
              message: "ok"
            });
          }
          case "ko": {
            return import_responseHandler.ResponseHandler.success(res, {
              statusCode: 200,
              status: "FAILURE",
              message: esResponse.body.message
            });
          }
          default: {
            this.logger.warn("Cannot reload new settings:", JSON.stringify(esResponse.body));
            return import_responseHandler.ResponseHandler.success(res, {
              statusCode: 200,
              status: "FAILURE",
              message: import_errors.default.cannotReloadNewSettings
            });
          }
        }
      }
      case 403: {
        isErrorInResponse(esResponse.body);
        const causeToMessageMap = {
          FORBIDDEN_BY_BLOCK: import_errors.default.forbidByBlockWithForbidTypeMatch,
          OPERATION_NOT_ALLOWED: import_errors.default.noAclBlockWasMatched,
          READONLYREST_NOT_READY_YET: import_errors.default.readonlyRestWasNotStarted,
          READONLYREST_FAILED_TO_START: import_errors.default.readonlyRestFailedToStart
        };
        const due_to = esResponse.body.error.due_to;
        const combinedMessage = import_responseHandler.ResponseHandler.combineForbiddenErrors(due_to, causeToMessageMap);
        if (combinedMessage) {
          return import_responseHandler.ResponseHandler.forbidden(res, combinedMessage);
        }
        this.logger.warn(`Error status ${due_to} is not handled:`, JSON.stringify(esResponse.body));
        return import_responseHandler.ResponseHandler.forbidden(res, import_errors.default.operationNotAllowed);
      }
      default: {
        this.logger.warn(
          `Post configuration Http status is not handled: status: ${esResponse.statusMessage} message: ${esResponse.statusMessage} body: ${(0, import_lodash.isObject)(esResponse.body) ? JSON.stringify(esResponse.body) : esResponse.body}`
        );
        return import_responseHandler.ResponseHandler.serverError(res, {
          error: "Failure",
          statusCode: 500,
          message: import_errors.default.internalServerError,
          status: "ERROR"
        });
      }
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorKbnApiController,
  isSuccessInResponse
});
