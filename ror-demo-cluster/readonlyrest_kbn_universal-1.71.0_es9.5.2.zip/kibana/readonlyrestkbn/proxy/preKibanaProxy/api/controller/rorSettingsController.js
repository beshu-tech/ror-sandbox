"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorSettingsController_exports = {};
__export(rorSettingsController_exports, {
  RorSettingsController: () => RorSettingsController
});
module.exports = __toCommonJS(rorSettingsController_exports);
var import_errors = __toESM(require("../../../constants/errors"));
var import_correlationIdWrapper = require("../../../core/api/correlationIdWrapper");
var import_responseHandler = require("../../../core/api/responseHandler");
var import_exhaustiveCheck = require("../../../core/common/exhaustiveCheck");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_RawRorSettingsParser = require("../../../core/rorSettings/rawRorSettingsParser/RawRorSettingsParser");
var import_RorSettingsManager = require("../../../core/rorSettings/RorSettingsManager");
class RorSettingsController {
  constructor(authController, authenticationFacade, rorEsApiClientWithAuthProvider) {
    this.authController = authController;
    this.authenticationFacade = authenticationFacade;
    this.rorEsApiClientWithAuthProvider = rorEsApiClientWithAuthProvider;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  async getSettings(request, res) {
    const esResponse = await (0, import_RorSettingsManager.getRorSettingsManager)().getMainSettingsFromIndex({
      identityHeaders: await request.getIdentitySessionHeaders(),
      whitelistedHeaders: await request.getWhitelistedHeaders(),
      correlationId: await request.getCorrelationId()
    });
    const status = esResponse.body.status;
    switch (status) {
      case "ok": {
        const stringRorSettings = esResponse.body.message;
        const parseToRawRorKbnAndEsSettingsOrRawEsSettingsResult = (0, import_RawRorSettingsParser.parseToRawRorKbnAndEsSettingsOrRawEsSettings)(stringRorSettings);
        if (!parseToRawRorKbnAndEsSettingsOrRawEsSettingsResult.ok) {
          return import_responseHandler.ResponseHandler.success(res, {
            statusCode: 200,
            status: "FAILURE",
            message: parseToRawRorKbnAndEsSettingsOrRawEsSettingsResult.error
          });
        }
        return import_responseHandler.ResponseHandler.success(res, {
          message: "ok",
          status: "SUCCESS",
          statusCode: 200,
          settings: parseToRawRorKbnAndEsSettingsOrRawEsSettingsResult.data.raw
        });
      }
      case "ko": {
        return import_responseHandler.ResponseHandler.success(res, {
          statusCode: 200,
          status: "FAILURE",
          message: esResponse.body.message
        });
      }
      case "empty": {
        return import_responseHandler.ResponseHandler.success(res, {
          statusCode: 200,
          status: "EMPTY",
          message: esResponse.body.message
        });
      }
      case 403: {
        const causeToMessageMap = {
          OPERATION_NOT_ALLOWED: import_errors.default.noAclBlockWasMatched,
          FORBIDDEN_BY_BLOCK: import_errors.default.forbidByBlockWithForbidTypeMatch,
          TEST_SETTINGS_NOT_CONFIGURED: import_errors.default.testSettingsAreNotConfigured,
          IMPERSONATION_NOT_ALLOWED: import_errors.default.impersonationNotAllowed,
          IMPERSONATION_NOT_SUPPORTED: import_errors.default.impersonationNotSupported,
          READONLYREST_NOT_READY_YET: import_errors.default.readonlyRestWasNotStarted,
          READONLYREST_FAILED_TO_START: import_errors.default.readonlyRestFailedToStart
        };
        const due_to = esResponse.body.error.due_to;
        const combinedMessage = import_responseHandler.ResponseHandler.combineForbiddenErrors(due_to, causeToMessageMap);
        if (combinedMessage) {
          return import_responseHandler.ResponseHandler.forbidden(res, combinedMessage);
        }
        return import_responseHandler.ResponseHandler.forbidden(res, import_errors.default.operationNotAllowed);
      }
      default: {
        throw new import_exhaustiveCheck.ExhaustiveCheck(status);
      }
    }
  }
  async fetchCurrentAuditConfiguration(request, res) {
    const esResponse = await this.getAsScopedUserRestRorEsApiClient(await request.getIdentitySessionHeaders()).withCorrelationIdHeader(await request.getCorrelationId()).fetchCurrentAuditConfiguration({
      identitySessionHeaders: await request.getIdentitySessionHeaders(),
      whitelistedHeaders: await request.getWhitelistedHeaders()
    });
    return import_responseHandler.ResponseHandler.mapEsResponse(res, esResponse);
  }
  async readRorKbnAndEsSettingsFromFile(rorRequest, res) {
    try {
      const mainSettingFromFileResult = await (0, import_RorSettingsManager.getRorSettingsManager)().getMainSettingsFromFile({
        identityHeaders: await rorRequest.getIdentitySessionHeaders(),
        whitelistedHeaders: await rorRequest.getWhitelistedHeaders(),
        correlationId: await rorRequest.getCorrelationId()
      });
      if (mainSettingFromFileResult.ok) {
        return import_responseHandler.ResponseHandler.success(res, {
          message: "ok",
          status: "SUCCESS",
          statusCode: 200,
          settings: mainSettingFromFileResult.data.raw
        });
      }
      if (!mainSettingFromFileResult.ok && "error" in mainSettingFromFileResult) {
        return import_responseHandler.ResponseHandler.success(res, {
          statusCode: 200,
          status: "FAILURE",
          message: mainSettingFromFileResult.error
        });
      }
      const esResponse = mainSettingFromFileResult.esFailureResponse;
      const status = esResponse.status;
      switch (status) {
        case "ko": {
          return import_responseHandler.ResponseHandler.success(res, {
            statusCode: 200,
            status: "FAILURE",
            message: esResponse.message
          });
        }
        case "empty": {
          return import_responseHandler.ResponseHandler.success(res, {
            statusCode: 200,
            status: "EMPTY",
            message: esResponse.message
          });
        }
        case 403: {
          const causeToMessageMap = {
            OPERATION_NOT_ALLOWED: import_errors.default.noAclBlockWasMatched,
            FORBIDDEN_BY_BLOCK: import_errors.default.forbidByBlockWithForbidTypeMatch,
            TEST_SETTINGS_NOT_CONFIGURED: import_errors.default.testSettingsAreNotConfigured,
            IMPERSONATION_NOT_ALLOWED: import_errors.default.impersonationNotAllowed,
            IMPERSONATION_NOT_SUPPORTED: import_errors.default.impersonationNotSupported,
            READONLYREST_NOT_READY_YET: import_errors.default.readonlyRestWasNotStarted,
            READONLYREST_FAILED_TO_START: import_errors.default.readonlyRestFailedToStart
          };
          const due_to = esResponse.error.due_to;
          const combinedMessage = import_responseHandler.ResponseHandler.combineForbiddenErrors(due_to, causeToMessageMap);
          if (combinedMessage) {
            return import_responseHandler.ResponseHandler.forbidden(res, combinedMessage);
          }
          return import_responseHandler.ResponseHandler.forbidden(res, import_errors.default.operationNotAllowed);
        }
        default: {
          throw new import_exhaustiveCheck.ExhaustiveCheck(status);
        }
      }
    } catch (e) {
      this.logger.error({
        message: `Error during loading ReadonlyREST settings from readonlyrest.yml file: ${e.name}: ${e.message}`,
        stack: e.stack
      });
      return import_responseHandler.ResponseHandler.unhandledServerError(res);
    }
  }
  async updateSettings(request, res) {
    const rorRequest = request.rorRequest;
    const stringSettings = rorRequest.getBody().settings;
    const parseToRawRorKbnAndEsSettingsResult = (0, import_RawRorSettingsParser.parseToRawRorKbnAndEsSettings)(stringSettings);
    if (!parseToRawRorKbnAndEsSettingsResult.ok) {
      return import_responseHandler.ResponseHandler.success(res, {
        statusCode: 200,
        status: "FAILURE",
        message: parseToRawRorKbnAndEsSettingsResult.error
      });
    }
    const esResponse = await (0, import_RorSettingsManager.getRorSettingsManager)().saveSettings({
      parsedToRawRorKbnAndEsSettings: parseToRawRorKbnAndEsSettingsResult.data,
      correlationId: await rorRequest.getCorrelationId(),
      identityHeaders: await rorRequest.getIdentitySessionHeaders(),
      whitelistedHeaders: await rorRequest.getWhitelistedHeaders()
    });
    if (!esResponse.ok) {
      return import_responseHandler.ResponseHandler.success(res, {
        statusCode: 200,
        status: "FAILURE",
        message: esResponse.error
      });
    }
    try {
      const response = await this.authenticationFacade.verifyCurrentUser(request);
      if (response.status === "ERROR") {
        await this.authController.handleLogout(request, res);
        return res;
      }
      return import_responseHandler.ResponseHandler.mapEsResponse(res, esResponse.data);
    } catch {
      await this.authController.handleLogout(request, res);
      return res;
    }
  }
  getAsScopedUserRestRorEsApiClient(identitySessionHeaders) {
    return new import_correlationIdWrapper.CorrelationIdWrapper(this.rorEsApiClientWithAuthProvider.asScoped(identitySessionHeaders));
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorSettingsController
});
