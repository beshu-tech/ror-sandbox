"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var testController_exports = {};
__export(testController_exports, {
  TestController: () => TestController
});
module.exports = __toCommonJS(testController_exports);
var import_correlationIdWrapper = require("../../../core/api/correlationIdWrapper");
var import_responseHandler = require("../../../core/api/responseHandler");
class TestController {
  constructor(rorEsApiClientWithAuthProvider) {
    this.rorEsApiClientWithAuthProvider = rorEsApiClientWithAuthProvider;
  }
  getAsScopedUserRestRorEsApiClient(identitySessionHeaders) {
    return new import_correlationIdWrapper.CorrelationIdWrapper(this.rorEsApiClientWithAuthProvider.asScoped(identitySessionHeaders));
  }
  async handleGetTestSettings(rorRequest, res) {
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    const identityMetadata = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata;
    if (!this.sufficientAccessLevel(identityMetadata == null ? void 0 : identityMetadata.kibanaAccess)) {
      return import_responseHandler.ResponseHandler.notSufficientAccessLevel(res);
    }
    const esResponse = await this.getAsScopedUserRestRorEsApiClient(await rorRequest.getIdentitySessionHeaders()).withCorrelationIdHeader(await rorRequest.getCorrelationId()).getTestSettings({
      identitySessionHeaders: await rorRequest.getIdentitySessionHeaders(),
      whitelistedHeaders: await rorRequest.getWhitelistedHeaders()
    });
    return import_responseHandler.ResponseHandler.mapEsResponse(res, esResponse);
  }
  async handlePostTestSettings(rorRequest, res) {
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    const identityMetadata = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata;
    if (!this.sufficientAccessLevel(identityMetadata == null ? void 0 : identityMetadata.kibanaAccess)) {
      return import_responseHandler.ResponseHandler.notSufficientAccessLevel(res);
    }
    const esResponse = await this.getAsScopedUserRestRorEsApiClient(await rorRequest.getIdentitySessionHeaders()).withCorrelationIdHeader(await rorRequest.getCorrelationId()).postTestSettings({
      requestBody: rorRequest.getBody(),
      identitySessionHeaders: await rorRequest.getIdentitySessionHeaders(),
      whitelistedHeaders: await rorRequest.getWhitelistedHeaders()
    });
    return import_responseHandler.ResponseHandler.mapEsResponse(res, esResponse);
  }
  async handleDeleteTestSettings(rorRequest, res) {
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    const identityMetadata = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata;
    if (!this.sufficientAccessLevel(identityMetadata == null ? void 0 : identityMetadata.kibanaAccess)) {
      return import_responseHandler.ResponseHandler.notSufficientAccessLevel(res);
    }
    const esResponse = await this.getAsScopedUserRestRorEsApiClient(await rorRequest.getIdentitySessionHeaders()).withCorrelationIdHeader(await rorRequest.getCorrelationId()).deleteTestSettings({
      identitySessionHeaders: await rorRequest.getIdentitySessionHeaders(),
      whitelistedHeaders: await rorRequest.getWhitelistedHeaders()
    });
    return import_responseHandler.ResponseHandler.mapEsResponse(res, esResponse);
  }
  async handleGetAuthMock(rorRequest, res) {
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    const identityMetadata = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata;
    if (!this.sufficientAccessLevel(identityMetadata == null ? void 0 : identityMetadata.kibanaAccess)) {
      return import_responseHandler.ResponseHandler.notSufficientAccessLevel(res);
    }
    const esResponse = await this.getAsScopedUserRestRorEsApiClient(await rorRequest.getIdentitySessionHeaders()).withCorrelationIdHeader(await rorRequest.getCorrelationId()).getAuthMock({
      identitySessionHeaders: await rorRequest.getIdentitySessionHeaders(),
      whitelistedHeaders: await rorRequest.getWhitelistedHeaders()
    });
    return import_responseHandler.ResponseHandler.mapEsResponse(res, esResponse);
  }
  async handlePostAuthMock(rorRequest, res) {
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    const identityMetadata = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata;
    if (!this.sufficientAccessLevel(identityMetadata == null ? void 0 : identityMetadata.kibanaAccess)) {
      return import_responseHandler.ResponseHandler.notSufficientAccessLevel(res);
    }
    const esResponse = await this.getAsScopedUserRestRorEsApiClient(await rorRequest.getIdentitySessionHeaders()).withCorrelationIdHeader(await rorRequest.getCorrelationId()).postAuthMock({
      requestBody: rorRequest.getBody(),
      identitySessionHeaders: await rorRequest.getIdentitySessionHeaders(),
      whitelistedHeaders: await rorRequest.getWhitelistedHeaders()
    });
    return import_responseHandler.ResponseHandler.mapEsResponse(res, esResponse);
  }
  async handleGetLocalUsers(rorRequest, res) {
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    const identityMetadata = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata;
    if (!this.sufficientAccessLevel(identityMetadata == null ? void 0 : identityMetadata.kibanaAccess)) {
      return import_responseHandler.ResponseHandler.notSufficientAccessLevel(res);
    }
    const esResponse = await this.getAsScopedUserRestRorEsApiClient(await rorRequest.getIdentitySessionHeaders()).withCorrelationIdHeader(await rorRequest.getCorrelationId()).getLocalUsers({
      identitySessionHeaders: await rorRequest.getIdentitySessionHeaders(),
      whitelistedHeaders: await rorRequest.getWhitelistedHeaders()
    });
    return import_responseHandler.ResponseHandler.mapEsResponse(res, esResponse);
  }
  sufficientAccessLevel(accessLevel) {
    return accessLevel === "unrestricted" || accessLevel === "admin";
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TestController
});
