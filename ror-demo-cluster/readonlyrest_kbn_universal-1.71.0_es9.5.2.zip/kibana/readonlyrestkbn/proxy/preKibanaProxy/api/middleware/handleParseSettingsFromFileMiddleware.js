"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var handleParseSettingsFromFileMiddleware_exports = {};
__export(handleParseSettingsFromFileMiddleware_exports, {
  getFileSizeInMB: () => getFileSizeInMB,
  handleParseSettingsFromFileMiddleware: () => handleParseSettingsFromFileMiddleware
});
module.exports = __toCommonJS(handleParseSettingsFromFileMiddleware_exports);
var import_path = __toESM(require("path"));
var import_fs_extra = __toESM(require("fs-extra"));
var import_multiparty = __toESM(require("multiparty"));
var import_errors = __toESM(require("../../../constants/errors"));
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
const getLogger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const fileToString = (file) => new Promise((resolve, reject) => {
  import_fs_extra.default.readFile(file.path, (err, data) => {
    if (err) return reject(err);
    resolve(data.toString());
  });
});
const getFileSizeInMB = (sizeInBytes) => {
  const fileSizeInKB = sizeInBytes / 1024;
  return fileSizeInKB / 1024;
};
async function handleParseSettingsFromFileMiddleware(request, res, next) {
  try {
    const form = new import_multiparty.default.Form();
    form.parse(request, async (err, fields, files) => {
      var _a;
      try {
        if (err) {
          throw err;
        }
        if (!((_a = files == null ? void 0 : files.file) == null ? void 0 : _a[0])) {
          res.status(400);
          return res.json({
            message: import_errors.default.fileIsRequiredField,
            status: "NO_FILE_FIELD_PROVIDED"
          });
        }
        const file = files.file[0];
        const acceptedExtensions = [".yml", ".yaml"];
        const fileExtension = import_path.default.extname(file.originalFilename);
        if (!acceptedExtensions.some((acceptedExtension) => acceptedExtension === fileExtension)) {
          res.status(400);
          return res.json({
            message: import_errors.default.fileExtensionOnlyYmlSupported,
            status: "WRONG_FILE_EXTENSION"
          });
        }
        if (getFileSizeInMB(file.size) > 10) {
          res.status(413);
          return res.json({
            message: import_errors.default.fileSizeExceeds("10MB"),
            status: "FILE_SIZE_EXCEEDS"
          });
        }
        res.locals.rawRorKbnSettings = await fileToString(file);
        return next();
      } catch (e) {
        res.status(500);
        getLogger().error({
          message: `Error handle upload configuration request: ${e.name}: ${e.message}`,
          stack: e.stack
        });
        return res.json({ message: import_errors.default.internalServerError, status: "INTERNAL_SERVER_ERROR" });
      }
    });
  } catch (e) {
    res.status(500);
    getLogger().error({
      message: `Error handle upload configuration request: ${e.name}: ${e.message}`,
      stack: e.stack
    });
    return res.json({ message: import_errors.default.internalServerError, status: "INTERNAL_SERVER_ERROR" });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getFileSizeInMB,
  handleParseSettingsFromFileMiddleware
});
