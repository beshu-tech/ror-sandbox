"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var requireSettingsOverrideMiddleware_exports = {};
__export(requireSettingsOverrideMiddleware_exports, {
  requireSettingsOverrideMiddleware: () => requireSettingsOverrideMiddleware
});
module.exports = __toCommonJS(requireSettingsOverrideMiddleware_exports);
var import_responseHandler = require("../../../core/api/responseHandler");
function requireSettingsOverrideMiddleware(req, res, next) {
  if (req.query.override !== "true") {
    import_responseHandler.ResponseHandler.clientError(res, {
      error: "Failure",
      status: "CONFIRMATION_REQUIRED",
      statusCode: 409,
      message: "Changing settings may invalidate all active user sessions, forcing users to re-login. Retry with ?override=true to confirm."
    });
    return;
  }
  next();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  requireSettingsOverrideMiddleware
});
