"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var validateRorSettingsSyntaxMiddleware_exports = {};
__export(validateRorSettingsSyntaxMiddleware_exports, {
  validateRorSettingsSyntaxMiddleware: () => validateRorSettingsSyntaxMiddleware
});
module.exports = __toCommonJS(validateRorSettingsSyntaxMiddleware_exports);
var import_errors = __toESM(require("../../../constants/errors"));
var import_responseHandler = require("../../../core/api/responseHandler");
var import_versionedLibraries = require("../../../core/common/versionedLibraries");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_RawRorSettingsValidators = require("../../../core/rorSettings/rawRorSettingsParser/RawRorSettingsValidators");
const getLogger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
const validateRorSettingsSyntaxMiddleware = (data, path, res, next) => {
  var _a;
  try {
    let newSettings;
    try {
      newSettings = import_versionedLibraries.yaml.parseDocument(data);
    } catch (e) {
      return import_responseHandler.ResponseHandler.clientError(res, {
        status: "SYNTAX_VALIDATION_ERROR",
        statusCode: 400,
        error: "Failure",
        message: `YAML syntax error: ${e.message}`
      });
    }
    if (newSettings.errors.length > 0) {
      const [firstErrorMessage] = newSettings.errors[0].message.split(" at line ");
      return import_responseHandler.ResponseHandler.clientError(res, {
        status: "SYNTAX_VALIDATION_ERROR",
        statusCode: 400,
        error: "Failure",
        message: `YAML syntax error: ${firstErrorMessage}`
      });
    }
    if (!((_a = newSettings.toJSON()) == null ? void 0 : _a.readonlyrest_kbn)) {
      getLogger().warn(
        import_errors.default.rorSettingsManager.deprecatedSettingsWarnings.readonlyrest_kbnSettingsNotAvailableInAPostRequest(path)
      );
      return next();
    }
    const validationResult = new import_RawRorSettingsValidators.RorKbnSchemaValidator().validate(newSettings);
    if (validationResult.ok) {
      return next();
    }
    return import_responseHandler.ResponseHandler.clientError(res, {
      status: "SYNTAX_VALIDATION_ERROR",
      message: validationResult.error,
      error: "Failure",
      statusCode: 400
    });
  } catch (e) {
    getLogger().error({ message: `Internal server error: ${e.message}` });
    return import_responseHandler.ResponseHandler.unhandledServerError(res);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  validateRorSettingsSyntaxMiddleware
});
