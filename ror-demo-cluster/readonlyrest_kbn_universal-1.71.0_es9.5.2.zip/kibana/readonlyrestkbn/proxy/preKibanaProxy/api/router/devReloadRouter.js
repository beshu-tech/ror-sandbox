"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var devReloadRouter_exports = {};
__export(devReloadRouter_exports, {
  buildDevReloadRouter: () => buildDevReloadRouter
});
module.exports = __toCommonJS(devReloadRouter_exports);
var import_express = __toESM(require("express"));
const LOOPBACK_ADDRESSES = /* @__PURE__ */ new Set(["127.0.0.1", "::1", "::ffff:127.0.0.1"]);
function buildDevReloadRouter(eventStream) {
  const router = import_express.default.Router();
  router.get("/events", (req, res) => {
    eventStream.connect(req, res);
  });
  router.post("/", (req, res) => {
    if (!req.socket.remoteAddress || !LOOPBACK_ADDRESSES.has(req.socket.remoteAddress)) {
      res.sendStatus(403);
      return;
    }
    eventStream.notifyReload();
    res.sendStatus(204);
  });
  router.post("/complete", (req, res) => {
    if (!req.socket.remoteAddress || !LOOPBACK_ADDRESSES.has(req.socket.remoteAddress)) {
      res.sendStatus(403);
      return;
    }
    eventStream.notifyReloadCompleted();
    res.sendStatus(204);
  });
  return router;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildDevReloadRouter
});
