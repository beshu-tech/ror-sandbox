"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var pkpApiRouter_exports = {};
__export(pkpApiRouter_exports, {
  buildPkpApiRouter: () => buildPkpApiRouter
});
module.exports = __toCommonJS(pkpApiRouter_exports);
var express = __toESM(require("express"));
var import_accessLevel = require("../../../../shared/types/accessLevel");
var import_errors = __toESM(require("../../../constants/errors"));
var import_requestUtils = require("../../../core/api/requestUtils");
var import_kibanaConfigController = require("../../../core/kibanaConfig/kibanaConfigController");
var import_LicenseController = require("../../../core/license/LicenseController");
var import_impersonateController = require("../controller/impersonateController");
var import_infoController = require("../controller/infoController");
var import_kibanaAppRegistryController = require("../controller/kibanaAppRegistryController");
var import_testController = require("../controller/testController");
var import_settingsRouter = require("./settingsRouter");
var import_testRouter = require("./testRouter");
function buildPkpApiRouter(rorEsApiClientWithAuthProvider, authenticationFacade, licenseService, authController, kibanaPort, logoutLinkProvider, rorSettingsStore) {
  const router = express.Router();
  const infoController = new import_infoController.InfoController(licenseService, logoutLinkProvider, rorSettingsStore);
  const kibanaAppRegistryController = new import_kibanaAppRegistryController.KibanaAppRegistryController();
  const testController = new import_testController.TestController(rorEsApiClientWithAuthProvider);
  const impersonateController = new import_impersonateController.ImpersonateController(authenticationFacade);
  const licenseController = new import_LicenseController.LicenseController(licenseService, rorSettingsStore);
  const kibanaConfigController = new import_kibanaConfigController.KibanaConfigController();
  router.get("/info", async (req, res) => infoController.handleGet(req.rorRequest, res));
  router.get(
    "/kbn_app_registry/hidden",
    async (req, res) => kibanaAppRegistryController.handleGetHiddenApps(req.rorRequest, res)
  );
  router.get(
    "/kbn_app_registry",
    async (req, res) => kibanaAppRegistryController.handleGetAllApps(req.rorRequest, res)
  );
  router.use(
    "/kbn_app_registry",
    async (req, res) => kibanaAppRegistryController.handlePost(req, res)
  );
  router.use(
    "/settings",
    (0, import_settingsRouter.buildSettingsRouter)(licenseService, authController, authenticationFacade, rorEsApiClientWithAuthProvider)
  );
  router.use("/test", (0, import_testRouter.buildTestRouter)(testController));
  router.post("/impersonate-user", impersonateController.handleImpersonateUser);
  router.post("/finish-impersonation", impersonateController.handleFinishImpersonation);
  router.get(
    "/license",
    (req, res, next) => authController.verifyAccessLevel(req, res, next, [import_accessLevel.AccessLevel.UNRESTRICTED, import_accessLevel.AccessLevel.ADMIN]),
    licenseController.handleGet.bind(licenseController)
  );
  router.post(
    "/license",
    (req, res, next) => authController.verifyAccessLevel(req, res, next, [import_accessLevel.AccessLevel.UNRESTRICTED, import_accessLevel.AccessLevel.ADMIN]),
    (req, res) => licenseController.handleAdd.bind(licenseController)(req, res, (isLicenseEditionChanged) => {
      if (isLicenseEditionChanged) {
        authenticationFacade.deleteAllSessions();
      }
    })
  );
  router.delete(
    "/license",
    (req, res, next) => authController.verifyAccessLevel(req, res, next, [import_accessLevel.AccessLevel.UNRESTRICTED, import_accessLevel.AccessLevel.ADMIN]),
    (req, res) => licenseController.handleDelete.bind(licenseController)(req, res, (isLicenseEditionChanged) => {
      if (isLicenseEditionChanged) {
        authenticationFacade.deleteAllSessions();
      }
    })
  );
  router.get("/license/cluster_uuid", licenseController.handleGetClusterUUID.bind(licenseController));
  router.post(
    "/kibanaConfig",
    (req, res, next) => licenseService.enterpriseLicenseRequired(res, next, import_errors.default.updateSettingsViaApiEnterpriseOnly),
    (req, res, next) => import_requestUtils.RequestUtils.verifyMediaType(req, res, next, ["application/yaml"]),
    (req, res, next) => import_requestUtils.RequestUtils.validateYamlRequest(req, res, next)(req.body),
    async (req, res) => kibanaConfigController.handleUpdateKibanaConfig(req, res, kibanaPort)
  );
  return router;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildPkpApiRouter
});
