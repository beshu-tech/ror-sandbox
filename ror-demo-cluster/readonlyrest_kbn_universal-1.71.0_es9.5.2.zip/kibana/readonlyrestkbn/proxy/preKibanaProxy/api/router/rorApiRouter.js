"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var rorApiRouter_exports = {};
__export(rorApiRouter_exports, {
  buildRorApiRouter: () => buildRorApiRouter
});
module.exports = __toCommonJS(rorApiRouter_exports);
var import_express = require("express");
var import_accessLevel = require("../../../../shared/types/accessLevel");
var import_errors = __toESM(require("../../../constants/errors"));
var import_requestUtils = require("../../../core/api/requestUtils");
var import_rorKbnApiController = require("../controller/rorKbnApiController");
var import_handleParseSettingsFromFileMiddleware = require("../middleware/handleParseSettingsFromFileMiddleware");
var import_requireSettingsOverrideMiddleware = require("../middleware/requireSettingsOverrideMiddleware");
var import_validateRorSettingsSyntaxMiddleware = require("../middleware/validateRorSettingsSyntaxMiddleware");
function buildRorApiRouter(licenseService, authController, authenticationFacade, rorSettingsStore) {
  const router = (0, import_express.Router)();
  const rorKbnApiController = new import_rorKbnApiController.RorKbnApiController(licenseService, rorSettingsStore);
  router.post(
    "/settings",
    (req, res, next) => licenseService.enterpriseLicenseRequired(res, next, import_errors.default.updateSettingsViaApiEnterpriseOnly),
    (req, res, next) => import_requestUtils.RequestUtils.verifyMediaType(req, res, next, ["application/yaml"]),
    import_requireSettingsOverrideMiddleware.requireSettingsOverrideMiddleware,
    (req, res, next) => (0, import_validateRorSettingsSyntaxMiddleware.validateRorSettingsSyntaxMiddleware)(req.body, req.path, res, next),
    async (req, res) => rorKbnApiController.handlePostSettings(req.rorRequest, res)
  );
  router.post(
    "/settings/upload",
    (req, res, next) => licenseService.enterpriseLicenseRequired(res, next, import_errors.default.updateSettingsViaApiEnterpriseOnly),
    (req, res, next) => import_requestUtils.RequestUtils.verifyMediaType(req, res, next, ["multipart/form-data"]),
    import_requireSettingsOverrideMiddleware.requireSettingsOverrideMiddleware,
    import_handleParseSettingsFromFileMiddleware.handleParseSettingsFromFileMiddleware,
    (req, res, next) => (0, import_validateRorSettingsSyntaxMiddleware.validateRorSettingsSyntaxMiddleware)(res.locals.rawRorKbnSettings, req.path, res, next),
    async (req, res) => rorKbnApiController.handleUploadConfiguration(req, res, res.locals.rawRorKbnSettings)
  );
  router.post(
    "/license",
    (req, res, next) => authController.verifyAccessLevel(req, res, next, [import_accessLevel.AccessLevel.UNRESTRICTED, import_accessLevel.AccessLevel.ADMIN]),
    (req, res, next) => import_requestUtils.RequestUtils.verifyMediaType(req, res, next, ["application/json"]),
    async (req, res) => rorKbnApiController.handleAddLicenseKey(req, res, (isLicenseEditionChanged) => {
      if (isLicenseEditionChanged) {
        authenticationFacade.deleteAllSessions();
      }
    })
  );
  router.get(
    "/user/tenants",
    (req, res, next) => licenseService.enterpriseLicenseRequired(
      res,
      next,
      import_errors.default.notSufficientLicenseToUseFeature("get user's tenants via ReadonlyREST API endpoint", "Enterprise")
    ),
    async (req, res) => rorKbnApiController.handleGetUserTenants(req, res)
  );
  return router;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildRorApiRouter
});
