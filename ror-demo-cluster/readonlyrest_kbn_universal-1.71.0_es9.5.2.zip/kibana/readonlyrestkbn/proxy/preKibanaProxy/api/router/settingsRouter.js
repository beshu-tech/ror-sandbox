"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var settingsRouter_exports = {};
__export(settingsRouter_exports, {
  buildSettingsRouter: () => buildSettingsRouter
});
module.exports = __toCommonJS(settingsRouter_exports);
var express = __toESM(require("express"));
var import_errors = __toESM(require("../../../constants/errors"));
var import_rorSettingsController = require("../controller/rorSettingsController");
var import_requireSettingsOverrideMiddleware = require("../middleware/requireSettingsOverrideMiddleware");
var import_validateRorSettingsSyntaxMiddleware = require("../middleware/validateRorSettingsSyntaxMiddleware");
function buildSettingsRouter(licenseService, authController, authenticationFacade, rorEsApiClientWithAuthProvider) {
  const router = express.Router();
  const settingsController = new import_rorSettingsController.RorSettingsController(
    authController,
    authenticationFacade,
    rorEsApiClientWithAuthProvider
  );
  router.get("/", async (req, res) => settingsController.getSettings(req.rorRequest, res));
  router.post(
    "/",
    (req, res, next) => licenseService.nonFreeLicenseRequired(res, next, import_errors.default.cannotSaveClusterWideSettingsOnFreeLicense),
    import_requireSettingsOverrideMiddleware.requireSettingsOverrideMiddleware,
    (req, res, next) => (0, import_validateRorSettingsSyntaxMiddleware.validateRorSettingsSyntaxMiddleware)(req.body.settings, req.path, res, next),
    async (req, res) => settingsController.updateSettings(req, res)
  );
  router.get(
    "/file",
    async (req, res) => settingsController.readRorKbnAndEsSettingsFromFile(req.rorRequest, res)
  );
  router.get(
    "/audit",
    async (req, res) => settingsController.fetchCurrentAuditConfiguration(req.rorRequest, res)
  );
  return router;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildSettingsRouter
});
