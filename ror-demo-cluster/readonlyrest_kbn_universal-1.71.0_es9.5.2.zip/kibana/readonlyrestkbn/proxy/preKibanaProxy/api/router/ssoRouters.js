"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var ssoRouters_exports = {};
__export(ssoRouters_exports, {
  OidcRouters: () => OidcRouters,
  SamlRouters: () => SamlRouters
});
module.exports = __toCommonJS(ssoRouters_exports);
var import_express = __toESM(require("express"));
var import_lodash = require("lodash");
var import_rxjs = require("rxjs");
var import_ActivationKey = require("../../../../shared/types/ActivationKey");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_jwtSigner = require("../../auth/jwtSigner");
var import_oidcRouterFactory = require("../../auth/oidc/oidcRouterFactory");
var import_samlRouterFactory = require("../../auth/saml/samlRouterFactory");
class SSORouters {
  constructor(basePathBuilder, licenseService, ssoType) {
    this.basePathBuilder = basePathBuilder;
    this.licenseService = licenseService;
    this.ssoType = ssoType;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "routers", import_express.default.Router());
  }
  getRouters() {
    return this.routers;
  }
  hasRouters() {
    return this.routers.stack.length > 0;
  }
  subscribeToChanges(settingsObservable) {
    (0, import_rxjs.combineLatest)([this.licenseService.onLicenseChanged$, settingsObservable]).pipe(
      (0, import_rxjs.catchError)((err, caught) => {
        this.logger.error({ message: `Error while rebuilding ${this.ssoType} SSO routers` }, err);
        return caught;
      })
    ).subscribe(([license]) => {
      if ((0, import_ActivationKey.isEnterpriseLicense)(license)) {
        this.rebuildRouters();
      } else {
        this.clearAllRouters();
      }
    });
  }
  clearAllRouters() {
    if (this.routers.stack.length > 0) {
      this.logger.info(`Clearing all ${this.ssoType} SSO routers (non-enterprise license)`);
      this.routers.stack.length = 0;
    }
  }
  rebuildRouters() {
    const newSettingsList = this.getLatestSettings();
    const newSettingsByName = new Map(newSettingsList.map((settings) => [settings.connectorName, settings]));
    const reusedConnectorNames = /* @__PURE__ */ new Set();
    const newRoutes = import_express.default.Router();
    for (const layer of this.routers.stack) {
      const subRouter = layer.handle;
      const name = subRouter._connectorName;
      const newSettings = name === void 0 ? void 0 : newSettingsByName.get(name);
      if (name === void 0) {
        this.logger.warn(`Found a ${this.ssoType} router layer without a _connectorName \u2014 dropping it`);
      } else if (newSettings === void 0) {
        this.logger.info(`Removing ${this.ssoType} SSO for "${name}"`);
      } else if ((0, import_lodash.isEqual)(subRouter._connectorSettings, newSettings)) {
        reusedConnectorNames.add(name);
        newRoutes.stack.push(layer);
      } else {
        this.logger.info(`Rebuilding ${this.ssoType} SSO for "${name}" (settings changed)`);
      }
    }
    for (const settings of newSettingsList) {
      if (!reusedConnectorNames.has(settings.connectorName)) {
        const routerPath = this.basePathBuilder.withBasePathPrefix(settings.routerPath);
        const subRouter = Object.assign(this.buildSubRouter(settings), {
          _connectorName: settings.connectorName,
          _connectorSettings: settings
        });
        this.logger.info(`Adding ${this.ssoType} SSO at "${routerPath}" path`);
        newRoutes.use(routerPath, subRouter);
      }
    }
    this.routers.stack = newRoutes.stack;
  }
}
class SamlRouters extends SSORouters {
  constructor(basePathBuilder, licenseService, rorSettingsStore, samlRouterSettingsList, legacyRenderer, ssoSessionService, samlLogoutTransactionCookieService, localFinalizationHandler) {
    super(basePathBuilder, licenseService, "SAML");
    this.rorSettingsStore = rorSettingsStore;
    this.samlRouterSettingsList = samlRouterSettingsList;
    __publicField(this, "jwtSigner");
    __publicField(this, "samlRouterFactory");
    this.jwtSigner = new import_jwtSigner.JwtSigner(rorSettingsStore);
    this.samlRouterFactory = new import_samlRouterFactory.SamlRouterFactory(
      this.jwtSigner,
      legacyRenderer,
      ssoSessionService,
      samlLogoutTransactionCookieService,
      localFinalizationHandler
    );
  }
  init() {
    this.subscribeToChanges(this.rorSettingsStore.observerRorKbnSettings((s) => {
      var _a;
      return (_a = s.authSettings) == null ? void 0 : _a.samlRawSettingsList;
    }));
  }
  getLatestSettings() {
    return this.samlRouterSettingsList.getSettingsList();
  }
  buildSubRouter(settings) {
    return this.samlRouterFactory.build(settings);
  }
}
class OidcRouters extends SSORouters {
  constructor(basePathBuilder, licenseService, rorSettingsStore, oidcRouterSettingsList, legacyRenderer, ssoSessionService, oidcLogoutTransactionCookieService, localFinalizationHandler) {
    super(basePathBuilder, licenseService, "OIDC");
    this.rorSettingsStore = rorSettingsStore;
    this.oidcRouterSettingsList = oidcRouterSettingsList;
    __publicField(this, "jwtSigner");
    __publicField(this, "oidcRouterFactory");
    this.jwtSigner = new import_jwtSigner.JwtSigner(rorSettingsStore);
    this.oidcRouterFactory = new import_oidcRouterFactory.OidcRouterFactory(
      this.jwtSigner,
      legacyRenderer,
      ssoSessionService,
      oidcLogoutTransactionCookieService,
      localFinalizationHandler
    );
  }
  init() {
    this.subscribeToChanges(this.rorSettingsStore.observerRorKbnSettings((s) => {
      var _a;
      return (_a = s.authSettings) == null ? void 0 : _a.oidcRawSettingsList;
    }));
  }
  getLatestSettings() {
    return this.oidcRouterSettingsList.getSettingsList();
  }
  buildSubRouter(settings) {
    return this.oidcRouterFactory.build(settings);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  OidcRouters,
  SamlRouters
});
