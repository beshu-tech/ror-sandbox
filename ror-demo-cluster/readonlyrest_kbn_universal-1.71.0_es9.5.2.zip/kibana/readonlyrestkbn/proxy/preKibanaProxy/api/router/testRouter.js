"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var testRouter_exports = {};
__export(testRouter_exports, {
  buildTestRouter: () => buildTestRouter
});
module.exports = __toCommonJS(testRouter_exports);
var express = __toESM(require("express"));
function buildTestRouter(testController) {
  const router = express.Router();
  router.get("/", async (req, res) => testController.handleGetTestSettings(req.rorRequest, res));
  router.post("/", async (req, res) => testController.handlePostTestSettings(req.rorRequest, res));
  router.delete(
    "/",
    async (req, res) => testController.handleDeleteTestSettings(req.rorRequest, res)
  );
  router.get("/authmock", async (req, res) => testController.handleGetAuthMock(req.rorRequest, res));
  router.post(
    "/authmock",
    async (req, res) => testController.handlePostAuthMock(req.rorRequest, res)
  );
  router.get(
    "/localusers",
    async (req, res) => testController.handleGetLocalUsers(req.rorRequest, res)
  );
  return router;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildTestRouter
});
