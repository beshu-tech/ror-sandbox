"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var auditLogEmitter_exports = {};
__export(auditLogEmitter_exports, {
  AuditLogEmitter: () => AuditLogEmitter
});
module.exports = __toCommonJS(auditLogEmitter_exports);
var import_correlationIdWrapper = require("../core/api/correlationIdWrapper");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
var AUDIT_EVENT_TYPE = /* @__PURE__ */ ((AUDIT_EVENT_TYPE2) => {
  AUDIT_EVENT_TYPE2["LOGOUT"] = "logout";
  return AUDIT_EVENT_TYPE2;
})(AUDIT_EVENT_TYPE || {});
const _AuditLogEmitter = class _AuditLogEmitter {
  constructor(rorEsApiClientWithAuthProvider) {
    this.rorEsApiClientWithAuthProvider = rorEsApiClientWithAuthProvider;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  async emitLogoutEvent(authHeaders, correlationId, whitelistedHeaders, origin) {
    return this.emitAuditEvent(authHeaders, whitelistedHeaders, correlationId, {
      event_type: "logout" /* LOGOUT */,
      agent: _AuditLogEmitter.AGENT_NAME,
      origin
    });
  }
  async emitLogoutEventIfAuthenticated(rorRequest) {
    var _a;
    const userRequestIdentity = await (rorRequest == null ? void 0 : rorRequest.getUserRequestIdentity());
    const origin = ((_a = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata) == null ? void 0 : _a.origin) || "N/A";
    if (await rorRequest.isAuthenticated()) {
      await this.emitLogoutEvent(
        await rorRequest.getIdentitySessionHeaders(),
        await rorRequest.getCorrelationId(),
        await rorRequest.getWhitelistedHeaders(),
        origin
      );
    }
  }
  async emitAuditEvent(authHeaders, whitelistedHeaders, correlationId, auditEvent) {
    this.logger.debug(`Emitting audit log event: ${JSON.stringify(auditEvent)}`);
    try {
      const response = await new import_correlationIdWrapper.CorrelationIdWrapper(this.rorEsApiClientWithAuthProvider.asScoped(authHeaders)).withCorrelationIdHeader(correlationId).postAuditEvent({ requestBody: auditEvent, identitySessionHeaders: authHeaders, whitelistedHeaders });
      if (response.status < 300) {
        this.logger.debug(
          `Successfully emitted audit event: ${JSON.stringify(auditEvent)} response: ${JSON.stringify(response)}`
        );
        return;
      }
      this.logger.error({
        message: `Error ${response.status} for ${auditEvent.event_type} audit event submission. (Message: ${response.statusMessage})`
      });
    } catch (e) {
      this.logger.error({ message: `Error emitting audit event: ${e.message}`, stack: e.stack });
    }
  }
};
__publicField(_AuditLogEmitter, "AGENT_NAME", "readonlyrestkbn");
let AuditLogEmitter = _AuditLogEmitter;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AuditLogEmitter
});
