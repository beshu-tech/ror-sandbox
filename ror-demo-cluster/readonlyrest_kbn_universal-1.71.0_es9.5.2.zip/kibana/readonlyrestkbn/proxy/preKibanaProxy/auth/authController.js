"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var authController_exports = {};
__export(authController_exports, {
  AuthController: () => AuthController
});
module.exports = __toCommonJS(authController_exports);
var import_queryStringKeys = require("../../../shared/constants/queryStringKeys");
var import_ActivationKey = require("../../../shared/types/ActivationKey");
var import_errors = __toESM(require("../../constants/errors"));
var import_basePathBuilder = require("../../core/basePath/basePathBuilder");
var import_types = require("../../core/common/types");
var import_urlUtils = require("../../core/common/urlUtils");
var import_cookieManager = require("../../core/cookieManager");
var import_identitySession = require("../../core/identitySession");
var import_rorLogger = require("../../core/logging/rorLogger");
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
var import_expressRorRequest = require("../../core/rorRequest/expressRorRequest");
var import_TenancyContext = require("../../core/tenancy/TenancyContext");
var import_csrf = require("./csrf");
var import_logoutLinkProvider = require("./logoutLinkProvider");
class AuthController {
  constructor(authenticationFacade, logoutLinkProvider, basePathSettings, tenancyService, rorSettingsStore, ssoSessionService, ssoLogoutTransactionVerifier, customLoginLink) {
    this.authenticationFacade = authenticationFacade;
    this.logoutLinkProvider = logoutLinkProvider;
    this.basePathSettings = basePathSettings;
    this.tenancyService = tenancyService;
    this.rorSettingsStore = rorSettingsStore;
    this.ssoSessionService = ssoSessionService;
    this.ssoLogoutTransactionVerifier = ssoLogoutTransactionVerifier;
    this.customLoginLink = customLoginLink;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "pathsOkForEmbeddedAuth");
    __publicField(this, "basePathBuilder");
    __publicField(this, "handleExternalSourceAuth", async (req, res, next) => {
      const { proxyAuthSettings, jwtQueryParam, cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      const forwardedAuthValue = req.headers[proxyAuthSettings.forward_auth_header];
      const forwardedAuthProxyConfigured = forwardedAuthValue != null && proxyAuthSettings.enabled;
      const jwtAuthConfigured = req.query[jwtQueryParam == null ? void 0 : jwtQueryParam.value];
      if (!forwardedAuthProxyConfigured && !jwtAuthConfigured) {
        return next();
      }
      try {
        const [encryptedCookie, userRequestIdentity] = await this.authenticationFacade.authorizeRequest(req.rorRequest);
        if (!await this.verifyUserAccessAfterAuthorization(
          req,
          res,
          userRequestIdentity.metadata.identitySessionHeaders,
          userRequestIdentity.metadata.whitelistedHeaders,
          userRequestIdentity.metadata.kibanaIndex
        ) || !await this.verifyUserApiOnlyAccess(req, res, userRequestIdentity.metadata.kibanaAccess)) {
          return;
        }
        res.cookie(
          cookieSettings.name,
          encryptedCookie,
          import_cookieManager.CookieManager.getCookiesOptions({ secure: cookieSettings.secure, sameSite: cookieSettings.sameSite })
        );
        req.rorRequest.getCookies()[cookieSettings.name] = encryptedCookie;
        this.logger.debug(
          `Session created for user '${userRequestIdentity.metadata.username}'; cookie synced to req.cookies so isAuthenticated() will return true within this request`
        );
      } catch (e) {
        this.logger.info(`Could not authorize through external source: ${e.message}`);
      }
      next();
    });
    __publicField(this, "redirectAuthenticated", async (req, res, next) => {
      if (req.query && req.query[import_types.AUTOLOGIN_QUERY_PARAM] === "false") {
        return next();
      }
      if (await req.rorRequest.isAuthenticated()) {
        res.redirect(this.buildNextUrl(req) || this.basePathBuilder.withBasePathPrefix("/", true));
        return;
      }
      next();
    });
    __publicField(this, "handleCustomLoginRedirection", async (req, res, next) => {
      if (this.customLoginLink != null) {
        res.redirect(this.customLoginLink);
        return;
      }
      next();
    });
    __publicField(this, "handleAuthentication", async (req, res, handleSuccess, handleError) => {
      try {
        const [encryptedCookie, userRequestIdentity] = await this.authenticationFacade.authorizeRequest(req.rorRequest);
        if (!userRequestIdentity.metadata.username) {
          this.throwEmptyMetadataReason();
        }
        return handleSuccess(encryptedCookie, userRequestIdentity);
      } catch (e) {
        return handleError(res, e);
      }
    });
    __publicField(this, "handleAuthenticationDirectRequestWithCredentials", async (req, res, handleSuccess, handleError) => {
      import_rorLogger.RorLogger.clearImpersonatingInfo();
      try {
        const xRorTenancyId = req.rorRequest.getHeaders()[import_types.X_ROR_TENANCY_ID];
        const xRorCorrelationId = req.rorRequest.getHeaders()[import_types.X_ROR_CORRELATION_ID];
        const xRorImpersonating = req.rorRequest.getHeaders()[import_types.X_ROR_IMPERSONATING];
        const isEntLicense = (0, import_ActivationKey.isEnterpriseLicense)(this.authenticationFacade.license);
        if (xRorTenancyId && !isEntLicense) {
          this.throwNotSufficientLicenseToUseFeatureError(`${import_types.X_ROR_TENANCY_ID} header`);
        }
        if (xRorImpersonating && !isEntLicense) {
          this.throwNotSufficientLicenseToUseFeatureError(`${xRorImpersonating} header`);
        }
        const [encryptedCookie, userRequestIdentity] = await this.authenticationFacade.authorizeDirectRequestWithCredentials(req.rorRequest, xRorCorrelationId);
        if (!userRequestIdentity.metadata.username) {
          this.throwEmptyMetadataReason();
        }
        return handleSuccess(encryptedCookie, userRequestIdentity);
      } catch (e) {
        return handleError(res, e);
      }
    });
    __publicField(this, "handleAuthenticationError", (res, error) => {
      function assertUnreachable(x) {
        throw new Error(`Unhandled case: ${x}`);
      }
      switch (error.reason) {
        case "EMPTY_METADATA":
          this.logger.error(
            new Error(
              "There is a problem with the ACL configuration. The login request is checked by the ACL and gets accepted by an ACL block with no authentication rule in it. Check documentation  https://docs.readonlyrest.com/kibana#no-authentication-rule-defined for more references"
            )
          );
          break;
        case "API_ONLY_KIBANA_ACCESS": {
          this.logger.info(`Could not login in: api_only Kibana access type user cannot log in to the Kibana.`);
          break;
        }
        case "DEFAULT_SPACE_IS_NOT_AVAILABLE": {
          this.logger.info(`Could not login in: There is a problem with authorization, default space is not available.`);
          break;
        }
        case "SERVER_ERROR":
        case "FORBIDDEN_BY_READONLYREST":
        case "CUSTOM_ERROR_FROM_ES": {
          this.logger.info(`Could not login in: ${error.message}`);
          break;
        }
        case "UNHANDLED_ERROR_FROM_ES": {
          this.logger.info(`Could not login in: unhandled server from Elasticsearch response: ${error.message}`);
          break;
        }
        case "NOT_SUFFICIENT_LICENSE": {
          this.logger.info(
            `Your request couldn\u2019t be processed due to restrictions associated with your license edition: ${error.message}`
          );
          break;
        }
        case "IMPERSONATION_NOT_ALLOWED":
        case "IMPERSONATION_NOT_SUPPORTED":
        case "TEST_SETTINGS_NOT_CONFIGURED":
        case "OPERATION_NOT_ALLOWED": {
          this.logger.info(`There is a problem with impersonating user: ${error.message}`);
          break;
        }
        default: {
          this.logger.info(`Could not login in: unhandled server error: ${error.message}`);
          assertUnreachable(error.reason);
        }
      }
      const statusCode = 403;
      res.status(statusCode);
      res.setHeader("Content-Type", "application/json");
      return res.json({ message: error.message, status: error.reason, statusCode, error: "Unauthorized" });
    });
    __publicField(this, "handleLoginPost", async (req, res) => {
      const { cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      const handleSuccess = async (encryptedCookie, userRequestIdentity) => {
        if (!await this.verifyUserAccessAfterAuthorization(
          req,
          res,
          userRequestIdentity.metadata.identitySessionHeaders,
          userRequestIdentity.metadata.whitelistedHeaders,
          userRequestIdentity.metadata.kibanaIndex
        ) || !await this.verifyUserApiOnlyAccess(req, res, userRequestIdentity.metadata.kibanaAccess)) {
          return;
        }
        let redirectUrl = this.buildNextUrl(req) || this.basePathBuilder.withBasePathPrefix("/", true);
        const { currentGroup, kibanaIndex } = userRequestIdentity.metadata;
        if (currentGroup) {
          const origin = `${req.protocol}://${req.headers.host}`;
          redirectUrl = this.tenancyService.persistTenancyContextInUrl(
            redirectUrl,
            (0, import_TenancyContext.tenancyFromId)(currentGroup.id, kibanaIndex),
            origin
          );
        }
        res.clearCookie(import_queryStringKeys.NEXT_URL);
        import_csrf.Csrf.clearCookie(res);
        import_csrf.Csrf.clearCsrfSessionIdCookie(res);
        res.cookie(
          cookieSettings.name,
          encryptedCookie,
          import_cookieManager.CookieManager.getCookiesOptions({ secure: cookieSettings.secure, sameSite: cookieSettings.sameSite })
        );
        res.setHeader("Content-Type", "application/json");
        this.logger.debug(
          `login request granted: username: ${userRequestIdentity.metadata.username}, groups: [${JSON.stringify(
            userRequestIdentity.metadata.availableGroups
          )}]`
        );
        this.logger.debug(`Redirecting to ${redirectUrl.split(/[?#]/)[0]}`);
        return res.json({ nextUrl: redirectUrl });
      };
      await this.handleAuthentication(req, res, handleSuccess, (res2, errors2) => {
        this.logRejectedLoginUsername(req);
        return this.handleAuthenticationError(res2, errors2);
      });
    });
    __publicField(this, "handleApiReqWithCredentialsOnboard", async (req, res, next) => {
      const { cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      if (!this.pathsOkForEmbeddedAuth.test(req.path) || req.rorRequest.isCookiePresent(cookieSettings.name)) {
        return next();
      }
      const handleSuccess = (encryptedCookie) => {
        req.cookies[cookieSettings.name] = encryptedCookie;
        return next();
      };
      return this.handleAuthenticationDirectRequestWithCredentials(
        req,
        res,
        handleSuccess,
        this.handleAuthenticationError
      );
    });
    __publicField(this, "handleApiReqWithJwtToken", async (req, res, next) => {
      const { cookieSettings, jwtQueryParam } = this.rorSettingsStore.getLatestRorKbnSettings();
      const hasJwtToken = Boolean(req.rorRequest.getQueries()[jwtQueryParam.value]);
      if (!hasJwtToken) {
        return next();
      }
      const handleSuccess = (encryptedCookie) => {
        res.cookie(
          cookieSettings.name,
          encryptedCookie,
          import_cookieManager.CookieManager.getCookiesOptions({ secure: cookieSettings.secure, sameSite: cookieSettings.sameSite })
        );
        req.cookies[cookieSettings.name] = encryptedCookie;
        return next();
      };
      return this.handleAuthenticationDirectRequestWithCredentials(req, res, handleSuccess, async (_res, error) => {
        this.logger.info(`JWT authentication failed, redirecting to logout: ${error.message}`);
        await this.handleLogout(req, res);
      });
    });
    __publicField(this, "handleLogout", async (req, res) => {
      try {
        let decision;
        try {
          decision = await this.decideLogoutFlow(req, res, req.rorRequest);
        } catch (error) {
          this.logger.error({
            message: "Failed to decide logout flow, falling back to local logout",
            stack: error instanceof Error ? error.stack : String(error)
          });
          await this.finalizeLocalLogout(req.rorRequest, res, req);
          return;
        }
        if (decision.kind === "sso") {
          await this.redirectToSsoLogout(res, decision, req);
        } else {
          await this.finalizeLocalLogout(req.rorRequest, res, req);
        }
      } catch (error) {
        this.logger.error({
          message: "Logout could not be finalized; sending a best-effort response instead of hanging",
          stack: error instanceof Error ? error.stack : String(error)
        });
        if (!res.headersSent) {
          res.status(500).send("Logout failed. Please close your browser session.");
        }
      }
    });
    __publicField(this, "createLocalFinalizationHandler", () => async (req, res) => {
      await this.finalizeLocalLogout(req.rorRequest, res, req);
    });
    __publicField(this, "decideLogoutFlow", async (req, res, rorRequest) => {
      const sid = await rorRequest.getSid();
      if (await this.verifySsoLogoutCompleted(req, res, sid)) {
        return { kind: "local" };
      }
      if (sid === null) {
        return { kind: "local" };
      }
      const connectorName = await this.resolveSsoConnectorName(rorRequest);
      if (!connectorName) {
        return { kind: "local" };
      }
      const url = this.logoutLinkProvider.resolveSsoLogoutLink(connectorName);
      if (!url) {
        return { kind: "local" };
      }
      return { kind: "sso", sid, connectorName, url };
    });
    __publicField(this, "verifySsoLogoutCompleted", async (req, res, sid) => {
      if (req.query.ssoLogoutCompleted !== "true" || sid === null) {
        return false;
      }
      return this.ssoLogoutTransactionVerifier.consumeTransaction(req, res, sid);
    });
    __publicField(this, "resolveSsoConnectorName", async (rorRequest) => {
      var _a;
      const identity = await rorRequest.getUserRequestIdentity();
      return (_a = identity == null ? void 0 : identity.metadata.origin) != null ? _a : this.ssoSessionService.getSsoConnectorName(rorRequest);
    });
    // SSO context: the local ROR session must stay alive - the IdP round-trip (via
    // Saml/OidcController) still needs it to build the protocol logout request. Local session
    // cleanup only happens once the IdP calls back to finishLogout/onLogoutCallback.
    __publicField(this, "redirectToSsoLogout", async (res, decision, req) => {
      this.redirectWithParams(res, req, decision.url);
    });
    // Local (non-SSO) context: there's no IdP round-trip to wait for, so we finalize the session
    // (audit, delete it, clear cookies) immediately and redirect straight to the result.
    __publicField(this, "finalizeLocalLogout", async (rorRequest, res, req) => {
      this.ssoLogoutTransactionVerifier.clearTransaction(res);
      const url = await this.authenticationFacade.finalizeLogout(rorRequest, res);
      this.redirectWithParams(res, req, url);
    });
    __publicField(this, "redirectWithParams", (res, req, url) => {
      const message = req.query.message;
      res.redirect(
        AuthController.setUrlParams(url, this.basePathSettings.kibanaBasePath, this.buildNextUrl(req), message)
      );
    });
    __publicField(this, "handleSessionProbe", async (req, res) => {
      var _a, _b, _c;
      res.setHeader("Content-Type", "application/json");
      const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
      const impersonatedBy = (_a = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata) == null ? void 0 : _a.impersonatedBy;
      const { rorRequest } = req;
      if (impersonatedBy) {
        const impersonateAs = (_c = (_b = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata) == null ? void 0 : _b.username) != null ? _c : "";
        const checkImpersonateResponse = await this.authenticationFacade.checkImpersonationStatus(
          await req.rorRequest.getIdentitySessionHeaders(),
          await req.rorRequest.getWhitelistedHeaders(),
          impersonateAs
        );
        if (checkImpersonateResponse.status === 401 || checkImpersonateResponse.status === 403) {
          await this.authenticationFacade.finishImpersonation(req.rorRequest, res);
          this.logger.info("Ttl is reached");
          res.status(401);
          res.json({ message: "Ttl is reached" });
          return;
        }
      }
      if (!await rorRequest.isAuthenticated()) {
        this.logger.info("No valid session");
        res.status(401);
        res.json({ message: "No valid session" });
        return;
      }
      const isSessionTimeout = await this.authenticationFacade.verifySessionTimeout(rorRequest);
      if (isSessionTimeout) {
        this.logger.info("Session timeout");
        res.status(401);
        res.json({ message: "Session timeout" });
        return;
      }
      try {
        this.logger.info("Refreshing session against ES");
        const currentUserRequestIdentity = await rorRequest.getUserRequestIdentity();
        const newSession = await this.authenticationFacade.refreshSessionAgainstEs(currentUserRequestIdentity);
        this.handleNewSession(
          currentUserRequestIdentity,
          newSession,
          res,
          currentUserRequestIdentity.metadata.availableGroups
        );
      } catch (e) {
        this.logger.info(`Could not refresh the session against ES: + ${e.message}`);
        res.status(401);
        res.json({ message: "Session no longer valid" });
      }
    });
    __publicField(this, "throwNotSufficientLicenseToUseFeatureError", (featureMessage) => {
      const error = {
        reason: "NOT_SUFFICIENT_LICENSE",
        message: import_errors.default.notSufficientLicenseToUseFeature(featureMessage),
        status: "ERROR"
      };
      throw error;
    });
    this.basePathBuilder = new import_basePathBuilder.BasePathBuilder(basePathSettings);
    this.pathsOkForEmbeddedAuth = new RegExp(
      `^${this.basePathBuilder.withBasePathPrefix("(/s/.*/(?:api|internal)/.*|/(?:api|internal)/.*|/pkp/api/.*)")}`
    );
  }
  handleNewSession(currentUserRequestIdentity, newSession, res, currentlyAvailableTenancies) {
    const { sessionSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    if (import_identitySession.IdentitySessionMetadataDifferenceChecker.isMissingMetadata(
      currentUserRequestIdentity.metadata,
      newSession.metadata
    )) {
      this.logger.info("Missing metadata");
      res.status(401);
      res.json({ message: "Missing metadata" });
      return;
    }
    if (import_identitySession.IdentitySessionMetadataDifferenceChecker.isDifferent(
      currentUserRequestIdentity.metadata,
      newSession.metadata,
      currentlyAvailableTenancies
    )) {
      this.logger.info("Significant session change detected");
      this.logger.debug(`Current sessionMetadata: ${JSON.stringify(currentUserRequestIdentity.metadata)}`);
      this.logger.debug(`New sessionMetadata: ${JSON.stringify(newSession.metadata)}`);
      res.status(200);
      res.json({
        message: "Session updated",
        reload: true,
        intervalMillis: sessionSettings.probeIntervalMillis
      });
      return;
    }
    res.status(200);
    res.json({ message: "Session valid", reload: false, intervalMillis: sessionSettings.probeIntervalMillis });
  }
  async redirectUnauthenticated(req, res, next) {
    const authenticated = await req.rorRequest.isAuthenticated();
    this.logger.debug(`redirectUnauthenticated: isAuthenticated=${authenticated} for ${req.method} ${req.path}`);
    if (!authenticated) {
      const redirectUrl = this.basePathBuilder.withBasePathPrefix(import_logoutLinkProvider.LogoutLinkProvider.ROR_LOGOUT_LINK, true);
      const nextUrlParam = req.originalUrl;
      if (nextUrlParam.includes(import_logoutLinkProvider.LogoutLinkProvider.ROR_LOGOUT_LINK) || nextUrlParam.includes("/login")) {
        this.logger.error(
          new Error(
            "There is a problem with handling this request. If you use reverse proxy and server.rewriteBasePath is set into a false, check the documentation for more information https://docs.readonlyrest.com/kibana#using-ror-with-a-reverse-proxy"
          )
        );
        res.sendStatus(400);
        return;
      }
      const redirectUrlWithNextUrl = AuthController.setUrlParams(
        redirectUrl,
        this.basePathSettings.kibanaBasePath,
        nextUrlParam
      );
      res.redirect(redirectUrlWithNextUrl);
      return;
    }
    next();
  }
  async refreshSession(req, res, next) {
    const { cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    try {
      if (!this.pathsOkForEmbeddedAuth.test(req.path) && req.query.jwt == null || req.rorRequest.isCookiePresent(cookieSettings.name)) {
        await this.authenticationFacade.refreshSession(req.rorRequest);
      }
      next();
    } catch (e) {
      this.logger.error({ message: `Error during a session refresh: ${e.message}`, stack: e.stack });
      await this.handleLogout(req, res);
    }
  }
  static setUrlParams(url, kibanaBasePath, nextUrlParam, message) {
    const urlSearchParams = new URLSearchParams();
    if (nextUrlParam) {
      if (!nextUrlParam.startsWith(kibanaBasePath)) {
        nextUrlParam = kibanaBasePath + nextUrlParam;
      }
      urlSearchParams.set(import_queryStringKeys.NEXT_URL, nextUrlParam);
    }
    if (message) {
      urlSearchParams.set(import_types.MESSAGE_QUERY_PARAM, message);
    }
    return Array.from(urlSearchParams).length > 0 ? `${url}?${urlSearchParams}` : url;
  }
  buildNextUrl(req) {
    const rawNextUrl = req.query[import_queryStringKeys.NEXT_URL];
    let nextUrl = typeof rawNextUrl === "string" ? (0, import_urlUtils.normalizeUrlEncoding)(rawNextUrl) : void 0;
    if (!nextUrl || nextUrl.includes("ror_kbn_") || nextUrl.includes(import_logoutLinkProvider.LogoutLinkProvider.ROR_LOGOUT_LINK)) {
      return;
    }
    if (!(0, import_urlUtils.isSafeRelativeUrl)(nextUrl)) {
      this.logger.warn(`Blocked unsafe nextUrl: ${nextUrl.replace(/[\r\n]/g, "\u23CE")}`);
      return;
    }
    if (nextUrl === "/" || nextUrl === "") {
      nextUrl = this.basePathBuilder.withBasePathPrefix(nextUrl, true);
    }
    this.logger.trace(`NextUrl in param: ${nextUrl}`);
    return nextUrl;
  }
  logRejectedLoginUsername(req) {
    let username = "";
    const body = req.rorRequest.getBody();
    const jwtToken = body == null ? void 0 : body[import_types.CONNECTOR_SVC_TRANSIENT_JWT];
    const forwardedUser = req.headers[import_types.X_FORWARDED_USER];
    if ((0, import_expressRorRequest.isLoginFormBody)(body)) {
      username = body.username;
    } else if (jwtToken) {
      const parsedJWT = JSON.parse(Buffer.from(jwtToken.split(".")[1], "base64").toString());
      username = parsedJWT.user;
    } else if (typeof forwardedUser === "string") {
      username = forwardedUser;
    }
    this.logger.debug(`login request rejected: username: ${username}`);
  }
  async verifyUserApiOnlyAccess(req, res, kibanaAccess) {
    if (kibanaAccess === "api_only") {
      this.logRejectedLoginUsername(req);
      this.handleAuthenticationError(res, {
        message: import_errors.default.defaultForbiddenMessage,
        reason: "API_ONLY_KIBANA_ACCESS",
        status: "ERROR"
      });
      return false;
    }
    return true;
  }
  async verifyUserAccessAfterAuthorization(req, res, identitySessionHeaders, whitelistedHeaders, kibanaIndex) {
    const responseSpace = await this.authenticationFacade.verifyUserAccess(
      identitySessionHeaders,
      whitelistedHeaders,
      kibanaIndex
    );
    if (responseSpace.status !== 200) {
      this.logRejectedLoginUsername(req);
      this.handleAuthenticationError(res, {
        status: "ERROR",
        message: import_errors.default.defaultForbiddenMessage,
        reason: "DEFAULT_SPACE_IS_NOT_AVAILABLE"
      });
      return false;
    }
    return true;
  }
  async verifyAccessLevel(req, res, next, requiredAccessLevels) {
    const accessLevel = await this.authenticationFacade.getAccessLevel(req);
    if (requiredAccessLevels.some((requiredAccessLevel) => requiredAccessLevel === accessLevel)) {
      return next();
    }
    return res.status(403).send({
      status: "FORBIDDEN",
      message: import_errors.default.inSufficientPermissions
    });
  }
  throwEmptyMetadataReason() {
    const error = {
      reason: "EMPTY_METADATA",
      message: import_errors.default.defaultForbiddenMessage,
      status: "ERROR"
    };
    throw error;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AuthController
});
