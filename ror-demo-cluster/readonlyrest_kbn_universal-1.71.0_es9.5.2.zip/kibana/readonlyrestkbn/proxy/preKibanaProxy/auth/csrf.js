"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var csrf_exports = {};
__export(csrf_exports, {
  Csrf: () => Csrf
});
module.exports = __toCommonJS(csrf_exports);
var import_crypto = require("crypto");
var import_base64url = __toESM(require("base64url"));
var import_csrf_csrf = require("csrf-csrf");
var import_errors = __toESM(require("../../constants/errors"));
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
const _Csrf = class _Csrf {
  static get CSRF_SESSION_COOKIE_NAME() {
    return `${_Csrf.CSRF_COOKIE_NAME}-session_id`;
  }
  static clearCsrfSessionIdCookie(res) {
    res.clearCookie(_Csrf.CSRF_SESSION_COOKIE_NAME, {
      path: "/",
      sameSite: "lax",
      httpOnly: true,
      secure: _Csrf.sslEnabled
    });
  }
  static generateToken(res, req) {
    _Csrf.setCsrfSessionIdCookie(req, res);
    return _Csrf.doubleCsrf.generateCsrfToken(req, res, { validateOnReuse: false, overwrite: false });
  }
  static checkCsrfTokenPresent(req, res, next) {
    const cookies = req.rorRequest.getCookies();
    const csrfCookie = cookies[_Csrf.CSRF_COOKIE_NAME];
    const csrfSessionCookie = cookies[_Csrf.CSRF_SESSION_COOKIE_NAME];
    if (!csrfCookie || !csrfSessionCookie) {
      _Csrf.logger.error({
        message: `CSRF cookies are missing (${_Csrf.CSRF_COOKIE_NAME}, ${_Csrf.CSRF_SESSION_COOKIE_NAME}). This usually indicates the login page was cached. See documentation: https://docs.readonlyrest.com/kibana#using-ror-with-a-reverse-proxy`
      });
      res.status(401).json({
        message: import_errors.default.cannotAuthenticate
      });
      return;
    }
    next();
  }
  static doubleCsrfProtection(req, res, next) {
    return _Csrf.doubleCsrf.doubleCsrfProtection(req, res, next);
  }
  static csrfErrorHandler(error, req, res, next) {
    var _a;
    if (error.code === ((_a = _Csrf.invalidCsrfTokenError()) == null ? void 0 : _a.code)) {
      _Csrf.logger.error({
        message: `CSRF error: ${error.message}. This can occur due to session sharing issues in multi-instance setups. See documentation: https://docs.readonlyrest.com/kibana#session-management-with-multiple-kibana-instances`
      });
      res.status(401).json({
        message: import_errors.default.cannotAuthenticate
      });
    } else {
      if (error == null ? void 0 : error.message) {
        _Csrf.logger.warn(`CSRF error: ${error.message}. Error code: ${error.code || "<unknown>"}`);
      }
      next();
    }
  }
  static clearCookie(res) {
    res.clearCookie(_Csrf.CSRF_COOKIE_NAME, {
      path: "/",
      sameSite: "lax",
      secure: _Csrf.sslEnabled
    });
  }
  static configure(sslEnabled, kibanaUrl, secretKey) {
    const master = (0, import_crypto.scryptSync)(secretKey, _Csrf.CSRF_SECRET_SALT, 32, { N: 16384, r: 8, p: 1 });
    const CSRF_SECRET = (0, import_crypto.createHmac)("sha256", master).update(_Csrf.CSRF_SECRET_SALT).digest("hex");
    _Csrf.sslEnabled = sslEnabled;
    _Csrf.CSRF_COOKIE_NAME = _Csrf.sslEnabled ? `__Host-ror.${_Csrf.CSRF_COOKIE_PATTERN(kibanaUrl)}` : _Csrf.CSRF_COOKIE_PATTERN(kibanaUrl);
    _Csrf.doubleCsrf = (0, import_csrf_csrf.doubleCsrf)({
      getSecret: () => CSRF_SECRET,
      getSessionIdentifier: _Csrf.getSessionIdentifier,
      size: 64,
      cookieName: _Csrf.CSRF_COOKIE_NAME,
      cookieOptions: {
        sameSite: "lax",
        path: "/",
        secure: _Csrf.sslEnabled
      },
      ignoredMethods: ["GET", "HEAD", "OPTIONS"],
      getCsrfTokenFromRequest: (req) => req.headers[_Csrf.CSRF_HEADER_NAME]
    });
  }
  static setCsrfSessionIdCookie(req, res) {
    const csrfSessionId = (0, import_crypto.randomBytes)(16).toString("hex");
    if (req.rorRequest.getCookies()[_Csrf.CSRF_SESSION_COOKIE_NAME]) {
      return;
    }
    req.rorRequest.getCookies()[_Csrf.CSRF_SESSION_COOKIE_NAME] = csrfSessionId;
    res.cookie(_Csrf.CSRF_SESSION_COOKIE_NAME, csrfSessionId, {
      path: "/",
      sameSite: "lax",
      httpOnly: true,
      secure: _Csrf.sslEnabled
    });
  }
  static invalidCsrfTokenError() {
    return _Csrf.doubleCsrf.invalidCsrfTokenError;
  }
  static getSessionIdentifier(req) {
    return req.rorRequest.getCookies()[_Csrf.CSRF_SESSION_COOKIE_NAME];
  }
};
__publicField(_Csrf, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
__publicField(_Csrf, "CSRF_SECRET_SALT", "X[%F`z@K#cIZ!'P]L)v!_]&N#\"NhxW");
__publicField(_Csrf, "CSRF_HEADER_NAME", "x-csrf-token");
__publicField(_Csrf, "CSRF_COOKIE_PATTERN", (kibanaUrl) => `x-csrf-token-${(0, import_base64url.default)(kibanaUrl)}`);
__publicField(_Csrf, "sslEnabled");
__publicField(_Csrf, "CSRF_COOKIE_NAME");
__publicField(_Csrf, "doubleCsrf");
let Csrf = _Csrf;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Csrf
});
