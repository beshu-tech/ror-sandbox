"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var jwtSigner_exports = {};
__export(jwtSigner_exports, {
  JwtSigner: () => JwtSigner
});
module.exports = __toCommonJS(jwtSigner_exports);
var import_versionedLibraries = require("../../core/common/versionedLibraries");
class JwtSigner {
  constructor(rorSettingsStore) {
    this.rorSettingsStore = rorSettingsStore;
  }
  sign(payload) {
    var _a;
    const { authSettings, sessionSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    return import_versionedLibraries.jsonwebtoken.sign(payload, (_a = authSettings == null ? void 0 : authSettings.signatureKey) != null ? _a : "", {
      expiresIn: `${sessionSettings.timeoutMinutes}m`
      // eslint-disable-next-line @typescript-eslint/consistent-type-imports
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  JwtSigner
});
