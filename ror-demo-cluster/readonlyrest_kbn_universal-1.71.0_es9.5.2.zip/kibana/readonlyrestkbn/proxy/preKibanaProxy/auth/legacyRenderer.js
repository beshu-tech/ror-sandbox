"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var legacyRenderer_exports = {};
__export(legacyRenderer_exports, {
  LegacyRenderer: () => LegacyRenderer
});
module.exports = __toCommonJS(legacyRenderer_exports);
var import_fs_extra = __toESM(require("fs-extra"));
var import_sanitizer = __toESM(require("sanitizer"));
var import_distributionInfoProvider = require("../../../kibana/patchers/distributionInfoProvider");
var import_queryStringKeys = require("../../../shared/constants/queryStringKeys");
var import_ActivationKey = require("../../../shared/types/ActivationKey");
var import_types = require("../../core/common/types");
var import_logLevel = require("../../core/logging/logLevel");
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
var import_TenancyContext = require("../../core/tenancy/TenancyContext");
var import_csrf = require("./csrf");
var import_templateCompiler = require("./template/templateCompiler");
const TEXT_HTML_UTF8 = "text/html; charset=utf-8";
const TEXT_CSS_UTF8 = "text/css; charset=utf-8";
const APPLICATION_JAVASCRIPT_UTF8 = "application/javascript; charset=UTF-8";
class LegacyRenderer {
  constructor(basePath, licenseService, samlRouterSettingsList, oidcRouterSettingsList, rorSettingsStore, tenancyService) {
    this.basePath = basePath;
    this.licenseService = licenseService;
    this.samlRouterSettingsList = samlRouterSettingsList;
    this.oidcRouterSettingsList = oidcRouterSettingsList;
    this.rorSettingsStore = rorSettingsStore;
    this.tenancyService = tenancyService;
    __publicField(this, "injectCustomJs");
    __publicField(this, "loginPageCustomizations");
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "renderLoginPage", async (req, res) => {
      try {
        const compiledHtml = (0, import_templateCompiler.compile)("./login_tpl.html", this.buildLoginTemplateArgs());
        res.setHeader(import_types.CONTENT_TYPE_HEADER, TEXT_HTML_UTF8);
        return res.send(compiledHtml);
      } catch (error) {
        this.logger.error({ message: `Failed to render login page: ${error.message}`, stack: error.stack });
        return res.status(200).send(
          (0, import_templateCompiler.compile)("./loading_tpl.html", {
            title: "Kibana is not ready yet",
            error: "Please hold while we sync up with Elasticsearch...",
            year: (/* @__PURE__ */ new Date()).getFullYear()
          })
        );
      }
    });
    __publicField(this, "renderLoginDeferredScript", async (req, res) => {
      try {
        const csrfToken = import_csrf.Csrf.generateToken(res, req);
        const compiled = (0, import_templateCompiler.compile)("./login_tpl_defer.js", this.buildLoginTemplateArgs(csrfToken));
        return this.renderJs(res, compiled);
      } catch (error) {
        this.logger.error({ message: `Failed to render login deferred script: ${error.message}`, stack: error.stack });
        return res.sendStatus(500);
      }
    });
    __publicField(this, "renderSessionProbeInjection", (req, res) => {
      const { sessionSettings, cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      const sessionProbeTemplateArgs = {
        intervalMillis: sessionSettings.probeIntervalMillis,
        sessionProbeUrl: `${this.basePath}/pkp/session-probe`,
        baseLogoutUrl: `${this.basePath}/logout`,
        sessionProbePrefix: `${cookieSettings.name}`,
        enableLogging: import_rorLoggerFactory.RorLoggerFactory.isLoggingEnabled(import_logLevel.LogLevel.DEBUG)
      };
      return this.renderJs(res, (0, import_templateCompiler.compile)("../../injection/scripts/sessionProbe.js", sessionProbeTemplateArgs));
    });
    __publicField(this, "renderCustomUserJsInjection", async (req, res) => {
      var _a;
      const userRequestIdentity = await ((_a = req.rorRequest) == null ? void 0 : _a.getUserRequestIdentity());
      return this.renderJs(res, this.injectCustomJs(userRequestIdentity == null ? void 0 : userRequestIdentity.metadata));
    });
    __publicField(this, "renderUnsupportedEndpointsFilter", (_req, res) => this.renderJs(res, (0, import_templateCompiler.compile)("../../injection/scripts/unsupportedEndpointsFilter.js", {})));
    __publicField(this, "renderActivationKeyExpirationAlert", async (req, res) => {
      var _a, _b;
      const license = this.licenseService.getActivationKey();
      const userRequestIdentity = await ((_a = req.rorRequest) == null ? void 0 : _a.getUserRequestIdentity());
      const javascript = (0, import_templateCompiler.compile)("../../injection/scripts/activationKeyExpirationAlert.js", {
        expirationDateEpoch: license.exp,
        isTrial: license.license.isTrial,
        kibanaAccess: (_b = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata) == null ? void 0 : _b.kibanaAccess
      });
      return this.renderJs(res, javascript);
    });
    __publicField(this, "renderSwitchGroup", async (req, res) => {
      var _a;
      const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
      const metadata = userRequestIdentity.metadata;
      const compiledHtml = (0, import_templateCompiler.compile)(
        "./switch_group_tpl.html",
        this.buildSwitchGroupTemplateArgs({
          // encodeURIComponent required: value is interpolated directly into a raw URL
          // string inside an HTML src attribute, so base64 chars (+, =, /) must be escaped.
          // switch_group_tpl_defer.js does NOT encode because its template embeds the raw
          // value into a JS string and then passes it to URLSearchParams.set(), which encodes it.
          newEncryptedTenancyContext: encodeURIComponent(
            this.tenancyService.buildEncryptedTenancyContext(
              (0, import_TenancyContext.tenancyFromKibanaIndex)((_a = metadata.currentGroup) == null ? void 0 : _a.id, metadata.kibanaIndex)
            )
          )
        })
      );
      res.setHeader(import_types.CONTENT_TYPE_HEADER, TEXT_HTML_UTF8);
      return res.send(compiledHtml);
    });
    __publicField(this, "renderSwitchGroupDeferredScript", async (req, res) => {
      var _a;
      const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
      const metadata = userRequestIdentity.metadata;
      return this.renderJs(
        res,
        (0, import_templateCompiler.compile)(
          "./switch_group_tpl_defer.js",
          this.buildSwitchGroupTemplateArgs({
            newEncryptedTenancyContext: this.tenancyService.buildEncryptedTenancyContext(
              (0, import_TenancyContext.tenancyFromKibanaIndex)((_a = metadata.currentGroup) == null ? void 0 : _a.id, metadata.kibanaIndex)
            )
          })
        )
      );
    });
    __publicField(this, "renderHiddenAppsInjection", async (req, res) => {
      var _a;
      const userRequestIdentity = await ((_a = req.rorRequest) == null ? void 0 : _a.getUserRequestIdentity());
      const kibanaHiddenApps = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata.kibanaHiddenApps;
      const appNames = kibanaHiddenApps || [];
      const templateArgs = {
        hiddenApps: [appNames.map((app) => `"${app}"`)],
        basePath: this.basePath,
        appRegistryPath: `${this.basePath}/pkp/api/kbn_app_registry`,
        hiddenAppsRegistryPath: `${this.basePath}/pkp/api/kbn_app_registry/hidden`
      };
      const javascript = (0, import_templateCompiler.compile)("../../injection/scripts/hiddenApps.js", templateArgs);
      return this.renderJs(res, javascript);
    });
    __publicField(this, "renderRorCssClassesInjection", async (req, res) => {
      var _a, _b;
      const userRequestIdentity = await ((_a = req.rorRequest) == null ? void 0 : _a.getUserRequestIdentity());
      const rorMetadata = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata;
      const kibanaHiddenApps = rorMetadata == null ? void 0 : rorMetadata.kibanaHiddenApps;
      const appNames = kibanaHiddenApps || [];
      const javascript = (0, import_templateCompiler.compile)("../../injection/scripts/rorCssClasses.js", {
        username: (rorMetadata == null ? void 0 : rorMetadata.username) || "",
        currentGroupId: ((_b = rorMetadata == null ? void 0 : rorMetadata.currentGroup) == null ? void 0 : _b.id) || "",
        kibanaAccess: (rorMetadata == null ? void 0 : rorMetadata.kibanaAccess) || "",
        hiddenApps: [appNames.map((app) => `"${app}"`)]
      });
      return this.renderJs(res, javascript);
    });
    __publicField(this, "renderJwtRedirect", (jwt, headers) => `<script src="${this.basePath}/pkp/autodeps?file=jquery/dist/jquery.min.js"></script>
    <script>
    // sessionStorage['nextUrl'] is always a decoded path (e.g. /app/kibana?tenancy=abc).
    // params.set() below will percent-encode it correctly before it reaches the server.
    const nextUrl = window.sessionStorage.getItem("nextUrl");


    let loginRedirect = "${this.basePath}/login";

    const params = new URLSearchParams();

    if (nextUrl) {
      params.set("nextUrl", nextUrl);
    }

    if ([...params].length > 0) {
      loginRedirect += "?" + params.toString();
    }

    const jsonBodyAsString = '{"${import_types.CONNECTOR_SVC_TRANSIENT_JWT}": "${jwt}"}';

    jQuery.ajax({
      url: loginRedirect,
      method: 'POST',
      contentType: 'application/json',
      headers: ${headers},
      dataType: "json",
      data: jsonBodyAsString
    }).then((response) => {
      try {
        const nextUrl = response.nextUrl;
        // new URL(nextUrl, window.location.origin) resolves relative paths (e.g. /app/kibana)
        // against the current origin for the same-origin check. window.location.href then uses
        // nextUrl as-is. Defense-in-depth: the server-side check in authController.ts buildNextUrl
        // is the primary guard; this check is the second line of defense.
        const parsed = nextUrl && new URL(nextUrl, window.location.origin);
        if (parsed && parsed.origin === window.location.origin) {
          window.location.href = nextUrl;
        } else {
          console.warn('JWT redirect: invalid or missing nextUrl, falling back to home. nextUrl:', nextUrl);
          window.location.href = "${this.basePath}/";
        }
      } catch (e) {
        console.error('JWT redirect unhandled error:', e);
        window.location.href = "${this.basePath}/";
      }
    }).fail((jqXHR, textStatus, errorThrown) => {
      console.error("JWT redirect failed:", textStatus, errorThrown);
      window.location.href = "${this.basePath}/login";
    });

    </script>`);
    __publicField(this, "serveDependenciesAutomaticallyFromNodeModules", (req, res) => {
      var _a, _b;
      const pathRequested = import_sanitizer.default.sanitize((_b = (_a = req == null ? void 0 : req.query) == null ? void 0 : _a.file) == null ? void 0 : _b.toString());
      if ((pathRequested == null ? void 0 : pathRequested.indexOf("..")) >= 0) {
        const msg = "You cannot navigate backwards..";
        this.logger.warn(msg);
        return res.status(403).send(msg);
      }
      const path2serve = `${__dirname}/../../../node_modules/${pathRequested}`.replace("//", "/");
      this.logger.debug(`Fetching frontend dependency: ${path2serve}`);
      const callback = (err, data) => {
        if (err) {
          const msg = `Something went wrong with finding the dependency: ${err.message}`;
          this.logger.warn(msg, err);
          return res.status(404).send("Something went wrong with finding the dependency. See errors in Kibana logs.");
        }
        if (path2serve.endsWith(".js")) {
          res.setHeader(import_types.CONTENT_TYPE_HEADER, APPLICATION_JAVASCRIPT_UTF8);
        } else if (path2serve.endsWith(".css")) {
          res.setHeader(import_types.CONTENT_TYPE_HEADER, TEXT_CSS_UTF8);
        } else {
          const msg = `File extension not allowed: ${pathRequested}`;
          this.logger.warn(msg, err);
          return res.status(403).send("File extension not allowed. See errors in Kibana logs.");
        }
        return res.send(data);
      };
      import_fs_extra.default.readFile(path2serve, "utf8", (err, data) => {
        try {
          callback(err, data);
        } catch (e) {
          this.logger.error({ message: `Autodeps failed to serve ${pathRequested}`, stack: e.stack });
        }
      });
      return res;
    });
    __publicField(this, "renderTenancyInjector", async (request, res) => {
      var _a;
      const userRequestIdentity = await request.rorRequest.getUserRequestIdentity();
      const metadata = userRequestIdentity.metadata;
      const templateArgs = {
        defaultEncryptedTenancyContext: this.tenancyService.buildEncryptedTenancyContext(
          (0, import_TenancyContext.tenancyFromKibanaIndex)((_a = metadata.currentGroup) == null ? void 0 : _a.id, metadata.kibanaIndex)
        )
      };
      const javascript = (0, import_templateCompiler.compile)("../../injection/scripts/tenancyContextInjector.js", templateArgs);
      return this.renderJs(res, javascript);
    });
    __publicField(this, "renderJs", (res, javascript) => {
      res.setHeader(import_types.CONTENT_TYPE_HEADER, APPLICATION_JAVASCRIPT_UTF8);
      return res.send(javascript);
    });
    __publicField(this, "buildLoginTemplateArgs", (csrfToken) => {
      var _a, _b, _c, _d, _e, _f;
      const { clearSessionOnEvents } = this.rorSettingsStore.getLatestRorKbnSettings();
      const license = this.licenseService.getActivationKey().license;
      const isEnterprise = (0, import_ActivationKey.isEnterpriseLicense)(license);
      const isFree = (0, import_ActivationKey.isFreeLicense)(license);
      const title = isFree ? null : (_a = this.loginPageCustomizations) == null ? void 0 : _a.title;
      const subtitle = isFree ? null : (_b = this.loginPageCustomizations) == null ? void 0 : _b.subtitle;
      const logoPath = isFree ? null : (_c = this.loginPageCustomizations) == null ? void 0 : _c.logoPath;
      const headInject = isFree ? null : (_d = this.loginPageCustomizations) == null ? void 0 : _d.htmlHeadInject;
      const customJSInject = isFree ? null : (_e = this.loginPageCustomizations) == null ? void 0 : _e.customJSInjectFile;
      const customCSSInject = isFree ? null : (_f = this.loginPageCustomizations) == null ? void 0 : _f.customCSSInjectFile;
      const ssoConnectors = isEnterprise ? this.buildSSOButtonProps(this.samlRouterSettingsList, this.oidcRouterSettingsList) : [];
      const activationKey = this.licenseService.getActivationKey();
      return {
        basePath: this.basePath,
        kbnVersion: import_distributionInfoProvider.DistributionInfoProvider.getInstance().kibanaVersion,
        logoutUrl: `${this.basePath}/logout`,
        loginUrl: `${this.basePath}/login`,
        ssoConnectors: JSON.stringify(ssoConnectors),
        clearSessionOnEvents: JSON.stringify(clearSessionOnEvents),
        year: (/* @__PURE__ */ new Date()).getFullYear(),
        edition: activationKey.license.edition,
        editionDisplayName: activationKey.license.edition_name,
        loginLogo: logoPath || `${this.basePath}/pkp/legacy/web/assets/readonlyrest_square_white.png`,
        loginTitle: title || "",
        loginSubtitle: subtitle || "",
        columns: !title && !subtitle ? 1 : 2,
        headInject: headInject || "",
        customJSInject: customJSInject || "",
        customCSSInject: `<style>${customCSSInject}</style>` || "",
        message: "",
        csrfToken,
        csrfHeaderName: import_csrf.Csrf.CSRF_HEADER_NAME
      };
    });
    __publicField(this, "buildSwitchGroupTemplateArgs", ({
      newEncryptedTenancyContext
    } = {}) => ({
      basePath: this.basePath,
      tenancyQueryStringKey: import_queryStringKeys.TENANCY_QUERY_STRING_KEY,
      newEncryptedTenancyContext
    }));
    rorSettingsStore.observerRorKbnSettings(({ customUXCodeInjection, loginPageCustomizations }) => ({
      customUXCodeInjection,
      loginPageCustomizations
    })).subscribe(({ customUXCodeInjection, loginPageCustomizations }) => {
      const jsInline = customUXCodeInjection == null ? void 0 : customUXCodeInjection.js;
      const jsFile = customUXCodeInjection == null ? void 0 : customUXCodeInjection.jsFileContent;
      let mixedCustomJsContentInjection;
      if (jsInline && jsFile) {
        mixedCustomJsContentInjection = `
        ${jsInline}
    ${jsFile}`;
      } else if (jsInline) {
        mixedCustomJsContentInjection = `
        ${jsInline}
`;
      } else if (jsFile) {
        mixedCustomJsContentInjection = `

    ${jsFile}`;
      }
      this.logger.trace(
        `Injecting custom user js: ${Boolean(customUXCodeInjection == null ? void 0 : customUXCodeInjection.js)}. Injecting custom user js for the login page: ${Boolean(loginPageCustomizations)}. Injecting custom user js file content: ${Boolean(customUXCodeInjection == null ? void 0 : customUXCodeInjection.jsFileContent)}`
      );
      this.injectCustomJs = LegacyRenderer.buildCustomJsInjection(mixedCustomJsContentInjection);
      this.loginPageCustomizations = loginPageCustomizations;
    });
  }
  renderRedirect(url) {
    return `<script>console.log("redirecting to ${url}"); window.location.href = '${url}'</script>`;
  }
  static resolveJwtRedirectTarget(nextUrl, origin, basePath) {
    try {
      if (nextUrl && typeof nextUrl === "string") {
        const parsed = new URL(nextUrl, origin);
        if (parsed.origin === origin) {
          return nextUrl;
        }
      }
    } catch {
    }
    return `${basePath}/`;
  }
  static buildCustomJsInjection(customJsInjection) {
    return function(rorMetadata) {
      if (customJsInjection == null) {
        return "";
      }
      return `
        const kibanaLoaded = new Promise((resolve) => {
        new MutationObserver((mutations, observer) => {
          for (const mutation of mutations) {
            for (const removedNode of mutation.removedNodes) {
              const kibanaSpinnerId = 'kbn_loading_message';
              if(removedNode.id === kibanaSpinnerId) {
                observer.disconnect();
                resolve();
                break;
              }
            }
          }
        })
          .observe(document.body, { childList: true  });
      });

      kibanaLoaded.then(() => {
        window.ROR_METADATA = ${JSON.stringify(rorMetadata)};${customJsInjection}
      });
    `;
    };
  }
  buildSSOButtonProps(samlRouterSettingsFactory, oidcRouterSettingsFactory) {
    return samlRouterSettingsFactory.getSettingsList().map((settings) => settings.toLegacySsoButtonProps()).concat(oidcRouterSettingsFactory.getSettingsList().map((settings) => settings.toLegacySsoButtonProps()));
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LegacyRenderer
});
