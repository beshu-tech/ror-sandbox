"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var logoutLinkProvider_exports = {};
__export(logoutLinkProvider_exports, {
  LogoutLinkProvider: () => LogoutLinkProvider
});
module.exports = __toCommonJS(logoutLinkProvider_exports);
var import_types = require("../../core/common/types");
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
const _LogoutLinkProvider = class _LogoutLinkProvider {
  constructor(kibanaBasePath, samlRouterSettingsFactory, oidcRouterSettingsFactory, rorSettingsStore) {
    this.kibanaBasePath = kibanaBasePath;
    this.samlRouterSettingsFactory = samlRouterSettingsFactory;
    this.oidcRouterSettingsFactory = oidcRouterSettingsFactory;
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "withBasePath", (path) => this.kibanaBasePath + path);
  }
  resolveLogoutLink(userRequestIdentityMetadata) {
    const originFromSession = userRequestIdentityMetadata.origin;
    if (originFromSession) {
      return this.buildLogoutForAuthProviderLink(userRequestIdentityMetadata);
    }
    return this.buildRorLogoutLink();
  }
  buildRorLogoutRedirectLink(userRequestIdentityMetadata) {
    const { customLogoutLink } = this.rorSettingsStore.getLatestRorKbnSettings();
    if (customLogoutLink == null) {
      return this.buildLoginLink(userRequestIdentityMetadata);
    }
    return this.buildCustomLogoutLink(userRequestIdentityMetadata);
  }
  resolveSsoLogoutLink(connectorName) {
    var _a;
    const samlSettings = this.samlRouterSettingsFactory.getSettingsList().find((settings) => settings.connectorName === connectorName);
    if (samlSettings) return samlSettings.logoutPathRelativeToRoot();
    return (_a = this.oidcRouterSettingsFactory.getSettingsList().find((settings) => settings.connectorName === connectorName)) == null ? void 0 : _a.logoutPathRelativeToRoot();
  }
  buildRorLogoutLink() {
    return this.withBasePath(_LogoutLinkProvider.ROR_LOGOUT_LINK);
  }
  buildLogoutForAuthProviderLink(userRequestIdentityMetadata) {
    const samlRouterSettings = this.samlRouterSettingsFactory.getSettingsList().find((settings) => settings.connectorName === userRequestIdentityMetadata.origin);
    if (samlRouterSettings) {
      return samlRouterSettings.logoutPathRelativeToRoot();
    }
    const oidcRouterSettings = this.oidcRouterSettingsFactory.getSettingsList().find((settings) => settings.connectorName === userRequestIdentityMetadata.origin);
    if (oidcRouterSettings) {
      return oidcRouterSettings.logoutPathRelativeToRoot();
    }
    return this.buildLoginLink(userRequestIdentityMetadata);
  }
  buildLoginLink(userRequestIdentityMetadata) {
    const { proxyAuthSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    return this.buildDefaultLoginLink(
      Boolean((proxyAuthSettings == null ? void 0 : proxyAuthSettings.enabled) && this.isProxyAuthHeaderSupplied(userRequestIdentityMetadata))
    );
  }
  isProxyAuthHeaderSupplied(userRequestIdentityMetadata) {
    var _a;
    const { proxyAuthSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    return (userRequestIdentityMetadata == null ? void 0 : userRequestIdentityMetadata.whitelistedHeaders.get((_a = proxyAuthSettings == null ? void 0 : proxyAuthSettings.forward_auth_header) != null ? _a : "")) != null;
  }
  buildDefaultLoginLink(autologinDisabled) {
    return this.withBasePath(autologinDisabled ? `/login?${import_types.AUTOLOGIN_QUERY_PARAM}=false` : "/login");
  }
  buildCustomLogoutLink(userRequestIdentityMetadata) {
    const originFromSession = userRequestIdentityMetadata == null ? void 0 : userRequestIdentityMetadata.origin;
    const customLogoutLink = this.replaceIdentityVariables(userRequestIdentityMetadata);
    const customLogoutUrl = new URL(
      (customLogoutLink == null ? void 0 : customLogoutLink.includes("://")) ? customLogoutLink : `http://${customLogoutLink}`
    );
    if (customLogoutUrl.searchParams.has(import_types.X_ROR_ORIGIN)) {
      return customLogoutUrl.toString();
    }
    customLogoutUrl.searchParams.set(
      import_types.X_ROR_ORIGIN,
      originFromSession || _LogoutLinkProvider.CUSTOM_LOGOUT_LINK_PARAM_VALUE
    );
    return customLogoutUrl.toString();
  }
  replaceIdentityVariables(userRequestIdentityMetadata) {
    const { customLogoutLink } = this.rorSettingsStore.getLatestRorKbnSettings();
    this.logger.trace("Beginning to replace identity variables in the custom logout url");
    if (!(customLogoutLink == null ? void 0 : customLogoutLink.includes("@{identity")) || !userRequestIdentityMetadata) {
      this.logger.debug("No identity variables found in the custom logout url or identity session metadata is empty");
      return customLogoutLink;
    }
    let logoutLinkWithReplacedVariables = customLogoutLink;
    Object.entries(userRequestIdentityMetadata).forEach(([key, value]) => {
      if (value) {
        const valueSerialized = JSON.stringify(value);
        this.logger.trace(`Replacing @{identity:${key}} with ${valueSerialized}`);
        logoutLinkWithReplacedVariables = logoutLinkWithReplacedVariables.replace(
          `@{identity:${key}}`,
          valueSerialized
        );
      }
    });
    this.logger.debug(`Replaced identity variables. The new logout url is: ${logoutLinkWithReplacedVariables}`);
    return logoutLinkWithReplacedVariables;
  }
};
__publicField(_LogoutLinkProvider, "ROR_LOGOUT_LINK", "/logout");
__publicField(_LogoutLinkProvider, "CUSTOM_LOGOUT_LINK_PARAM_VALUE", "custom_logout_link");
let LogoutLinkProvider = _LogoutLinkProvider;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LogoutLinkProvider
});
