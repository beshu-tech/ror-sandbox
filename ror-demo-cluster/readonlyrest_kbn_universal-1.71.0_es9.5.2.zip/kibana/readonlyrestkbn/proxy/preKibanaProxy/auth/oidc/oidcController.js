"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var oidcController_exports = {};
__export(oidcController_exports, {
  OidcController: () => OidcController
});
module.exports = __toCommonJS(oidcController_exports);
var import_crypto = require("crypto");
var import_queryStringKeys = require("../../../../shared/constants/queryStringKeys");
var import_types = require("../../../core/common/types");
var import_urlUtils = require("../../../core/common/urlUtils");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_csrf = require("../csrf");
var import_oidcSessionProfileResolver = require("./oidcSessionProfileResolver");
class OidcController {
  constructor(settings, jwtSigner, legacyRenderer, ssoSessionService, ssoLogoutTransactionCookieService, localFinalizationHandler) {
    this.settings = settings;
    this.jwtSigner = jwtSigner;
    this.legacyRenderer = legacyRenderer;
    this.ssoLogoutTransactionCookieService = ssoLogoutTransactionCookieService;
    this.localFinalizationHandler = localFinalizationHandler;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "sessionProfileResolver");
    __publicField(this, "onLoginCallback", (req, res) => {
      const profile = req.session.user;
      if (!profile) {
        this.logger.error({ message: "User is not defined" });
        return;
      }
      const user = profile[this.settings.usernameParameter];
      this.logger.debug(`Obtained user name from profile: ${user}`);
      const groups = this.getGroups(profile);
      this.logger.debug(`Obtained groups from profile: ${groups}`);
      const jwt = this.createJWT(user, groups, profile);
      const csrfToken = import_csrf.Csrf.generateToken(res, req);
      const headers = {
        [import_csrf.Csrf.CSRF_HEADER_NAME]: csrfToken
      };
      const redirectLoginBody = this.legacyRenderer.renderJwtRedirect(jwt, JSON.stringify(headers));
      res.send(redirectLoginBody);
    });
    __publicField(this, "onLogout", async (req, res) => {
      OidcController.captureLogoutRedirectParams(req);
      try {
        const userInfo = JSON.stringify(req.session.user);
        const sessionProfile = await this.sessionProfileResolver.resolve(req);
        if (!sessionProfile) {
          this.logger.warn(
            `${this.settings.connectorName}: No valid OIDC session profile available, falling back to local logout only`
          );
          return this.localFinalizationHandler(req, res);
        }
        const logoutUrl = sessionProfile.endSessionUrl;
        this.logger.trace(`Logout called for user: ${userInfo}. redirecting to ${logoutUrl}`);
        const sid = await req.rorRequest.getSid();
        if (sid === null) {
          throw new Error(
            `${this.settings.connectorName}: Expected a ROR session SID when redirecting to the IdP for logout`
          );
        }
        const nonce = (0, import_crypto.randomBytes)(16).toString("hex");
        await this.ssoLogoutTransactionCookieService.markTransaction(res, sid, this.settings.connectorName, nonce);
        const state = await this.ssoLogoutTransactionCookieService.createStateToken(
          sid,
          this.settings.connectorName,
          nonce
        );
        return res.redirect((0, import_urlUtils.appendQueryParam)(logoutUrl, "state", state));
      } catch {
        this.logger.warn(
          `${this.settings.connectorName}: OIDC protocol logout could not be initiated; falling back to local logout. The IdP session may remain active.`
        );
        return this.localFinalizationHandler(req, res);
      }
    });
    __publicField(this, "onLogoutCallback", async (req, res, next) => {
      const state = req.query.state;
      const sid = await req.rorRequest.getSid().catch(() => null);
      if (typeof state !== "string" || !sid) {
        this.logger.warn(`${this.settings.connectorName}: Logout callback missing state or session SID; rejecting`);
        res.status(400).send("Missing state parameter or session");
        return;
      }
      const stateNonce = await this.ssoLogoutTransactionCookieService.verifyStateToken(
        state,
        sid,
        this.settings.connectorName
      );
      if (stateNonce === null) {
        this.logger.warn(`${this.settings.connectorName}: Logout callback state verification failed; rejecting`);
        res.status(400).send("Invalid state parameter");
        return;
      }
      const logoutRedirectParams = req.session.logoutRedirectParams;
      await new Promise((resolve) => {
        req.logout(async (err) => {
          try {
            if (err) {
              this.logger.error({ message: `${this.settings.connectorName} error: ${err.message}`, stack: err.stack });
              next(err);
              return resolve();
            }
            res.clearCookie(this.settings.cookieSettings.name, { path: "/" });
            await this.ssoLogoutTransactionCookieService.markRoundTripAck(res, this.settings.connectorName, stateNonce);
            const logoutRedirectPath = OidcController.buildLogoutRedirectPath(this.settings, logoutRedirectParams);
            this.logger.trace(`Redirecting to ${logoutRedirectPath}`);
            res.send(this.legacyRenderer.renderRedirect(logoutRedirectPath));
          } catch (e) {
            this.logger.error({
              message: `Something went wrong with ${this.settings.connectorName} connector. ${e.message}`,
              stack: e.stack
            });
            next(e);
          } finally {
            resolve();
          }
        });
      });
    });
    this.sessionProfileResolver = new import_oidcSessionProfileResolver.OidcSessionProfileResolver(
      settings.connectorName,
      settings.oidcLogoutUrl,
      ssoSessionService
    );
  }
  // The nextUrl/message query params on the browser's request to this connector's logout path
  // don't survive the external IdP redirect, so they're captured into the connector-specific
  // Passport session here and re-attached to the redirect target in onLogoutCallback.
  // AuthController re-validates nextUrl before use, so no validation is duplicated here.
  static captureLogoutRedirectParams(req) {
    const nextUrl = typeof req.query[import_queryStringKeys.NEXT_URL] === "string" ? req.query[import_queryStringKeys.NEXT_URL] : void 0;
    const message = typeof req.query[import_types.MESSAGE_QUERY_PARAM] === "string" ? req.query[import_types.MESSAGE_QUERY_PARAM] : void 0;
    if (nextUrl || message) {
      req.session.logoutRedirectParams = {
        nextUrl,
        message
      };
    }
  }
  static buildLogoutRedirectPath(settings, params) {
    if (!(params == null ? void 0 : params.nextUrl) && !(params == null ? void 0 : params.message)) {
      return settings.logoutRedirectPath;
    }
    const searchParams = new URLSearchParams();
    if (params.nextUrl) searchParams.set(import_queryStringKeys.NEXT_URL, params.nextUrl);
    if (params.message) searchParams.set(import_types.MESSAGE_QUERY_PARAM, params.message);
    const separator = settings.logoutRedirectPath.includes("?") ? "&" : "?";
    return `${settings.logoutRedirectPath}${separator}${searchParams}`;
  }
  getGroups(user) {
    const groups = user[this.settings.groupsParameter];
    if (!groups) {
      return [];
    }
    if (typeof groups === "string") {
      return groups.split(",");
    }
    return Object.assign([], groups);
  }
  createJWT(user, groups, expressUser) {
    const { rorOidcLogoutUrl, ...assertion } = expressUser;
    delete assertion[this.settings.groupsParameter];
    const claims = {
      user,
      groups,
      assertion,
      [import_types.X_ROR_ORIGIN]: this.settings.connectorName,
      [import_types.SSO_SESSION_PROFILE_CLAIM]: rorOidcLogoutUrl ? {
        protocol: "oidc",
        connectorName: this.settings.connectorName,
        endSessionUrl: rorOidcLogoutUrl
      } : void 0
    };
    this.logger.debug(`Created JWT for ROR for ${this.settings.connectorName}`);
    return this.jwtSigner.sign(claims);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  OidcController
});
