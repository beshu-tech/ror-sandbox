"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var oidcLogoutTransactionCookieService_exports = {};
__export(oidcLogoutTransactionCookieService_exports, {
  OidcLogoutTransactionCookieService: () => OidcLogoutTransactionCookieService
});
module.exports = __toCommonJS(oidcLogoutTransactionCookieService_exports);
var import_iron = __toESM(require("@hapi/iron"));
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_ssoLogoutTransactionCookieService = require("../ssoLogoutTransactionCookieService");
class OidcLogoutTransactionCookieService extends import_ssoLogoutTransactionCookieService.SsoLogoutTransactionCookieService {
  constructor() {
    super(...arguments);
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "markTransaction", async (res, sid, connectorName, nonce) => {
      await this.sealIntent(res, sid, connectorName, "oidc", nonce);
    });
    __publicField(this, "markRoundTripAck", async (res, connectorName, nonce) => {
      await this.sealAck(res, connectorName, "oidc", nonce);
    });
    __publicField(this, "createStateToken", async (sid, connectorName, nonce) => {
      const token = {
        sid,
        action: import_ssoLogoutTransactionCookieService.SSO_LOGOUT_ACTION,
        connectorName,
        protocol: "oidc",
        iat: Date.now(),
        nonce
      };
      return import_iron.default.seal(token, this.cookieConfig.password, this.ironOptions());
    });
    // Nonce is threaded through to markRoundTripAck so the ack can be bound to this exact attempt.
    __publicField(this, "verifyStateToken", async (state, sid, connectorName) => {
      var _a;
      if (typeof state !== "string") return null;
      try {
        const token = await import_iron.default.unseal(state, this.cookieConfig.password, this.ironOptions());
        if (token.action === import_ssoLogoutTransactionCookieService.SSO_LOGOUT_ACTION && token.sid === sid && token.connectorName === connectorName && token.protocol === "oidc") {
          return (_a = token.nonce) != null ? _a : null;
        }
        return null;
      } catch (error) {
        this.logger.debug(`SSO logout state token rejected: ${error.message}`);
        return null;
      }
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  OidcLogoutTransactionCookieService
});
