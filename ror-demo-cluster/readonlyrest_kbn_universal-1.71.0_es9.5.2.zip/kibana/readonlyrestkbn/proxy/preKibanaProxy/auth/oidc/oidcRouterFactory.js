"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var oidcRouterFactory_exports = {};
__export(oidcRouterFactory_exports, {
  OidcRouterFactory: () => OidcRouterFactory
});
module.exports = __toCommonJS(oidcRouterFactory_exports);
var import_cookie_parser = __toESM(require("cookie-parser"));
var express = __toESM(require("express"));
var import_passport = require("passport");
var import_distributionInfoProvider = require("../../../../kibana/patchers/distributionInfoProvider");
var import_timeUtils = require("../../../core/common/timeUtils");
var import_versionedLibraries = require("../../../core/common/versionedLibraries");
var import_cookieManager = require("../../../core/cookieManager");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_oidcController = require("./oidcController");
var import_oidcTransactionCookieMiddleware = require("./oidcTransactionCookieMiddleware");
const PASSPORT_OIDC_STRATEGY = "oidc";
const OIDC_TRANSACTION_TTL_MILLIS = 10 * 60 * 1e3;
const _OidcRouterFactory = class _OidcRouterFactory {
  constructor(jwtSigner, legacyRenderer, ssoSessionService, ssoLogoutTransactionCookieService, localFinalizationHandler) {
    this.jwtSigner = jwtSigner;
    this.legacyRenderer = legacyRenderer;
    this.ssoSessionService = ssoSessionService;
    this.ssoLogoutTransactionCookieService = ssoLogoutTransactionCookieService;
    this.localFinalizationHandler = localFinalizationHandler;
  }
  static get openIdClient() {
    if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("7.12.0")) {
      _OidcRouterFactory.getLogger().warn(
        "Your Kibana version ships with an obsolete Node.js version, incompatible with the most recent OIDC client. WE HIGHLY RECOMMENDED TO UPGRADE TO KIBANA >= 7.12.0 so that ROR can use the most updated, certified OIDC client version with all security fixes applied."
      );
      return require("openid-client-ancient");
    }
    return require("openid-client");
  }
  static buildOidcStrategySettings(settings) {
    var _a, _b, _c, _d, _e;
    const openIdClient = _OidcRouterFactory.openIdClient;
    const issuer = new openIdClient.Issuer({
      issuer: settings.issuer,
      token_endpoint: settings.oidcTokenURL,
      authorization_endpoint: settings.oidcAuthorizationURL,
      userinfo_endpoint: settings.oidcUserInfoURL,
      jwks_uri: settings.jwksURL,
      end_session_endpoint: settings.oidcLogoutUrl,
      ...(_a = settings == null ? void 0 : settings.issuerAdditionalParameters) == null ? void 0 : _a.metadata
    });
    const client = new issuer.Client(
      {
        client_id: settings.clientId,
        client_secret: settings.clientSecret,
        redirect_uris: [settings.loginCallbackURL],
        post_logout_redirect_uris: [settings.oidcLogoutUrl],
        token_endpoint_auth_method: settings.tokenEndpointAuthMethod,
        ...(_b = settings.clientAdditionalParameters) == null ? void 0 : _b.metadata
      },
      (_c = settings == null ? void 0 : settings.clientAdditionalParameters) == null ? void 0 : _c.jwks,
      (_d = settings == null ? void 0 : settings.clientAdditionalParameters) == null ? void 0 : _d.options
    );
    client.authorizationUrl({
      scope: settings.scope
    });
    client[openIdClient.custom.clock_tolerance] = (_e = settings.clockToleranceSeconds) != null ? _e : 0;
    const httpOptions = (options = {}) => {
      var _a2, _b2, _c2;
      if (settings.proxyURL) {
        const isOidcSSL = (_c2 = (_b2 = (_a2 = settings.issuer) == null ? void 0 : _a2.toLowerCase()) == null ? void 0 : _b2.trim()) == null ? void 0 : _c2.startsWith("https");
        if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("7.11.0")) {
          if (isOidcSSL) {
            options.agent = {
              https: new import_versionedLibraries.HttpsProxyAgent(settings.proxyURL, { rejectUnauthorized: false })
            };
          } else {
            options.agent = {
              http: new import_versionedLibraries.HttpProxyAgent(settings.proxyURL)
            };
          }
        } else {
          options.agent = isOidcSSL ? new import_versionedLibraries.HttpsProxyAgent(settings.proxyURL, { rejectUnauthorized: false }) : new import_versionedLibraries.HttpProxyAgent(settings.proxyURL);
        }
      }
      options.timeout = 1e4;
      return options;
    };
    client[openIdClient.custom.http_options] = httpOptions;
    issuer[openIdClient.custom.http_options] = httpOptions;
    return {
      client
    };
  }
  static buildOidcControllerSettings(settings) {
    return {
      connectorName: settings.connectorName,
      usernameParameter: settings.usernameParameter,
      groupsParameter: settings.groupsParameter,
      cookieSettings: settings.cookieSettings,
      logoutPath: settings.logoutPath,
      logoutRedirectPath: settings.logoutRedirectPath,
      oidcLogoutUrl: settings.oidcLogoutUrl
    };
  }
  static configurePassport(oidcStrategy) {
    const passport = new import_passport.Passport();
    passport.serializeUser((user, next) => next(null, user));
    passport.deserializeUser((obj, next) => next(null, obj));
    passport.use(PASSPORT_OIDC_STRATEGY, oidcStrategy);
    return passport;
  }
  build(settings) {
    var _a, _b, _c;
    const oidcStrategy = this.buildOidcStrategy(settings);
    const oidcControllerSettings = _OidcRouterFactory.buildOidcControllerSettings(settings);
    const oidcController = new import_oidcController.OidcController(
      oidcControllerSettings,
      this.jwtSigner,
      this.legacyRenderer,
      this.ssoSessionService,
      this.ssoLogoutTransactionCookieService,
      this.localFinalizationHandler
    );
    const router = express.Router();
    const passport = _OidcRouterFactory.configurePassport(oidcStrategy);
    router.use(express.urlencoded({ extended: true }));
    const isRorSSL = (_c = (_b = (_a = settings.loginCallbackURL) == null ? void 0 : _a.toLowerCase()) == null ? void 0 : _b.trim()) == null ? void 0 : _c.startsWith("https");
    const transactionCookieOptions = import_cookieManager.CookieManager.getCookiesOptions({
      sameSite: "lax",
      secure: isRorSSL,
      maxAge: OIDC_TRANSACTION_TTL_MILLIS
    });
    _OidcRouterFactory.getLogger().trace(
      `${settings.connectorName} will hold the OIDC transaction cookie until ${import_timeUtils.TimeUtils.nowPlusMillis(
        OIDC_TRANSACTION_TTL_MILLIS
      )}.`
    );
    const transactionCookieMiddleware = new import_oidcTransactionCookieMiddleware.OidcTransactionCookieMiddleware({
      cookieName: settings.cookieSettings.name,
      password: settings.cookieSettings.password,
      cookieOptions: transactionCookieOptions,
      ttlMillis: OIDC_TRANSACTION_TTL_MILLIS
    });
    router.use((0, import_cookie_parser.default)());
    router.use(transactionCookieMiddleware.handle);
    router.use(passport.initialize());
    router.get(
      settings.loginPath,
      transactionCookieMiddleware.interceptResponseEnd,
      passport.authenticate(PASSPORT_OIDC_STRATEGY, { failureRedirect: "/", scope: settings.scope })
    );
    router.use(
      settings.loginCallbackPath,
      (req, res) => passport.authenticate(
        PASSPORT_OIDC_STRATEGY,
        { failureRedirect: "/", scope: settings.scope },
        (err, user, info) => {
          if (!user) {
            return this.handleLoginCallbackError(settings, transactionCookieMiddleware, err, req, res, info);
          }
          req.session.user = user;
          transactionCookieMiddleware.clearCookie(res);
          return oidcController.onLoginCallback(req, res);
        }
      )(req, res)
    );
    router.use(settings.logoutPath, transactionCookieMiddleware.interceptResponseEnd, oidcController.onLogout);
    router.use(settings.logoutCallbackPath, oidcController.onLogoutCallback);
    return router;
  }
  handleLoginCallbackError(settings, transactionCookieMiddleware, err, req, res, info) {
    var _a, _b, _c;
    const isRorSSL = (_c = (_b = (_a = settings.loginCallbackURL) == null ? void 0 : _a.toLowerCase()) == null ? void 0 : _b.trim()) == null ? void 0 : _c.startsWith("https");
    const isReverseProxy = req.headers.host !== settings.kibanaExternalHost;
    const missingHttpsForwaredProtoHeader = req.headers["x-forwarded-proto"] !== "https";
    if (isRorSSL && isReverseProxy && missingHttpsForwaredProtoHeader) {
      _OidcRouterFactory.getLogger().error({
        message: `${settings.connectorName} error: If you use a reverse proxy, you need to configure x-forwarded-proto header with an HTTPS value to run the OIDC connector properly`
      });
    }
    _OidcRouterFactory.getLogger().error(
      { message: `${settings.connectorName} error:`, stack: err == null ? void 0 : err.stack },
      (err == null ? void 0 : err.message) || info || res
    );
    req.logout(() => {
      transactionCookieMiddleware.clearCookie(res);
      return res.send(
        `<h2> There was an error in the OIDC connector ${settings.connectorName}</h2>
       <p>For more information, consult the kibana logs.</p>`
      );
    });
  }
  buildOidcStrategy(settings) {
    const strategySettings = _OidcRouterFactory.buildOidcStrategySettings(settings);
    _OidcRouterFactory.getLogger().trace("Strategy settings:", strategySettings);
    return new _OidcRouterFactory.openIdClient.Strategy(
      strategySettings,
      async (tokenset, profile, done) => {
        const logoutUrl = strategySettings.client.endSessionUrl({
          id_token_hint: tokenset.id_token,
          post_logout_redirect_uri: settings.logoutCallbackUrl
        });
        if (settings.userInfoSource === "access_token") {
          try {
            const userinfo = tokenset.access_token ? JSON.parse(Buffer.from(tokenset.access_token.split(".")[1], "base64").toString()) : void 0;
            import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename).debug(`Obtained raw profile from access_token`, userinfo);
            return done(null, { ...userinfo, rorOidcLogoutUrl: logoutUrl });
          } catch (error) {
            import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename).error({
              message: `Error fetching userinfo: ${error.message}`,
              stack: error.stack
            });
            return done(error);
          }
        }
        if (settings.userInfoSource === "id_token") {
          try {
            const userinfo = tokenset.claims();
            import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename).debug(`Obtained raw profile from id_token`, userinfo);
            return done(null, { ...userinfo, rorOidcLogoutUrl: logoutUrl });
          } catch (error) {
            import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename).error({
              message: `Error fetching userinfo: ${error.message}`,
              stack: error.stack
            });
            return done(error);
          }
        }
        import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename).debug(`Obtained raw profile: ${JSON.stringify(profile)}`);
        return done(null, { ...profile, rorOidcLogoutUrl: logoutUrl });
      }
    );
  }
};
__publicField(_OidcRouterFactory, "getLogger", () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let OidcRouterFactory = _OidcRouterFactory;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  OidcRouterFactory
});
