"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var oidcRouterSettings_exports = {};
__export(oidcRouterSettings_exports, {
  OidcRouterSettings: () => OidcRouterSettings,
  OidcRouterSettingsList: () => OidcRouterSettingsList
});
module.exports = __toCommonJS(oidcRouterSettings_exports);
var import_basePathBuilder = require("../../../core/basePath/basePathBuilder");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_logoutLinkProvider = require("../logoutLinkProvider");
const SSO_PREFIX = "ror_kbn_";
const ROUTES = {
  LOGIN: "/login-ep",
  LOGOUT: "/logout-oidc",
  LOGIN_CALLBACK: "/callback",
  LOGOUT_CALLBACK: "/logout-callback"
};
class OidcRouterSettings {
  constructor(basePathSettings, config, cookieSettings) {
    __publicField(this, "connectorName");
    __publicField(this, "buttonName");
    __publicField(this, "routerPath");
    __publicField(this, "scope");
    __publicField(this, "issuer");
    __publicField(this, "usernameParameter");
    __publicField(this, "groupsParameter");
    __publicField(this, "clientId");
    __publicField(this, "clientSecret");
    __publicField(this, "oidcTokenURL");
    __publicField(this, "oidcAuthorizationURL");
    __publicField(this, "oidcUserInfoURL");
    __publicField(this, "oidcLogoutUrl");
    __publicField(this, "loginPath");
    __publicField(this, "logoutPath");
    __publicField(this, "loginCallbackPath");
    __publicField(this, "logoutCallbackPath");
    __publicField(this, "loginCallbackURL");
    __publicField(this, "logoutCallbackUrl");
    __publicField(this, "logoutRedirectPath");
    __publicField(this, "jwksURL");
    __publicField(this, "kibanaExternalHost");
    __publicField(this, "proxyURL");
    __publicField(this, "clockToleranceSeconds");
    __publicField(this, "tokenEndpointAuthMethod");
    __publicField(this, "userInfoSource");
    __publicField(this, "issuerAdditionalParameters");
    __publicField(this, "clientAdditionalParameters");
    __publicField(this, "cookieSettings");
    __publicField(this, "routerPathRelativeToRoot");
    const { withBasePathPrefix } = new import_basePathBuilder.BasePathBuilder(basePathSettings);
    this.connectorName = config.name;
    this.buttonName = config.buttonName;
    this.routerPath = `/${SSO_PREFIX}${config.name}`;
    this.routerPathRelativeToRoot = withBasePathPrefix(this.routerPath, true);
    this.scope = config.scope;
    this.issuer = config.issuer;
    this.usernameParameter = config.usernameParameter;
    this.groupsParameter = config.groupsParameter;
    this.clientId = config.clientId;
    this.clientSecret = config.clientSecret;
    this.oidcTokenURL = config.tokenURL;
    this.oidcAuthorizationURL = config.authorizationURL;
    this.oidcUserInfoURL = config.userInfoURL;
    this.oidcLogoutUrl = config.logoutUrl;
    this.loginPath = ROUTES.LOGIN;
    this.logoutPath = ROUTES.LOGOUT;
    this.loginCallbackPath = ROUTES.LOGIN_CALLBACK;
    this.logoutCallbackPath = ROUTES.LOGOUT_CALLBACK;
    this.logoutRedirectPath = `${withBasePathPrefix(import_logoutLinkProvider.LogoutLinkProvider.ROR_LOGOUT_LINK, true)}?ssoLogoutCompleted=true`;
    this.loginCallbackURL = `${config.protocol}://${config.kibanaExternalHost + this.routerPathRelativeToRoot + ROUTES.LOGIN_CALLBACK}`;
    this.logoutCallbackUrl = `${config.protocol}://${config.kibanaExternalHost + this.routerPathRelativeToRoot + ROUTES.LOGOUT_CALLBACK}`;
    this.cookieSettings = {
      name: `${cookieSettings.name}_${config.name}`,
      password: cookieSettings.password
    };
    this.jwksURL = config.jwksURL;
    this.kibanaExternalHost = config.kibanaExternalHost;
    this.proxyURL = config.proxyURL;
    this.clockToleranceSeconds = config.clockToleranceSeconds;
    this.tokenEndpointAuthMethod = config.tokenEndpointAuthMethod;
    this.userInfoSource = config.userInfoSource;
    this.issuerAdditionalParameters = config.issuerAdditionalParameters;
    this.clientAdditionalParameters = config.clientAdditionalParameters;
  }
  loginPathRelativeToRoot() {
    return `${this.routerPathRelativeToRoot}${this.loginPath}`;
  }
  logoutPathRelativeToRoot() {
    return `${this.routerPathRelativeToRoot}${this.logoutPath}`;
  }
  toLegacySsoButtonProps() {
    return {
      name: this.connectorName,
      type: "oidc",
      buttonName: this.buttonName,
      loginUrl: this.loginPathRelativeToRoot()
    };
  }
}
class OidcRouterSettingsList {
  constructor(basePathSettings, rorSettingsStore) {
    this.basePathSettings = basePathSettings;
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  getSettingsList() {
    const { authSettings, cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    if (!authSettings) {
      return [];
    }
    if (!OidcRouterSettingsList.signatureKeyExists(authSettings)) {
      this.logger.info("No auth.signature_key set");
      return [];
    }
    if (!OidcRouterSettingsList.oidcConfigurationsExist(authSettings)) {
      this.logger.info("No OIDC configurations found");
      return [];
    }
    const configs = authSettings.oidcRawSettingsList.filter((config) => config.enabled);
    if (configs.length === 0) {
      this.logger.info("No enabled OIDC configurations found");
      return [];
    }
    return configs.map((config) => new OidcRouterSettings(this.basePathSettings, config, cookieSettings));
  }
  static signatureKeyExists(auth) {
    return Boolean(auth.signatureKey);
  }
  static oidcConfigurationsExist(auth) {
    var _a;
    return ((_a = auth.oidcRawSettingsList) == null ? void 0 : _a.length) !== 0;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  OidcRouterSettings,
  OidcRouterSettingsList
});
