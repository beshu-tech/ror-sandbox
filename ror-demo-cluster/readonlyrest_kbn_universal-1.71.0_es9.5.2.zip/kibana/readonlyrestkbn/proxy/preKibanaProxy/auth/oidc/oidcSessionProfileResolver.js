"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var oidcSessionProfileResolver_exports = {};
__export(oidcSessionProfileResolver_exports, {
  OidcSessionProfileResolver: () => OidcSessionProfileResolver
});
module.exports = __toCommonJS(oidcSessionProfileResolver_exports);
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
class OidcSessionProfileResolver {
  constructor(connectorName, providerEndSessionUrl, ssoSessionService) {
    this.connectorName = connectorName;
    this.ssoSessionService = ssoSessionService;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "expectedOrigin");
    this.expectedOrigin = OidcSessionProfileResolver.parseOrigin(providerEndSessionUrl);
    if (!this.expectedOrigin) {
      this.logger.error({
        message: `${connectorName}: logoutUrl "${providerEndSessionUrl}" is not a valid absolute URL. SSO protocol logout will be disabled for this connector; falling back to local logout only.`
      });
    }
  }
  async resolve(req) {
    const context = req.rorRequest ? await this.ssoSessionService.getSsoSessionProfile(req.rorRequest) : void 0;
    if (!context || context.protocol !== "oidc" || context.connectorName !== this.connectorName) return void 0;
    const endSessionUrl = this.getValidatedEndSessionUrl(context.endSessionUrl);
    return endSessionUrl ? { ...context, endSessionUrl } : void 0;
  }
  getValidatedEndSessionUrl(endSessionUrl) {
    if (!this.expectedOrigin) return void 0;
    const origin = OidcSessionProfileResolver.parseOrigin(endSessionUrl);
    return origin === this.expectedOrigin ? endSessionUrl : void 0;
  }
  static parseOrigin(url) {
    try {
      return new URL(url).origin;
    } catch {
      return void 0;
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  OidcSessionProfileResolver
});
