"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var oidcTransactionCookieMiddleware_exports = {};
__export(oidcTransactionCookieMiddleware_exports, {
  OidcTransactionCookieMiddleware: () => OidcTransactionCookieMiddleware
});
module.exports = __toCommonJS(oidcTransactionCookieMiddleware_exports);
var import_iron = __toESM(require("@hapi/iron"));
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
const sessionCompatibilityShape = {
  save: (callback) => callback == null ? void 0 : callback(),
  reload: (callback) => callback == null ? void 0 : callback(),
  destroy: (callback) => callback == null ? void 0 : callback(),
  regenerate: (callback) => callback == null ? void 0 : callback(),
  touch: () => void 0
};
class OidcTransactionCookieMiddleware {
  constructor(config) {
    this.config = config;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    /**
     * Populates req.session from the incoming cookie (or {} if absent/invalid) before the Strategy
     * runs. Mount on the whole router.
     */
    __publicField(this, "handle", async (req, res, next) => {
      var _a;
      try {
        const transaction = await this.readTransaction((_a = req.cookies) == null ? void 0 : _a[this.config.cookieName]);
        req.session = Object.assign(transaction, sessionCompatibilityShape);
        next();
      } catch (error) {
        next(error);
      }
    });
    /**
     * Arranges for req.session to be sealed back into the cookie before the authorization redirect
     * to the IdP is sent. Mount only on the login route, ahead of passport.authenticate(...).
     *
     * openid-client's Strategy does NOT call res.redirect() for this -- Passport's own
     * `strategy.redirect` helper deliberately bypasses it (see passport/lib/middleware/authenticate.js:
     * "NOTE: Do not use res.redirect from Express, because it can't decide what it wants") and instead
     * sets `Location`/`Content-Length` headers and calls `res.end()` directly. res.end() is therefore
     * the only hook available between the Strategy deciding to redirect and the response being sent.
     */
    __publicField(this, "interceptResponseEnd", (req, res, next) => {
      const originalEnd = res.end.bind(res);
      res.end = ((...args) => {
        if (res.headersSent) {
          return originalEnd(...args);
        }
        void this.sealBeforeEnd(req, res, originalEnd, args);
        return res;
      });
      next();
    });
  }
  async seal(transaction) {
    return import_iron.default.seal(transaction, this.config.password, this.ironOptions());
  }
  writeCookie(res, sealedTransaction) {
    res.cookie(this.config.cookieName, sealedTransaction, this.config.cookieOptions);
  }
  clearCookie(res) {
    const { maxAge: _maxAge, ...matchingOptions } = this.config.cookieOptions;
    res.clearCookie(this.config.cookieName, matchingOptions);
  }
  /**
   * Iron.seal is asynchronous, so a sealing failure must stop the response from being sent at all --
   * the application must not redirect to the IdP for a transaction that wasn't durably stored.
   */
  async sealBeforeEnd(req, res, originalEnd, endArgs) {
    var _a;
    try {
      const sealed = await this.seal((_a = req.session) != null ? _a : {});
      this.writeCookie(res, sealed);
      originalEnd(...endArgs);
    } catch (error) {
      this.logger.warn("Failed to seal the OIDC transaction cookie; blocking the redirect to the IdP", error);
      if (!res.headersSent) {
        res.removeHeader("Location");
        res.removeHeader("Content-Length");
        res.statusCode = 500;
        originalEnd();
      }
    }
  }
  async readTransaction(cookieValue) {
    if (!cookieValue) {
      return {};
    }
    try {
      return await import_iron.default.unseal(cookieValue, this.config.password, this.ironOptions());
    } catch (error) {
      this.logger.warn("OIDC transaction cookie rejected", error);
      return {};
    }
  }
  ironOptions() {
    return { ...import_iron.default.defaults, ttl: this.config.ttlMillis };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  OidcTransactionCookieMiddleware
});
