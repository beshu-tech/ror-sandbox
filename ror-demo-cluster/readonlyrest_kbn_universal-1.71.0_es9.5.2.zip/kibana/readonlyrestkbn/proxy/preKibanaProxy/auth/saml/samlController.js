"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var samlController_exports = {};
__export(samlController_exports, {
  SamlController: () => SamlController
});
module.exports = __toCommonJS(samlController_exports);
var import_queryStringKeys = require("../../../../shared/constants/queryStringKeys");
var import_types = require("../../../core/common/types");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_csrf = require("../csrf");
var import_samlSessionProfileResolver = require("./samlSessionProfileResolver");
class SamlController {
  constructor(settings, samlStrategy, jwtSigner, legacyRenderer, ssoSessionService, ssoLogoutTransactionCookieService, localFinalizationHandler) {
    this.settings = settings;
    this.samlStrategy = samlStrategy;
    this.jwtSigner = jwtSigner;
    this.legacyRenderer = legacyRenderer;
    this.ssoLogoutTransactionCookieService = ssoLogoutTransactionCookieService;
    this.localFinalizationHandler = localFinalizationHandler;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "HEADER_SIZE_MAX", 8192 - "Bearer ".length);
    __publicField(this, "HEADER_SIZE_WATERMARK", this.HEADER_SIZE_MAX * 0.9);
    __publicField(this, "HEADER_SIZE_ADVICE", `Please set "readonlyrest_kbn.logLevel: trace", look for "JWT claims for ROR" in Kibana logs, and inspect for any data duplication in the JSON Object. If no data is being duplicated, this user has too many groups, or the individual group strings length are too long.`);
    __publicField(this, "sessionProfileResolver");
    __publicField(this, "onLoginCallback", (req, res) => {
      var _a;
      const profile = req.session.user;
      if (!profile) {
        this.logger.error({ message: "User is not defined" });
        return;
      }
      const assertion = (_a = profile.getAssertionXml) == null ? void 0 : _a.call(profile);
      this.logger.debug(`Received SAML Assertion response`, JSON.stringify(assertion));
      const user = profile[this.settings.usernameParameter];
      if (!user) {
        this.logger.error({ message: `Obtained unusable user name from profile: ${user}` });
      } else {
        this.logger.debug(`Obtained user name from profile: ${user}`);
      }
      const groups = this.getGroups(profile);
      this.logger.debug(`Obtained groups from profile: ${groups}`);
      const jwt = this.createJWT(user, groups, profile);
      const csrfToken = import_csrf.Csrf.generateToken(res, req);
      const headers = {
        [import_csrf.Csrf.CSRF_HEADER_NAME]: csrfToken
      };
      const redirectLoginBody = this.legacyRenderer.renderJwtRedirect(jwt, JSON.stringify(headers));
      res.send(redirectLoginBody);
    });
    __publicField(this, "onLogout", async (req, res) => {
      SamlController.captureLogoutRedirectParams(req);
      try {
        const profile = await this.sessionProfileResolver.resolve(req);
        if (!profile) {
          this.logger.warn(`Cannot perform SAML logout for ${this.settings.connectorName}: user profile is missing`);
          return this.localFinalizationHandler(req, res);
        }
        return this.samlStrategy.logout(
          { ...req, user: profile },
          // samlStrategy.logout is a third-party Node-style callback API: it doesn't await this
          // callback's returned promise, so any exception thrown here - including from the awaited
          // getSid() below - would otherwise become an unhandled rejection instead of being caught
          // by the try/catch around this method's synchronous invocation. Catch locally instead.
          async (err, uri) => {
            try {
              if (err) {
                this.logger.error({
                  message: `Something went wrong with ${this.settings.connectorName} connector. ${err.message}`,
                  stack: err.stack
                });
                return await this.localFinalizationHandler(req, res);
              }
              const userInfo = JSON.stringify(profile);
              this.logger.trace(`Logout called for user: ${userInfo}. redirecting to ${uri}`);
              if (typeof uri !== "string") {
                return await this.localFinalizationHandler(req, res);
              }
              const sid = await req.rorRequest.getSid();
              if (sid === null) {
                this.logger.error({
                  message: `${this.settings.connectorName}: Expected a ROR session SID when redirecting to the IdP for logout`
                });
                return await this.localFinalizationHandler(req, res);
              }
              await this.ssoLogoutTransactionCookieService.markTransaction(res, sid, this.settings.connectorName);
              return res.redirect(uri);
            } catch (e) {
              this.logger.error({
                message: `Something went wrong with ${this.settings.connectorName} connector. ${e.message}`,
                stack: e.stack
              });
              return this.localFinalizationHandler(req, res);
            }
          }
        );
      } catch (e) {
        this.logger.error({
          message: `Something went wrong with ${this.settings.connectorName} connector. ${e.message}`,
          stack: e.stack
        });
        return this.localFinalizationHandler(req, res);
      }
    });
    __publicField(this, "onLogoutCallback", async (req, res, next) => {
      const userInfo = JSON.stringify(req.session.user);
      this.logger.trace(`Logout callback called for user: ${userInfo}`);
      return this.finishLogout(req, res, next);
    });
    __publicField(this, "onGetMetadata", (req, res) => {
      res.type("application/xml");
      res.send(this.samlStrategy.generateServiceProviderMetadata(null, null));
    });
    this.sessionProfileResolver = new import_samlSessionProfileResolver.SamlSessionProfileResolver(settings.connectorName, ssoSessionService);
  }
  async finishLogout(req, res, next) {
    const logoutRedirectParams = req.session.logoutRedirectParams;
    await new Promise((resolve) => {
      req.logout(async (err) => {
        try {
          if (err) {
            this.logger.error({ message: `${this.settings.connectorName} error: ${err.message}`, stack: err.stack });
            next(err);
            return resolve();
          }
          res.clearCookie(this.settings.cookieSettings.name, { path: "/" });
          await this.ssoLogoutTransactionCookieService.markRoundTripAck(res, this.settings.connectorName);
          res.send(
            this.legacyRenderer.renderRedirect(
              SamlController.buildLogoutRedirectPath(this.settings, logoutRedirectParams)
            )
          );
        } catch (e) {
          this.logger.error({
            message: `Something went wrong with ${this.settings.connectorName} connector. ${e.message}`,
            stack: e.stack
          });
          next(e);
        } finally {
          resolve();
        }
      });
    });
  }
  // The nextUrl/message query params on the browser's request to this connector's logout path
  // don't survive the external IdP redirect, so they're captured into the connector-specific
  // Passport session here and re-attached to the redirect target in finishLogout. AuthController
  // re-validates nextUrl before use, so no validation is duplicated here.
  static captureLogoutRedirectParams(req) {
    const nextUrl = typeof req.query[import_queryStringKeys.NEXT_URL] === "string" ? req.query[import_queryStringKeys.NEXT_URL] : void 0;
    const message = typeof req.query[import_types.MESSAGE_QUERY_PARAM] === "string" ? req.query[import_types.MESSAGE_QUERY_PARAM] : void 0;
    if (nextUrl || message) {
      req.session.logoutRedirectParams = { nextUrl, message };
    }
  }
  static buildLogoutRedirectPath(settings, params) {
    if (!(params == null ? void 0 : params.nextUrl) && !(params == null ? void 0 : params.message)) {
      return settings.logoutRedirectPath;
    }
    const searchParams = new URLSearchParams();
    if (params.nextUrl) searchParams.set(import_queryStringKeys.NEXT_URL, params.nextUrl);
    if (params.message) searchParams.set(import_types.MESSAGE_QUERY_PARAM, params.message);
    const separator = settings.logoutRedirectPath.includes("?") ? "&" : "?";
    return `${settings.logoutRedirectPath}${separator}${searchParams}`;
  }
  getGroups(user) {
    const groups = user[this.settings.groupsParameter];
    if (!groups) {
      return [];
    }
    if (typeof groups === "string") {
      return groups.split(",");
    }
    return Object.assign([], groups);
  }
  createJWT(user, groups, expressUser) {
    const logoutProfile = expressUser;
    const assertion = { ...expressUser };
    try {
      delete assertion[this.settings.groupsParameter];
      delete assertion.attributes;
    } catch (e) {
      this.logger.warn(`Could not remove groups from assertion: ${e}`);
    }
    const claims = {
      user,
      groups,
      assertion,
      [import_types.X_ROR_ORIGIN]: this.settings.connectorName,
      [import_types.SSO_SESSION_PROFILE_CLAIM]: {
        protocol: "saml",
        connectorName: this.settings.connectorName,
        nameID: logoutProfile.nameID,
        nameIDFormat: logoutProfile.nameIDFormat,
        sessionIndex: logoutProfile.sessionIndex,
        nameQualifier: logoutProfile.nameQualifier,
        spNameQualifier: logoutProfile.spNameQualifier
      }
    };
    this.logger.trace(`JWT claims for ROR for ${this.settings.connectorName}`, claims);
    const encodedJWT = this.jwtSigner.sign(claims);
    const jwtSize = Buffer.byteLength(encodedJWT, "utf8");
    const jwtSizeInfo = `(size: ${jwtSize} of ${this.HEADER_SIZE_MAX} Bytes)`;
    if (jwtSize >= this.HEADER_SIZE_MAX) {
      this.logger.error({ message: `Too large JWT token size ${jwtSizeInfo}! ${this.HEADER_SIZE_ADVICE}` });
    } else if (jwtSize >= this.HEADER_SIZE_WATERMARK) {
      this.logger.warn(`JWT token size is approaching the limit ${jwtSizeInfo}! ${this.HEADER_SIZE_ADVICE}`);
    }
    this.logger.debug(`Created JWT for ROR for ${this.settings.connectorName}, ${jwtSizeInfo}`);
    return encodedJWT;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SamlController
});
