"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var samlRouterFactory_exports = {};
__export(samlRouterFactory_exports, {
  SamlRouterFactory: () => SamlRouterFactory
});
module.exports = __toCommonJS(samlRouterFactory_exports);
var import_cookie_parser = __toESM(require("cookie-parser"));
var express = __toESM(require("express"));
var import_express_session = __toESM(require("express-session"));
var import_passport = require("passport");
var import_timeUtils = require("../../../core/common/timeUtils");
var import_versionedLibraries = require("../../../core/common/versionedLibraries");
var import_cookieManager = require("../../../core/cookieManager");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_samlController = require("./samlController");
const PASSPORT_SAML_STRATEGY = "saml";
const _SamlRouterFactory = class _SamlRouterFactory {
  constructor(jwtSigner, legacyRenderer, ssoSessionService, ssoLogoutTransactionCookieService, localFinalizationHandler) {
    this.jwtSigner = jwtSigner;
    this.legacyRenderer = legacyRenderer;
    this.ssoSessionService = ssoSessionService;
    this.ssoLogoutTransactionCookieService = ssoLogoutTransactionCookieService;
    this.localFinalizationHandler = localFinalizationHandler;
  }
  build(settings) {
    var _a, _b, _c;
    const samlStrategy = this.buildSamlStrategy(settings);
    const samlControllerSettings = _SamlRouterFactory.buildSamlControllerSettings(settings);
    const samlController = new import_samlController.SamlController(
      samlControllerSettings,
      samlStrategy,
      this.jwtSigner,
      this.legacyRenderer,
      this.ssoSessionService,
      this.ssoLogoutTransactionCookieService,
      this.localFinalizationHandler
    );
    const router = express.Router();
    const passport = _SamlRouterFactory.configurePassport(samlStrategy);
    router.use(express.urlencoded({ extended: true }));
    router.use((0, import_cookie_parser.default)());
    const cookieOptions = import_cookieManager.CookieManager.getCookiesOptions();
    cookieOptions.secure = (_b = (_a = settings.callbackURL) == null ? void 0 : _a.toLowerCase()) == null ? void 0 : _b.trim().startsWith("https");
    _SamlRouterFactory.getLogger().trace(
      `${settings.connectorName} will set a cookie valid for ${import_timeUtils.TimeUtils.nowPlusMillis(
        (_c = cookieOptions == null ? void 0 : cookieOptions.maxAge) != null ? _c : 0
      )} minutes.`
    );
    const sessionOptions = {
      name: settings.cookieSettings.name,
      secret: settings.cookieSettings.password,
      cookie: cookieOptions,
      resave: false,
      saveUninitialized: false,
      unset: "destroy"
    };
    router.use((0, import_express_session.default)(sessionOptions));
    router.use(passport.initialize());
    router.use(passport.session());
    router.get("metadata.xml", samlController.onGetMetadata);
    router.get(
      settings.loginPath,
      passport.authenticate(PASSPORT_SAML_STRATEGY, (err) => {
        if (err) {
          _SamlRouterFactory.getLogger().error({
            message: `${settings.connectorName} error: ${err == null ? void 0 : err.message}`,
            stack: err == null ? void 0 : err.stack
          });
        }
      })
    );
    router.use(settings.loginCallbackPath, _SamlRouterFactory.rejectUnsignedRedirectBindingSamlMessage);
    router.use(settings.logoutCallbackPath, _SamlRouterFactory.rejectUnsignedRedirectBindingSamlMessage);
    router.use(
      settings.loginCallbackPath,
      (req, res, next) => passport.authenticate(
        PASSPORT_SAML_STRATEGY,
        { failureRedirect: "/", failureFlash: true },
        (err, user, info) => {
          if (!user) {
            return this.handleLoginCallbackError(settings, err, req, res, info);
          }
          req.session.user = user;
          return samlController.onLoginCallback(req, res);
        }
      )(req, res, next)
    );
    router.use(settings.loginCallbackPath, samlController.onLogoutCallback);
    router.use(settings.logoutPath, samlController.onLogout);
    router.use(
      settings.logoutCallbackPath,
      (req, res, next) => passport.authenticate(PASSPORT_SAML_STRATEGY, (err, user) => {
        var _a2;
        if (err || !user) {
          _SamlRouterFactory.getLogger().error({
            message: `${settings.connectorName} SLO callback rejected: ${(_a2 = err == null ? void 0 : err.message) != null ? _a2 : "validation failed"}`
          });
          return res.status(400).send("SAML LogoutResponse validation failed");
        }
        next();
      })(req, res, next)
    );
    router.use(settings.logoutCallbackPath, samlController.onLogoutCallback);
    return router;
  }
  static buildSamlStrategySettings(settings) {
    const samlStrategySettings = {
      protocol: settings.protocol,
      entryPoint: settings.entryPoint,
      issuer: settings.issuer,
      callbackUrl: settings.callbackURL,
      logoutCallbackUrl: settings.logoutCallbackUrl,
      decryptionPvk: settings.decryptionPvk
    };
    if (import_versionedLibraries.passportSaml.isAncient) {
      samlStrategySettings.cert = settings.cert;
    } else {
      samlStrategySettings.idpCert = settings.cert;
      samlStrategySettings.wantAssertionsSigned = false;
    }
    if (settings.disableRequestedAuthnContext) {
      samlStrategySettings.disableRequestedAuthnContext = settings.disableRequestedAuthnContext;
    }
    if (settings.authnContext) {
      samlStrategySettings.authnContext = settings.authnContext;
    }
    if (settings.identifierFormat || settings.identifierFormat === null) {
      samlStrategySettings.identifierFormat = settings.identifierFormat;
    }
    if (settings.privateCert) {
      samlStrategySettings.privateCert = settings.privateCert;
    }
    if (settings.decryptionPvk) {
      samlStrategySettings.decryptionPvk = settings.decryptionPvk;
    }
    return Object.assign(samlStrategySettings, settings.extraSettings);
  }
  static buildSamlControllerSettings(settings) {
    return {
      connectorName: settings.connectorName,
      usernameParameter: settings.usernameParameter,
      groupsParameter: settings.groupsParameter,
      cookieSettings: settings.cookieSettings,
      logoutPath: settings.logoutPath,
      logoutRedirectPath: settings.logoutRedirectPath
    };
  }
  static configurePassport(samlStrategy) {
    const passport = new import_passport.Passport();
    passport.serializeUser((user, next) => next(null, user));
    passport.deserializeUser((obj, next) => next(null, obj));
    passport.use(samlStrategy);
    return passport;
  }
  buildSamlStrategy(settings) {
    const strategySettings = _SamlRouterFactory.buildSamlStrategySettings(settings);
    _SamlRouterFactory.getLogger().trace("Strategy settings:", settings);
    const verifyWithoutReq = (profile, done) => {
      import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename).debug(`Obtained raw profile: ${JSON.stringify(profile)}`);
      done(null, profile != null ? profile : void 0);
    };
    return new import_versionedLibraries.passportSaml.library.Strategy(strategySettings, verifyWithoutReq, verifyWithoutReq);
  }
  // Rejects a redirect-bound (query-string) SAMLResponse/SAMLRequest that carries no Signature
  // parameter. @node-saml/node-saml only verifies that parameter when present - and treats it as
  // "not present" whenever it's falsy, so an empty string is enough to make hasValidSignatureForRedirect
  // skip verification and return true, same as an absent parameter. Leaving this unchecked would let
  // a client-forged, unsigned LogoutResponse reach passport-saml's internal pass()-through path with
  // no proof the IdP was ever involved. POST-bound messages are unaffected: they carry
  // SAMLResponse/SAMLRequest in the body, not the query string, so this check never triggers for
  // them, and node-saml already requires a valid signature on that path.
  static rejectUnsignedRedirectBindingSamlMessage(req, res, next) {
    const carriesRedirectBoundMessage = req.query.SAMLResponse !== void 0 || req.query.SAMLRequest !== void 0;
    if (carriesRedirectBoundMessage && (typeof req.query.Signature !== "string" || req.query.Signature === "")) {
      _SamlRouterFactory.getLogger().warn("Rejected a redirect-bound SAML message with no Signature parameter");
      res.status(400).send("SAML message must be signed");
      return;
    }
    next();
  }
  handleLoginCallbackError(settings, err, req, res, info) {
    _SamlRouterFactory.getLogger().error({
      message: `${settings.connectorName} error: ${(err == null ? void 0 : err.message) || info || res}`,
      stack: err == null ? void 0 : err.stack
    });
    req.logout(() => {
      res.clearCookie(settings.cookieSettings.name, { path: "/" });
      return res.send(
        `<h2> There was an error in the SAML connector ${settings.connectorName}</h2>
       <p>For more information, consult the kibana logs.</p>`
      );
    });
  }
};
__publicField(_SamlRouterFactory, "getLogger", () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let SamlRouterFactory = _SamlRouterFactory;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SamlRouterFactory
});
