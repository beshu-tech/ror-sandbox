"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var samlRouterSettings_exports = {};
__export(samlRouterSettings_exports, {
  SamlRouterSettings: () => SamlRouterSettings,
  SamlRouterSettingsList: () => SamlRouterSettingsList
});
module.exports = __toCommonJS(samlRouterSettings_exports);
var import_basePathBuilder = require("../../../core/basePath/basePathBuilder");
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_logoutLinkProvider = require("../logoutLinkProvider");
const SSO_PREFIX = "ror_kbn_";
const ROUTES = {
  LOGIN: "/login",
  LOGOUT: "/logout-saml",
  LOGIN_CALLBACK: "/assert",
  LOGOUT_CALLBACK: "/notifylogout"
};
class SamlRouterSettings {
  constructor(basePathSettings, settings, cookieSettings) {
    __publicField(this, "connectorName");
    __publicField(this, "protocol");
    __publicField(this, "entryPoint");
    __publicField(this, "issuer");
    __publicField(this, "usernameParameter");
    __publicField(this, "groupsParameter");
    __publicField(this, "buttonName");
    __publicField(this, "routerPath");
    __publicField(this, "callbackURL");
    __publicField(this, "logoutCallbackUrl");
    __publicField(this, "loginPath");
    __publicField(this, "logoutPath");
    __publicField(this, "loginCallbackPath");
    __publicField(this, "logoutCallbackPath");
    __publicField(this, "logoutRedirectPath");
    __publicField(this, "cert");
    __publicField(this, "privateCert");
    __publicField(this, "decryptionPvk");
    __publicField(this, "extraSettings");
    __publicField(this, "disableRequestedAuthnContext");
    __publicField(this, "authnContext");
    __publicField(this, "identifierFormat");
    __publicField(this, "cookieSettings");
    __publicField(this, "routerPathRelativeToRoot");
    var _a;
    const { withBasePathPrefix } = new import_basePathBuilder.BasePathBuilder(basePathSettings);
    this.connectorName = settings.name;
    this.protocol = settings.protocol;
    this.entryPoint = settings.entryPoint;
    this.issuer = settings.issuer;
    this.usernameParameter = settings.usernameParameter;
    this.groupsParameter = settings.groupsParameter;
    this.buttonName = settings.buttonName;
    this.loginPath = ROUTES.LOGIN;
    this.logoutPath = ROUTES.LOGOUT;
    this.loginCallbackPath = ROUTES.LOGIN_CALLBACK;
    this.logoutCallbackPath = ROUTES.LOGOUT_CALLBACK;
    this.routerPath = `/${SSO_PREFIX}${settings.name}`;
    this.routerPathRelativeToRoot = withBasePathPrefix(this.routerPath, true);
    this.callbackURL = `${settings.protocol}://${settings.kibanaExternalHost + this.routerPathRelativeToRoot + ROUTES.LOGIN_CALLBACK}`;
    this.logoutCallbackUrl = `${settings.protocol}://${settings.kibanaExternalHost + this.routerPathRelativeToRoot + ROUTES.LOGOUT_CALLBACK}`;
    this.logoutRedirectPath = `${withBasePathPrefix(import_logoutLinkProvider.LogoutLinkProvider.ROR_LOGOUT_LINK, true)}?ssoLogoutCompleted=true`;
    this.cert = settings.cert;
    this.privateCert = settings.privateCert;
    this.decryptionPvk = settings.decryptionPvk;
    this.extraSettings = (_a = settings == null ? void 0 : settings.extraSettings) != null ? _a : {};
    this.cookieSettings = {
      name: `${cookieSettings.name}_${this.connectorName}`,
      password: cookieSettings.password
    };
    this.disableRequestedAuthnContext = settings.disableRequestedAuthnContext;
    this.authnContext = settings.authnContext;
    this.identifierFormat = settings.identifierFormat;
  }
  loginPathRelativeToRoot() {
    return `${this.routerPathRelativeToRoot}${this.loginPath}`;
  }
  logoutPathRelativeToRoot() {
    return `${this.routerPathRelativeToRoot}${this.logoutPath}`;
  }
  toLegacySsoButtonProps() {
    return {
      name: this.connectorName,
      type: "saml",
      buttonName: this.buttonName,
      loginUrl: this.loginPathRelativeToRoot()
    };
  }
}
class SamlRouterSettingsList {
  constructor(basePathSettings, rorSettingsStore) {
    this.basePathSettings = basePathSettings;
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
  }
  getSettingsList() {
    const { cookieSettings, authSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    if (!authSettings) {
      return [];
    }
    if (!SamlRouterSettingsList.signatureKeyExists(authSettings)) {
      this.logger.info("No auth.signature_key set");
      return [];
    }
    if (!SamlRouterSettingsList.samlSettingsListExist(authSettings)) {
      this.logger.info("No SAML configurations found");
      return [];
    }
    const settings = authSettings.samlRawSettingsList.filter((config) => config.enabled);
    if (settings.length === 0) {
      this.logger.info("No enabled SAML configurations found");
      return [];
    }
    return settings.map((config) => new SamlRouterSettings(this.basePathSettings, config, cookieSettings));
  }
  static signatureKeyExists(auth) {
    return Boolean(auth.signatureKey);
  }
  static samlSettingsListExist(auth) {
    var _a;
    return ((_a = auth.samlRawSettingsList) == null ? void 0 : _a.length) !== 0;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SamlRouterSettings,
  SamlRouterSettingsList
});
