"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var ssoLogoutTransactionCookieService_exports = {};
__export(ssoLogoutTransactionCookieService_exports, {
  SSO_LOGOUT_ACK_ACTION: () => SSO_LOGOUT_ACK_ACTION,
  SSO_LOGOUT_ACTION: () => SSO_LOGOUT_ACTION,
  SsoLogoutTransactionCookieService: () => SsoLogoutTransactionCookieService
});
module.exports = __toCommonJS(ssoLogoutTransactionCookieService_exports);
var import_iron = __toESM(require("@hapi/iron"));
var import_cookieManager = require("../../core/cookieManager");
const SSO_LOGOUT_ACTION = "sso-logout";
const SSO_LOGOUT_ACK_ACTION = "sso-logout-ack";
const _SsoLogoutTransactionCookieService = class _SsoLogoutTransactionCookieService {
  constructor(rorSettingsStore) {
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "clearTransaction", (res) => {
      const { maxAge: _maxAge, ...matchingOptions } = this.cookieOptions();
      res.clearCookie(_SsoLogoutTransactionCookieService.INTENT_COOKIE_NAME, matchingOptions);
      res.clearCookie(_SsoLogoutTransactionCookieService.ACK_COOKIE_NAME, matchingOptions);
    });
    __publicField(this, "sealIntent", async (res, sid, connectorName, protocol, nonce) => {
      const intent = {
        sid,
        action: SSO_LOGOUT_ACTION,
        connectorName,
        protocol,
        iat: Date.now(),
        nonce
      };
      const sealed = await import_iron.default.seal(intent, this.cookieConfig.password, this.ironOptions());
      res.cookie(_SsoLogoutTransactionCookieService.INTENT_COOKIE_NAME, sealed, this.cookieOptions());
    });
    __publicField(this, "sealAck", async (res, connectorName, protocol, nonce) => {
      const ack = { action: SSO_LOGOUT_ACK_ACTION, connectorName, protocol, iat: Date.now(), nonce };
      const sealed = await import_iron.default.seal(ack, this.cookieConfig.password, this.ironOptions());
      res.cookie(_SsoLogoutTransactionCookieService.ACK_COOKIE_NAME, sealed, this.cookieOptions());
    });
  }
  // Read live instead of snapshotting at construction: the cookie password is rotatable at runtime
  // (RorSettingsManager re-encrypts the activation key on change) and PreKibanaProxy is a
  // long-lived singleton that is never rebuilt, so a snapshot would keep sealing and unsealing with
  // the retired password forever - same reason CookieManager/JwtSigner/Csrf read it live.
  get cookieConfig() {
    return this.rorSettingsStore.getLatestRorKbnSettings().cookieSettings;
  }
  cookieOptions() {
    return {
      ...import_cookieManager.CookieManager.getCookiesOptions({
        maxAge: _SsoLogoutTransactionCookieService.TTL_MILLIS,
        secure: this.cookieConfig.secure,
        sameSite: "lax"
      }),
      path: "/"
    };
  }
  ironOptions() {
    return { ...import_iron.default.defaults, ttl: _SsoLogoutTransactionCookieService.TTL_MILLIS };
  }
};
__publicField(_SsoLogoutTransactionCookieService, "INTENT_COOKIE_NAME", "rorSsoLogoutTx");
__publicField(_SsoLogoutTransactionCookieService, "ACK_COOKIE_NAME", "rorSsoLogoutAck");
__publicField(_SsoLogoutTransactionCookieService, "TTL_MILLIS", 10 * 60 * 1e3);
let SsoLogoutTransactionCookieService = _SsoLogoutTransactionCookieService;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SSO_LOGOUT_ACK_ACTION,
  SSO_LOGOUT_ACTION,
  SsoLogoutTransactionCookieService
});
