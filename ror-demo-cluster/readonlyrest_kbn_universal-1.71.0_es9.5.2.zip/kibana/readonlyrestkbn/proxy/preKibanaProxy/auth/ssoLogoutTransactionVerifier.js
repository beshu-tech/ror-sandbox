"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var ssoLogoutTransactionVerifier_exports = {};
__export(ssoLogoutTransactionVerifier_exports, {
  SsoLogoutTransactionVerifier: () => SsoLogoutTransactionVerifier
});
module.exports = __toCommonJS(ssoLogoutTransactionVerifier_exports);
var import_iron = __toESM(require("@hapi/iron"));
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
var import_ssoLogoutTransactionCookieService = require("./ssoLogoutTransactionCookieService");
class ExactNonceRoundTripBinding {
  matches(intent, ack) {
    return Boolean(intent.nonce && ack.nonce && intent.nonce === ack.nonce);
  }
}
class TimeWindowRoundTripBinding {
  constructor(maxRoundTripMillis) {
    this.maxRoundTripMillis = maxRoundTripMillis;
  }
  matches(intent, ack) {
    return ack.iat >= intent.iat && ack.iat - intent.iat <= this.maxRoundTripMillis;
  }
}
const _SsoLogoutTransactionVerifier = class _SsoLogoutTransactionVerifier extends import_ssoLogoutTransactionCookieService.SsoLogoutTransactionCookieService {
  constructor() {
    super(...arguments);
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "consumeTransaction", async (req, res, sid) => {
      var _a, _b;
      const sealedIntent = (_a = req.cookies) == null ? void 0 : _a[import_ssoLogoutTransactionCookieService.SsoLogoutTransactionCookieService.INTENT_COOKIE_NAME];
      const sealedAck = (_b = req.cookies) == null ? void 0 : _b[import_ssoLogoutTransactionCookieService.SsoLogoutTransactionCookieService.ACK_COOKIE_NAME];
      this.clearTransaction(res);
      if (!sealedIntent || !sealedAck || !sid) return false;
      try {
        const intent = await import_iron.default.unseal(sealedIntent, this.cookieConfig.password, this.ironOptions());
        const ack = await import_iron.default.unseal(sealedAck, this.cookieConfig.password, this.ironOptions());
        if (intent.action !== import_ssoLogoutTransactionCookieService.SSO_LOGOUT_ACTION || intent.sid !== sid || ack.action !== import_ssoLogoutTransactionCookieService.SSO_LOGOUT_ACK_ACTION || ack.connectorName !== intent.connectorName || ack.protocol !== intent.protocol) {
          return false;
        }
        const binding = intent.protocol === "oidc" ? new ExactNonceRoundTripBinding() : new TimeWindowRoundTripBinding(_SsoLogoutTransactionVerifier.MAX_ROUND_TRIP_MILLIS);
        return binding.matches(intent, ack);
      } catch (error) {
        this.logger.debug(`SSO logout transaction cookies rejected: ${error.message}`);
        return false;
      }
    });
  }
};
__publicField(_SsoLogoutTransactionVerifier, "MAX_ROUND_TRIP_MILLIS", 5 * 60 * 1e3);
let SsoLogoutTransactionVerifier = _SsoLogoutTransactionVerifier;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SsoLogoutTransactionVerifier
});
