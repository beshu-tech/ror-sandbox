/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

const ROR_TENANCY_ID_QUERY_PARAM_KEY = '${tenancyQueryStringKey}';
const NEW_ENCRYPTED_TENANCY_CONTEXT = '${newEncryptedTenancyContext}';

function getSwitchGroupUrl(url) {
  const logger = message => console.log('Error during getting switch group url:', message);

  if (!url) {
    logger('URL is undefined or empty');
    return window.location.origin;
  }

  try {
    const urlObject = new URL(url);
    const redirectTo = urlObject.searchParams.get('redirectTo');

    if (!redirectTo) {
      logger('RedirectTo query string parameter is not available');
      return window.location.origin;
    }

    return decodeURIComponent(redirectTo);
  } catch (e) {
    logger(`Invalid URL: ${e.message}`);
    return window.location.origin;
  }
}

function removeAppDetailsFromUrl(url) {
  const logger = message => console.log('Remove app details from url failed:', message);

  try {
    if (!url) {
      logger('URL is not available.');
      return window.location.origin;
    }

    const parsedUrl = new URL(url);
    const segments = parsedUrl.pathname.split('/').filter(Boolean);

    if (segments[2] !== 'app' || !segments[3]) {
      return url;
    }

    const isManagement = segments[3] === 'management';
    const baseLength = isManagement ? 6 : 4;

    parsedUrl.pathname = `/${segments.slice(0, baseLength).join('/')}`;

    parsedUrl.hash = '';
    parsedUrl.search = '';

    return parsedUrl.toString();
  } catch (e) {
    logger(e.message);
    return url;
  }
}

function withTenancyParam(url, tenancy) {
  try {
    const parsedUrl = new URL(url);
    parsedUrl.searchParams.set(ROR_TENANCY_ID_QUERY_PARAM_KEY, tenancy);
    return parsedUrl.toString();
  } catch (e) {
    console.log('Error adding tenancy param:', e.message);
    return url;
  }
}

function redirectUser(url) {
  window.location.href = withTenancyParam(
    removeAppDetailsFromUrl(getSwitchGroupUrl(url)),
    NEW_ENCRYPTED_TENANCY_CONTEXT
  );
}

redirectUser(window.location.href);

if (typeof module !== 'undefined' && Object.prototype.hasOwnProperty.call(module, 'exports')) {
  module.exports = {
    getSwitchGroupUrl,
    removeAppDetailsFromUrl
  };
}
