"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var templateCompiler_exports = {};
__export(templateCompiler_exports, {
  compile: () => compile
});
module.exports = __toCommonJS(templateCompiler_exports);
function compile(tpl, args) {
  function readModuleFile(path) {
    const filename = require.resolve(path);
    return require("fs").readFileSync(filename, "utf8");
  }
  return readModuleFile(tpl).replace(/\${(\w+)}/g, (_, v) => args[v] === "" || args[v] ? args[v] : `\${${v}}`);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  compile
});
