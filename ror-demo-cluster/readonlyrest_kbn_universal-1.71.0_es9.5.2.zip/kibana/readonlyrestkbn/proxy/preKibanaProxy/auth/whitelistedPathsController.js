"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var whitelistedPathsController_exports = {};
__export(whitelistedPathsController_exports, {
  WhitelistedPathsController: () => WhitelistedPathsController
});
module.exports = __toCommonJS(whitelistedPathsController_exports);
class WhitelistedPathsController {
  constructor(directAccessProxy, rorSettingsStore) {
    this.directAccessProxy = directAccessProxy;
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "handleWhitelistedPaths", (req, res, next) => {
      if (this.isWhitelistedPath(req.path)) {
        return this.directAccessProxy(req, res, next);
      }
      return next();
    });
  }
  static getRegexPattern(values) {
    let regexpPattern = `^${values.join("$|^")}$`;
    if (regexpPattern.startsWith("^^")) {
      regexpPattern = regexpPattern.replace("^^", "^");
    }
    if (regexpPattern.endsWith("$$")) {
      regexpPattern = regexpPattern.replace("$$", "$");
    }
    return regexpPattern;
  }
  isWhitelistedPath(path) {
    const { whitelistedPaths } = this.rorSettingsStore.getLatestRorKbnSettings();
    const whitelistedPathRegex = whitelistedPaths.length === 0 ? null : new RegExp(WhitelistedPathsController.getRegexPattern(whitelistedPaths), "i");
    return whitelistedPathRegex == null ? void 0 : whitelistedPathRegex.test(path);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  WhitelistedPathsController
});
