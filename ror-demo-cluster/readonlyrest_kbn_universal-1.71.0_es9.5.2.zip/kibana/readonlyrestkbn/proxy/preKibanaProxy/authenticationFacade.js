"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var authenticationFacade_exports = {};
__export(authenticationFacade_exports, {
  AuthenticationFacade: () => AuthenticationFacade
});
module.exports = __toCommonJS(authenticationFacade_exports);
var import_uuid = require("uuid");
var import_accessLevel = require("../../shared/types/accessLevel");
var import_errors = __toESM(require("../constants/errors"));
var import_correlationIdWrapper = require("../core/api/correlationIdWrapper");
var import_restRorEsApiClient = require("../core/api/restRorEsApiClient");
var import_requestHeadersWhitelistApplier = require("../core/common/requestHeadersWhitelistApplier");
var import_toOptionalString = require("../core/common/toOptionalString");
var import_types = require("../core/common/types");
var import_cookieManager = require("../core/cookieManager");
var import_rorLogger = require("../core/logging/rorLogger");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
var import_expressRorRequest = require("../core/rorRequest/expressRorRequest");
var import_TenancyContext = require("../core/tenancy/TenancyContext");
class AuthenticationFacade {
  constructor(sessionManagerProvider, cookieManager, esApiClientAuthWrapper, rorEsApiClientWithAuthProvider, credentialHeadersCollector, requestHeadersWhitelist, licenseService, identitySessionBuilder, indexCreator, tenancyService, multiTenancyChecker, rorSettingsStore, auditLogEmitter, logoutLinkProvider) {
    this.sessionManagerProvider = sessionManagerProvider;
    this.cookieManager = cookieManager;
    this.esApiClientAuthWrapper = esApiClientAuthWrapper;
    this.rorEsApiClientWithAuthProvider = rorEsApiClientWithAuthProvider;
    this.credentialHeadersCollector = credentialHeadersCollector;
    this.requestHeadersWhitelist = requestHeadersWhitelist;
    this.licenseService = licenseService;
    this.identitySessionBuilder = identitySessionBuilder;
    this.indexCreator = indexCreator;
    this.tenancyService = tenancyService;
    this.multiTenancyChecker = multiTenancyChecker;
    this.rorSettingsStore = rorSettingsStore;
    this.auditLogEmitter = auditLogEmitter;
    this.logoutLinkProvider = logoutLinkProvider;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "handleImpersonate403UserState", (impersonateAs, due_to) => {
      if (due_to == null ? void 0 : due_to.includes("NOT_SUFFICIENT_LICENSE")) {
        return {
          reason: "NOT_SUFFICIENT_LICENSE",
          message: import_errors.default.notSufficientLicenseToUseFeature("impersonation feature"),
          status: "ERROR"
        };
      }
      if (due_to == null ? void 0 : due_to.includes("IMPERSONATION_NOT_ALLOWED")) {
        return {
          reason: "IMPERSONATION_NOT_ALLOWED",
          message: `You are not allowed to impersonate ${impersonateAs} user`,
          status: "ERROR"
        };
      }
      if (due_to == null ? void 0 : due_to.includes("IMPERSONATION_NOT_SUPPORTED")) {
        return {
          reason: "IMPERSONATION_NOT_SUPPORTED",
          message: "You have been using an rule that does not support impersonation feature",
          status: "ERROR"
        };
      }
      if (due_to == null ? void 0 : due_to.includes("TEST_SETTINGS_NOT_CONFIGURED")) {
        return {
          reason: "TEST_SETTINGS_NOT_CONFIGURED",
          message: "To impersonate users, make sure to configure the test settings first",
          status: "ERROR"
        };
      }
      return {
        reason: "OPERATION_NOT_ALLOWED",
        message: `Operation not allowed`,
        status: "ERROR"
      };
    });
  }
  async authorizeRequest(rorRequest, correlationId = (0, import_uuid.v4)()) {
    const { credentialHeaders, ssoSessionProfile } = this.credentialHeadersCollector.collectCredentialHeadersAndSsoSessionProfile(rorRequest);
    const allReqHeaders = rorRequest.getHeaders();
    const forwardAuthHeaders = this.credentialHeadersCollector.collectForwardAuthHeader(rorRequest);
    const whitelistedHeaders = new Map(forwardAuthHeaders);
    import_requestHeadersWhitelistApplier.RequestHeadersWhitelistApplier.applyToMap(
      this.logger,
      this.requestHeadersWhitelist,
      allReqHeaders,
      whitelistedHeaders
    );
    const queries = rorRequest.getQueries();
    const defaultGroup = (0, import_toOptionalString.toOptionalString)(queries.defaultGroup);
    const response = await this.getAsScopedUserRestRorEsApiClient(credentialHeaders).withCorrelationIdHeader(correlationId).authorizeUser({
      multiTenancyChecker: this.multiTenancyChecker,
      identitySessionHeaders: credentialHeaders,
      whitelistedHeaders,
      licenseEdition: this.licenseService.getLicenseEdition()
    });
    if (response.status === "ERROR") {
      throw response;
    }
    const identitySession = await this.identitySessionBuilder.createIdentitySession(
      credentialHeaders,
      whitelistedHeaders,
      response.data,
      await rorRequest.lastSessionActivityDate(),
      this.sessionManagerProvider.get().createNewSessionExpirationDate()
    );
    if (ssoSessionProfile) {
      identitySession.metadata = { ...identitySession.metadata, ssoSessionProfile };
    }
    await this.sessionManagerProvider.get().set(identitySession.sid, identitySession.metadata);
    const userRequestIdentity = await this.resolveUserRequestIdentityWithFallbackToFirstTenancy(
      rorRequest,
      identitySession,
      defaultGroup
    );
    await this.indexCreator.createIndexAndSpace(userRequestIdentity.metadata);
    this.appendCorrelationIdHeader(userRequestIdentity, userRequestIdentity.metadata.correlationId);
    const encryptedCookie = await this.cookieManager.encryptRorCookie(
      identitySession.sid
    );
    return [encryptedCookie, userRequestIdentity];
  }
  async resolveUserRequestIdentityWithFallbackToFirstTenancy(rorRequest, identitySession, defaultGroup) {
    var _a;
    const userRequestIdentity = await rorRequest.getUserRequestIdentity({
      sid: identitySession.sid,
      predefinedTenancyId: defaultGroup
    });
    if (userRequestIdentity) {
      return userRequestIdentity;
    }
    const availableTenancies = await this.tenancyService.getAvailableTenanciesForUser(identitySession.sid);
    const fallbackTenancyId = (_a = availableTenancies[0]) == null ? void 0 : _a.group.id;
    const fallback = fallbackTenancyId ? await rorRequest.getUserRequestIdentity({
      sid: identitySession.sid,
      predefinedTenancyId: fallbackTenancyId
    }) : null;
    if (!fallback) {
      this.logger.warn(
        `Could not build user request identity for the requested tenancy '${defaultGroup}' nor for the fallback tenancy '${fallbackTenancyId}'`
      );
      const error = {
        status: "ERROR",
        reason: "SERVER_ERROR",
        message: import_errors.default.cannotAuthenticate
      };
      throw error;
    }
    this.logger.warn(
      `Could not resolve requested tenancy '${defaultGroup}'; falling back to the first available tenancy '${fallbackTenancyId}'`
    );
    return fallback;
  }
  async authorizeDirectRequestWithCredentials(rorRequest, correlationId = (0, import_uuid.v4)()) {
    const credentialHeaders = this.credentialHeadersCollector.collectCredentialHeaders(rorRequest);
    const allReqHeaders = rorRequest.getHeaders();
    this.logger.debug(`All request headers from ${rorRequest.getUrl()}:`, allReqHeaders);
    const forwardAuthHeaders = this.credentialHeadersCollector.collectForwardAuthHeader(rorRequest);
    const whitelistedHeaders = new Map(forwardAuthHeaders);
    import_requestHeadersWhitelistApplier.RequestHeadersWhitelistApplier.applyToMap(
      this.logger,
      this.requestHeadersWhitelist,
      allReqHeaders,
      whitelistedHeaders
    );
    const xRorImpersonating = allReqHeaders[import_types.X_ROR_IMPERSONATING];
    const impersonateAs = (0, import_toOptionalString.toOptionalString)(xRorImpersonating);
    const response = await this.getDirectRequestResponseData({
      identitySessionHeaders: credentialHeaders,
      whitelistedHeaders,
      correlationId,
      impersonateAs
    });
    const identitySession = await this.identitySessionBuilder.createIdentitySession(
      credentialHeaders,
      whitelistedHeaders,
      response.data,
      await rorRequest.lastSessionActivityDate(),
      this.sessionManagerProvider.get().createNewSessionExpirationDate()
    );
    await this.sessionManagerProvider.get().setShortLivedSessionInMemory(identitySession.sid, identitySession.metadata);
    const userRequestIdentity = await this.resolveUserRequestIdentityWithFallbackToFirstTenancy(
      rorRequest,
      identitySession,
      void 0
    );
    this.logger.trace(`User request identity for a direct request:`, userRequestIdentity);
    if (xRorImpersonating) {
      import_rorLogger.RorLogger.appendImpersonatingInfo(userRequestIdentity.metadata.username);
    }
    await this.indexCreator.createIndexAndSpace(userRequestIdentity.metadata);
    this.appendCorrelationIdHeader(userRequestIdentity, identitySession.metadata.correlationId);
    const encryptedCookie = await this.cookieManager.encryptRorCookie(
      identitySession.sid
    );
    return [encryptedCookie, userRequestIdentity];
  }
  async getDirectRequestResponseData({
    identitySessionHeaders,
    whitelistedHeaders,
    correlationId,
    impersonateAs
  }) {
    var _a, _b;
    if (impersonateAs) {
      const checkImpersonateResponse = await this.checkImpersonationStatus(
        identitySessionHeaders,
        whitelistedHeaders,
        impersonateAs
      );
      if (checkImpersonateResponse.status === 403) {
        (0, import_restRorEsApiClient.checkEsAuthorizationResponseErrorStatus)(checkImpersonateResponse);
        throw this.handleImpersonate403UserState(
          impersonateAs,
          this.getDueTo((_b = (_a = checkImpersonateResponse.body.error) == null ? void 0 : _a.due_to) != null ? _b : [])
        );
      }
      if (checkImpersonateResponse.status !== 200) {
        throw checkImpersonateResponse;
      }
      return { data: checkImpersonateResponse.body, status: "SUCCESS" };
    }
    const response = await this.getAsScopedUserRestRorEsApiClient(identitySessionHeaders).withCorrelationIdHeader(correlationId).authorizeUser({
      multiTenancyChecker: this.multiTenancyChecker,
      identitySessionHeaders,
      whitelistedHeaders,
      licenseEdition: this.licenseService.getLicenseEdition()
    });
    if (response.status === "ERROR") {
      throw response;
    }
    return response;
  }
  async clearSession(request) {
    const sid = await request.getSid();
    if (sid) {
      await this.sessionManagerProvider.get().delete(sid);
      this.sessionManagerProvider.get().clearMostRecentlyAccessed();
    }
  }
  async finalizeLogout(rorRequest, res) {
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    await this.auditLogEmitter.emitLogoutEventIfAuthenticated(rorRequest);
    await this.clearSession(rorRequest);
    const { cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
    res.clearCookie(cookieSettings.name);
    res.clearCookie(`${cookieSettings.name}-SP`);
    return this.logoutLinkProvider.buildRorLogoutRedirectLink((userRequestIdentity == null ? void 0 : userRequestIdentity.metadata) || void 0);
  }
  async refreshSession(rorRequest) {
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    if (userRequestIdentity) {
      await this.sessionManagerProvider.get().refreshSession(userRequestIdentity == null ? void 0 : userRequestIdentity.sid, rorRequest.getUrl());
    }
  }
  async refreshSessionAgainstEs(userRequestIdentity) {
    const { identitySessionHeaders, whitelistedHeaders, correlationId } = userRequestIdentity.metadata;
    const response = await this.getAsScopedUserRestRorEsApiClient(identitySessionHeaders).withCorrelationIdHeader(correlationId).authorizeUser({
      multiTenancyChecker: this.multiTenancyChecker,
      identitySessionHeaders,
      whitelistedHeaders,
      licenseEdition: this.licenseService.getLicenseEdition()
    });
    if (response.status === "ERROR") {
      throw response;
    }
    const currentSessionMetadata = await this.sessionManagerProvider.get().get(userRequestIdentity.sid);
    const newMetadata = {
      ...this.identitySessionBuilder.buildIdentitySessionMetadata({
        identitySessionHeaders,
        whitelistedHeaders,
        responseData: response.data,
        lastSessionActivityDate: userRequestIdentity.metadata.lastSessionActivityDate,
        expiresAt: this.sessionManagerProvider.get().createNewSessionExpirationDate(),
        impersonatedBy: userRequestIdentity.metadata.impersonatedBy
      }),
      ssoSessionProfile: currentSessionMetadata == null ? void 0 : currentSessionMetadata.ssoSessionProfile
    };
    await this.sessionManagerProvider.get().set(userRequestIdentity.sid, newMetadata);
    const identitySessionMetadata = await this.sessionManagerProvider.get().get(userRequestIdentity.sid);
    if (!identitySessionMetadata) {
      throw new Error("Failed to get user identity session");
    }
    return {
      sid: userRequestIdentity.sid,
      metadata: identitySessionMetadata
    };
  }
  async checkImpersonationStatus(identitySessionHeaders, whitelistedHeaders, impersonateAs) {
    return this.getAsScopedUserRestRorEsApiClient(identitySessionHeaders).withCorrelationIdHeader(identitySessionHeaders.get(import_types.X_ROR_CORRELATION_ID)).checkImpersonatedUser({
      impersonateAs,
      identitySessionHeaders,
      whitelistedHeaders,
      multiTenancyChecker: this.multiTenancyChecker,
      licenseEdition: this.licenseService.getLicenseEdition()
    });
  }
  async impersonateUser(rorRequest, res, currentUserIdentity) {
    var _a, _b, _c;
    const appendImpersonateAsHeader = (userRequestIdentity, impersonateAs) => {
      const { identitySessionHeaders } = userRequestIdentity.metadata;
      return identitySessionHeaders.set(import_types.X_ROR_IMPERSONATING, impersonateAs);
    };
    const setNewImpersonateAsSession = async (identitySessionHeaders, whitelistedHeaders, impersonatedUserResponse, currentUsername, ssoSessionProfile, sid) => {
      const newSid = (0, import_uuid.v4)();
      const newIdentitySessionMetadata = {
        ...this.identitySessionBuilder.buildIdentitySessionMetadata({
          identitySessionHeaders,
          whitelistedHeaders,
          responseData: impersonatedUserResponse,
          lastSessionActivityDate: await rorRequest.lastSessionActivityDate(),
          expiresAt: this.sessionManagerProvider.get().createNewSessionExpirationDate(),
          impersonatedBy: currentUsername
        }),
        ssoSessionProfile
      };
      this.logger.debug("Identity session metadata for impersonated user:", impersonatedUserResponse);
      await this.sessionManagerProvider.get().set(newSid, newIdentitySessionMetadata);
      const impersonatedUserRequestIdentity = await rorRequest.getUserRequestIdentity({
        sid: newSid,
        predefinedTenancyId: newIdentitySessionMetadata.type === "USER_WITH_GROUPS" ? newIdentitySessionMetadata.groups[0].group.id : void 0
      });
      await this.indexCreator.createIndexAndSpace(impersonatedUserRequestIdentity.metadata);
      this.sessionManagerProvider.get().delete(sid);
      const encryptedCookie = await this.cookieManager.encryptRorCookie(newSid);
      return { encryptedCookie, impersonatedUserRequestIdentity };
    };
    try {
      const body = rorRequest.getBody();
      const impersonateAs = (0, import_expressRorRequest.isLoginFormBody)(body) ? body.username : "";
      const checkImpersonateResponse = await this.checkImpersonationStatus(
        await rorRequest.getIdentitySessionHeaders(),
        await rorRequest.getWhitelistedHeaders(),
        impersonateAs
      );
      if (checkImpersonateResponse.status === 403) {
        (0, import_restRorEsApiClient.checkEsAuthorizationResponseErrorStatus)(checkImpersonateResponse);
        this.logger.debug(
          `Error while impersonating user ${JSON.stringify((_a = checkImpersonateResponse.body.error) == null ? void 0 : _a.due_to)}`
        );
        const impersonate403UserState = this.handleImpersonate403UserState(
          impersonateAs,
          this.getDueTo((_c = (_b = checkImpersonateResponse.body.error) == null ? void 0 : _b.due_to) != null ? _c : [])
        );
        return res.status(403).json(impersonate403UserState);
      }
      const identitySessionHeaders = appendImpersonateAsHeader(currentUserIdentity, impersonateAs);
      (0, import_restRorEsApiClient.checkEsAuthorizationResponseSuccessStatus)(checkImpersonateResponse);
      this.appendCorrelationIdHeader(currentUserIdentity, currentUserIdentity.metadata.correlationId);
      const currentSessionMetadata = await this.sessionManagerProvider.get().get(currentUserIdentity.sid);
      const { encryptedCookie, impersonatedUserRequestIdentity } = await setNewImpersonateAsSession(
        identitySessionHeaders,
        currentUserIdentity.metadata.whitelistedHeaders,
        checkImpersonateResponse.body,
        currentUserIdentity.metadata.username,
        currentSessionMetadata == null ? void 0 : currentSessionMetadata.ssoSessionProfile,
        currentUserIdentity.sid
      );
      const { cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      res.cookie(
        cookieSettings.name,
        encryptedCookie,
        import_cookieManager.CookieManager.getCookiesOptions({
          secure: cookieSettings.secure,
          sameSite: cookieSettings.sameSite
        })
      );
      import_rorLogger.RorLogger.appendImpersonatingInfo(impersonatedUserRequestIdentity.metadata.username);
      return res.status(200).json({
        status: "ok",
        redirectUrl: await this.buildRedirectUrlForImpersonation(impersonatedUserRequestIdentity.metadata)
      });
    } catch (e) {
      this.logger.error(e.message, e);
      res.status(500).json({ message: e.message });
    }
  }
  async finishImpersonation(rorRequest, res) {
    const deleteImpersonateAsHeader = (userRequestIdentity) => {
      const { identitySessionHeaders } = userRequestIdentity.metadata;
      identitySessionHeaders.delete(import_types.X_ROR_IMPERSONATING);
      return identitySessionHeaders;
    };
    const setUserSession = async (identitySessionHeaders, whitelistedHeaders, userResponse, ssoSessionProfile, currentSid, newSid) => {
      const sessionManager = this.sessionManagerProvider.get();
      const newIdentitySessionMetadata = {
        ...this.identitySessionBuilder.buildIdentitySessionMetadata({
          identitySessionHeaders,
          whitelistedHeaders,
          responseData: userResponse.data,
          lastSessionActivityDate: await rorRequest.lastSessionActivityDate(),
          expiresAt: sessionManager.createNewSessionExpirationDate()
        }),
        ssoSessionProfile
      };
      await sessionManager.set(newSid, newIdentitySessionMetadata);
      sessionManager.delete(currentSid);
      const resolvedMetadata = await sessionManager.get(newSid);
      if (!resolvedMetadata) {
        throw new Error("Failed to get user identity session");
      }
      return { sid: newSid, metadata: resolvedMetadata };
    };
    try {
      const userRequestIdentity = await rorRequest.getUserRequestIdentity();
      const identitySessionHeaders = deleteImpersonateAsHeader(userRequestIdentity);
      const response = await this.getAsScopedUserRestRorEsApiClient(identitySessionHeaders).withCorrelationIdHeader(userRequestIdentity.metadata.correlationId).authorizeUser({
        multiTenancyChecker: this.multiTenancyChecker,
        identitySessionHeaders,
        whitelistedHeaders: userRequestIdentity.metadata.whitelistedHeaders,
        licenseEdition: this.licenseService.getLicenseEdition()
      });
      if (response.status === "ERROR") {
        throw response;
      }
      const newSid = (0, import_uuid.v4)();
      const currentSessionMetadata = await this.sessionManagerProvider.get().get(userRequestIdentity.sid);
      const newIdentitySession = await setUserSession(
        identitySessionHeaders,
        userRequestIdentity.metadata.whitelistedHeaders,
        response,
        currentSessionMetadata == null ? void 0 : currentSessionMetadata.ssoSessionProfile,
        userRequestIdentity.sid,
        newSid
      );
      const encryptedCookie = await this.cookieManager.encryptRorCookie(newSid);
      const { cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      res.cookie(
        cookieSettings.name,
        encryptedCookie,
        import_cookieManager.CookieManager.getCookiesOptions({
          secure: cookieSettings.secure,
          sameSite: cookieSettings.sameSite
        })
      );
      import_rorLogger.RorLogger.clearImpersonatingInfo();
      return newIdentitySession;
    } catch (e) {
      this.logger.error(e.message, e);
      throw e;
    }
  }
  async verifySessionTimeout(rorRequest) {
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    const sid = userRequestIdentity == null ? void 0 : userRequestIdentity.sid;
    return this.sessionManagerProvider.get().checkIfSessionTimeout(sid);
  }
  async verifyUserAccess(identitySessionHeaders, whitelistedHeaders, kibanaIndex) {
    return this.esApiClientAuthWrapper.asScoped(identitySessionHeaders).verifyUserAccess({ kibanaIndex, identitySessionHeaders, whitelistedHeaders });
  }
  appendCorrelationIdHeader(userRequestIdentity, correlationId) {
    const userRequestIdentityHeaders = userRequestIdentity.metadata.identitySessionHeaders;
    return userRequestIdentityHeaders.set(import_types.X_ROR_CORRELATION_ID, correlationId);
  }
  async verifyCurrentUser(request) {
    var _a, _b;
    const rorRequest = request.rorRequest;
    const userRequestIdentity = await rorRequest.getUserRequestIdentity();
    return this.getAsScopedUserRestRorEsApiClient(userRequestIdentity.metadata.identitySessionHeaders).withCorrelationIdHeader(userRequestIdentity.metadata.correlationId).authorizeUserAttachingMetadata({
      groupId: (_b = (_a = userRequestIdentity.metadata.currentGroup) == null ? void 0 : _a.id) != null ? _b : "",
      multiTenancyChecker: this.multiTenancyChecker,
      licenseEdition: this.licenseService.getLicenseEdition(),
      identitySessionHeaders: userRequestIdentity.metadata.identitySessionHeaders,
      whitelistedHeaders: userRequestIdentity.metadata.whitelistedHeaders
    });
  }
  async getAccessLevel(req) {
    try {
      const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
      const accessLevel = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata.kibanaAccess;
      if (accessLevel) {
        return accessLevel;
      }
    } catch (e) {
      this.logger.error({ message: `Failed to get access level from rorRequest: ${e.message}`, stack: e.stack });
    }
    return import_accessLevel.AccessLevel.RO;
  }
  async deleteAllSessions() {
    await this.sessionManagerProvider.get().deleteAllSessions();
  }
  get license() {
    return this.licenseService.getActivationKey().license;
  }
  async buildRedirectUrlForImpersonation(userRequestIdentityMetadata) {
    const homeUrl = `/s/default/app/home`;
    if (!userRequestIdentityMetadata.currentGroup) {
      return homeUrl;
    }
    return this.tenancyService.persistTenancyContextInUrl(
      homeUrl,
      (0, import_TenancyContext.tenancyFromId)(userRequestIdentityMetadata.currentGroup.id, userRequestIdentityMetadata.kibanaIndex)
    );
  }
  getDueTo(dueTo) {
    if (Array.isArray(dueTo)) {
      return dueTo;
    }
    return [dueTo];
  }
  getAsScopedUserRestRorEsApiClient(identitySessionHeaders) {
    return new import_correlationIdWrapper.CorrelationIdWrapper(this.rorEsApiClientWithAuthProvider.asScoped(identitySessionHeaders));
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AuthenticationFacade
});
