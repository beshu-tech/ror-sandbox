"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var customMiddleware_exports = {};
__export(customMiddleware_exports, {
  CustomMiddleware: () => CustomMiddleware
});
module.exports = __toCommonJS(customMiddleware_exports);
var import_fs_extra = __toESM(require("fs-extra"));
var import_node_fetch = __toESM(require("node-fetch"));
var import_ActivationKey = require("../../shared/types/ActivationKey");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
class CustomMiddleware {
  constructor(rorSettingsStore) {
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    global.fetch = import_node_fetch.default;
    global.logger = this.logger;
  }
  async inject(req, res, next, licenseService) {
    const { customMiddlewareInjectFile, customMiddlewareInject } = this.rorSettingsStore.getLatestRorKbnSettings();
    const license = licenseService.getActivationKey().license;
    const isEnterprise = (0, import_ActivationKey.isEnterpriseLicense)(license);
    if (!isEnterprise) {
      return next();
    }
    if (customMiddlewareInjectFile) {
      return this.injectFromFile(req, res, next, customMiddlewareInjectFile);
    }
    if (customMiddlewareInject) {
      return this.injectInline(req, res, next, customMiddlewareInject);
    }
    return next();
  }
  async injectFromFile(req, res, next, customMiddlewareInjectFile) {
    try {
      const read = (f) => import_fs_extra.default.readFileSync(f).toString();
      const include = (f) => {
        const content = read(f);
        eval.apply(global, [content]);
        return this.getFunctionName(content);
      };
      const { functionName } = include(customMiddlewareInjectFile);
      return await global[functionName](req, res, next);
    } catch (e) {
      this.logger.error({ message: e.message, stack: e.stack });
    }
  }
  async injectInline(req, res, next, customMiddlewareInject) {
    try {
      const include = (content) => {
        eval.apply(global, [content]);
        return this.getFunctionName(content);
      };
      const { functionName } = include(customMiddlewareInject);
      return await global[functionName](req, res, next);
    } catch (e) {
      this.logger.error({ message: e.message, stack: e.stack });
    }
  }
  getFunctionName(content) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
    const functionDeclarationName = (_c = (_b = (_a = content.split("(")) == null ? void 0 : _a[0]) == null ? void 0 : _b.split("function ")) == null ? void 0 : _c[1];
    const constBasedExpression = (_f = (_e = (_d = content.split(" =")) == null ? void 0 : _d[0]) == null ? void 0 : _e.split("const ")) == null ? void 0 : _f[1];
    const letBasedExpression = (_i = (_h = (_g = content.split(" =")) == null ? void 0 : _g[0]) == null ? void 0 : _h.split("let ")) == null ? void 0 : _i[1];
    const functionExpressionName = (_l = (_k = (_j = content.split(" =")) == null ? void 0 : _j[0]) == null ? void 0 : _k.split("var ")) == null ? void 0 : _l[1];
    if (!functionDeclarationName && constBasedExpression || letBasedExpression) {
      throw new Error(
        " You need to declare your customMiddleware as function declaration (function FUNCTION_NAME()) or function expression with a var (var FUNCTION_NAME =)"
      );
    }
    return { functionName: functionDeclarationName || functionExpressionName };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CustomMiddleware
});
