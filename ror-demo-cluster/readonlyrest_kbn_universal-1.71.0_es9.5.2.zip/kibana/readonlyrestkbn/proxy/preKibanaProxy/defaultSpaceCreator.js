"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var defaultSpaceCreator_exports = {};
__export(defaultSpaceCreator_exports, {
  DefaultSpaceCreator: () => DefaultSpaceCreator
});
module.exports = __toCommonJS(defaultSpaceCreator_exports);
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
class DefaultSpaceCreator {
  constructor(esApiClientWithAuthProvider) {
    this.esApiClientWithAuthProvider = esApiClientWithAuthProvider;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "DEFAULT_SPACE_DOCUMENT_ID", "space:default");
    /**
       * When a new major release of Kibana gets released, we can check if we need to update the structure
       * of this document. Here is how to extract it from a running Elasticsearch instance:
    
       curl -H "content-type: application/json" -u kibana:kibana -X POST "localhost:9200/_search" -d '{"query": {"simple_query_string":{"query": "space"}}}' | jq
    
       */
    __publicField(this, "DEFAULT_SPACE_DOCUMENT_BODY", {
      space: {
        name: "Default",
        description: "This is your default space! (created by ReadonlyREST Enterprise)",
        color: "#00bfb3",
        disabledFeatures: [],
        _reserved: true
      },
      type: "space",
      references: [],
      migrationVersion: {
        space: "6.6.0"
      }
    });
    __publicField(this, "createDefaultSpaceDocumentIfNeeded", async (kibanaIndex) => {
      const spaceDocumentExists = await this.spaceDocumentExists(kibanaIndex);
      if (!spaceDocumentExists) {
        await this.createDefaultSpaceDocument(kibanaIndex, this.DEFAULT_SPACE_DOCUMENT_BODY);
      }
    });
    __publicField(this, "spaceDocumentExists", async (kibanaIndex) => this.esApiClientWithAuthProvider.asTechnicalUser().getDocumentById({ indexName: kibanaIndex, docId: this.DEFAULT_SPACE_DOCUMENT_ID }).then(async (response) => {
      const text = await response.text();
      this.logger.trace(`spaceDocumentExists response ${response.status}: ${text}`);
      return response.status === 200;
    }));
    __publicField(this, "createDefaultSpaceDocument", async (currentKibanaIndex, spaceDocumentRequestBody, retryAfterMappingFix = true) => {
      this.logger.trace(`Creating default space document for index: ${currentKibanaIndex}`);
      const response = await this.esApiClientWithAuthProvider.asTechnicalUser().createOrUpdateDocumentInIndex({
        requestBody: spaceDocumentRequestBody,
        indexName: currentKibanaIndex,
        docId: this.DEFAULT_SPACE_DOCUMENT_ID
      });
      const text = await response.text();
      this.logger.trace(`createDefaultSpaceDocument response ${response.status}: ${text}`);
      if (retryAfterMappingFix && DefaultSpaceCreator.isMissingSpaceMappingError(response.status, text)) {
        this.logger.debug(
          `Index ${currentKibanaIndex} is missing the "space" type mapping (is xpack.spaces.enabled set to false?) \u2014 adding it and retrying.`
        );
        await this.addSpaceMapping(currentKibanaIndex);
        await this.createDefaultSpaceDocument(currentKibanaIndex, spaceDocumentRequestBody, false);
      }
    });
    __publicField(this, "addSpaceMapping", async (kibanaIndex) => {
      const response = await this.esApiClientWithAuthProvider.asTechnicalUser().putMapping({
        indexName: kibanaIndex,
        requestBody: {
          properties: {
            space: {
              dynamic: true,
              properties: {}
            }
          }
        }
      });
      const text = await response.text();
      this.logger.trace(`addSpaceMapping response ${response.status}: ${text}`);
    });
  }
  static isMissingSpaceMappingError(status, responseText) {
    return status === 400 && responseText.includes("strict_dynamic_mapping_exception") && responseText.includes("[space]");
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DefaultSpaceCreator
});
