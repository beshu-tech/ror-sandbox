"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var devReloadEventStream_exports = {};
__export(devReloadEventStream_exports, {
  DevReloadEventStream: () => DevReloadEventStream
});
module.exports = __toCommonJS(devReloadEventStream_exports);
class DevReloadEventStream {
  constructor() {
    __publicField(this, "clients", /* @__PURE__ */ new Set());
    __publicField(this, "reloadCompleted", false);
  }
  connect(req, res) {
    res.set({
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "Content-Type": "text/event-stream"
    });
    res.flushHeaders();
    if (this.reloadCompleted) {
      res.write("event: ready\ndata: {}\n\n");
    }
    this.clients.add(res);
    req.on("close", () => this.clients.delete(res));
  }
  notifyReload() {
    this.reloadCompleted = false;
    for (const client of this.clients) {
      client.write("event: reload\ndata: {}\n\n");
    }
  }
  notifyReloadCompleted() {
    this.reloadCompleted = true;
    for (const client of this.clients) {
      client.write("event: ready\ndata: {}\n\n");
    }
  }
  close() {
    for (const client of this.clients) {
      client.end();
    }
    this.clients.clear();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DevReloadEventStream
});
