"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var devReloadExtension_exports = {};
__export(devReloadExtension_exports, {
  DevReloadExtension: () => DevReloadExtension
});
module.exports = __toCommonJS(devReloadExtension_exports);
var import_types = require("../../core/common/types");
var import_devReloadRouter = require("../api/router/devReloadRouter");
var import_templateCompiler = require("../auth/template/templateCompiler");
var import_devReloadEventStream = require("./devReloadEventStream");
const APPLICATION_JAVASCRIPT_UTF8 = "application/javascript; charset=UTF-8";
class DevReloadExtension {
  constructor(eventStream = new import_devReloadEventStream.DevReloadEventStream()) {
    this.eventStream = eventStream;
  }
  additionalBodyScripts(kibanaBasePath) {
    return [`${kibanaBasePath}/pkp/injections/dev-reload-indicator.js`];
  }
  registerPublicRoutes(app, withBasePathPrefix) {
    app.use(withBasePathPrefix("/pkp/dev-reload"), (0, import_devReloadRouter.buildDevReloadRouter)(this.eventStream));
  }
  registerAuthenticatedRoutes(app, withBasePathPrefix, kibanaBasePath) {
    app.get(withBasePathPrefix("/pkp/injections/dev-reload-indicator.js"), (_req, res) => {
      const javascript = (0, import_templateCompiler.compile)("../../injection/scripts/devReloadIndicator.js", {
        devReloadEventsUrl: `${kibanaBasePath}/pkp/dev-reload/events`
      });
      res.setHeader(import_types.CONTENT_TYPE_HEADER, APPLICATION_JAVASCRIPT_UTF8);
      return res.send(javascript);
    });
  }
  close() {
    this.eventStream.close();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DevReloadExtension
});
