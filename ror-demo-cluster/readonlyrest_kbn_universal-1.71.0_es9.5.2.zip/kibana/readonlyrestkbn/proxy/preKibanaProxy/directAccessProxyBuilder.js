"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var directAccessProxyBuilder_exports = {};
__export(directAccessProxyBuilder_exports, {
  DirectAccessProxyBuilder: () => DirectAccessProxyBuilder
});
module.exports = __toCommonJS(directAccessProxyBuilder_exports);
var import_express_http_proxy = __toESM(require("express-http-proxy"));
var import_proxyRequestHeaders = require("../core/common/proxyRequestHeaders");
var import_requestHeadersWhitelistApplier = require("../core/common/requestHeadersWhitelistApplier");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
const _DirectAccessProxyBuilder = class _DirectAccessProxyBuilder {
  constructor(kibanaUrl, requestHeadersWhitelist, rorSettingsStore) {
    this.kibanaUrl = kibanaUrl;
    this.requestHeadersWhitelist = requestHeadersWhitelist;
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "authorizationHeaderDecorator", async (proxyRequestOptions, sourceRequest) => {
      var _a;
      const { pkpKibanaToken } = this.rorSettingsStore.getLatestRorKbnSettings();
      (_a = proxyRequestOptions.headers) != null ? _a : proxyRequestOptions.headers = {};
      const headers = proxyRequestOptions.headers;
      import_requestHeadersWhitelistApplier.RequestHeadersWhitelistApplier.apply(
        _DirectAccessProxyBuilder.logger,
        this.requestHeadersWhitelist,
        sourceRequest.headers,
        headers
      );
      (0, import_proxyRequestHeaders.prepareProxyRequestHeaders)(
        _DirectAccessProxyBuilder.logger,
        this.requestHeadersWhitelist,
        sourceRequest.headers,
        headers
      );
      headers["x-ror-pkp-kibana-token"] = pkpKibanaToken;
      return proxyRequestOptions;
    });
    __publicField(this, "proxyErrorHandler", (error, res, next) => {
      import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename).trace("error: ", error);
      next(error);
    });
  }
  build() {
    const proxyOptions = {
      https: false,
      preserveHostHdr: true,
      parseReqBody: false,
      // @ts-ignore
      proxyReqOptDecorator: this.authorizationHeaderDecorator,
      // @ts-ignore
      proxyErrorHandler: this.proxyErrorHandler,
      limit: "500gb",
      skipToNextHandlerFilter(proxyRes) {
        if (proxyRes.statusCode === 404) {
          _DirectAccessProxyBuilder.logger.error(
            new Error(
              `The request ${proxyRes.method} ${proxyRes.url} was handled as a readonlyrest_kbn.whitelistedPaths, but resulted in a 404. Please check the list of whitelisted paths and review they are all valid and correct. Typically this option is used only for health checks. See documentation: https://docs.readonlyrest.com/kibana#enable-health-check-endpoint`
            )
          );
        }
        return false;
      }
    };
    return (0, import_express_http_proxy.default)(this.kibanaUrl, proxyOptions);
  }
};
__publicField(_DirectAccessProxyBuilder, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let DirectAccessProxyBuilder = _DirectAccessProxyBuilder;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DirectAccessProxyBuilder
});
