"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var abstractIndexCreator_exports = {};
__export(abstractIndexCreator_exports, {
  AbstractIndexCreator: () => AbstractIndexCreator
});
module.exports = __toCommonJS(abstractIndexCreator_exports);
var import_distributionInfoProvider = require("../../../kibana/patchers/distributionInfoProvider");
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
var import_tenantIndexBasedOnTemplateApplier = require("./indexTemplating/tenantIndexBasedOnTemplateApplier");
var import_tenancyIndexRepairer = require("./tenancyIndexRepairer");
const migrator = require("../../../kibana/migrator");
class AbstractIndexCreator {
  constructor(esApiClientWithAuthProvider, esApiAdvancedClientWithAuthProvider, defaultKibanaIndex, implementorFilePathForLogging, defaultSpaceCreator, rorSettingsStore, pollConfig) {
    this.esApiClientWithAuthProvider = esApiClientWithAuthProvider;
    this.esApiAdvancedClientWithAuthProvider = esApiAdvancedClientWithAuthProvider;
    this.defaultKibanaIndex = defaultKibanaIndex;
    this.defaultSpaceCreator = defaultSpaceCreator;
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger");
    __publicField(this, "indexTemplateApplier");
    __publicField(this, "tenancyIndexRepairer");
    this.logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(implementorFilePathForLogging);
    this.indexTemplateApplier = new import_tenantIndexBasedOnTemplateApplier.TenantIndexBasedOnTemplateApplier(esApiClientWithAuthProvider, rorSettingsStore);
    this.tenancyIndexRepairer = new import_tenancyIndexRepairer.TenancyIndexRepairer(
      esApiAdvancedClientWithAuthProvider,
      rorSettingsStore,
      pollConfig
    );
  }
  async createIndexAndSpace(metadata) {
    if (metadata.kibanaIndex) {
      await this.migrateIndexes(metadata.kibanaIndex);
      await this.createIndexIfNecessary(metadata.kibanaIndex, metadata.kibanaTemplateIndex);
      await this.defaultSpaceCreator.createDefaultSpaceDocumentIfNeeded(metadata.kibanaIndex);
    }
  }
  async createIndexIfNecessary(kibanaIndex, kibanaTemplateIndexFromSession) {
    if (!await this.doesIndexExist(kibanaIndex)) {
      this.logger.debug(`Kibana index ${kibanaIndex} did not exist`);
      await this.createKibanaIndex(kibanaIndex, this.defaultKibanaIndex);
    }
    for (const suffix of import_tenancyIndexRepairer.SUB_INDEX_SUFFIXES) {
      await this.createKibanaTenantBasedIndex(kibanaIndex, suffix);
    }
    const { kibanaTemplateIndex: templateIndexFromConfig } = this.rorSettingsStore.getLatestRorKbnSettings();
    const kibanaTemplateIndex = kibanaTemplateIndexFromSession || templateIndexFromConfig;
    if (!kibanaTemplateIndex) {
      return;
    }
    if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("8.12.0")) {
      await this.indexTemplateApplier.applyTemplateToIndex(kibanaIndex, kibanaTemplateIndex);
    }
    if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaNeverOrEqualTo("8.8.0")) {
      await this.indexTemplateApplier.applyTemplateToIndex(
        `${kibanaIndex}_analytics`,
        `${kibanaTemplateIndex}_analytics`
      );
    }
  }
  async createKibanaTenantBasedIndex(kibanaIndex, suffix) {
    if (await this.doesIndexExist(`${this.defaultKibanaIndex}_${suffix}`)) {
      if (!await this.doesIndexExist(`${kibanaIndex}_${suffix}`)) {
        this.logger.debug(`Creating tenant based index for .kibana_${suffix}`);
        await this.createKibanaIndex(kibanaIndex, `${this.defaultKibanaIndex}_${suffix}`);
      }
    }
  }
  async migrateIndexes(kibanaIndex) {
    if (await this.isMigrationNeeded(kibanaIndex)) {
      try {
        await migrator.runMigration(kibanaIndex, this.logger);
      } catch (e) {
        if (kibanaIndex === this.defaultKibanaIndex || !import_tenancyIndexRepairer.TenancyIndexRepairer.isVersionGateError(e)) {
          throw e;
        }
        this.logger.warn(
          `Migration failed for tenancy index ${kibanaIndex}: ${e.message}. Reindexing stale versioned indexes to the correct version name.`
        );
        const recoveryResult = await this.tenancyIndexRepairer.recover(kibanaIndex);
        if (!recoveryResult.ok) {
          throw e;
        }
      }
    }
  }
  async getDefaultIndexMapping(index) {
    const response = await this.esApiClientWithAuthProvider.asTechnicalUser().getMappingDefinitions({ indexName: index });
    const mappingsJsonResponse = await response.json();
    const { error } = mappingsJsonResponse;
    if (mappingsJsonResponse.status === 404) {
      this.logger.debug("Kibana index mappings not found", JSON.stringify(mappingsJsonResponse));
      throw new Error("Kibana index mappings not found");
    }
    if (error) {
      this.logger.error({ message: "Error in reading kibana index mappings:" }, mappingsJsonResponse);
      throw new Error(JSON.stringify(mappingsJsonResponse));
    }
    this.logger.debug(
      `Mappings extracted from default kibana index (${index}):`,
      `${JSON.stringify(mappingsJsonResponse).substring(0, 30)}...`
    );
    return mappingsJsonResponse;
  }
  async doesIndexExist(kibanaIndex) {
    const response = await this.esApiClientWithAuthProvider.asTechnicalUser().checkIndices({ indexName: kibanaIndex });
    return response.status === 200;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AbstractIndexCreator
});
