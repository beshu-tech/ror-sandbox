"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var documentRequestIndexCreator_exports = {};
__export(documentRequestIndexCreator_exports, {
  DocumentRequestIndexCreator: () => DocumentRequestIndexCreator
});
module.exports = __toCommonJS(documentRequestIndexCreator_exports);
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
var import_ensuredIndexAndSpaceCache = require("./ensuredIndexAndSpaceCache");
class DocumentRequestIndexCreator {
  constructor(indexCreator, onError) {
    this.indexCreator = indexCreator;
    this.onError = onError;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "ensureIndexAndSpaceForRequest", async (req, res, next) => {
      if (!this.isDocumentRequest(req)) {
        return next();
      }
      try {
        const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
        if (!(userRequestIdentity == null ? void 0 : userRequestIdentity.metadata)) {
          this.logger.debug("User request identity metadata not available, skipping index creation");
          return next();
        }
        const { sid, metadata } = userRequestIdentity;
        if (import_ensuredIndexAndSpaceCache.ensuredIndexAndSpaceCache.has(sid, metadata.kibanaIndex)) {
          return next();
        }
        this.logger.debug("Creating index and space for", {
          username: metadata.username,
          index: metadata.kibanaIndex
        });
        await this.indexCreator.createIndexAndSpace(metadata);
        import_ensuredIndexAndSpaceCache.ensuredIndexAndSpaceCache.set(sid, metadata.kibanaIndex);
        return next();
      } catch (error) {
        this.logger.error({
          message: "Failed to create index and space for document request",
          stack: error instanceof Error ? error.stack : String(error)
        });
        return this.onError(req, res);
      }
    });
  }
  isDocumentRequest(req) {
    const acceptHeader = req.get("accept") || "";
    return acceptHeader.includes("text/html");
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DocumentRequestIndexCreator
});
