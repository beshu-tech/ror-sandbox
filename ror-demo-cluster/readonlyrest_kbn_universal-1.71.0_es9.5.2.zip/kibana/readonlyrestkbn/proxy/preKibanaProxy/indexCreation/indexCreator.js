"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var indexCreator_exports = {};
__export(indexCreator_exports, {
  IndexCreator: () => IndexCreator
});
module.exports = __toCommonJS(indexCreator_exports);
var import_distributionInfoProvider = require("../../../kibana/patchers/distributionInfoProvider");
var import_abstractIndexCreator = require("./abstractIndexCreator");
const _IndexCreator = class _IndexCreator extends import_abstractIndexCreator.AbstractIndexCreator {
  constructor(defaultKibanaIndex, esApiClientWithAuthProvider, esApiAdvancedClientWithAuthProvider, defaultSpaceCreator, rorSettingsStore, pollConfig) {
    super(
      esApiClientWithAuthProvider,
      esApiAdvancedClientWithAuthProvider,
      defaultKibanaIndex,
      __filename,
      defaultSpaceCreator,
      rorSettingsStore,
      pollConfig
    );
    this.defaultKibanaIndex = defaultKibanaIndex;
    this.esApiClientWithAuthProvider = esApiClientWithAuthProvider;
    this.esApiAdvancedClientWithAuthProvider = esApiAdvancedClientWithAuthProvider;
    this.rorSettingsStore = rorSettingsStore;
  }
  async createKibanaIndex(kibanaIndexFromSession, baseIndex) {
    const mapping = await this.getDefaultIndexMapping(baseIndex);
    const realDefaultKibanaIndexPotentiallyBehindAlias = Object.keys(mapping)[0];
    const { tenantIndex } = this.rorSettingsStore.getLatestRorKbnSettings();
    const versionedBaseIndex = await this.resolveCurrentVersionIndex(
      realDefaultKibanaIndexPotentiallyBehindAlias,
      baseIndex
    );
    const mappingWithAliasHandled = mapping[realDefaultKibanaIndexPotentiallyBehindAlias].mappings;
    const putPayload = {
      settings: {
        "index.mapping.total_fields.limit": 2e3,
        number_of_shards: tenantIndex == null ? void 0 : tenantIndex.number_of_shards,
        number_of_replicas: tenantIndex == null ? void 0 : tenantIndex.number_of_replicas
      },
      mappings: { properties: mappingWithAliasHandled.properties }
    };
    const kibanaIndexToCreate = versionedBaseIndex.split(this.defaultKibanaIndex).join(kibanaIndexFromSession);
    const shortFormAlias = _IndexCreator.getShortFormAlias(kibanaIndexToCreate);
    const kibanaIndexToCreateWithoutAlias = kibanaIndexToCreate.split(/_\d./)[0];
    this.logger.debug(
      `Discovered Kibana >= 7.12.0 index migration algorithm in use. Will create the index ${kibanaIndexToCreate} with aliases: ${shortFormAlias}`
    );
    if (shortFormAlias && kibanaIndexToCreateWithoutAlias) {
      putPayload.aliases = {
        [kibanaIndexToCreateWithoutAlias]: {},
        [shortFormAlias]: {}
      };
    }
    this.logger.debug(
      `kibana_index resolution: default=${baseIndex} (physical=${realDefaultKibanaIndexPotentiallyBehindAlias}, versioned=${versionedBaseIndex}), fromSession=${kibanaIndexFromSession}, willBeCreated=${kibanaIndexToCreate}`
    );
    this.logger.debug(
      `Creating kibana index ${kibanaIndexFromSession} with mappings from ${baseIndex}: PUT ${JSON.stringify(
        putPayload
      ).substring(0, 50)}...`
    );
    await this.esApiClientWithAuthProvider.asTechnicalUser().createIndex({ indexName: kibanaIndexToCreate, requestBody: putPayload });
  }
  async resolveCurrentVersionIndex(kibanaIndex, baseIndex) {
    var _a, _b;
    try {
      const aliasResponse = await this.esApiClientWithAuthProvider.asTechnicalUser().getAliases();
      if (!aliasResponse.ok) return kibanaIndex;
      const aliasData = await aliasResponse.json();
      const aliases = Object.keys((_b = (_a = aliasData[kibanaIndex]) == null ? void 0 : _a.aliases) != null ? _b : {});
      const baseVersion = import_distributionInfoProvider.DistributionInfoProvider.getInstance().kibanaBaseVersion;
      const currentVersionAlias = aliases.find((alias) => alias === `${baseIndex}_${baseVersion}`);
      if (currentVersionAlias) {
        const suffix = _IndexCreator.getPost712KibanaIndexSuffix(kibanaIndex);
        if (suffix) {
          const resolved = `${currentVersionAlias}${suffix}`;
          if (resolved !== kibanaIndex) {
            this.logger.debug(
              `resolveCurrentVersionIndex: kibana index ${kibanaIndex} carries alias ${currentVersionAlias} \u2014 using ${resolved} as tenancy index template`
            );
          }
          return resolved;
        }
      }
    } catch (e) {
      this.logger.error({
        message: `resolveCurrentVersionIndex failed for ${kibanaIndex}: ${e.message}`,
        stack: e.stack
      });
    }
    return kibanaIndex;
  }
  async isMigrationNeeded(kibanaIndex) {
    var _a;
    try {
      const response = await this.esApiClientWithAuthProvider.asTechnicalUser().getAliases({ indexName: kibanaIndex });
      if (!response.ok) {
        return false;
      }
      const data = await response.json();
      this.logger.debug('isMigrationNeeded "/alias" endpoint data', data);
      const kibanaIndexVersion = (_a = _IndexCreator.getShortFormAlias(Object.keys(data)[0])) == null ? void 0 : _a.split(`${kibanaIndex}_`)[1];
      this.logger.debug(`isMigrationNeeded kibanaIndexVersion: ${kibanaIndexVersion}`);
      const kibanaBaseVersion = import_distributionInfoProvider.DistributionInfoProvider.getInstance().kibanaBaseVersion;
      const indexBaseVersion = import_distributionInfoProvider.DistributionInfoProvider.extractBaseVersion(kibanaIndexVersion || "");
      this.logger.debug(`isMigrationNeeded kibanaBaseVersion: ${kibanaBaseVersion}`);
      this.logger.debug(`isMigrationNeeded indexBaseVersion ${indexBaseVersion}`);
      return kibanaBaseVersion !== indexBaseVersion;
    } catch (e) {
      this.logger.error({ message: `Failed is migration needed check: ${e.message}`, stack: e.stack });
      return false;
    }
  }
  static getShortFormAlias(kibanaIndexToCreate) {
    const post712suffix = _IndexCreator.getPost712KibanaIndexSuffix(kibanaIndexToCreate);
    if (!post712suffix) {
      return null;
    }
    return kibanaIndexToCreate.substring(0, kibanaIndexToCreate.length - post712suffix.length);
  }
  static getPost712KibanaIndexSuffix(defaultKibanaIndex) {
    const match = defaultKibanaIndex.match(_IndexCreator.POST_7_12_KIBANA_INDEX_SUFFIX);
    return match ? match[0] : null;
  }
};
__publicField(_IndexCreator, "POST_7_12_KIBANA_INDEX_SUFFIX", /_[0-9][0-9][0-9]$/);
let IndexCreator = _IndexCreator;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  IndexCreator
});
