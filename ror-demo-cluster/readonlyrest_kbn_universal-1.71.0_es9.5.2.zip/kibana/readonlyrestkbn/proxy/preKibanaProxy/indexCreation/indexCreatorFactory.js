"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var indexCreatorFactory_exports = {};
__export(indexCreatorFactory_exports, {
  IndexCreatorFactory: () => IndexCreatorFactory
});
module.exports = __toCommonJS(indexCreatorFactory_exports);
var import_distributionInfoProvider = require("../../../kibana/patchers/distributionInfoProvider");
var import_indexCreator = require("./indexCreator");
var import_pre_7_12_0_index_creator = require("./pre_7_12_0__index_creator");
class IndexCreatorFactory {
  static create(defaultKibanaIndex, esApiClientWithAuthProvider, esApiAdvancedClientWithAuthProvider, defaultSpaceCreator, rorSettingsStore) {
    return import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("7.12.0") ? new import_pre_7_12_0_index_creator.Pre_7_12_0_IndexCreator(
      defaultKibanaIndex,
      esApiClientWithAuthProvider,
      esApiAdvancedClientWithAuthProvider,
      defaultSpaceCreator,
      rorSettingsStore
    ) : new import_indexCreator.IndexCreator(
      defaultKibanaIndex,
      esApiClientWithAuthProvider,
      esApiAdvancedClientWithAuthProvider,
      defaultSpaceCreator,
      rorSettingsStore
    );
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  IndexCreatorFactory
});
