"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var templateIndexSurplusRemover_exports = {};
__export(templateIndexSurplusRemover_exports, {
  TemplateIndexSurplusRemover: () => TemplateIndexSurplusRemover
});
module.exports = __toCommonJS(templateIndexSurplusRemover_exports);
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
class TemplateIndexSurplusRemover {
  constructor(esApiClientWithAuthProvider) {
    this.esApiClientWithAuthProvider = esApiClientWithAuthProvider;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "verifyDocumentExistsIn", (index) => (documentId) => this.esApiClientWithAuthProvider.asTechnicalUser().checkDocument({ indexName: index, docId: documentId }).then((response) => response.status).then((status) => ({ id: documentId, exists: status === 200 })));
  }
  async removeFromTargetDocumentsMissingInTemplate(numberOfDocumentsInTemplate, tenantIndex, templateIndex) {
    this.logger.info(`Looking for documents present in '${tenantIndex}' but not in template index`);
    const allDocumentsInTarget = await this.retrieveAllDocumentsFrom(tenantIndex);
    const surplus = await this.identifySurplus(
      numberOfDocumentsInTemplate,
      tenantIndex,
      allDocumentsInTarget,
      templateIndex
    );
    return this.removeSurplusFrom(tenantIndex, surplus);
  }
  async retrieveAllDocumentsFrom(tenantIndex) {
    const response = await this.esApiClientWithAuthProvider.asTechnicalUser().runSearch({ indexName: tenantIndex });
    const json = await response.json();
    this.logger.trace("Response: ", JSON.stringify(json));
    return json.hits.hits.map((hit) => hit._id);
  }
  async identifySurplus(numberOfDocumentsInTemplate, tenantIndex, allDocumentsInTarget, templateIndex) {
    if (allDocumentsInTarget.length === numberOfDocumentsInTemplate) {
      this.logger.info(`All documents in '${templateIndex}' match documents in '${tenantIndex}'. Nothing to remove.`);
      return Promise.resolve([]);
    }
    this.logger.info(
      `Target '${tenantIndex}' contains ${allDocumentsInTarget.length} documents but '${templateIndex}' contains ${numberOfDocumentsInTemplate}. Need to delete surplus.`
    );
    return Promise.all(allDocumentsInTarget.map(this.verifyDocumentExistsIn(templateIndex))).then(
      (documents) => documents.filter((document) => !document.exists).map((document) => document.id)
    );
  }
  removeSurplusFrom(index, surplus) {
    Promise.all(
      surplus.map((documentId) => {
        this.logger.debug(`Deleting document with id: '${documentId}'`);
        return this.esApiClientWithAuthProvider.asTechnicalUser().deleteDocument({ indexName: index, docId: documentId });
      })
    );
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TemplateIndexSurplusRemover
});
