"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var tenantIndexBasedOnTemplateApplier_exports = {};
__export(tenantIndexBasedOnTemplateApplier_exports, {
  TenantIndexBasedOnTemplateApplier: () => TenantIndexBasedOnTemplateApplier
});
module.exports = __toCommonJS(tenantIndexBasedOnTemplateApplier_exports);
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_templateIndexSurplusRemover = require("./templateIndexSurplusRemover");
class TenantIndexBasedOnTemplateApplier {
  constructor(esApiClientWithAuthProvider, rorSettingsStore) {
    this.esApiClientWithAuthProvider = esApiClientWithAuthProvider;
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "templateIndexSurplusRemover");
    this.templateIndexSurplusRemover = new import_templateIndexSurplusRemover.TemplateIndexSurplusRemover(esApiClientWithAuthProvider);
  }
  async applyTemplateToIndex(tenantIndex, templateIndex) {
    if (templateIndex == null) {
      this.logger.debug("Template index not defined. Returning");
      return Promise.resolve();
    }
    if (templateIndex === tenantIndex) {
      this.logger.info("Template and target indices are the same. Aborting reindexing.");
      return Promise.resolve();
    }
    try {
      const totalDocumentsCopied = await this.copyAllDocumentsFromTemplateTo(tenantIndex, templateIndex);
      const { resetKibanaIndexToTemplate } = this.rorSettingsStore.getLatestRorKbnSettings();
      if (resetKibanaIndexToTemplate) {
        return this.templateIndexSurplusRemover.removeFromTargetDocumentsMissingInTemplate(
          totalDocumentsCopied,
          tenantIndex,
          templateIndex
        );
      }
    } catch (error) {
      this.handleErrors(error, tenantIndex, templateIndex);
    }
  }
  async copyAllDocumentsFromTemplateTo(tenantIndex, templateIndex) {
    this.logger.info(`Copying all Kibana objects from '${templateIndex}' to '${tenantIndex}'`);
    return this.esApiClientWithAuthProvider.asTechnicalUser().reindexDocuments({
      requestBody: {
        source: {
          index: templateIndex
        },
        dest: {
          index: tenantIndex,
          version_type: "internal"
          // blindly overwrite (was internal by default, but better force it: default may vary in the future)
        }
      }
    }).then(async (response) => {
      const data = await response.json();
      this.logger.debug("Re-indexed documents:", data);
      return data;
    }).catch((e) => {
      this.logger.error({ message: `Re-indexed documents error: ${e.message}`, stack: e.stack });
    }).then((json) => json.total);
  }
  handleErrors(error, target, templateIndex) {
    var _a;
    if ((_a = error.message) == null ? void 0 : _a.includes("index_not_found_exception")) {
      this.logger.warn("Template index was not found, won't copy anything");
    } else {
      this.logger.error({
        message: `Reindexing for '${target}' based on template index '${templateIndex}' failed: ${error.message}`,
        stack: error.stack
      });
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TenantIndexBasedOnTemplateApplier
});
