"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var pre_7_12_0_index_creator_exports = {};
__export(pre_7_12_0_index_creator_exports, {
  Pre_7_12_0_IndexCreator: () => Pre_7_12_0_IndexCreator
});
module.exports = __toCommonJS(pre_7_12_0_index_creator_exports);
var import_abstractIndexCreator = require("./abstractIndexCreator");
class Pre_7_12_0_IndexCreator extends import_abstractIndexCreator.AbstractIndexCreator {
  constructor(defaultKibanaIndex, esApiClientWithAuthProvider, esApiAdvancedClientWithAuthProvider, defaultSpaceCreator, rorSettingsStore) {
    super(
      esApiClientWithAuthProvider,
      esApiAdvancedClientWithAuthProvider,
      defaultKibanaIndex,
      __filename,
      defaultSpaceCreator,
      rorSettingsStore
    );
    this.defaultKibanaIndex = defaultKibanaIndex;
    this.esApiClientWithAuthProvider = esApiClientWithAuthProvider;
  }
  async createKibanaIndex(kibanaIndexFromSession, baseIndex) {
    const mapping = await this.getDefaultIndexMapping(baseIndex);
    const realDefaultKibanaIndexPotentiallyBehindAlias = Object.keys(mapping)[0];
    const mappingWithAliasHandled = mapping[realDefaultKibanaIndexPotentiallyBehindAlias].mappings;
    const putPayload = { mappings: { properties: mappingWithAliasHandled.properties } };
    this.logger.debug(
      `kibana_index resolution: default=${baseIndex}, fromSession=${kibanaIndexFromSession}, willBeCreated=${kibanaIndexFromSession}`
    );
    this.logger.debug(
      `Creating kibana index ${kibanaIndexFromSession} with mappings from ${baseIndex}: PUT ${JSON.stringify(
        putPayload
      ).substring(0, 50)}...`
    );
    await this.esApiClientWithAuthProvider.asTechnicalUser().createIndex({ indexName: kibanaIndexFromSession, requestBody: putPayload });
  }
  isMigrationNeeded() {
    return false;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Pre_7_12_0_IndexCreator
});
