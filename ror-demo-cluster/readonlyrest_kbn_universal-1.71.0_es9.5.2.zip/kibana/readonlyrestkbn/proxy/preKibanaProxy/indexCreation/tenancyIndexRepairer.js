"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var tenancyIndexRepairer_exports = {};
__export(tenancyIndexRepairer_exports, {
  SUB_INDEX_SUFFIXES: () => SUB_INDEX_SUFFIXES,
  TenancyIndexRepairer: () => TenancyIndexRepairer
});
module.exports = __toCommonJS(tenancyIndexRepairer_exports);
var import_distributionInfoProvider = require("../../../kibana/patchers/distributionInfoProvider");
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
const migrator = require("../../../kibana/migrator");
const SUB_INDEX_SUFFIXES = [
  "analytics",
  "alerting_cases",
  "security_solution",
  "ingest",
  "usage_counters",
  "search_solution"
];
const _TenancyIndexRepairer = class _TenancyIndexRepairer {
  constructor(esApiAdvancedClientWithAuthProvider, rorSettingsStore, pollConfig = {}) {
    this.esApiAdvancedClientWithAuthProvider = esApiAdvancedClientWithAuthProvider;
    this.rorSettingsStore = rorSettingsStore;
    __publicField(this, "pollIntervalMs");
    __publicField(this, "maxAttempts");
    __publicField(this, "maxConsecutiveFailures");
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    var _a, _b, _c;
    this.pollIntervalMs = (_a = pollConfig.pollIntervalMs) != null ? _a : 5e3;
    this.maxAttempts = (_b = pollConfig.maxAttempts) != null ? _b : 360;
    this.maxConsecutiveFailures = (_c = pollConfig.maxConsecutiveFailures) != null ? _c : 3;
  }
  static isVersionGateError(e) {
    return e instanceof migrator.KibanaVersionGateError;
  }
  async recover(kibanaIndex) {
    let inFlight = _TenancyIndexRepairer.recoveryInFlight.get(kibanaIndex);
    if (!inFlight) {
      const maxMs = this.maxAttempts * this.pollIntervalMs;
      const promise = (async () => {
        const currentVersion = import_distributionInfoProvider.DistributionInfoProvider.getInstance().kibanaBaseVersion;
        const repairResult = await this.repairAll(kibanaIndex, currentVersion);
        if (!repairResult.ok) {
          return repairResult;
        }
        await migrator.runMigration(kibanaIndex, this.logger);
        return { ok: true };
      })().finally(() => {
        _TenancyIndexRepairer.recoveryInFlight.delete(kibanaIndex);
      });
      inFlight = { promise, startedAt: Date.now(), maxMs };
      _TenancyIndexRepairer.recoveryInFlight.set(kibanaIndex, inFlight);
    } else {
      const remainingMin = Math.ceil(Math.max(0, inFlight.maxMs - (Date.now() - inFlight.startedAt)) / 6e4);
      this.logger.warn(
        `Tenancy index repair already in progress for ${kibanaIndex} \u2014 login will resume when complete (~${remainingMin} min remaining)`
      );
    }
    return inFlight.promise;
  }
  async repairAll(kibanaIndex, currentVersion) {
    const suffixes = ["", ...SUB_INDEX_SUFFIXES.map((s) => `_${s}`)];
    for (const suffix of suffixes) {
      const alias = `${kibanaIndex}${suffix}`;
      const isMainAlias = suffix === "";
      try {
        const result = await this.repairAlias(alias, isMainAlias, currentVersion);
        if (!result.ok) return result;
      } catch (repairError) {
        if (isMainAlias) {
          throw repairError;
        }
        this.logger.error({
          message: `Failed to repair stale tenancy index for alias ${alias}: ${repairError.message}`
        });
      }
    }
    return { ok: true };
  }
  async repairAlias(alias, isMainAlias, currentVersion) {
    var _a;
    const aliasData = await this.fetchAliases(alias);
    if (aliasData === null) {
      if (isMainAlias) {
        throw new Error(`Cannot fetch aliases for main tenancy index ${alias}: repair aborted`);
      }
      return { ok: true };
    }
    for (const oldIndex of Object.keys(aliasData)) {
      const versionedIndexMatch = oldIndex.match(
        new RegExp(`^${_TenancyIndexRepairer.escapeRegExp(alias)}_(?<version>\\d+\\.\\d+\\.\\d+)(?<seq>_\\d{3})$`)
      );
      if (!versionedIndexMatch) continue;
      const numericSuffix = (_a = versionedIndexMatch.groups) == null ? void 0 : _a.seq;
      const newIndex = `${alias}_${currentVersion}${numericSuffix}`;
      if (newIndex === oldIndex) continue;
      const repaired = await this.reindexStaleIndex(oldIndex, newIndex, alias, currentVersion);
      if (!repaired.ok && isMainAlias) return repaired;
    }
    return { ok: true };
  }
  async reindexStaleIndex(oldIndex, newIndex, alias, version) {
    this.logger.info(`Reindexing stale tenancy index: ${oldIndex} \u2192 ${newIndex}`);
    const mapping = await this.fetchMapping(oldIndex);
    const safetyCheck = this.assertSafeToRename(mapping, oldIndex);
    if (safetyCheck !== null) return safetyCheck;
    await this.writeBlock(oldIndex);
    let taskId;
    let newIndexCreated = false;
    try {
      const srcCount = await this.fetchDocumentCount(oldIndex);
      const settings = await this.fetchIndexSettings(oldIndex);
      const createPayload = this.resolveCreatePayload(mapping, oldIndex, settings);
      await this.createTargetIndex(newIndex, createPayload);
      newIndexCreated = true;
      taskId = await this.startReindex(oldIndex, newIndex);
      const reindexResult = await this.pollUntilComplete(taskId);
      if (reindexResult.failures && reindexResult.failures.length > 0) {
        throw new Error(
          `Reindex ${oldIndex} \u2192 ${newIndex} completed with ${reindexResult.failures.length} failure(s): ${JSON.stringify(reindexResult.failures)}`
        );
      }
      this.verifyDocumentCounts(reindexResult, srcCount, oldIndex, newIndex);
      await this.swapAliases(oldIndex, newIndex, alias, `${alias}_${version}`);
      await this.unblock(oldIndex).catch((unblockErr) => {
        this.logger.warn(`Could not unblock ${oldIndex} after alias swap: ${unblockErr.message}`);
      });
    } catch (error) {
      await this.rollback({ oldIndex, newIndex, taskId, newIndexCreated });
      this.logger.warn(`Reindex ${oldIndex} \u2192 ${newIndex} failed, rolling back: ${error.message}`);
      throw error;
    }
    this.logger.info(`Deleting old stale index ${oldIndex} after successful reindex`);
    await this.deleteIndex(oldIndex).catch((err) => {
      this.logger.warn(
        `Could not delete stale index ${oldIndex} (now alias-free, safe to clean up manually): ${err.message}`
      );
    });
    return { ok: true };
  }
  assertSafeToRename(mapping, index) {
    var _a, _b, _c;
    const metaHashes = (_c = (_b = (_a = mapping[index]) == null ? void 0 : _a.mappings) == null ? void 0 : _b._meta) == null ? void 0 : _c.migrationMappingPropertyHashes;
    if (metaHashes && Object.keys(metaHashes).length > 0) {
      const message = `Repair of ${index} aborted: mappings._meta.migrationMappingPropertyHashes is non-empty, indicating this index was written by an older Kibana. Upgrade through the required intermediate version before migrating to the current major.`;
      this.logger.warn(message);
      return { ok: false, message };
    }
    return null;
  }
  resolveCreatePayload(mapping, oldIndex, settings) {
    var _a, _b, _c, _d;
    const { tenantIndex } = this.rorSettingsStore.getLatestRorKbnSettings();
    return {
      mappings: (_b = (_a = mapping[oldIndex]) == null ? void 0 : _a.mappings) != null ? _b : {},
      settings: {
        "index.mapping.total_fields.limit": settings.fieldLimit,
        number_of_shards: (_c = settings.shards) != null ? _c : tenantIndex == null ? void 0 : tenantIndex.number_of_shards,
        number_of_replicas: (_d = settings.replicas) != null ? _d : tenantIndex == null ? void 0 : tenantIndex.number_of_replicas
      }
    };
  }
  async createTargetIndex(newIndex, payload) {
    var _a, _b;
    let createResponse = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().createIndex({ indexName: newIndex, requestBody: payload });
    if (createResponse.status === 400) {
      const aliasData = await this.fetchAliases(newIndex);
      if (aliasData !== null) {
        const orphanAliases = (_b = (_a = aliasData[newIndex]) == null ? void 0 : _a.aliases) != null ? _b : {};
        if (Object.keys(orphanAliases).length === 0) {
          this.logger.warn(`Deleting alias-free orphan ${newIndex} left by a prior crashed repair`);
          await this.deleteIndex(newIndex);
          createResponse = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().createIndex({ indexName: newIndex, requestBody: payload });
        }
      }
    }
    if (createResponse.status >= 300) {
      throw new Error(`Failed to create index ${newIndex}: HTTP ${createResponse.status}`);
    }
  }
  async pollUntilComplete(taskId) {
    const { pollIntervalMs: pollMs, maxAttempts, maxConsecutiveFailures } = this;
    let consecutiveFailures = 0;
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      if (attempt > 0) {
        await new Promise((resolve) => setTimeout(resolve, pollMs));
      }
      let taskStatus;
      try {
        const response = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().getTask({ taskId });
        taskStatus = {
          ok: response.ok,
          status: response.status,
          // eslint-disable-next-line no-await-in-loop
          data: response.ok ? await response.json() : void 0
        };
      } catch (fetchErr) {
        consecutiveFailures += 1;
        if (consecutiveFailures >= maxConsecutiveFailures) {
          throw new Error(
            `Could not poll reindex task ${taskId} \u2014 ${maxConsecutiveFailures} consecutive failures: ${fetchErr.message}`
          );
        }
        this.logger.warn(
          `Transient fetch error polling task ${taskId} (${consecutiveFailures}/${maxConsecutiveFailures}): ${fetchErr.message}`
        );
        continue;
      }
      if (!taskStatus.ok) {
        consecutiveFailures += 1;
        if (consecutiveFailures >= maxConsecutiveFailures) {
          throw new Error(
            `Could not poll reindex task ${taskId} \u2014 ${maxConsecutiveFailures} consecutive failures: HTTP ${taskStatus.status}`
          );
        }
        this.logger.warn(
          `Transient HTTP failure polling task ${taskId} (${consecutiveFailures}/${maxConsecutiveFailures}): HTTP ${taskStatus.status}`
        );
        continue;
      }
      consecutiveFailures = 0;
      const taskData = taskStatus.data;
      if (taskData.completed) {
        if (taskData.error) {
          throw new Error(`Reindex task ${taskId} failed: ${JSON.stringify(taskData.error)}`);
        }
        if (!taskData.response) {
          throw new Error(`Reindex task ${taskId} completed but response body was empty`);
        }
        return taskData.response;
      }
      this.logger.debug(`Waiting for reindex task ${taskId} (attempt ${attempt + 1}/${maxAttempts})`);
    }
    throw new Error(`Reindex task ${taskId} did not complete within ${maxAttempts * pollMs / 6e4} minutes`);
  }
  verifyDocumentCounts(result, srcCount, oldIndex, newIndex) {
    const reindexedCount = result.created + result.updated;
    if (reindexedCount !== srcCount) {
      throw new Error(
        `Doc count mismatch after reindex: source ${oldIndex}=${srcCount}, dest ${newIndex} written=${reindexedCount} (task total=${result.total})`
      );
    }
  }
  async rollback(params) {
    const { oldIndex, newIndex, taskId, newIndexCreated } = params;
    if (taskId) {
      await this.cancelTask(taskId);
    }
    await this.unblock(oldIndex).catch((unblockErr) => {
      this.logger.error({
        message: `Could not unblock source index ${oldIndex} during rollback: ${unblockErr.message}`
      });
    });
    if (newIndexCreated) {
      await this.deleteIndex(newIndex).catch((cleanupErr) => {
        this.logger.error({
          message: `Rollback cleanup failed \u2014 orphaned index ${newIndex}: ${cleanupErr.message}`
        });
      });
    }
  }
  async fetchAliases(alias) {
    const response = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().getAliases({ indexName: alias });
    if (!response.ok) return null;
    return response.json();
  }
  async fetchMapping(index) {
    const response = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().getMappingDefinitions({ indexName: index });
    if (!response.ok) {
      throw new Error(`Could not fetch mapping for ${index}`);
    }
    return response.json();
  }
  async writeBlock(index) {
    const response = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().setIndexWriteBlock({ indexName: index });
    if (response.status >= 300) {
      throw new Error(`Could not write-block source index ${index} before reindex`);
    }
  }
  async unblock(index) {
    const response = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().clearIndexWriteBlock({ indexName: index });
    if (response.status >= 300) {
      throw new Error(`Could not unblock index ${index}: HTTP ${response.status}`);
    }
  }
  async fetchDocumentCount(index) {
    const response = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().countDocuments({ indexName: index });
    if (!response.ok) {
      throw new Error(`Could not fetch document count for ${index}`);
    }
    const { count } = await response.json();
    return count;
  }
  async fetchIndexSettings(index) {
    var _a, _b, _c, _d;
    const response = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().getIndexSettings({ indexName: index });
    if (!response.ok) {
      this.logger.warn(`Could not fetch settings for ${index}, using defaults`);
      return { fieldLimit: 2e3, shards: void 0, replicas: void 0 };
    }
    const data = await response.json();
    const indexSettings = (_b = (_a = data[index]) == null ? void 0 : _a.settings) == null ? void 0 : _b.index;
    return {
      fieldLimit: ((_d = (_c = indexSettings == null ? void 0 : indexSettings.mapping) == null ? void 0 : _c.total_fields) == null ? void 0 : _d.limit) != null ? Number(indexSettings.mapping.total_fields.limit) : 2e3,
      shards: (indexSettings == null ? void 0 : indexSettings.number_of_shards) != null ? Number(indexSettings.number_of_shards) : void 0,
      replicas: (indexSettings == null ? void 0 : indexSettings.number_of_replicas) != null ? Number(indexSettings.number_of_replicas) : void 0
    };
  }
  async startReindex(source, dest) {
    const response = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().startAsyncReindex({ sourceIndex: source, destIndex: dest });
    if (!response.ok) {
      throw new Error(`Reindex from ${source} to ${dest} failed to start`);
    }
    const { task } = await response.json();
    return task;
  }
  async swapAliases(oldIndex, newIndex, alias, versionAlias) {
    const response = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().updateAliases({
      actions: [
        { remove: { index: oldIndex, alias } },
        { add: { index: newIndex, alias } },
        { add: { index: newIndex, alias: versionAlias } }
      ]
    });
    if (!response.ok) {
      throw new Error(`Alias update failed for ${newIndex}`);
    }
  }
  async cancelTask(taskId) {
    const response = await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().cancelTask({ taskId }).catch((cancelErr) => {
      this.logger.warn(`Could not cancel reindex task ${taskId}: ${cancelErr.message}`);
      return void 0;
    });
    if (response && !response.ok) {
      this.logger.warn(`Cancel request for reindex task ${taskId} returned HTTP ${response.status}`);
    }
  }
  async deleteIndex(index) {
    await this.esApiAdvancedClientWithAuthProvider.asTechnicalUser().deleteIndex({ indexName: index });
  }
  static escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
};
__publicField(_TenancyIndexRepairer, "recoveryInFlight", /* @__PURE__ */ new Map());
let TenancyIndexRepairer = _TenancyIndexRepairer;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SUB_INDEX_SUFFIXES,
  TenancyIndexRepairer
});
