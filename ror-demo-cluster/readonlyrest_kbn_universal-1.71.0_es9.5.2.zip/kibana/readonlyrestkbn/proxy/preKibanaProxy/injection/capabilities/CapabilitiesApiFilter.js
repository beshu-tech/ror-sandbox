"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var CapabilitiesApiFilter_exports = {};
__export(CapabilitiesApiFilter_exports, {
  CapabilitiesApiFilter: () => CapabilitiesApiFilter
});
module.exports = __toCommonJS(CapabilitiesApiFilter_exports);
var import_json_stable_stringify = __toESM(require("json-stable-stringify"));
var import_lodash = __toESM(require("lodash"));
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import__ = require(".");
const _CapabilitiesApiFilter = class _CapabilitiesApiFilter {
  static shouldInterceptResponseBody(req) {
    return req.path.includes("/api/core/capabilities");
  }
  static async interceptResponseBody(req, respBody) {
    const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
    const metadata = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata;
    if (!metadata) {
      return respBody;
    }
    const capResponse = this.fromResponseBuffer(respBody);
    const modifiedResponse = (0, import__.transform)(capResponse != null ? capResponse : {}, metadata);
    _CapabilitiesApiFilter.logger().trace("Modified intercepted body to: ", modifiedResponse);
    return Buffer.from((0, import_json_stable_stringify.default)(modifiedResponse, { space: "  " }));
  }
  static fromResponseBuffer(respBody) {
    let parsed;
    try {
      parsed = JSON.parse(respBody.toString());
    } catch {
      _CapabilitiesApiFilter.logger().warn(`Problem with parsing JSON ${respBody.toString().substr(0, 30)}...`);
    }
    if (!parsed || import_lodash.default.isEmpty(parsed.navLinks) || import_lodash.default.isEmpty(parsed.catalogue)) {
      _CapabilitiesApiFilter.logger().error({ message: `Bad object parsed!! ${JSON.stringify(parsed)}` });
    }
    return parsed;
  }
};
__publicField(_CapabilitiesApiFilter, "logger", () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let CapabilitiesApiFilter = _CapabilitiesApiFilter;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CapabilitiesApiFilter
});
