"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var capabilities_exports = {};
__export(capabilities_exports, {
  transform: () => transform
});
module.exports = __toCommonJS(capabilities_exports);
var import_HiddenAppsTransformer = require("./transformers/HiddenAppsTransformer");
var import_ManagementDisableTransformer = require("./transformers/ManagementDisableTransformer");
var import_MinimumManagementTransformer = require("./transformers/MinimumManagementTransformer");
var import_ObservabilityTransformer = require("./transformers/ObservabilityTransformer");
var import_ROUserTransformer = require("./transformers/ROUserTransformer");
function transform(cap, metadata) {
  const transformers = [
    import_HiddenAppsTransformer.HiddenAppsTransformer.transform,
    import_ROUserTransformer.ROUserTransformer.transform,
    import_ManagementDisableTransformer.ManagementDisableTransformer.transform,
    import_ObservabilityTransformer.ObservabilityTransformer.transform,
    import_MinimumManagementTransformer.MinimumManagementTransformer.transform
  ];
  cap = transformers.reduce((acc, fn) => fn(acc, metadata), cap);
  return cap;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  transform
});
