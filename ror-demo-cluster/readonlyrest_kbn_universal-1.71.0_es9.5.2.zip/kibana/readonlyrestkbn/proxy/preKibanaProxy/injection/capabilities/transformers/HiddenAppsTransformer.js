"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var HiddenAppsTransformer_exports = {};
__export(HiddenAppsTransformer_exports, {
  HiddenAppsTransformer: () => HiddenAppsTransformer
});
module.exports = __toCommonJS(HiddenAppsTransformer_exports);
var import_rorLoggerFactory = require("../../../../core/logging/rorLoggerFactory");
var import_utils = require("../utils");
const _HiddenAppsTransformer = class _HiddenAppsTransformer {
  static transform(cap, metadata) {
    const capsToDeactivate = (0, import_utils.getCapabilitiesToRemove)(metadata);
    const mutate = (section, o) => (0, import_utils.mutateAllCapabilitiesInObject)(o[section], (capability, subApp) => {
      const enableSubAppCapability = () => {
        const isSubAppDisabledViaSpacesApi = subApp && !o[section][capability][subApp];
        if (isSubAppDisabledViaSpacesApi) {
          return false;
        }
        const enable = !capsToDeactivate.find((c) => c === subApp);
        if (!enable) {
          _HiddenAppsTransformer.logger().trace(`Disabling capability ${section}.${capability}.${subApp}`);
        }
        return enable;
      };
      const enableCapability = () => {
        const isAppDisabledViaSpacesApi = !o[section][capability];
        if (isAppDisabledViaSpacesApi) {
          return false;
        }
        const enable = !capsToDeactivate.find((c) => c === capability);
        if (!enable) {
          _HiddenAppsTransformer.logger().trace(`Disabling capability ${section}.${capability}`);
        }
        return enable;
      };
      if (subApp) {
        return enableSubAppCapability();
      }
      return enableCapability();
    });
    mutate("navLinks", cap);
    mutate("catalogue", cap);
    mutate("management", cap);
    return cap;
  }
};
__publicField(_HiddenAppsTransformer, "logger", () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let HiddenAppsTransformer = _HiddenAppsTransformer;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HiddenAppsTransformer
});
