"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ManagementDisableTransformer_exports = {};
__export(ManagementDisableTransformer_exports, {
  ManagementDisableTransformer: () => ManagementDisableTransformer
});
module.exports = __toCommonJS(ManagementDisableTransformer_exports);
var import_lodash = __toESM(require("lodash"));
var import_utils = require("../utils");
class ManagementDisableTransformer {
  static transform(cap, metadata) {
    const capsToDeactivate = (0, import_utils.getCapabilitiesToRemove)(metadata);
    ManagementDisableTransformer.hideManagementSecurityBasedSubApps(cap);
    if (capsToDeactivate.includes("index_management") || capsToDeactivate.includes("management")) {
      cap = ManagementDisableTransformer.hideIndexManagementApp(cap);
    }
    if (capsToDeactivate.includes("index_management") || capsToDeactivate.includes("data_quality")) {
      cap = ManagementDisableTransformer.hideDataQualitySetApp(cap);
    }
    if (!capsToDeactivate.includes("management")) {
      return cap;
    }
    cap = import_lodash.default.merge(cap, {
      catalogue: {
        index_lifecycle_management: false,
        snapshot_restore: false,
        rollup_jobs: false,
        watcher: false,
        transform: false,
        spaces: false
      }
    });
    const managementSection = cap.management;
    for (const subsection in managementSection) {
      if (Object.prototype.hasOwnProperty.call(managementSection, subsection)) {
        ManagementDisableTransformer.disableAll(managementSection[subsection]);
      }
    }
    return cap;
  }
  static disableAll(o) {
    (0, import_utils.mutateAllCapabilitiesInObject)(o, () => false);
  }
  static hideManagementSecurityBasedSubApps(cap) {
    ManagementDisableTransformer.disableAll(cap.management.security);
    (0, import_utils.overridePropertiesByJsonPath)(
      cap,
      ["navLinks.securitySolutionUI", "management.stack.license_management"],
      () => false
    );
  }
  static hideIndexManagementApp(cap) {
    ManagementDisableTransformer.disableAll(cap.index_management);
    return cap;
  }
  static hideDataQualitySetApp(cap) {
    ManagementDisableTransformer.disableAll(cap.dataQuality);
    return cap;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ManagementDisableTransformer
});
