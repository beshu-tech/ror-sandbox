"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var MinimumManagementTransformer_exports = {};
__export(MinimumManagementTransformer_exports, {
  MinimumManagementTransformer: () => MinimumManagementTransformer
});
module.exports = __toCommonJS(MinimumManagementTransformer_exports);
var import_rorReservedHiddenAppsValues = require("../../../../../shared/constants/rorReservedHiddenAppsValues");
var import_utils = require("../utils");
class MinimumManagementTransformer {
  static transform(cap, metadata) {
    var _a;
    if ((_a = metadata.kibanaHiddenApps) == null ? void 0 : _a.includes(import_rorReservedHiddenAppsValues.RorReservedHiddenAppsValue.ROR_MANAGE_KIBANA)) {
      return cap;
    }
    (0, import_utils.overridePropertiesByJsonPath)(
      cap,
      [
        "navLinks.management",
        "catalogue.indexPatterns",
        "catalogue.saved_objects",
        "savedObjectManagement.read",
        "savedObjectsManagement.read",
        "kibana.objects"
      ],
      () => true
    );
    const capsToDeactivate = (0, import_utils.getCapabilitiesToRemove)(metadata);
    if (capsToDeactivate.includes("management")) {
      (0, import_utils.overridePropertiesByJsonPath)(
        cap,
        [
          "management.insightsAndAlerting.reporting",
          "management.kibana.dataViews",
          // needed for 8.0
          "management.kibana.indexPatterns",
          "management.kibana.objects",
          // needed for 7.9
          "catalogue.reporting"
        ],
        () => true
      );
    }
    return cap;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  MinimumManagementTransformer
});
