"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ObservabilityTransformer_exports = {};
__export(ObservabilityTransformer_exports, {
  ObservabilityTransformer: () => ObservabilityTransformer
});
module.exports = __toCommonJS(ObservabilityTransformer_exports);
var import_hiddenAppsChecker = require("../../../../../shared/utils/hiddenAppsChecker");
var import_rorLoggerFactory = require("../../../../core/logging/rorLoggerFactory");
var import_utils = require("../utils");
const logger = import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
class ObservabilityTransformer {
  static transform(cap, metadata) {
    const observabilityOverviewBasedCaps = [
      "Observability|Observability",
      "Observability|Overview",
      "Observability|Alerts",
      "Observability|Cases",
      "Observability|SLOs"
    ];
    const isRegexNegation = /\(\?!\(.*(Observability|Alerts|Overview|Cases|SLOs).*\)/;
    if (observabilityOverviewBasedCaps.some(
      (observabilityOverviewBasedCap) => {
        var _a;
        return (_a = metadata.kibanaHiddenApps) == null ? void 0 : _a.some(
          (kibanaHiddenApp) => isRegexNegation.test(kibanaHiddenApp) ? false : (0, import_hiddenAppsChecker.hiddenAppsChecker)(kibanaHiddenApp, observabilityOverviewBasedCap, logger)
        );
      }
    )) {
      (0, import_utils.overridePropertiesByJsonPath)(cap, ["navLinks.observability-overview"], () => false);
    } else {
      (0, import_utils.overridePropertiesByJsonPath)(cap, ["navLinks.observability-overview"], () => true);
    }
    return cap;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ObservabilityTransformer
});
