"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ROUserTransformer_exports = {};
__export(ROUserTransformer_exports, {
  ROUserTransformer: () => ROUserTransformer
});
module.exports = __toCommonJS(ROUserTransformer_exports);
var import_accessLevel = require("../../../../../shared/types/accessLevel");
var import_utils = require("../utils");
const NON_RO_OP_MATCHER = /.*create.*|.*write.*|.*save.*|.*edit.*|.*delete.*|.*update.*|.*manage.*|.*copy.*|shareIntoSpace|.*crud.*/i;
const MANAGEMENT_WHITELIST = /indexPatterns|objects|reporting|dataViews/;
class ROUserTransformer {
  static transform(cap, metadata) {
    if (import_accessLevel.AccessLevel.RO !== metadata.kibanaAccess && import_accessLevel.AccessLevel.RO_STRICT !== metadata.kibanaAccess) {
      return cap;
    }
    for (const entry in cap) {
      if (entry === "catalogue" || entry === "navLinks" || entry === "management") {
        continue;
      }
      (0, import_utils.mutateAllCapabilitiesInObject)(cap[entry], (e) => !NON_RO_OP_MATCHER.test(e));
    }
    const { management } = cap;
    for (const i in management) {
      if (Object.prototype.hasOwnProperty.call(management, i)) {
        (0, import_utils.mutateAllCapabilitiesInObject)(management[i], (e) => MANAGEMENT_WHITELIST.test(e));
      }
    }
    (0, import_utils.mutateAllCapabilitiesInObject)(cap.savedObjectsManagement, () => false);
    (0, import_utils.mutateAllCapabilitiesInObject)(cap.index_management, () => false);
    (0, import_utils.mutateAllCapabilitiesInObject)(cap.dataQuality, () => false);
    (0, import_utils.overridePropertiesByJsonPath)(
      cap,
      ["catalogue.advanced_settings", "fileUpload.show", "navLinks.ingestManager"],
      () => false
    );
    return cap;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ROUserTransformer
});
