"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var utils_exports = {};
__export(utils_exports, {
  getCapabilitiesToRemove: () => getCapabilitiesToRemove,
  mutateAllCapabilitiesInObject: () => mutateAllCapabilitiesInObject,
  overridePropertiesByJsonPath: () => overridePropertiesByJsonPath,
  overridePropertyByJsonPath: () => overridePropertyByJsonPath
});
module.exports = __toCommonJS(utils_exports);
var import_rorLoggerFactory = require("../../../core/logging/rorLoggerFactory");
var import_kibanaAppsRegistry = require("../../kibana_apps/kibanaAppsRegistry");
const logger = () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename);
function mutateAllCapabilitiesInObject(obj, shouldEnable) {
  for (const i in obj) {
    if (obj[i] !== void 0) {
      if (typeof obj[i] === "object") {
        for (const j in obj[i]) {
          if (Object.prototype.hasOwnProperty.call(obj[i], j)) {
            obj[i][j] = shouldEnable(i, j);
          }
        }
      } else {
        obj[i] = shouldEnable(i);
      }
    } else {
      console.log(`Tried to mutate NON existing property ${i} of `, obj);
    }
  }
  return obj;
}
function overridePropertyByJsonPath(obj, thePath, value) {
  const path = thePath.split(".");
  let i;
  for (i = 0; i < path.length - 1; i++) {
    const val = obj[path[i]];
    if (val === void 0) {
      return;
    }
    obj = val;
  }
  if (obj[path[i]] === void 0) {
    return;
  }
  obj[path[i]] = value;
}
function overridePropertiesByJsonPath(obj, paths, getValue) {
  paths.forEach((path) => overridePropertyByJsonPath(obj, path, getValue(path)));
}
function getCapabilitiesToRemove(metadata) {
  var _a;
  const hiddenApps = [...(_a = metadata.kibanaHiddenApps) != null ? _a : [], "Security"];
  if (hiddenApps.length === 0) {
    return [];
  }
  let capabilities2remove = [];
  for (const g of hiddenApps) {
    capabilities2remove = capabilities2remove.concat(import_kibanaAppsRegistry.KibanaAppsRegistry.app2capabilities(g) || []);
  }
  capabilities2remove = [...new Set(capabilities2remove.map((c) => c == null ? void 0 : c.trim()).filter((c) => Boolean(c)))];
  logger().debug(`Will hide apps ${hiddenApps}. Hence will remove capabilities: ${capabilities2remove}`);
  return capabilities2remove;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getCapabilitiesToRemove,
  mutateAllCapabilitiesInObject,
  overridePropertiesByJsonPath,
  overridePropertyByJsonPath
});
