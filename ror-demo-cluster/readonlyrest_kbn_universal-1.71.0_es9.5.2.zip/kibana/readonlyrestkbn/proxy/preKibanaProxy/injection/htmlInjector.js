"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var htmlInjector_exports = {};
__export(htmlInjector_exports, {
  HtmlInjector: () => HtmlInjector
});
module.exports = __toCommonJS(htmlInjector_exports);
var import_distributionInfoProvider = require("../../../kibana/patchers/distributionInfoProvider");
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
const HTML_HEAD_OPENING_TAG = "<head>";
const HTML_HEAD_CLOSING_TAG = "</head>";
const HTML_BODY_CLOSING_TAG = "</body>";
class HtmlInjector {
  constructor(kibanaBasePath, settingsOrCss, optionsOrCssFileContent, options = {}) {
    __publicField(this, "rorSettingsStore");
    __publicField(this, "customUserCss");
    __publicField(this, "customUserCssFileContent");
    __publicField(this, "options");
    __publicField(this, "kibanaBasePath");
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    this.kibanaBasePath = kibanaBasePath;
    if (typeof settingsOrCss === "object") {
      this.rorSettingsStore = settingsOrCss;
      this.options = optionsOrCssFileContent != null ? optionsOrCssFileContent : {};
    } else {
      this.customUserCss = settingsOrCss;
      this.customUserCssFileContent = optionsOrCssFileContent;
      this.options = options;
    }
  }
  injectCssAndJsScriptsIntoHtml(interceptedHtmlResponse) {
    const { css, cssFileContent } = this.getCustomCss();
    const isCustomUserCssDefined = css != null;
    const isCustomUserCssFileContentDefined = cssFileContent != null;
    this.logger.trace(
      `Injecting custom user css: ${isCustomUserCssDefined}. Injecting custom user css file content: ${isCustomUserCssFileContentDefined}`
    );
    const htmlSplitAtHeadTag = interceptedHtmlResponse.toString().split(HTML_HEAD_CLOSING_TAG);
    const htmlSplitAtBodyTag = htmlSplitAtHeadTag[1] && htmlSplitAtHeadTag[1].split(HTML_BODY_CLOSING_TAG);
    const [beforeHeadOpen, afterHeadOpen] = htmlSplitAtHeadTag[0].split(HTML_HEAD_OPENING_TAG);
    const htmlHeadInjections = this.buildHtmlHeadInjections(isCustomUserCssDefined, isCustomUserCssFileContentDefined);
    const htmlBodyInjections = this.buildHtmlBodyInjections();
    const htmlSectionsBuffers = [
      beforeHeadOpen,
      HTML_HEAD_OPENING_TAG,
      this.buildFetchOverrideScript(),
      afterHeadOpen != null ? afterHeadOpen : "",
      htmlHeadInjections,
      HTML_HEAD_CLOSING_TAG,
      htmlSplitAtBodyTag[0],
      htmlBodyInjections,
      HTML_BODY_CLOSING_TAG,
      htmlSplitAtBodyTag[1]
    ].map((htmlSection) => Buffer.from(htmlSection));
    return Buffer.concat(htmlSectionsBuffers);
  }
  buildFetchOverrideScript() {
    return `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/injections/unsupported-endpoints-filter.js"></script>`;
  }
  buildHtmlHeadInjections(shouldInjectCustomUserCss, shouldInjectCustomUserCssFileContent) {
    const { css, cssFileContent } = this.getCustomCss();
    let injectedHtml = import_distributionInfoProvider.DistributionInfoProvider.isEnvironmentDev() ? this.getLessNotCompiledToCssInjection() : this.getLessCompiledToCssInjection();
    if (shouldInjectCustomUserCss) {
      injectedHtml += `<style>${css}</style>`;
    }
    if (shouldInjectCustomUserCssFileContent) {
      injectedHtml += `<style>${cssFileContent}</style>`;
    }
    return injectedHtml;
  }
  getCustomCss() {
    var _a, _b, _c;
    const customUXCodeInjection = (_a = this.rorSettingsStore) == null ? void 0 : _a.getLatestRorKbnSettings().customUXCodeInjection;
    return {
      css: (_b = customUXCodeInjection == null ? void 0 : customUXCodeInjection.css) != null ? _b : this.customUserCss,
      cssFileContent: (_c = customUXCodeInjection == null ? void 0 : customUXCodeInjection.cssFileContent) != null ? _c : this.customUserCssFileContent
    };
  }
  getLessNotCompiledToCssInjection() {
    return `<link rel="stylesheet/less" type="text/css" href="${this.kibanaBasePath}/pkp/legacy/web/assets/less/main.less"/><script type="application/javascript" src="${this.kibanaBasePath}/pkp/autodeps?file=less/dist/less.min.js"></script>`;
  }
  getLessCompiledToCssInjection() {
    return `<link rel="stylesheet" type="text/css" href="${this.kibanaBasePath}/pkp/legacy/web/assets/css/main.css"/>`;
  }
  buildHtmlBodyInjections() {
    var _a;
    let toInject = `<script type="application/javascript" src="${this.kibanaBasePath}/pkp/legacy/web/assets/js/ie-alert.js"></script><script type="application/javascript" src="${this.kibanaBasePath}/pkp/autodeps?file=jquery/dist/jquery.min.js"></script><script type="application/javascript" src="${this.kibanaBasePath}/pkp/autodeps?file=xregexp/xregexp-all.js"></script><script type="application/javascript" src="${this.kibanaBasePath}/pkp/injections/tenancy-context-injector.js"></script><script type="application/javascript" src="${this.kibanaBasePath}/pkp/injections/hidden-apps.js"></script><script type="application/javascript" src="${this.kibanaBasePath}/pkp/injections/ror-css-classes.js"></script><script type="application/javascript" src="${this.kibanaBasePath}/pkp/autodeps?file=js-cookie/dist/js.cookie.min.js"></script><script type="application/javascript" src="${this.kibanaBasePath}/pkp/injections/session-probe.js"></script><script type="application/javascript" src="${this.kibanaBasePath}/pkp/injections/activation-expiration-alert.js"></script>`;
    toInject += `<script type="application/javascript" defer src="${this.kibanaBasePath}/pkp/injections/custom.js"></script>`;
    toInject += ((_a = this.options.additionalBodyScripts) != null ? _a : []).map((script) => `<script type="application/javascript" src="${script}"></script>`).join("");
    return toInject;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HtmlInjector
});
