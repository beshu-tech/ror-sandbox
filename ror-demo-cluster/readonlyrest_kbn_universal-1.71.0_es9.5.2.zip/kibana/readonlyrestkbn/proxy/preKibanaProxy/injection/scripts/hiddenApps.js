/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

// Let's have our own scope, so we don't leak variables and functions into global scope
(function hiddenAppsScope() {
  function isJsonString(str) {
    try {
      JSON.parse(str);
    } catch {
      return false;
    }
    return true;
  }

  function logWithContext(...params) {
    params.unshift('[ROR|hiddenApps] ');
    console.log(...params);
  }

  const pathsWhitelist = [
    '/app/management/insightsAndAlerting/reporting',
    '/app/management/insightsAndAlerting/reporting/exports', // For Kibana 8.19.x
    '/app/management/kibana/indexPatterns',
    '/app/management/kibana/objects',
    '/app/management/kibana/dataViews'
  ];

  const APP_IDS_TO_BE_HIDDEN = ['Security'];
  const ALL_MENU_APPS = new Map();
  let FOUND_MENU_APPS_TO_BE_HIDDEN = [];

  // This selector is tested and works from 7.9.0 to 7.11.1 <--- #UPDATE_ME
  const DOM_MENU_ELEMENTS_SELECTOR = '[data-test-subj*="collapsibleNavGroup-"]';
  const DOM_SIDEBAR_TOGGLE_BUTTON_SELECTOR = "[aria-label*='Toggle primary navigation']";
  const RECENT_ACTIONS_GROUP_NAME = 'recently';

  const SPACES_PREFIX_REGEX = /\/s\/[a-z0-9]+\//;

  function getTenancyFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('tenancy');
  }

  function getAppsToHideFromRegistry() {
    const tenancy = getTenancyFromUrl();
    return $.ajax({
      url: '${hiddenAppsRegistryPath}',
      type: 'get',
      processData: false,
      dataType: 'json',
      headers: tenancy ? { 'X-ROR-TENANCY': tenancy } : undefined,
      success: data => console.log('success getting apps from registry', data),
      error: err => console.log('cannot get apps from registry', err)
    });
  }

  function getAllAppsFromRegistry() {
    const tenancy = getTenancyFromUrl();
    return $.ajax({
      url: '${appRegistryPath}',
      type: 'get',
      processData: false,
      dataType: 'json',
      headers: tenancy ? { 'X-ROR-TENANCY': tenancy } : undefined,
      success: data => console.log('success getting apps from registry', data),
      error: err => console.log('cannot get apps from registry', err)
    });
  }

  function setAppIdsToBeHidden(appIds) {
    APP_IDS_TO_BE_HIDDEN.push(...appIds);
    console.log('hiddenApps', APP_IDS_TO_BE_HIDDEN);
  }

  function hiddenAppsParser(hiddenApps) {
    return JSON.parse(hiddenApps.replace(/\\/g, '\\\\'));
  }

  setAppIdsToBeHidden(
    isJsonString('[${hiddenApps}]')
      ? (() => {
          // eslint-disable-next-line no-undef
          const hiddenAppsRaw = String.raw`[${hiddenApps}]`;
          return hiddenAppsParser(hiddenAppsRaw);
        })()
      : []
  );

  function buildAppMetadata(appElement, groupName) {
    const href = appElement.attr('href');
    return {
      id: `${groupName}|${appElement.text()}`,
      name: appElement.text(),
      groupName,
      href,
      path: new URL(href).pathname.replace(SPACES_PREFIX_REGEX, '/')
    };
  }

  async function printAllMenuApps() {
    logWithContext('=========== Apps ROR can hide =============');
    const { allAppsFromRegistry } = await getAllAppsFromRegistry();
    allAppsFromRegistry
      .sort((a, b) => a.id.localeCompare(b.id))
      .forEach(appMetadata => logWithContext(`${appMetadata.id} => ${appMetadata.path}`));
    logWithContext('===========================================');
    logWithContext('Apps array for kibanaAppRegistry.ts', ALL_MENU_APPS.entries());
  }

  function appendCSStoDOM(cssSelectorsArray) {
    if (cssSelectorsArray.length === 0) {
      return;
    }
    const selectorsString = cssSelectorsArray.join(', ');
    logWithContext('Final CSS selector string:', cssSelectorsArray);
    // noinspection HtmlDeprecatedAttribute
    $(`
      <style type="text/css">
        ${selectorsString} {
          display: none;
        }
      </style>
    `).appendTo('head');
  }

  function expressionMatchesAppId(expression, appId) {
    function parseRegexpFromStringBasedRegexpValue() {
      const expressionWithoutRegexStartEndSymbols = expression.substr(1).slice(0, -1);
      const expressionWithEscapeValues = expressionWithoutRegexStartEndSymbols;
      return new RegExp(expressionWithEscapeValues);
    }

    function parseRegexpFromString() {
      const startWithRegex = new RegExp(`${expression.replace(/\|/g, '\\|')}.*`);
      return startWithRegex;
    }

    const isRegexExpression = expression.startsWith('/') && expression.endsWith('/');

    try {
      const regExp = isRegexExpression ? parseRegexpFromStringBasedRegexpValue() : parseRegexpFromString();
      return window.XRegExp.test(appId, regExp);
    } catch {
      logWithContext(`Invalid regular expression: ${expression} Ignoring!`);
      return false;
    }
  }

  function shouldHideApp(appId, appIdsToBeHidden) {
    return Boolean(appIdsToBeHidden.find(expression => expressionMatchesAppId(expression, appId)));
  }

  function computeEmptyGroupNames(survivorAppIds) {
    const groupNames = [...new Set([...ALL_MENU_APPS.values()].map(v => v.groupName))];
    logWithContext(`Groups found ${groupNames}`);

    const emptyOnes = groupNames.filter(groupName => !survivorAppIds.find(id => id.startsWith(groupName)));
    logWithContext(`Empty groups found ${emptyOnes}`);
    return emptyOnes;
  }

  function computeGroupHideSelector(groupName) {
    // Normal algorithm for transforming submenu (aka group) UI label names (as seen by the user) into CSS submenu selector
    let transformedName = groupName.replace(/ /g, '');
    transformedName = transformedName.charAt(0).toLowerCase() + transformedName.slice(1);

    // Some exceptions to be handled to the above, for some specific submenus. This is because the submenu selector follows the kibana plugin name (as seen in kibana.json), and the label may vary.
    if (transformedName === 'security') {
      transformedName = 'securitySolution';
    }
    if (transformedName === 'analytics') {
      transformedName = 'kibana';
    }

    if (transformedName === 'elasticsearch') {
      transformedName = 'enterpriseSearch';
    }

    return `[data-test-subj="collapsibleNavGroup-${transformedName}"]`;
  }

  function computeAppHideSelector(appMetadata) {
    if (appMetadata.id === 'Home') {
      // Special case for "Home" app, which is not under a <li> but directly an <a>
      return `a[href*="${appMetadata.path}"]`;
    }
    if (appMetadata.href) {
      return `a[href="${appMetadata.href}"], li[url="${appMetadata.path}"]`;
    }
    return `li[url="${appMetadata.path}"]`;
  }

  function shouldHideDashboardOrDashboardsApp(appIdsToBeHidden) {
    const isDashboardHiddenApps = shouldHideApp('Analytics|Dashboard', appIdsToBeHidden);
    const isDashboardsHiddenApps = shouldHideApp('Analytics|Dashboards', appIdsToBeHidden);

    // Case 1: Dashboard visible and Dashboards hidden
    if (!isDashboardHiddenApps && isDashboardsHiddenApps) {
      return false;
    }
    // Case 2: Dashboard hidden and Dashboards visible
    if (isDashboardHiddenApps && !isDashboardsHiddenApps) {
      return false;
    }
    // Case 3: Dashboard hidden and Dashboards hidden
    if (isDashboardHiddenApps && isDashboardsHiddenApps) {
      return true;
    }
    return false;
  }

  async function getCssSelectorsToHide() {
    const survivorAppIds = [...ALL_MENU_APPS.keys()].filter(id => {
      if (id === 'Analytics|Dashboard' || id === 'Analytics|Dashboards') {
        /**
         * To keep backward compatibility with Kibana version below 8.14.0 during upgrade,
         * let user define Dashboard app both Analytics|Dashboard or Analytics|Dashboards
         * */
        return !shouldHideDashboardOrDashboardsApp(APP_IDS_TO_BE_HIDDEN);
      }

      return !shouldHideApp(id, APP_IDS_TO_BE_HIDDEN);
    });
    const emptyGroupsNames = computeEmptyGroupNames(survivorAppIds);
    const { hiddenApps } = await getAppsToHideFromRegistry();

    let appsToHide = [...ALL_MENU_APPS.values()]
      .filter(appMetadata => !survivorAppIds.includes(appMetadata.id))
      .concat(hiddenApps);
    FOUND_MENU_APPS_TO_BE_HIDDEN = [].concat(appsToHide);

    const observabilityOverviewBasedCaps = [
      'Observability|Overview',
      'Observability|Alerts',
      'Observability|Cases',
      'Observability|SLOs',
      'Observability|Observability'
    ];
    const isRegexNegation = /\(\?!\(.*(Alerts|Overview|Cases|APM).*\)/;

    if (
      observabilityOverviewBasedCaps.some(observabilityOverviewBasedCap =>
        APP_IDS_TO_BE_HIDDEN.some(kibanaHiddenApp =>
          isRegexNegation.test(kibanaHiddenApp)
            ? false
            : expressionMatchesAppId(kibanaHiddenApp, observabilityOverviewBasedCap)
        )
      )
    ) {
      const observability = appsToHide.filter(app =>
        observabilityOverviewBasedCaps.some(observabilityOverviewBasedCap => observabilityOverviewBasedCap !== app.id)
      );

      appsToHide = appsToHide.concat(observability);
    } else {
      appsToHide = appsToHide.filter(
        app =>
          !observabilityOverviewBasedCaps.some(
            observabilityOverviewBasedCap => observabilityOverviewBasedCap === app.id
          )
      );
    }

    logWithContext(
      'Will hide apps:',
      appsToHide.map(_ => _.id)
    );

    const unusedExpressions = APP_IDS_TO_BE_HIDDEN.filter(
      expression =>
        expression !== 'readonlyrest_kbn' &&
        expression !== 'ROR Manage Kibana' &&
        expression !== 'ROR Security Settings' &&
        !appsToHide.find(appMetadata => expressionMatchesAppId(expression, appMetadata.id))
    );
    if (unusedExpressions && unusedExpressions.length) {
      logWithContext('Malformed expressions that did not match any app to hide:', unusedExpressions);
    }
    const groupsToHideSelectors = emptyGroupsNames.map(computeGroupHideSelector);
    const appToHideSelectors = appsToHide.map(computeAppHideSelector);
    return groupsToHideSelectors.concat(appToHideSelectors);
  }

  function harvestAvailableAppsFromNav() {
    $(DOM_MENU_ELEMENTS_SELECTOR).each((_, menuGroup) => {
      if ($(menuGroup).text().toLowerCase().includes(RECENT_ACTIONS_GROUP_NAME)) {
        return;
      }
      const groupName = $(menuGroup).find('.euiTitle').text();
      $(menuGroup)
        .find('a')
        .map((_, app) => buildAppMetadata($(app), groupName))
        .each((_, appMetadata) => ALL_MENU_APPS.set(appMetadata.id, appMetadata));
    });
  }

  function ensureNavBarState(desiredState) {
    const navToggleButton = $(DOM_SIDEBAR_TOGGLE_BUTTON_SELECTOR);
    if (navToggleButton.length === 0) {
      return false;
    }
    const isOpen = navToggleButton.attr('aria-expanded') === 'true';
    const shouldToggle = desiredState !== isOpen;
    const stateForLogging = desiredState ? 'opened' : 'closed';
    if (shouldToggle) {
      navToggleButton.click();
      logWithContext(`Successfully ${stateForLogging} nav bar`);
    } else {
      logWithContext(`Nav bar was already ${stateForLogging}`);
    }
    return shouldToggle;
  }

  function executeWhenAppsListAvailable(callBack) {
    const kibanaLoaded = new Promise(resolve => {
      new MutationObserver((mutations, observer) => {
        for (const mutation of mutations) {
          for (const removedNode of mutation.removedNodes) {
            const kibanaSpinnerId = 'kbn_loading_message';
            if (removedNode.id === kibanaSpinnerId) {
              observer.disconnect();
              resolve();
              break;
            }
          }
        }
      }).observe(document.body, { childList: true });
    });

    kibanaLoaded.then(() => {
      ensureNavBarState(true);
      harvestAvailableAppsFromNav();
      callBack();
      ensureNavBarState(false);
    });
  }

  function prohibitNavigationIfNeeded() {
    const rorManageKibanaButtonHiddenId = 'ROR Manage Kibana';
    const { pathname } = window.location;
    const pathStrippedOfSpacePrefix = pathname.replace(SPACES_PREFIX_REGEX, '/');
    const spacePermissionsUrlRegexp = /app\/management\/kibana\/spaces\/edit\/([^/]+)\/roles/;

    if (spacePermissionsUrlRegexp.test(pathStrippedOfSpacePrefix)) {
      window.location.replace('${basePath}/');
    }

    if (
      pathsWhitelist.includes(pathStrippedOfSpacePrefix) &&
      !APP_IDS_TO_BE_HIDDEN.includes(rorManageKibanaButtonHiddenId)
    ) {
      return;
    }

    FOUND_MENU_APPS_TO_BE_HIDDEN.forEach(appMetadata => {
      if (pathStrippedOfSpacePrefix.indexOf(appMetadata.path) >= 0) {
        logWithContext(`Cannot navigate to ${pathname} because ${appMetadata.name} app is hidden`);
        window.location.replace('${basePath}/');
      }
    });
  }

  function sendAppsToRegistry(appsArray) {
    const tenancy = getTenancyFromUrl();
    const baseHeaders = { 'Content-Type': 'application/json' };
    const headers = tenancy ? { ...baseHeaders, 'X-ROR-TENANCY': tenancy } : baseHeaders;
    $.ajax({
      url: '${appRegistryPath}',
      type: 'post',
      headers,
      data: JSON.stringify(appsArray),
      processData: false,
      dataType: 'json',
      success: data => console.log('success sending apps to registry', data),
      error: err => console.log('cannot send apps to registry', err)
    });
  }

  executeWhenAppsListAvailable(async () => {
    const asArrayOfObjects = Array.from(ALL_MENU_APPS.values());
    await sendAppsToRegistry(asArrayOfObjects);
    await printAllMenuApps();
    const cssSelectorsForHiding = await getCssSelectorsToHide();
    appendCSStoDOM(cssSelectorsForHiding);
    prohibitNavigationIfNeeded();
  });

  function hideSecuritySolutionViewOption() {
    if (!shouldHideApp('Security', APP_IDS_TO_BE_HIDDEN)) {
      return;
    }
    appendCSStoDOM(['[data-test-subj="solutionViewSecurityOption"]']);
  }

  hideSecuritySolutionViewOption();

  // For testing hidden app functionality purpose
  if (typeof module !== 'undefined' && Object.prototype.hasOwnProperty.call(module, 'exports')) {
    module.exports = {
      FOUND_MENU_APPS_TO_BE_HIDDEN,
      APP_IDS_TO_BE_HIDDEN,
      shouldHideApp,
      prohibitNavigationIfNeeded,
      setAppIdsToBeHidden,
      hiddenAppsParser,
      hideSecuritySolutionViewOption
    };
  }
})();
