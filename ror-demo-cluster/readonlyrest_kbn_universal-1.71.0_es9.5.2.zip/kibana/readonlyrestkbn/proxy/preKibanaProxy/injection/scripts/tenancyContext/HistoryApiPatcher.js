"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var HistoryApiPatcher_exports = {};
__export(HistoryApiPatcher_exports, {
  HistoryApiPatcher: () => HistoryApiPatcher
});
module.exports = __toCommonJS(HistoryApiPatcher_exports);
var import_queryStringKeys = require("../../../../../shared/constants/queryStringKeys");
class HistoryApiPatcher {
  constructor(tenancyUrlService, defaultTenancyId) {
    this.tenancyUrlService = tenancyUrlService;
    this.defaultTenancyId = defaultTenancyId;
    __publicField(this, "lastTenancyId", null);
  }
  patchHistoryMethods() {
    ["pushState", "replaceState"].forEach((method) => {
      const original = window.history[method];
      window.history[method] = (state, title, url) => {
        if (url) {
          const newUrl = new URL(url.toString(), window.location.origin);
          this.ensureTenantInUrlParam(newUrl);
          return original.call(window.history, state, title, newUrl.toString());
        }
        return original.call(window.history, state, title, url);
      };
    });
  }
  ensureTenancyInUrl() {
    const currentUrl = this.tenancyUrlService.getCurrentUrl();
    if (!currentUrl.searchParams.has(import_queryStringKeys.TENANCY_QUERY_STRING_KEY)) {
      this.tenancyUrlService.setTenancyId(this.defaultTenancyId);
      window.history.replaceState(window.history.state, "", currentUrl.toString());
    }
    this.lastTenancyId = currentUrl.searchParams.get(import_queryStringKeys.TENANCY_QUERY_STRING_KEY);
  }
  ensureTenantInUrlParam(newUrl) {
    if (!newUrl.searchParams.has(import_queryStringKeys.TENANCY_QUERY_STRING_KEY)) {
      newUrl.searchParams.set(import_queryStringKeys.TENANCY_QUERY_STRING_KEY, this.lastTenancyId || this.defaultTenancyId);
    }
    this.lastTenancyId = this.tenancyUrlService.getCurrentTenancy();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HistoryApiPatcher
});
