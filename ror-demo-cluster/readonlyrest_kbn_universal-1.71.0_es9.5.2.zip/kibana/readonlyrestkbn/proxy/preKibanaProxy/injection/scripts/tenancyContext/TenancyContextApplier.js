"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var TenancyContextApplier_exports = {};
__export(TenancyContextApplier_exports, {
  TenancyContextApplier: () => TenancyContextApplier
});
module.exports = __toCommonJS(TenancyContextApplier_exports);
var import_headers = require("../../../../../shared/constants/headers");
var import_queryStringKeys = require("../../../../../shared/constants/queryStringKeys");
class TenancyContextApplier {
  constructor(tenancyUrlService) {
    this.tenancyUrlService = tenancyUrlService;
  }
  addTenancyToIframeString(iframeString, tenancyId) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(iframeString, "text/html");
    const iframe = doc.querySelector("iframe");
    if (!iframe || !iframe.src) return iframeString;
    const url = new URL(iframe.src);
    url.searchParams.set(import_queryStringKeys.TENANCY_QUERY_STRING_KEY, tenancyId);
    iframe.src = url.toString();
    return iframe.outerHTML;
  }
  createRequestWithTenancy(input, init = {}) {
    const tenancyId = this.tenancyUrlService.getCurrentTenancy();
    if (input instanceof Request) {
      const headers2 = new Headers(input.headers);
      headers2.set(import_headers.X_ROR_TENANCY, tenancyId);
      return new Request(input, { headers: headers2 });
    }
    const headers = new Headers(init.headers || {});
    headers.set(import_headers.X_ROR_TENANCY, tenancyId);
    return new Request(input.toString(), { ...init, headers });
  }
  extendHeadersWithTenancy(headers) {
    headers[import_headers.X_ROR_TENANCY] = this.tenancyUrlService.getCurrentTenancy();
    return headers;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TenancyContextApplier
});
