"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var kibanaAppsRegistry_exports = {};
__export(kibanaAppsRegistry_exports, {
  KibanaAppsRegistry: () => KibanaAppsRegistry
});
module.exports = __toCommonJS(kibanaAppsRegistry_exports);
var import_distributionInfoProvider = require("../../../kibana/patchers/distributionInfoProvider");
var import_rorReservedHiddenAppsValues = require("../../../shared/constants/rorReservedHiddenAppsValues");
var import_hiddenAppsChecker = require("../../../shared/utils/hiddenAppsChecker");
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
const _KibanaAppsRegistry = class _KibanaAppsRegistry {
  static initialize() {
    _KibanaAppsRegistry.registry = [
      ...this.navigationItems(),
      ...this.stackManagementIngest,
      ...this.stackManagementData(),
      ...this.stackManagementAlertsAndInsights,
      ...this.stackManagementKibana(),
      ...this.stackManagementStack,
      ...this.elasticsearch
    ];
  }
  static app2capabilities(groupName) {
    const caps = this.registry.filter((i) => {
      if ((i.id === "Analytics|Dashboard" || i.id === "Analytics|Dashboards") && import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaNeverOrEqualTo("8.14.0")) {
        return this.shouldHideDashboardOrDashboardsApp(groupName);
      }
      return this.expressionMatchesAppId(groupName, i.id);
    }).map((i) => i.flags).reduce((acc, val) => acc.concat(val), []);
    return [...new Set(caps)];
  }
  static enrichRegistry(kibanaApps) {
    kibanaApps.forEach((a) => {
      if (!this.registry.find((x) => x.id === a.id)) {
        _KibanaAppsRegistry.logger().info("Found new kibana app, adding to registry ", a);
        this.registry.push(a);
      }
    });
  }
  static isNavigationAllowed(path, hiddenAppsIdsOrPartialIds) {
    const pathStrippedOfSpacePrefix = path.replace(/\/s\/[a-z0-9]+\//, "/");
    if (_KibanaAppsRegistry.pathsWhitelist.includes(pathStrippedOfSpacePrefix) && !hiddenAppsIdsOrPartialIds.includes(this.rorManageKibanaButtonHiddenId)) {
      _KibanaAppsRegistry.logger().trace(`${pathStrippedOfSpacePrefix} path is added into a whitelist`);
      return true;
    }
    if (hiddenAppsIdsOrPartialIds.length === 0) {
      _KibanaAppsRegistry.logger().trace("No hidden apps configured for identity");
      return true;
    }
    const currentApp = _KibanaAppsRegistry.getAppByPath(pathStrippedOfSpacePrefix);
    if (!currentApp) {
      _KibanaAppsRegistry.logger().trace("Cannot extract app name from request path: ", pathStrippedOfSpacePrefix);
      return true;
    }
    _KibanaAppsRegistry.logger().trace(`Matched app from path: ${pathStrippedOfSpacePrefix}`, currentApp.id);
    const hiddenApps = this.getAppsByIdOrPartialId(hiddenAppsIdsOrPartialIds);
    _KibanaAppsRegistry.logger().trace(
      `Hidden apps for user`,
      hiddenApps.map((a) => a.id)
    );
    if (hiddenApps.find((x) => x.id === currentApp.id)) {
      _KibanaAppsRegistry.logger().trace(`Current app "${currentApp.id}" is hidden. Hence, will NOT allow navigation.`);
      return false;
    }
    return true;
  }
  static getPathsOfAppsToHide(hiddenAppsIdsOrPartialIds) {
    return _KibanaAppsRegistry.registry.filter((app) => this.shouldAppBeHidden(app, hiddenAppsIdsOrPartialIds));
  }
  static get allAppsFromRegistry() {
    return _KibanaAppsRegistry.registry;
  }
  static shouldAppBeHidden(app, hiddenAppsIdsOrPartialIds) {
    _KibanaAppsRegistry.logger().trace(`Deciding whether to hide app: ${app.id}`);
    const isStackManagementInHiddenApps = hiddenAppsIdsOrPartialIds.some(
      (hiddenAppsIdsOrPartialId) => (0, import_hiddenAppsChecker.hiddenAppsChecker)(hiddenAppsIdsOrPartialId, "Management|Stack Management", _KibanaAppsRegistry.logger())
    );
    if (_KibanaAppsRegistry.pathsWhitelist.includes(app.path) && isStackManagementInHiddenApps && !hiddenAppsIdsOrPartialIds.includes(this.rorManageKibanaButtonHiddenId)) {
      _KibanaAppsRegistry.logger().trace(`${app.path} path is added into a whitelist, hence will not hide it`);
      return false;
    }
    if (hiddenAppsIdsOrPartialIds.length === 0) {
      _KibanaAppsRegistry.logger().trace("No hidden apps configured for identity, hence will not hide ");
      return false;
    }
    const hiddenApps = this.getAppsByIdOrPartialId(hiddenAppsIdsOrPartialIds);
    if (hiddenApps.find((x) => x.id === app.id)) {
      _KibanaAppsRegistry.logger().trace(`The app "${app.id}" is configured as hidden for identity. Hence, will hide.`);
      return true;
    }
    _KibanaAppsRegistry.logger().trace(`Not hiding app: ${app.id}`);
    return false;
  }
  static expressionMatchesAppId(expression, appId) {
    return (0, import_hiddenAppsChecker.hiddenAppsChecker)(expression, appId, _KibanaAppsRegistry.logger());
  }
  static getAppByPath(path) {
    return _KibanaAppsRegistry.registry.find((app) => path.startsWith(app.path));
  }
  static getAppsByIdOrPartialId(appIdOrPartial) {
    const appsDeep = appIdOrPartial.map(
      (x) => _KibanaAppsRegistry.registry.filter((app) => (0, import_hiddenAppsChecker.hiddenAppsChecker)(x, app.id, _KibanaAppsRegistry.logger()))
    );
    return [].concat.apply([], appsDeep);
  }
  static shouldHideDashboardOrDashboardsApp(groupName) {
    const isDashboardHiddenApps = this.expressionMatchesAppId(groupName, "Analytics|Dashboard");
    const isDashboardsHiddenApps = this.expressionMatchesAppId(groupName, "Analytics|Dashboards");
    if (!isDashboardHiddenApps && isDashboardsHiddenApps) {
      return false;
    }
    if (isDashboardHiddenApps && !isDashboardsHiddenApps) {
      return false;
    }
    if (isDashboardHiddenApps && isDashboardsHiddenApps) {
      return true;
    }
    return false;
  }
};
__publicField(_KibanaAppsRegistry, "rorManageKibanaButtonHiddenId", import_rorReservedHiddenAppsValues.RorReservedHiddenAppsValue.ROR_MANAGE_KIBANA);
__publicField(_KibanaAppsRegistry, "pathsWhitelist", [
  "/app/management/insightsAndAlerting/reporting",
  "/app/management/insightsAndAlerting/reporting/exports",
  // For Kibana 8.19.x
  "/app/management/kibana/indexPatterns",
  "/app/management/kibana/objects",
  "/app/management/kibana/dataViews"
]);
__publicField(_KibanaAppsRegistry, "navigationItems", () => {
  const apps = [
    {
      id: "Analytics|Analytics",
      path: "/app/kibana_overview",
      flags: ["kibanaOverview"]
    },
    {
      id: "Analytics|Overview",
      path: "/app/kibana_overview",
      flags: ["kibanaOverview"]
    },
    {
      id: "Analytics|Discover",
      path: "/app/discover",
      flags: ["discover"]
    },
    {
      id: "Analytics|Dashboard",
      path: "/app/dashboards",
      flags: ["dashboards", "dashboard"]
    },
    {
      id: "Analytics|Canvas",
      path: "/app/canvas",
      flags: ["canvas"]
    },
    {
      id: "Analytics|Maps",
      path: "/app/maps",
      flags: ["maps"]
    },
    {
      id: "Analytics|Machine Learning",
      path: "/app/ml",
      flags: ["ml", "ml_file_data_visualizer"]
    },
    {
      id: "Analytics|Visualize Library",
      path: "/app/visualize",
      flags: ["visualize", "lens"]
    },
    {
      id: "Analytics|Graph",
      path: "/app/graph",
      flags: ["graph"]
    },
    {
      id: "Search|Content",
      path: "/app/enterprise_search/content",
      flags: ["enterpriseSearchContent"]
    },
    {
      id: "Search|Elasticsearch",
      path: "/app/enterprise_search/elasticsearch",
      flags: ["enterpriseSearchElasticsearch"]
    },
    {
      id: "Search|Vector Search",
      path: "/app/enterprise_search/vector_search",
      flags: ["enterpriseSearchVectorSearch"]
    },
    {
      id: "Search|Semantic Search",
      path: "/app/enterprise_search/semantic_search",
      flags: ["enterpriseSearchSemanticSearch"]
    },
    {
      id: "Search|Playground",
      path: "/app/enterprise_search/playground",
      flags: []
    },
    {
      id: "Search|Behavioral Analytics",
      path: "/app/enterprise_search/analytics",
      flags: []
    },
    {
      id: "Enterprise Search|Overview",
      path: "/app/enterprise_search/overview",
      flags: ["enterpriseSearch", "searchExperiences"]
    },
    {
      id: "Enterprise Search|App Search",
      path: "/app/enterprise_search/app_search",
      flags: ["appSearch"]
    },
    {
      id: "Enterprise Search|Workplace Search",
      path: "/app/enterprise_search/workplace_search",
      flags: ["workplaceSearch"]
    },
    {
      id: "Observability|Observability",
      path: "/app/observability",
      flags: ["observability"]
    },
    {
      id: "Observability|Overview",
      path: "/app/observability",
      flags: ["observability-overview", "observabilityOnboarding"]
    },
    {
      id: "Observability|Logs",
      path: "/app/observability/logs",
      flags: ["logs", "observability-logs-explorer", "observability-log-explorer"]
    },
    {
      id: "Observability|Alerts",
      path: "/app/observability/alerts",
      flags: ["alerts"]
    },
    {
      id: "Observability|Cases",
      path: "/app/observability/cases",
      flags: ["cases"]
    },
    {
      id: "Observability|SLOs",
      flags: ["slos", "slo"],
      path: "/app/observability/slos"
    },
    {
      id: "Observability|Synthetics",
      flags: ["synthetics"],
      path: "/app/synthetics"
    },
    {
      id: "Observability|Metrics",
      path: "/app/observability/metrics",
      flags: ["metrics"]
    },
    {
      id: "Observability|APM",
      path: "/app/apm",
      flags: ["apm"]
    },
    {
      id: "Observability|Uptime",
      path: "/app/uptime",
      flags: ["uptime"]
    },
    {
      id: "Observability|User Experience",
      path: "/app/ux",
      flags: ["ux"]
    },
    {
      id: "Observability|Inventory",
      path: "/app/inventory",
      flags: ["inventory"]
    },
    {
      id: "Observability|Infrastructure",
      path: "/app/metrics",
      flags: []
    },
    {
      id: "Observability|ObservabilityAIAssistant",
      path: "/app/observabilityAIAssistant",
      flags: ["observabilityAIAssistant"]
    },
    {
      id: "Security|Overview",
      path: "/app/security/overview",
      flags: ["siem", "securitySolution"]
    },
    {
      id: "Security|Security",
      path: "/app/security",
      flags: ["siem", "securitySolution", "security"]
    },
    {
      id: "Security|Detections",
      path: "/app/security/detections",
      flags: ["siem", "securitySolution"]
    },
    {
      id: "Security|Rules",
      path: "/app/security/rules",
      flags: ["siem", "securitySolution"]
    },
    {
      id: "Security|Hosts",
      path: "/app/security/hosts",
      flags: [
        "siem",
        "securitySolution",
        "securitySolution:administration",
        "securitySolution:case",
        "securitySolution:detections",
        "securitySolution:hosts",
        "securitySolution:network",
        "securitySolution:overview",
        "securitySolution:timelines"
      ]
    },
    {
      id: "Security|Network",
      path: "/app/security/network",
      flags: ["siem", "securitySolution"]
    },
    {
      id: "Security|Timelines",
      path: "/app/security/timelines",
      flags: ["siem", "securitySolution"]
    },
    {
      id: "Security|Cases",
      path: "/app/security/cases",
      flags: ["siem", "securitySolution"]
    },
    {
      id: "Security|Administration",
      path: "/app/security/administration",
      flags: ["siem", "securitySolution"]
    },
    {
      id: "Security|TrustedApplications",
      path: "/app/security/trusted_apps",
      flags: ["siem", "securitySolution"]
    },
    {
      id: "Security|Exceptions",
      path: "/app/security/exceptions",
      flags: ["siem", "securitySolution"]
    },
    {
      id: "Management|Dev Tools",
      path: "/app/dev_tools",
      flags: ["dev_tools", "console"]
    },
    {
      id: "Management|Fleet",
      path: "/app/fleet",
      flags: ["fleet"]
    },
    {
      id: "Management|Integrations",
      path: "/app/integrations",
      flags: ["integrations"]
    },
    {
      id: "Management|Stack Management",
      path: "/app/management",
      flags: ["management"]
    },
    {
      id: "Management|Management",
      path: "/app/management",
      flags: ["management"]
    },
    {
      id: "Management|Osquery",
      path: "/app/osquery",
      flags: ["osquery"]
    },
    {
      id: "Management|Stack Monitoring",
      path: "/app/monitoring",
      flags: ["Stack Monitoring", "monitoring"]
    },
    {
      id: "Management|Streams",
      path: "/app/streams",
      flags: ["streams"]
    },
    {
      id: "Management|Cloud Connect",
      path: "/app/cloud_connect",
      flags: ["cloud_connect"]
    },
    {
      id: "Management|Workflows",
      path: "/app/workflows",
      flags: ["workflows"]
    }
  ];
  if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaNeverOrEqualTo("8.14.0")) {
    apps.push({
      id: "Analytics|Dashboards",
      path: "/app/dashboards",
      flags: ["dashboards", "dashboard"]
    });
  }
  return apps;
});
__publicField(_KibanaAppsRegistry, "stackManagementIngest", [
  {
    id: "Management|Stack Management|Ingest|Ingest Pipelines",
    path: "/app/management/ingest/ingest_pipelines",
    flags: ["ingest_pipelines", "pipelines"]
  }
]);
__publicField(_KibanaAppsRegistry, "stackManagementData", () => {
  const apps = [
    {
      id: "Management|Stack Management|Data|Index Management",
      path: "/app/management/data/index_management",
      flags: ["index_management"]
    },
    {
      id: "Management|Stack Management|Data|Index Lifecycle Policies",
      path: "/app/management/data/index_lifecycle_management",
      flags: ["index_lifecycle_management"]
    },
    {
      id: "Management|Stack Management|Data|Snapshot and Restore",
      path: "/app/management/data/snapshot_restore/snapshots",
      flags: ["snapshot_restore"]
    },
    {
      id: "Management|Stack Management|Data|Rollup Jobs",
      path: "/app/management/data/rollup_jobs/job_list",
      flags: ["rollup_jobs"]
    },
    {
      id: "Management|Stack Management|Data|Transforms",
      path: "/app/management/data/transform",
      flags: ["transform"]
    },
    {
      id: "Management|Stack Management|Data|Remote Clusters",
      path: "/app/management/data/remote_clusters",
      flags: ["remote_clusters", "cross_cluster_replication"]
    },
    {
      id: "Management|Stack Management|Data|Data Set Quality",
      path: "/app/management/data/data_quality",
      flags: ["data_quality"]
    }
  ];
  if (!import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("8.7.0")) {
    apps.push({
      id: "Management|Stack Management|Data|Migrate",
      path: "/app/management/data/migrate_data",
      flags: ["migrate_data"]
    });
  }
  return apps;
});
__publicField(_KibanaAppsRegistry, "stackManagementAlertsAndInsights", [
  {
    id: "Management|Stack Management|Alerts and Insights|Reporting",
    path: "/app/management/insightsAndAlerting/reporting",
    flags: ["reporting"]
  },
  {
    id: "Management|Stack Management|Alerts and Insights|Rules",
    path: "/app/management/insightsAndAlerting/triggersActions",
    flags: ["triggersActions", "rules"]
  },
  {
    id: "Management|Stack Management|Alerts and Insights|Connectors",
    path: "/app/management/insightsAndAlerting/triggersActionsConnectors",
    flags: ["triggersActionsConnectors"]
  },
  {
    id: "Management|Stack Management|Alerts and Insights|Cases",
    path: "/app/management/insightsAndAlerting/cases",
    flags: ["cases"]
  },
  {
    id: "Management|Stack Management|Alerts and Insights|Machine Learning",
    path: "/app/management/insightsAndAlerting/jobsListLink",
    flags: ["jobsListLink"]
  }
]);
__publicField(_KibanaAppsRegistry, "stackManagementKibana", () => {
  const apps = [
    {
      id: "Management|Stack Management|Kibana|Spaces",
      path: "/app/management/kibana/spaces",
      flags: ["spaces"]
    },
    {
      id: "Management|Stack Management|Kibana|Advanced Settings",
      path: "/app/management/kibana/settings",
      flags: ["settings"]
    },
    {
      id: "Management|Stack Management|Kibana|Search Sessions",
      path: "/app/management/kibana/search_sessions",
      flags: ["search_sessions"]
    },
    {
      id: "Management|Stack Management|Kibana|Tags",
      path: "/app/management/kibana/tags",
      flags: ["tags"]
    },
    {
      id: "Management|Stack Management|Kibana|Saved Objects",
      path: "/app/management/kibana/objects",
      flags: ["objects"]
    },
    {
      id: "Management|Stack Management|Kibana|AI Assistants",
      path: "/app/management/kibana/aiAssistantManagementSelection",
      flags: ["aiAssistantManagementSelection", "securityAiAssistantManagement", "observabilityAiAssistantManagement"]
    },
    {
      id: "Home",
      path: "/app/home",
      flags: ["home"]
    }
  ];
  if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("8.0.0")) {
    apps.push({
      id: "Management|Stack Management|Kibana|Index Patterns",
      path: "/app/management/kibana/indexPatterns",
      flags: ["indexPatterns"]
    });
  } else {
    apps.push({
      id: "Management|Stack Management|Kibana|Data Views",
      path: "/app/management/kibana/dataViews",
      flags: ["indexPatterns"]
    });
  }
  if (!import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("8.7.0")) {
    apps.push({
      id: "Management|Stack Management|Kibana|Files",
      path: "/app/management/kibana/filesManagement",
      flags: ["filesManagement"]
    });
  }
  return apps;
});
__publicField(_KibanaAppsRegistry, "stackManagementStack", [
  {
    id: "Management|Stack Management|Stack|License Management",
    path: "/app/management/stack/license_management",
    flags: ["license_management"]
  },
  {
    id: "Management|Stack Management|Stack|Upgrade Assistant",
    path: "/app/management/stack/upgrade_assistant",
    flags: ["upgrade_assistant"]
  }
]);
__publicField(_KibanaAppsRegistry, "elasticsearch", [
  {
    id: "Elasticsearch|Elasticsearch",
    path: "/app/elasticsearch/elasticsearch",
    flags: [
      "elasticsearchStart",
      "elasticsearchIndices",
      "enterpriseSearchAISearch",
      "searchExperiences",
      "enterpriseSearch",
      "enterpriseSearchApplications"
    ]
  },
  {
    id: "Elasticsearch|Home",
    path: "/app/elasticsearch/home",
    flags: ["searchHomepage"]
  },
  {
    id: "Elasticsearch|Index Management",
    path: "/app/elasticsearch/index_management",
    flags: ["elasticsearchIndexManagement"]
  },
  {
    id: "Elasticsearch|Synonyms",
    path: "/app/elasticsearch/synonyms",
    flags: ["searchSynonyms"]
  },
  {
    id: "Elasticsearch|Content",
    path: "/app/elasticsearch/content",
    flags: ["enterpriseSearchContent"]
  },
  {
    id: "Elasticsearch|Vector Search",
    path: "/app/elasticsearch/vector_search",
    flags: ["enterpriseSearchVectorSearch"]
  },
  {
    id: "Elasticsearch|Semantic Search",
    path: "/app/elasticsearch/semantic_search",
    flags: ["enterpriseSearchSemanticSearch"]
  },
  {
    id: "Elasticsearch|Behavioral Analytics",
    path: "/app/elasticsearch/analytics",
    flags: ["enterpriseSearchAnalytics"]
  },
  {
    id: "Elasticsearch|Query Rules",
    path: "/app/elasticsearch/query_rules",
    flags: ["searchQueryRules"]
  },
  {
    id: "Elasticsearch|Playground",
    path: "/app/elasticsearch/playground",
    flags: ["searchPlayground"]
  },
  {
    id: "Elasticsearch|Getting started",
    path: "/app/elasticsearch/getting_started",
    flags: ["searchGettingStarted"]
  },
  {
    id: "Elasticsearch|Agents",
    path: "/app/agent_builder",
    flags: ["agent_builder"]
  }
]);
// initialize with basic known apps, so we avoid people getting smart with nextUrl query param
// #TODO keep in sync with new versions of Kibana (pick the most updated list from the browser console.log)
__publicField(_KibanaAppsRegistry, "registry", []);
__publicField(_KibanaAppsRegistry, "logger", () => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let KibanaAppsRegistry = _KibanaAppsRegistry;
KibanaAppsRegistry.initialize();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KibanaAppsRegistry
});
