"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var knownHiddenAppsIdsProvider_exports = {};
__export(knownHiddenAppsIdsProvider_exports, {
  createKnownHiddenAppsIdsProvider: () => createKnownHiddenAppsIdsProvider
});
module.exports = __toCommonJS(knownHiddenAppsIdsProvider_exports);
var import_rorReservedHiddenAppsValues = require("../../../shared/constants/rorReservedHiddenAppsValues");
var import_kibanaAppsRegistry = require("./kibanaAppsRegistry");
function createKnownHiddenAppsIdsProvider() {
  return () => [...import_kibanaAppsRegistry.KibanaAppsRegistry.allAppsFromRegistry.map((app) => app.id), ...import_rorReservedHiddenAppsValues.ALL_ROR_RESERVED_HIDDEN_APPS_VALUES];
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createKnownHiddenAppsIdsProvider
});
