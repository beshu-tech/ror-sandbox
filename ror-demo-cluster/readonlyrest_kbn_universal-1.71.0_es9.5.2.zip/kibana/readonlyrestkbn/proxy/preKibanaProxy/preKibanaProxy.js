"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var preKibanaProxy_exports = {};
__export(preKibanaProxy_exports, {
  PreKibanaProxy: () => PreKibanaProxy
});
module.exports = __toCommonJS(preKibanaProxy_exports);
var import_cookie_parser = __toESM(require("cookie-parser"));
var import_cors = __toESM(require("cors"));
var import_express = __toESM(require("express"));
var import_morgan = __toESM(require("morgan"));
var import_rxjs = require("rxjs");
var import_tcp_port_used = __toESM(require("tcp-port-used"));
var import_distributionInfoProvider = require("../../kibana/patchers/distributionInfoProvider");
var import_errors = __toESM(require("../constants/errors"));
var import_basePathBuilder = require("../core/basePath/basePathBuilder");
var import_httpResponseMiddleware = require("../core/httpResponseMiddleware");
var import_identitySessionBuilder = require("../core/identitySessionBuilder");
var import_rorLogger = require("../core/logging/rorLogger");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
var import_conditionalMiddleware = require("../core/middleware/conditionalMiddleware");
var import_ssoSessionService = require("../core/rorRequest/ssoSessionService");
var import_pkpApiRouter = require("./api/router/pkpApiRouter");
var import_rorApiRouter = require("./api/router/rorApiRouter");
var import_ssoRouters = require("./api/router/ssoRouters");
var import_auditLogEmitter = require("./auditLogEmitter");
var import_authController = require("./auth/authController");
var import_csrf = require("./auth/csrf");
var import_legacyRenderer = require("./auth/legacyRenderer");
var import_logoutLinkProvider = require("./auth/logoutLinkProvider");
var import_oidcLogoutTransactionCookieService = require("./auth/oidc/oidcLogoutTransactionCookieService");
var import_oidcRouterSettings = require("./auth/oidc/oidcRouterSettings");
var import_samlLogoutTransactionCookieService = require("./auth/saml/samlLogoutTransactionCookieService");
var import_samlRouterSettings = require("./auth/saml/samlRouterSettings");
var import_ssoLogoutTransactionVerifier = require("./auth/ssoLogoutTransactionVerifier");
var import_whitelistedPathsController = require("./auth/whitelistedPathsController");
var import_authenticationFacade = require("./authenticationFacade");
var import_customMiddleware = require("./customMiddleware");
var import_defaultSpaceCreator = require("./defaultSpaceCreator");
var import_directAccessProxyBuilder = require("./directAccessProxyBuilder");
var import_documentRequestIndexCreator = require("./indexCreation/documentRequestIndexCreator");
var import_indexCreatorFactory = require("./indexCreation/indexCreatorFactory");
var import_htmlInjector = require("./injection/htmlInjector");
var import_proxyBuilder = require("./proxyBuilder");
var import_requestChecker = require("./requestChecker");
var import_serverCreator = require("./serverCreator");
class PreKibanaProxy {
  constructor(sessionManagerProvider, cookieManager, rorRequestAppender, esApiClientWithAuthProvider, esApiAdvancedClientWithAuthProvider, rorEsApiClientWithAuthProvider, identitySessionHeadersCollector, identitySessionHeadersValidation, licenseService, kibanaSettingsForPkp, elasticsearchSettings, rorSettingsStore, tenancyService, multiTenancyChecker, userMetadataResolver, extensions = []) {
    this.sessionManagerProvider = sessionManagerProvider;
    this.rorRequestAppender = rorRequestAppender;
    this.licenseService = licenseService;
    this.kibanaSettingsForPkp = kibanaSettingsForPkp;
    this.elasticsearchSettings = elasticsearchSettings;
    this.rorSettingsStore = rorSettingsStore;
    this.tenancyService = tenancyService;
    this.multiTenancyChecker = multiTenancyChecker;
    this.userMetadataResolver = userMetadataResolver;
    this.extensions = extensions;
    __publicField(this, "app");
    __publicField(this, "server");
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "serverCreator");
    __publicField(this, "samlRouterSettingsList");
    __publicField(this, "oidcRouterSettingsList");
    __publicField(this, "legacyRenderer");
    __publicField(this, "authController");
    __publicField(this, "ssoSessionService");
    __publicField(this, "ssoLogoutTransactionVerifier");
    __publicField(this, "samlLogoutTransactionCookieService");
    __publicField(this, "oidcLogoutTransactionCookieService");
    __publicField(this, "pkpApiRouter");
    __publicField(this, "rorApiRouter");
    __publicField(this, "proxy");
    __publicField(this, "auditLogEmitter");
    __publicField(this, "whitelistedPathsController");
    __publicField(this, "isReservedPath");
    __publicField(this, "cookieManager");
    __publicField(this, "identitySessionHeadersValidation");
    __publicField(this, "requestChecker");
    __publicField(this, "customMiddleware");
    __publicField(this, "indexCreator");
    __publicField(this, "documentRequestIndexCreator");
    __publicField(this, "basePathBuilder");
    __publicField(this, "samlRouters");
    __publicField(this, "oidcRouters");
    __publicField(this, "appendImpersonateInfoToLogs", async (req, res, next) => {
      var _a;
      const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
      const userImpersonated = (_a = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata) == null ? void 0 : _a.impersonatedBy;
      if (userImpersonated) {
        import_rorLogger.RorLogger.appendImpersonatingInfo(userRequestIdentity.metadata.username);
      } else {
        import_rorLogger.RorLogger.clearImpersonatingInfo();
      }
      next();
    });
    __publicField(this, "appendCorrelationIdInfoToLogs", async (req, res, next) => {
      var _a;
      const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
      const correlationId = (_a = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata) == null ? void 0 : _a.correlationId;
      if (correlationId) {
        import_rorLogger.RorLogger.appendCorrelationId(correlationId);
      } else {
        import_rorLogger.RorLogger.clearCorrelationId();
      }
      next();
    });
    __publicField(this, "multitenancyRequired", async (_, res, next) => {
      if (!this.multiTenancyChecker.multiTenancyFeatureAvailable()) {
        return res.status(403).type("text/plain").send("Enterprise license required");
      }
      return next();
    });
    this.basePathBuilder = new import_basePathBuilder.BasePathBuilder({
      rewriteBasePath: kibanaSettingsForPkp.rewriteBasePath,
      kibanaBasePath: kibanaSettingsForPkp.kibanaBasePath
    });
    const { withBasePathPrefix } = this.basePathBuilder;
    this.app = (0, import_express.default)();
    this.serverCreator = new import_serverCreator.ServerCreator(this.kibanaSettingsForPkp.kibanaSslSettings);
    this.cookieManager = cookieManager;
    const defaultSpaceCreator = new import_defaultSpaceCreator.DefaultSpaceCreator(esApiClientWithAuthProvider);
    this.indexCreator = import_indexCreatorFactory.IndexCreatorFactory.create(
      this.kibanaSettingsForPkp.kibanaIndex,
      esApiClientWithAuthProvider,
      esApiAdvancedClientWithAuthProvider,
      defaultSpaceCreator,
      rorSettingsStore
    );
    const identitySessionBuilder = new import_identitySessionBuilder.IdentitySessionBuilder(
      this.multiTenancyChecker,
      this.licenseService,
      this.userMetadataResolver
    );
    this.auditLogEmitter = new import_auditLogEmitter.AuditLogEmitter(rorEsApiClientWithAuthProvider);
    this.samlRouterSettingsList = new import_samlRouterSettings.SamlRouterSettingsList(
      {
        rewriteBasePath: kibanaSettingsForPkp.rewriteBasePath,
        kibanaBasePath: kibanaSettingsForPkp.kibanaBasePath
      },
      rorSettingsStore
    );
    this.oidcRouterSettingsList = new import_oidcRouterSettings.OidcRouterSettingsList(
      {
        rewriteBasePath: this.kibanaSettingsForPkp.rewriteBasePath,
        kibanaBasePath: this.kibanaSettingsForPkp.kibanaBasePath
      },
      rorSettingsStore
    );
    const logoutLinkProvider = new import_logoutLinkProvider.LogoutLinkProvider(
      this.kibanaSettingsForPkp.kibanaBasePath,
      this.samlRouterSettingsList,
      this.oidcRouterSettingsList,
      rorSettingsStore
    );
    const authenticationFacade = new import_authenticationFacade.AuthenticationFacade(
      sessionManagerProvider,
      cookieManager,
      esApiClientWithAuthProvider,
      rorEsApiClientWithAuthProvider,
      identitySessionHeadersCollector,
      this.elasticsearchSettings.requestHeadersWhitelist,
      this.licenseService,
      identitySessionBuilder,
      this.indexCreator,
      tenancyService,
      this.multiTenancyChecker,
      rorSettingsStore,
      this.auditLogEmitter,
      logoutLinkProvider
    );
    this.ssoSessionService = new import_ssoSessionService.SsoSessionService(sessionManagerProvider);
    this.ssoLogoutTransactionVerifier = new import_ssoLogoutTransactionVerifier.SsoLogoutTransactionVerifier(rorSettingsStore);
    this.samlLogoutTransactionCookieService = new import_samlLogoutTransactionCookieService.SamlLogoutTransactionCookieService(rorSettingsStore);
    this.oidcLogoutTransactionCookieService = new import_oidcLogoutTransactionCookieService.OidcLogoutTransactionCookieService(rorSettingsStore);
    this.legacyRenderer = new import_legacyRenderer.LegacyRenderer(
      this.kibanaSettingsForPkp.kibanaBasePath,
      this.licenseService,
      this.samlRouterSettingsList,
      this.oidcRouterSettingsList,
      rorSettingsStore,
      this.tenancyService
    );
    this.authController = new import_authController.AuthController(
      authenticationFacade,
      logoutLinkProvider,
      {
        rewriteBasePath: this.kibanaSettingsForPkp.rewriteBasePath,
        kibanaBasePath: this.kibanaSettingsForPkp.kibanaBasePath
      },
      tenancyService,
      rorSettingsStore,
      this.ssoSessionService,
      this.ssoLogoutTransactionVerifier,
      rorSettingsStore.getLatestRorKbnSettings().customLoginLink
    );
    this.pkpApiRouter = (0, import_pkpApiRouter.buildPkpApiRouter)(
      rorEsApiClientWithAuthProvider,
      authenticationFacade,
      this.licenseService,
      this.authController,
      this.kibanaSettingsForPkp.bindAddress.port,
      logoutLinkProvider,
      rorSettingsStore
    );
    this.rorApiRouter = (0, import_rorApiRouter.buildRorApiRouter)(
      this.licenseService,
      this.authController,
      authenticationFacade,
      rorSettingsStore
    );
    this.proxy = this.buildProxy();
    const directAccessProxy = new import_directAccessProxyBuilder.DirectAccessProxyBuilder(
      this.kibanaSettingsForPkp.kibanaUrl,
      this.elasticsearchSettings.requestHeadersWhitelist,
      rorSettingsStore
    ).build();
    this.whitelistedPathsController = new import_whitelistedPathsController.WhitelistedPathsController(directAccessProxy, rorSettingsStore);
    this.isReservedPath = new RegExp(`^${withBasePathPrefix("(/pkp.*|/log(in|out)|/switch-group|/api/ror)")}`);
    this.identitySessionHeadersValidation = identitySessionHeadersValidation;
    this.requestChecker = new import_requestChecker.RequestChecker(this.kibanaSettingsForPkp.kibanaBasePath);
    this.documentRequestIndexCreator = new import_documentRequestIndexCreator.DocumentRequestIndexCreator(
      this.indexCreator,
      this.authController.handleLogout
    );
    this.customMiddleware = new import_customMiddleware.CustomMiddleware(rorSettingsStore);
    this.samlRouters = new import_ssoRouters.SamlRouters(
      this.basePathBuilder,
      this.licenseService,
      rorSettingsStore,
      this.samlRouterSettingsList,
      this.legacyRenderer,
      this.ssoSessionService,
      this.samlLogoutTransactionCookieService,
      this.authController.createLocalFinalizationHandler()
    );
    this.oidcRouters = new import_ssoRouters.OidcRouters(
      this.basePathBuilder,
      this.licenseService,
      rorSettingsStore,
      this.oidcRouterSettingsList,
      this.legacyRenderer,
      this.ssoSessionService,
      this.oidcLogoutTransactionCookieService,
      this.authController.createLocalFinalizationHandler()
    );
    this.init();
  }
  close() {
    var _a, _b;
    this.licenseService.destroy();
    this.extensions.forEach((extension) => extension.close());
    (_a = this.server) == null ? void 0 : _a.removeAllListeners();
    (_b = this.server) == null ? void 0 : _b.close();
  }
  buildProxy() {
    const htmlInjector = new import_htmlInjector.HtmlInjector(this.kibanaSettingsForPkp.kibanaBasePath, this.rorSettingsStore, {
      additionalBodyScripts: this.extensions.flatMap(
        (extension) => extension.additionalBodyScripts(this.kibanaSettingsForPkp.kibanaBasePath)
      )
    });
    return new import_proxyBuilder.ProxyBuilder(
      htmlInjector,
      this.authController,
      this.cookieManager,
      this.kibanaSettingsForPkp,
      this.elasticsearchSettings,
      this.tenancyService,
      this.rorSettingsStore,
      this.multiTenancyChecker
    ).build();
  }
  init() {
    const { withBasePathPrefix } = this.basePathBuilder;
    this.samlRouters.init();
    this.oidcRouters.init();
    this.app.disable("x-powered-by");
    this.app.use((0, import_httpResponseMiddleware.setSecurityHeadersMiddleware)(this.kibanaSettingsForPkp.securityHeaders));
    this.app.set("json spaces", 2);
    this.initDevInterceptors();
    this.extensions.forEach((extension) => extension.registerPublicRoutes(this.app, withBasePathPrefix));
    this.app.use((req, res, next) => {
      if (!this.isReservedPath.test(req.path)) {
        return next();
      }
      if (req.header("content-type") === "application/yaml") {
        return import_express.default.text({ type: ["application/yaml"] })(req, res, next);
      }
      return import_express.default.json({ limit: "500gb" })(req, res, next);
    });
    this.app.use((req, res, next) => {
      res.on("finish", async () => {
        if (res.statusCode === 401 || res.statusCode === 403) {
          await this.identitySessionHeadersValidation.revalidate(req);
        }
      });
      next();
    });
    this.app.use(this.whitelistedPathsController.handleWhitelistedPaths);
    this.app.use((0, import_cookie_parser.default)());
    this.app.use(this.rorRequestAppender.appendRorRequest);
    this.app.use(this.authController.handleApiReqWithJwtToken);
    this.app.use(this.authController.handleApiReqWithCredentialsOnboard);
    this.app.use(
      (0, import_conditionalMiddleware.conditionalMiddleware)(
        (req) => req.rorRequest.isAuthenticated(),
        this.requestChecker.userRequestIdentityVerification
      )
    );
    this.app.use(
      (0, import_conditionalMiddleware.conditionalMiddleware)(
        (req) => req.rorRequest.isAuthenticated(),
        this.documentRequestIndexCreator.ensureIndexAndSpaceForRequest
      )
    );
    this.app.use((0, import_conditionalMiddleware.conditionalMiddleware)((req) => req.rorRequest.isAuthenticated(), this.appendImpersonateInfoToLogs));
    this.app.use((0, import_conditionalMiddleware.conditionalMiddleware)((req) => req.rorRequest.isAuthenticated(), this.appendCorrelationIdInfoToLogs));
    this.app.use(
      (0, import_conditionalMiddleware.conditionalMiddleware)((req) => req.rorRequest.isAuthenticated(), this.requestChecker.enforceApiOnlyAccess)
    );
    this.app.use(async (req, res, next) => this.customMiddleware.inject(req, res, next, this.licenseService));
    this.app.use(
      (0, import_conditionalMiddleware.conditionalMiddleware)(
        async (req) => !await req.rorRequest.isAuthenticated(),
        this.authController.handleExternalSourceAuth
      )
    );
    this.app.use((0, import_conditionalMiddleware.conditionalMiddleware)(async () => this.samlRouters.hasRouters(), this.samlRouters.getRouters()));
    this.app.use((0, import_conditionalMiddleware.conditionalMiddleware)(async () => this.oidcRouters.hasRouters(), this.oidcRouters.getRouters()));
    this.app.use(withBasePathPrefix("/pkp/legacy/web"), import_express.default.static(`${__dirname}/../../public`));
    this.app.get(
      withBasePathPrefix("/pkp/autodeps"),
      this.legacyRenderer.serveDependenciesAutomaticallyFromNodeModules
    );
    this.app.get(withBasePathPrefix("/login"), this.authController.redirectAuthenticated);
    this.app.get(withBasePathPrefix("/login"), this.authController.handleCustomLoginRedirection);
    this.app.get(withBasePathPrefix("/login"), (0, import_httpResponseMiddleware.setNoCacheHeadersMiddleware)(), this.legacyRenderer.renderLoginPage);
    this.app.get(
      withBasePathPrefix("/pkp/legacy/web/assets/js/login_tpl_defer.js"),
      (0, import_httpResponseMiddleware.setNoCacheHeadersMiddleware)(),
      this.legacyRenderer.renderLoginDeferredScript
    );
    this.app.post(
      withBasePathPrefix("/login"),
      // We need to call it this way to be able to mock checkCsrfTokenPresent in our tests
      (req, res, next) => import_csrf.Csrf.checkCsrfTokenPresent(req, res, next),
      // We need to call it this way to be able to mock doubleCsrfProtection in our tests
      (req, res, next) => import_csrf.Csrf.doubleCsrfProtection(req, res, next),
      import_csrf.Csrf.csrfErrorHandler,
      this.authController.handleLoginPost
    );
    this.app.get(
      withBasePathPrefix(import_logoutLinkProvider.LogoutLinkProvider.ROR_LOGOUT_LINK),
      (0, import_httpResponseMiddleware.setNoCacheHeadersMiddleware)(false),
      this.authController.handleLogout
    );
    this.app.get(withBasePathPrefix("/pkp/session-probe"), this.authController.handleSessionProbe);
    this.app.use(this.authController.redirectUnauthenticated.bind(this.authController));
    this.app.use(this.authController.refreshSession.bind(this.authController));
    this.app.get(
      withBasePathPrefix("/switch-group"),
      this.multitenancyRequired,
      (0, import_conditionalMiddleware.conditionalMiddleware)(async (req) => req.rorRequest.isAuthenticated(), this.switchTenancy.bind(this))
    );
    this.app.get(
      withBasePathPrefix("/pkp/legacy/web/assets/js/switch_group_tpl_defer.js"),
      this.multitenancyRequired,
      this.legacyRenderer.renderSwitchGroupDeferredScript
    );
    this.extensions.forEach(
      (extension) => extension.registerAuthenticatedRoutes(this.app, withBasePathPrefix, this.kibanaSettingsForPkp.kibanaBasePath)
    );
    this.app.use(withBasePathPrefix("/api/ror"), this.rorApiRouter);
    this.app.use(withBasePathPrefix("/pkp/api"), this.pkpApiRouter);
    this.app.use(withBasePathPrefix("/pkp/web/static"), import_express.default.static(`${__dirname}/../../web-app/build/web/static`));
    this.app.use(withBasePathPrefix("/pkp/web/vs"), import_express.default.static(`${__dirname}/../../web-app/build/web/vs`));
    this.app.use(withBasePathPrefix("/pkp/web/assets"), import_express.default.static(`${__dirname}/../../web-app/build/web/assets`));
    this.app.use(
      withBasePathPrefix("/pkp/web"),
      (req, res) => res.sendFile("index.html", { root: `${__dirname}/../../web-app/build` })
    );
    this.app.get(withBasePathPrefix("/pkp/injections/custom.js"), this.legacyRenderer.renderCustomUserJsInjection);
    this.app.get(
      withBasePathPrefix("/pkp/injections/tenancy-context-injector.js"),
      this.multitenancyRequired,
      this.legacyRenderer.renderTenancyInjector
    );
    this.app.get(withBasePathPrefix("/pkp/injections/hidden-apps.js"), this.legacyRenderer.renderHiddenAppsInjection);
    this.app.get(
      withBasePathPrefix("/pkp/injections/ror-css-classes.js"),
      this.legacyRenderer.renderRorCssClassesInjection
    );
    this.app.get(
      withBasePathPrefix("/pkp/injections/session-probe.js"),
      this.legacyRenderer.renderSessionProbeInjection
    );
    this.app.get(
      withBasePathPrefix("/pkp/injections/activation-expiration-alert.js"),
      this.legacyRenderer.renderActivationKeyExpirationAlert
    );
    this.app.get(
      withBasePathPrefix("/pkp/injections/unsupported-endpoints-filter.js"),
      this.legacyRenderer.renderUnsupportedEndpointsFilter
    );
    this.app.use(this.proxy);
    this.licenseService.onLicenseChanged$.pipe((0, import_rxjs.skip)(1)).subscribe(async () => {
      await this.sessionManagerProvider.get().deleteAllSessions();
    });
    this.rorSettingsStore.observerRorKbnSettings(({ cookieSettings }) => cookieSettings).subscribe((cookieSettings) => {
      import_csrf.Csrf.configure(
        Boolean(this.kibanaSettingsForPkp.kibanaSslSettings),
        `${this.kibanaSettingsForPkp.bindAddress.host}:${this.kibanaSettingsForPkp.bindAddress.port}`,
        cookieSettings.password
      );
    });
    this.launch();
  }
  async switchTenancy(req, res) {
    const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
    if (!userRequestIdentity) {
      this.logger.error({ message: import_errors.default.userRequestIdentityNotAvailable });
      return this.authController.handleLogout(req, res);
    }
    try {
      const switchTenancyPermitted = await this.tenancyService.accessPolicy.switchTenancyPermitted(req);
      if (!switchTenancyPermitted.ok) {
        this.logger.error({ message: switchTenancyPermitted.message, stack: switchTenancyPermitted.stack });
        return await this.authController.handleLogout(req, res);
      }
      await this.indexCreator.createIndexAndSpace(userRequestIdentity.metadata);
      await this.legacyRenderer.renderSwitchGroup(req, res);
    } catch (e) {
      this.logger.error({ message: e.message, stack: e.stack });
      await this.authController.handleLogout(req, res);
    }
  }
  initDevInterceptors() {
    if (import_distributionInfoProvider.DistributionInfoProvider.isEnvironmentDev()) {
      this.app.use("/*", (0, import_cors.default)({ origin: true, credentials: true }));
      this.app.use((0, import_morgan.default)("PKP :method :url :status :response-time ms - :res[content-length]"));
    }
  }
  launch() {
    const { host, port } = this.kibanaSettingsForPkp.bindAddress;
    import_tcp_port_used.default.check(port, host).then(async (inUse) => {
      if (!inUse) {
        import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename).trace(`Pre-kibana-proxy will listen on http://${host}:${port}`);
        this.server = this.serverCreator.createServer(this.app, this.kibanaSettingsForPkp.bindAddress);
      }
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PreKibanaProxy
});
