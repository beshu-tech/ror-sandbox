"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var proxyBuilder_exports = {};
__export(proxyBuilder_exports, {
  ProxyBuilder: () => ProxyBuilder
});
module.exports = __toCommonJS(proxyBuilder_exports);
var import_dns = __toESM(require("dns"));
var import_express_http_proxy = __toESM(require("express-http-proxy"));
var import_distributionInfoProvider = require("../../kibana/patchers/distributionInfoProvider");
var import_authorizationHeaderBuilder = require("../core/authorization/authorizationHeaderBuilder");
var import_proxyRequestHeaders = require("../core/common/proxyRequestHeaders");
var import_types = require("../core/common/types");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
var import_TenancyContext = require("../core/tenancy/TenancyContext");
var import_CapabilitiesInterceptor = require("./proxyResponseInterceptors/CapabilitiesInterceptor");
var import_CustomIntegrationsInterceptor = require("./proxyResponseInterceptors/CustomIntegrationsInterceptor");
var import_GlobalSearchInterceptor = require("./proxyResponseInterceptors/GlobalSearchInterceptor");
var import_HtmlNavigationInterceptor = require("./proxyResponseInterceptors/HtmlNavigationInterceptor");
var import_KibanaErrorInterceptor = require("./proxyResponseInterceptors/KibanaErrorInterceptor");
var import_ProxyResponseInterceptorHandler = require("./proxyResponseInterceptors/ProxyResponseInterceptorHandler");
if ("setDefaultResultOrder" in import_dns.default) {
  import_dns.default.setDefaultResultOrder("ipv4first");
}
const _ProxyBuilder = class _ProxyBuilder {
  constructor(htmlInjector, authController, cookieManager, kibanaSettingsForPkp, elasticsearchSettings, tenancyService, rorSettingsStore, multiTenancyChecker) {
    this.cookieManager = cookieManager;
    this.kibanaSettingsForPkp = kibanaSettingsForPkp;
    this.elasticsearchSettings = elasticsearchSettings;
    this.tenancyService = tenancyService;
    this.rorSettingsStore = rorSettingsStore;
    this.multiTenancyChecker = multiTenancyChecker;
    __publicField(this, "authorizationHeaderBuilder");
    __publicField(this, "responseHandler");
    __publicField(this, "authorizationHeaderDecorator", async (proxyRequestOptions, sourceRequest) => {
      var _a, _b, _c;
      const { pkpKibanaToken, cookieSettings } = this.rorSettingsStore.getLatestRorKbnSettings();
      (_a = proxyRequestOptions.headers) != null ? _a : proxyRequestOptions.headers = {};
      const headers = proxyRequestOptions.headers;
      (0, import_proxyRequestHeaders.prepareProxyRequestHeaders)(
        _ProxyBuilder.logger,
        this.elasticsearchSettings.requestHeadersWhitelist,
        sourceRequest.headers,
        headers
      );
      headers["x-ror-pkp-kibana-token"] = pkpKibanaToken;
      const sourceResponseHeaders = (_b = sourceRequest.res) == null ? void 0 : _b.getHeaders();
      if (sourceResponseHeaders == null ? void 0 : sourceResponseHeaders["set-cookie"]) {
        const cookie = (_c = this.cookieManager.parseCookieHeader(sourceResponseHeaders["set-cookie"].toString())) == null ? void 0 : _c[cookieSettings.name];
        headers.cookie = `${cookieSettings.name}=${cookie}`;
      }
      const tenancyIdFromRequestHeader = headers[import_types.X_ROR_TENANCY_ID];
      const userRequestIdentity = await sourceRequest.rorRequest.getUserRequestIdentity({
        predefinedTenancyId: typeof tenancyIdFromRequestHeader === "string" ? tenancyIdFromRequestHeader : void 0
      });
      headers.Authorization = await this.authorizationHeaderBuilder.prepareAuthorizationHeaderFromRequest(
        sourceRequest.rorRequest,
        userRequestIdentity
      );
      headers[import_types.X_ROR_KIBANA_INDEX] = this.multiTenancyChecker.multiTenancyFeatureAvailable() && (userRequestIdentity == null ? void 0 : userRequestIdentity.metadata.kibanaIndex) || this.kibanaSettingsForPkp.kibanaIndex;
      return proxyRequestOptions;
    });
    __publicField(this, "resolveProxyRequestPath", async (sourceRequest) => {
      var _a;
      const url = sourceRequest.rorRequest.getUrl();
      return (_a = this.rewriteRorBundleVersion(url)) != null ? _a : this.addDefaultSpacePrefix(url);
    });
    __publicField(this, "userResHeaderDecorator", async (headers, userReq, existingSetCookieHeaders) => {
      const upstreamSetCookieHeaders = headers["set-cookie"];
      if (existingSetCookieHeaders !== void 0) {
        headers["set-cookie"] = [
          ..._ProxyBuilder.toHeaderValues(existingSetCookieHeaders),
          ..._ProxyBuilder.toHeaderValues(upstreamSetCookieHeaders)
        ];
      }
      if (headers["www-authenticate"]) {
        delete headers["www-authenticate"];
      }
      const location = Array.isArray(headers.location) ? headers.location[0] : headers.location;
      if (location) {
        const origin = `${userReq.protocol}://${userReq.get("host")}`;
        const identity = await userReq.rorRequest.getUserRequestIdentity();
        if (identity == null ? void 0 : identity.metadata.currentGroup) {
          headers.location = this.tenancyService.persistTenancyContextInUrl(
            location,
            (0, import_TenancyContext.tenancyFromId)(identity.metadata.currentGroup.id, identity.metadata.kibanaIndex),
            origin
          );
        }
      }
      return headers;
    });
    __publicField(this, "interceptResponse", (proxyResponse, proxyResData, userReq, userRes) => this.responseHandler.run(proxyResponse, proxyResData, userReq, userRes));
    __publicField(this, "proxyErrorHandler", (error, res, next) => {
      _ProxyBuilder.logger.trace("PreKibanaProxy error ", error);
      next(error);
    });
    this.authorizationHeaderBuilder = new import_authorizationHeaderBuilder.AuthorizationHeaderBuilder(
      multiTenancyChecker,
      kibanaSettingsForPkp.kibanaIndex
    );
    this.responseHandler = new import_ProxyResponseInterceptorHandler.ProxyResponseInterceptorHandler([
      new import_KibanaErrorInterceptor.KibanaErrorInterceptor(authController),
      new import_CapabilitiesInterceptor.CapabilitiesInterceptor(),
      new import_CustomIntegrationsInterceptor.CustomIntegrationsInterceptor(),
      new import_GlobalSearchInterceptor.GlobalSearchInterceptor(),
      new import_HtmlNavigationInterceptor.HtmlNavigationInterceptor(
        htmlInjector,
        tenancyService,
        kibanaSettingsForPkp.kibanaBasePath,
        kibanaSettingsForPkp.rewriteBasePath
      )
    ]);
  }
  build() {
    const isMultipartRequest = (req) => {
      const contentTypeHeader = req.headers["content-type"];
      return (contentTypeHeader == null ? void 0 : contentTypeHeader.indexOf("multipart")) > -1;
    };
    return (req, res, next) => {
      const existingSetCookieHeaders = res.getHeader("set-cookie");
      const proxyOptions = {
        parseReqBody: !isMultipartRequest(req),
        https: false,
        preserveHostHdr: true,
        // @ts-ignore
        proxyReqOptDecorator: this.authorizationHeaderDecorator,
        // @ts-ignore
        proxyReqPathResolver: this.resolveProxyRequestPath,
        // @ts-ignore
        userResDecorator: this.interceptResponse,
        // @ts-ignore
        proxyErrorHandler: this.proxyErrorHandler,
        // @ts-ignore
        userResHeaderDecorator: (headers) => this.userResHeaderDecorator(headers, req, existingSetCookieHeaders),
        limit: "500gb"
      };
      return (0, import_express_http_proxy.default)(this.kibanaSettingsForPkp.kibanaUrl, proxyOptions)(req, res, next);
    };
  }
  rewriteRorBundleVersion(url) {
    const match = url.match(_ProxyBuilder.ROR_BUNDLE_PATH_PATTERN);
    if (!match) return null;
    const rewritten = match[1] + import_distributionInfoProvider.DistributionInfoProvider.getInstance().versionString + match[2];
    _ProxyBuilder.logger.debug(`Rewriting stale ROR bundle path: ${url} \u2192 ${rewritten}`);
    return rewritten;
  }
  addDefaultSpacePrefix(url) {
    const { spacesEnabled } = this.kibanaSettingsForPkp;
    if (import_distributionInfoProvider.DistributionInfoProvider.getInstance().isKibanaMoreAncientThan("7.11.0") || !spacesEnabled) {
      return url;
    }
    if (url.includes("/s/") || url.includes("/spaces/space_selector")) {
      return url;
    }
    if (this.kibanaSettingsForPkp.kibanaBasePath && this.kibanaSettingsForPkp.rewriteBasePath) {
      const urlWithoutBasePath = url.replace(this.kibanaSettingsForPkp.kibanaBasePath, "");
      return `${this.kibanaSettingsForPkp.kibanaBasePath}/s/default${urlWithoutBasePath}`;
    }
    return `/s/default${url}`;
  }
  static toHeaderValues(headers) {
    if (headers === void 0) return [];
    return Array.isArray(headers) ? headers : [headers.toString()];
  }
};
__publicField(_ProxyBuilder, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
// In non-sticky load-balanced setups, the browser may receive an HTML page from an instance
// running a different ROR version. That HTML embeds a bundle URL with the old version's path
// segment (e.g. "1.69.1_es9.0.0"). When the next request lands on this instance, the path
// would 404. We rewrite any stale ROR bundle version to the current instance's version.
__publicField(_ProxyBuilder, "ROR_BUNDLE_PATH_PATTERN", /^(.*\/bundles\/plugin\/readonlyrestkbn\/)[^/]+(\/.*)/);
let ProxyBuilder = _ProxyBuilder;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ProxyBuilder
});
