"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var CustomIntegrationsInterceptor_exports = {};
__export(CustomIntegrationsInterceptor_exports, {
  CustomIntegrationsInterceptor: () => CustomIntegrationsInterceptor
});
module.exports = __toCommonJS(CustomIntegrationsInterceptor_exports);
var import_SearchFilter = require("../SearchFilter");
class CustomIntegrationsInterceptor {
  async intercept(_proxyResponse, proxyResData, userReq, _userRes) {
    if (!userReq.url.includes("customIntegrations/replacementCustomIntegrations") && // for Kibana 8.x and 9.x
    !userReq.url.endsWith("/api/fleet/epm/packages") && // for Kibana 8.x and 9.x
    !userReq.url.includes("/api/fleet/epm/packages?experimental=true")) {
      return { handled: false };
    }
    const parsedCustomIntegrations = proxyResData.length > 0 ? JSON.parse(proxyResData.toString()) : [];
    const hiddenAppNames = await userReq.rorRequest.extractHiddenAppsNames();
    return {
      handled: true,
      data: import_SearchFilter.SearchFilter.toBuffer(import_SearchFilter.SearchFilter.filterCustomIntegrations(parsedCustomIntegrations, hiddenAppNames))
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CustomIntegrationsInterceptor
});
