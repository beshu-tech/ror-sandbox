"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var GlobalSearchInterceptor_exports = {};
__export(GlobalSearchInterceptor_exports, {
  GlobalSearchInterceptor: () => GlobalSearchInterceptor
});
module.exports = __toCommonJS(GlobalSearchInterceptor_exports);
var import_SearchFilter = require("../SearchFilter");
class GlobalSearchInterceptor {
  async intercept(_proxyResponse, proxyResData, userReq, _userRes) {
    if (!userReq.url.includes("internal/global_search/find")) {
      return { handled: false };
    }
    const parsedSearchResults = proxyResData.length > 0 ? JSON.parse(proxyResData.toString()) : { results: [] };
    const hiddenAppNames = await userReq.rorRequest.extractHiddenAppsNames();
    const filteredSearchResults = import_SearchFilter.SearchFilter.filterGlobalSearchResults(parsedSearchResults == null ? void 0 : parsedSearchResults.results, hiddenAppNames);
    return { handled: true, data: import_SearchFilter.SearchFilter.toBuffer({ results: filteredSearchResults }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  GlobalSearchInterceptor
});
