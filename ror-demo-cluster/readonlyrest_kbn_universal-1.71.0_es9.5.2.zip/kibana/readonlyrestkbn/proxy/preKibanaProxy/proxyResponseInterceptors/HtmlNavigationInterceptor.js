"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var HtmlNavigationInterceptor_exports = {};
__export(HtmlNavigationInterceptor_exports, {
  HtmlNavigationInterceptor: () => HtmlNavigationInterceptor
});
module.exports = __toCommonJS(HtmlNavigationInterceptor_exports);
var import_queryStringKeys = require("../../../shared/constants/queryStringKeys");
var import_basePathBuilder = require("../../core/basePath/basePathBuilder");
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
var import_TenancyContext = require("../../core/tenancy/TenancyContext");
var import_kibanaAppsRegistry = require("../kibana_apps/kibanaAppsRegistry");
const _HtmlNavigationInterceptor = class _HtmlNavigationInterceptor {
  constructor(htmlInjector, tenancyService, kibanaBasePath, rewriteBasePath) {
    this.htmlInjector = htmlInjector;
    this.tenancyService = tenancyService;
    this.kibanaBasePath = kibanaBasePath;
    this.rewriteBasePath = rewriteBasePath;
  }
  async intercept(proxyResponse, proxyResData, userReq, userRes) {
    if (!_HtmlNavigationInterceptor.isResponseValidHTML(proxyResponse, proxyResData)) {
      return { handled: false };
    }
    const hiddenAppNames = await userReq.rorRequest.extractHiddenAppsNames();
    const userHasAccessToTenancy = await this.tenancyService.accessPolicy.hasUserAccessToTenancyFromUrl(userReq);
    if (!import_kibanaAppsRegistry.KibanaAppsRegistry.isNavigationAllowed(userReq.path, hiddenAppNames) || !userHasAccessToTenancy) {
      return { handled: true, data: await this.redirectIfNavigationIsNotAllowed(userReq, userRes, proxyResData) };
    }
    return { handled: true, data: this.htmlInjector.injectCssAndJsScriptsIntoHtml(proxyResData) };
  }
  static isResponseValidHTML(response, responseData) {
    return !!response.headers["content-type"] && response.headers["content-type"].toString().includes("html") && responseData.toString().includes("<head>") && responseData.toString().includes("<body>");
  }
  async redirectIfNavigationIsNotAllowed(userReq, userRes, proxyResData) {
    var _a;
    _HtmlNavigationInterceptor.logger.info(`Attempted navigation to prohibited path ${userReq.path}`);
    const userRequestIdentity = await userReq.rorRequest.getUserRequestIdentity();
    const basePathBuilder = new import_basePathBuilder.BasePathBuilder({
      rewriteBasePath: this.rewriteBasePath,
      kibanaBasePath: this.kibanaBasePath
    });
    const origin = `${userReq.protocol}://${userReq.get("host")}`;
    const fullUrl = encodeURIComponent(`${origin}${userReq.originalUrl}`);
    const notFoundUrl = `/app/page-not-found?${import_queryStringKeys.NOT_FOUND_QUERY_STRING_KEY}=${fullUrl}`;
    const redirectUrl = userRequestIdentity ? this.tenancyService.persistTenancyContextInUrl(
      notFoundUrl,
      (0, import_TenancyContext.tenancyFromKibanaIndex)(
        (_a = userRequestIdentity.metadata.currentGroup) == null ? void 0 : _a.id,
        userRequestIdentity.metadata.kibanaIndex
      ),
      origin
    ) : notFoundUrl;
    userRes.redirect(basePathBuilder.withBasePathPrefix(redirectUrl));
    return proxyResData;
  }
};
__publicField(_HtmlNavigationInterceptor, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let HtmlNavigationInterceptor = _HtmlNavigationInterceptor;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HtmlNavigationInterceptor
});
