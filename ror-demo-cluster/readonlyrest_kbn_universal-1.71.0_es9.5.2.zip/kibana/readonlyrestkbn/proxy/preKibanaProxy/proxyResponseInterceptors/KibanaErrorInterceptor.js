"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var KibanaErrorInterceptor_exports = {};
__export(KibanaErrorInterceptor_exports, {
  KibanaErrorInterceptor: () => KibanaErrorInterceptor
});
module.exports = __toCommonJS(KibanaErrorInterceptor_exports);
var import_json_stable_stringify = __toESM(require("json-stable-stringify"));
var import_rorLoggerFactory = require("../../core/logging/rorLoggerFactory");
const _KibanaErrorInterceptor = class _KibanaErrorInterceptor {
  constructor(authController) {
    this.authController = authController;
  }
  async intercept(_proxyResponse, proxyResData, userReq, userRes) {
    if (userRes.statusCode === 404 && (userReq.url.includes("/api/index_patterns/_fields_for_wildcard") || // For Kibana 8.x
    userReq.url.includes("/internal/data_views/fields"))) {
      const silenced = this.silenceKibanaError(userReq, proxyResData, userRes);
      if (silenced) {
        return { handled: true, data: silenced };
      }
      return { handled: false };
    }
    if (userRes.statusCode === 500) {
      await this.handle500(userReq, userRes, proxyResData);
    }
    return { handled: false };
  }
  silenceKibanaError(userReq, proxyResData, userRes) {
    const parsedData = proxyResData.length > 0 ? JSON.parse(proxyResData.toString()) : proxyResData;
    if (parsedData.message.includes("forbidden_response")) {
      _KibanaErrorInterceptor.logger.debug(
        `Suppressing Kibana error for request URL: ${userReq.url}, original error:`,
        proxyResData.toString()
      );
      userRes.statusCode = 200;
      return Buffer.from((0, import_json_stable_stringify.default)({ fields: [], indices: [] }, { space: "  " }));
    }
  }
  async handle500(userReq, userRes, proxyResData) {
    const parsedData = proxyResData.length > 0 ? JSON.parse(proxyResData.toString()) : proxyResData;
    const urlsToPerformLogout = ["/", "/spaces/space_selector"];
    _KibanaErrorInterceptor.logger.info(
      `Receiving 500 error from Kibana response with a data: ${proxyResData.toString()}, from url: ${userReq.url} and requested from address: ${userReq.headers.referer}`
    );
    if (urlsToPerformLogout.some((url) => url === userReq.url) && parsedData.statusCode === 500 && parsedData.error === "Internal Server Error") {
      const message = "Kibana returned an error status and the session is finished. There is probably something wrong with your configuration files and the ReadonlyREST Elasticsearch security plugin for Kibana could not work properly.";
      _KibanaErrorInterceptor.logger.error({ message });
      await this.authController.handleLogout(userReq, userRes);
      throw new Error(message);
    }
  }
};
__publicField(_KibanaErrorInterceptor, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
let KibanaErrorInterceptor = _KibanaErrorInterceptor;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KibanaErrorInterceptor
});
