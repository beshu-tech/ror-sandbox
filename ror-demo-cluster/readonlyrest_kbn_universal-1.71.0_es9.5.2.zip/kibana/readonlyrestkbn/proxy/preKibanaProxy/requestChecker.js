"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var requestChecker_exports = {};
__export(requestChecker_exports, {
  RequestChecker: () => RequestChecker
});
module.exports = __toCommonJS(requestChecker_exports);
var import_lodash = require("lodash");
var import_xregexp = __toESM(require("xregexp"));
var import_kibanaIndexDependentUrls = require("../../shared/constants/kibanaIndexDependentUrls");
var import_queryStringKeys = require("../../shared/constants/queryStringKeys");
var import_kibanaApiPath = require("../core/common/kibanaApiPath");
var import_urlUtils = require("../core/common/urlUtils");
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
var import_tenancyUrl = require("../core/tenancy/tenancyUrl");
class RequestChecker {
  constructor(kibanaBasePath) {
    this.kibanaBasePath = kibanaBasePath;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "apiPathRegexp");
    __publicField(this, "userRequestIdentityVerification", async (req, res, next) => {
      if (!req.rorRequest.getQueries()[import_queryStringKeys.TENANCY_QUERY_STRING_KEY]) {
        return next();
      }
      const ensuredIdentityAvailability = await req.rorRequest.ensuredIdentityAvailability();
      if (!ensuredIdentityAvailability.ok) {
        if (ensuredIdentityAvailability.reason === "no_group_matching_tenancy_context") {
          const isSavedObjectUrl = (0, import_kibanaIndexDependentUrls.isSavedObjectDependentUrl)(req.url);
          if (isSavedObjectUrl) {
            return res.redirect(this.withBasePath("/app/page-not-found"));
          }
          const origin = `${req.protocol}://${req.headers.host}`;
          const stripped = (0, import_tenancyUrl.stripTenancyFromUrl)(req.url, origin);
          if (stripped === null || !(0, import_urlUtils.isSafeRelativeUrl)(stripped)) {
            if (stripped !== null) {
              this.logger.warn(`Blocked unsafe redirect after tenancy strip: ${stripped.replace(/[\r\n]/g, "\u23CE")}`);
            }
            return res.redirect(this.withBasePath("/app/page-not-found"));
          }
          return res.redirect(stripped);
        }
        this.logger.error({
          message: `There was a problem with accessing user request identity: ${ensuredIdentityAvailability.reason}, url: ${req.url}`
        });
        return this.internalServerError(res);
      }
      return next();
    });
    __publicField(this, "withBasePath", (path) => this.kibanaBasePath + path);
    this.apiPathRegexp = import_kibanaApiPath.KibanaApiPath.buildPathRegex(this.kibanaBasePath);
    this.enforceApiOnlyAccess = this.enforceApiOnlyAccess.bind(this);
  }
  async enforceApiOnlyAccess(req, res, next) {
    var _a;
    try {
      const userRequestIdentity = await req.rorRequest.getUserRequestIdentity();
      if (((_a = userRequestIdentity == null ? void 0 : userRequestIdentity.metadata) == null ? void 0 : _a.kibanaAccess) !== "api_only") {
        return next();
      }
      const normalizedPath = this.normalizeApiPath(req.path);
      if (normalizedPath === null) {
        return this.forbidden(res);
      }
      const { allowedApiPaths } = userRequestIdentity.metadata;
      if (allowedApiPaths && !(0, import_lodash.isEmpty)(allowedApiPaths)) {
        const compiledPaths = this.compileValidAllowedApiPaths(allowedApiPaths);
        const isPermitted = compiledPaths.some(({ http_method, compiledPathRegex }) => {
          const methodAllowed = http_method === "ANY" || http_method.toLowerCase() === req.rorRequest.getMethod().toLowerCase();
          return methodAllowed && compiledPathRegex.test(normalizedPath);
        });
        if (!isPermitted) {
          return this.forbidden(res);
        }
      }
      return next();
    } catch (e) {
      this.logger.error({
        message: `api only access enforcement: ${e instanceof Error ? e.message : String(e)}`,
        stack: e instanceof Error ? e.stack : void 0
      });
      return this.internalServerError(res);
    }
  }
  normalizeApiPath(path) {
    var _a, _b;
    return (_b = (_a = this.apiPathRegexp.exec(path)) == null ? void 0 : _a[1]) != null ? _b : null;
  }
  compilePathRegex(pathRegex) {
    try {
      return import_xregexp.default.cache(pathRegex, "");
    } catch {
      return void 0;
    }
  }
  compileValidAllowedApiPaths(allowedApiPaths) {
    return allowedApiPaths.map((allowedPath) => ({ ...allowedPath, compiledPathRegex: this.compilePathRegex(allowedPath.path_regex) })).filter((allowedPath) => allowedPath.compiledPathRegex !== void 0);
  }
  forbidden(res) {
    return res.status(403).json({ status_code: 403, status: "forbidden", message: "forbidden" });
  }
  internalServerError(res) {
    return res.status(500).json({ status_code: 500, status: "ko", message: "Internal server error" });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RequestChecker
});
