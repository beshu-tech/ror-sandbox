"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var serverCreator_exports = {};
__export(serverCreator_exports, {
  ServerCreator: () => ServerCreator
});
module.exports = __toCommonJS(serverCreator_exports);
var import_crypto = require("crypto");
var import_fs = __toESM(require("fs"));
var import_https = __toESM(require("https"));
var import_tls = __toESM(require("tls"));
var import_lodash = __toESM(require("lodash"));
var import_rorLoggerFactory = require("../core/logging/rorLoggerFactory");
var _a;
const ALL_TLS_VERSIONS = ["TLSv1.1", "TLSv1.2", "TLSv1.3"];
function detectRuntimeMaxTlsVersion() {
  const v = import_tls.default.DEFAULT_MAX_VERSION;
  if (v === "TLSv1.3" || v === "TLSv1.2" || v === "TLSv1.1") return v;
  return "TLSv1.2";
}
const RUNTIME_MAX_TLS_VERSION = detectRuntimeMaxTlsVersion();
const VERSION_ORDER = ALL_TLS_VERSIONS.slice(0, ALL_TLS_VERSIONS.indexOf(RUNTIME_MAX_TLS_VERSION) + 1);
const { SSL_OP_NO_TLSv1_1, SSL_OP_NO_TLSv1_2 } = import_crypto.constants;
const SSL_OP_NO_TLSv1_3 = (_a = import_crypto.constants.SSL_OP_NO_TLSv1_3) != null ? _a : 0;
const BASE_DISABLED_BITMASK = import_crypto.constants.SSL_OP_NO_TLSv1;
class ServerCreator {
  constructor(sslSettings) {
    this.sslSettings = sslSettings;
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    // TLSv1.0 and below are always disallowed; specific versions within TLSv1.x are controlled per-request
    __publicField(this, "secureOptionsBitmask", BASE_DISABLED_BITMASK);
    if (sslSettings) {
      this.initializeSupportedProtocols(sslSettings);
    }
  }
  createServer(app, bindAddress) {
    app.disable("x-powered-by");
    if (!this.sslSettings) {
      return app.listen(bindAddress.port, bindAddress.host).on("error", (err) => {
        this.logger.error({ message: `listen error: ${err.message}`, stack: err.stack });
      });
    }
    app.set("trust proxy", "127.0.0.1");
    return this.createHttpsServer(app, bindAddress.host, bindAddress.port);
  }
  initializeSupportedProtocols(sslConfig) {
    if (!sslConfig.supportedProtocols) {
      this.logger.info(
        `ROR PKP SSL server will accept protocols: ${[...VERSION_ORDER]} (bitmask: ${this.secureOptionsBitmask})`
      );
      return;
    }
    if (sslConfig.supportedProtocols.length === 0) {
      throw new Error("server.ssl.secureProtocols should be a non empty array or undefined");
    }
    const invalidValues = sslConfig.supportedProtocols.filter((x) => !VERSION_ORDER.includes(x));
    if (invalidValues.length > 0) {
      throw new Error(
        `Unrecognised supportedProtocol values: ${invalidValues}, available values are: ${[...VERSION_ORDER]}`
      );
    }
    if (!sslConfig.supportedProtocols.includes("TLSv1.1")) {
      this.logger.debug("Disallow TLSv1.1");
      this.secureOptionsBitmask |= SSL_OP_NO_TLSv1_1;
    }
    if (!sslConfig.supportedProtocols.includes("TLSv1.2")) {
      this.logger.debug("Disallow TLSv1.2");
      this.secureOptionsBitmask |= SSL_OP_NO_TLSv1_2;
    }
    if (!sslConfig.supportedProtocols.includes("TLSv1.3")) {
      this.logger.debug("Disallow TLSv1.3");
      this.secureOptionsBitmask |= SSL_OP_NO_TLSv1_3;
    }
    this.logger.info(
      `ROR PKP SSL server will accept protocols: ${sslConfig.supportedProtocols} (bitmask: ${this.secureOptionsBitmask})`
    );
  }
  createHttpsServer(app, host, port) {
    var _a2, _b;
    if (!this.sslSettings) {
      throw new Error("missing ssl settings");
    }
    const options = {
      secureOptions: this.secureOptionsBitmask,
      ciphers: (_a2 = this.sslSettings.cipherSuites) == null ? void 0 : _a2.join(":"),
      honorCipherOrder: true
    };
    const keystoreOrCertOptions = ((_b = this.sslSettings) == null ? void 0 : _b.keystorePath) ? {
      pfx: import_fs.default.readFileSync(this.sslSettings.keystorePath),
      passphrase: this.sslSettings.keystorePassword
    } : {
      key: import_fs.default.readFileSync(this.sslSettings.keyPath),
      passphrase: this.sslSettings.keyPassphrase,
      cert: import_fs.default.readFileSync(this.sslSettings.certificatePath)
    };
    Object.assign(options, keystoreOrCertOptions);
    if (Array.isArray(this.sslSettings.cipherSuites) && this.sslSettings.cipherSuites.length > 0) {
      options.ciphers = this.sslSettings.cipherSuites.join(":");
    }
    const ca = this.sslSettings.certificateAuthorities;
    if (!import_lodash.default.isEmpty(ca)) {
      options.ca = ca;
    }
    let server;
    try {
      this.logger.debug(`Creating TLS server on https://${host}:${port} with options:`, options);
      server = import_https.default.createServer(options, app).listen(port, host);
      server.on("tlsClientError", (err) => {
        this.logger.warn(`TLS handshake rejected: ${err.message}`);
      });
    } catch (error) {
      if (error.message.includes("mac verify failure")) {
        this.logger.error({
          message: "The keystore password provided in kibana.yml does not match the password the PKCS#12 file is encrypted with. Please provide a valid password",
          stack: error.stack
        });
        process.exit(1);
      } else {
        this.logger.error({ message: `Error creating https server: ${error.message}`, stack: error.stack });
        process.exit(1);
      }
    }
    return server;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ServerCreator
});
