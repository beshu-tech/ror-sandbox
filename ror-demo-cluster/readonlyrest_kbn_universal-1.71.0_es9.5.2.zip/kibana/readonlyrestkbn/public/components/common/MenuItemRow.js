"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var MenuItemRow_exports = {};
__export(MenuItemRow_exports, {
  MenuItemRow: () => MenuItemRow
});
module.exports = __toCommonJS(MenuItemRow_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_linkButton = __toESM(require("./linkButton"));
var import_text = require("./text");
function MenuItemRow({ item, index, isSelected, isFocused, renderItem, onItemClick }) {
  if (item.isHeader) {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      import_text.Text,
      {
        style: {
          fontSize: "11px",
          fontWeight: 600,
          textTransform: "uppercase",
          color: "inherit",
          opacity: 0.6,
          padding: "4px 8px",
          marginTop: index > 0 ? "8px" : "0"
        },
        children: item.title
      },
      index
    );
  }
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { "data-menu-index": index, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_linkButton.default,
    {
      style: { color: "inherit" },
      isSelected,
      isFocused,
      contentJustify: renderItem ? "flex-start" : "flex-end",
      onClick: (event) => onItemClick(item, event),
      children: renderItem ? renderItem(item, isSelected) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_text.Text,
        {
          style: {
            whiteSpace: "normal",
            wordBreak: "break-word",
            textAlign: "right"
          },
          children: item.title
        }
      )
    }
  ) }, index);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  MenuItemRow
});
