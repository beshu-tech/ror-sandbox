"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var flexItem_exports = {};
__export(flexItem_exports, {
  FlexItem: () => FlexItem
});
module.exports = __toCommonJS(flexItem_exports);
var import_jsx_runtime = (
  // @ts-ignore
  require("react/jsx-runtime")
);
var import_eui = require("@elastic/eui");
function FlexItem({ className, style, children, grow }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiFlexItem, { className, style, grow, children });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  FlexItem
});
