"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var menuButton_exports = {};
__export(menuButton_exports, {
  default: () => menuButton_default
});
module.exports = __toCommonJS(menuButton_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_arrowLeftIcon = require("../icons/arrowLeftIcon");
var import_button = require("./button");
function MenuButton({ handleClick, text, className }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
    import_button.Button,
    {
      onClick: handleClick,
      className: `ror_menu_button ${className}`,
      fullWidth: true,
      textProps: { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } },
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_arrowLeftIcon.ArrowLeftIcon, { fill: "#006BB4" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { flex: 1, marginRight: "24px" }, children: text })
      ]
    }
  );
}
var menuButton_default = MenuButton;
