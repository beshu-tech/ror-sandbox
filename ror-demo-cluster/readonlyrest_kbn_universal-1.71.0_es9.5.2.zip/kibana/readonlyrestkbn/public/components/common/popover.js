"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var popover_exports = {};
__export(popover_exports, {
  Popover: () => Popover
});
module.exports = __toCommonJS(popover_exports);
var import_jsx_runtime = (
  // @ts-ignore
  require("react/jsx-runtime")
);
var import_eui = require("@elastic/eui");
var import_themeProvider = require("../../providers/themeProvider");
var import_styleConstants = require("../../utils/styleConstants");
function Popover({
  children,
  style,
  id,
  isOpen,
  anchorPosition,
  closePopover,
  panelPaddingSize,
  hasArrow,
  button,
  repositionOnScroll = true,
  ownFocus = false,
  ...props
}) {
  const emptyCloseAction = () => "noop";
  const { theme } = (0, import_themeProvider.useTheme)();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_eui.EuiPopover,
    {
      panelStyle: {
        ...import_styleConstants.ROR_BASE_TYPOGRAPHY,
        backgroundColor: theme.colors.bgPaper,
        color: theme.colors.textPrimary
      },
      button,
      style,
      id,
      isOpen,
      anchorPosition,
      closePopover: closePopover || emptyCloseAction,
      panelPaddingSize,
      repositionOnScroll,
      hasArrow,
      ownFocus,
      ...props,
      children
    }
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Popover
});
