"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var search_exports = {};
__export(search_exports, {
  default: () => search_default
});
module.exports = __toCommonJS(search_exports);
var import_jsx_runtime = (
  // @ts-ignore
  require("react/jsx-runtime")
);
var import_eui = require("@elastic/eui");
var import_themeProvider = require("../../providers/themeProvider");
function Search({ placeholder, value, isClearable, onChange, style, autoFocus }) {
  const { theme } = (0, import_themeProvider.useTheme)();
  const themedStyle = {
    backgroundColor: theme.colors.codeBackground,
    color: theme.colors.textPrimary,
    borderColor: theme.colors.border,
    ...style
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_eui.EuiFieldSearch,
    {
      ref: (ref) => {
        if ((ref == null ? void 0 : ref.inputElement) && autoFocus) {
          setTimeout(() => {
            var _a;
            (_a = ref.inputElement) == null ? void 0 : _a.focus();
          }, 100);
        }
      },
      placeholder,
      value,
      isClearable,
      onChange,
      style: themedStyle
    }
  );
}
var search_default = Search;
