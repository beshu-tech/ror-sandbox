"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var external_alerting_and_reporting_link_exports = {};
__export(external_alerting_and_reporting_link_exports, {
  ExternalAlertingAndReportingLink: () => ExternalAlertingAndReportingLink
});
module.exports = __toCommonJS(external_alerting_and_reporting_link_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_button = require("../common/button");
var import_flexGroup = require("../common/flexGroup");
var import_text = require("../common/text");
function ExternalAlertingAndReportingLink() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
    import_flexGroup.FlexGroup,
    {
      id: "external-alerting-and-reporting-link",
      style: { alignItems: "center", justifyContent: "center", flexDirection: "column" },
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_text.Text, { style: { marginBottom: "16px" }, children: "Kibana alerting does not work with ReadonlyREST, but we are working on an even better alerting and reporting solution." }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_button.Button, { href: "https://anaphora.it", target: "_blank", children: "Register your interest" })
      ]
    }
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ExternalAlertingAndReportingLink
});
