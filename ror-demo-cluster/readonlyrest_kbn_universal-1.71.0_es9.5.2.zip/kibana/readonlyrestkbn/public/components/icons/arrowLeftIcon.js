"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var arrowLeftIcon_exports = {};
__export(arrowLeftIcon_exports, {
  ArrowLeftIcon: () => ArrowLeftIcon
});
module.exports = __toCommonJS(arrowLeftIcon_exports);
var import_jsx_runtime = require("react/jsx-runtime");
function ArrowLeftIcon({ title = "", titleId = "", fill, ...props }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      height: "24px",
      viewBox: "0 0 24 24",
      width: "24px",
      fill,
      "aria-labelledby": titleId,
      ...props,
      children: [
        title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { id: titleId, children: title }) : null,
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M14 7l-5 5 5 5V7z" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M24 0v24H0V0h24z", fill: "none" })
      ]
    }
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ArrowLeftIcon
});
