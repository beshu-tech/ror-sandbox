"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var mountPageNotFound_exports = {};
__export(mountPageNotFound_exports, {
  MountPageNotFound: () => MountPageNotFound
});
module.exports = __toCommonJS(mountPageNotFound_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_react_dom = __toESM(require("react-dom"));
var import_queryStringKeys = require("../../../shared/constants/queryStringKeys");
var import_themeProvider = require("../../providers/themeProvider");
var import_pageNotFound = require("./pageNotFound");
class MountPageNotFound {
  constructor(kibanaVersion) {
    this.kibanaVersion = kibanaVersion;
  }
  registerPageNotFoundPage(core) {
    core.application.register({
      id: "page-not-found",
      category: {
        id: "ReadonlyREST-category",
        label: "ReadonlyREST"
      },
      visibleIn: [],
      // not searchable, navigable for Kibana 8.x and above
      searchable: false,
      // not searchable for Kibana 7.x
      navLinkStatus: 3,
      // hidden navigation item for Kibana 7.x
      mount: (params) => this.mountPageNotFoundPage(params.element)
    });
  }
  mountPageNotFoundPage(target) {
    import_react_dom.default.render(
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_themeProvider.ThemeProvider, { kibanaVersion: this.kibanaVersion, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_pageNotFound.PageNotFound, { notFoundUrl: this.getNotFoundUrl() }) }),
      target
    );
    return () => import_react_dom.default.unmountComponentAtNode(target);
  }
  getNotFoundUrl() {
    var _a;
    const url = new URL(window.location.href);
    const notFoundUrl = (_a = url.searchParams.get(import_queryStringKeys.NOT_FOUND_QUERY_STRING_KEY)) != null ? _a : "";
    this.clearNotFoundUrlFromBrowserUrl(url);
    return notFoundUrl;
  }
  clearNotFoundUrlFromBrowserUrl(url) {
    url.searchParams.delete(import_queryStringKeys.NOT_FOUND_QUERY_STRING_KEY);
    window.history.replaceState({}, "", url.toString());
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  MountPageNotFound
});
