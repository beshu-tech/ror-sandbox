"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ImpersonationSection_exports = {};
__export(ImpersonationSection_exports, {
  ImpersonationSection: () => ImpersonationSection
});
module.exports = __toCommonJS(ImpersonationSection_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_eui = require("@elastic/eui");
var import_themeProvider = require("../../providers/themeProvider");
var import_styleConstants = require("../../utils/styleConstants");
const userRowStyle = {
  ...import_styleConstants.USER_SECTION_STYLES.userRow,
  gap: "12px"
};
const userInfoStyle = {
  display: "flex",
  flexDirection: "column",
  // Keep the whole row centered, but left-align text inside this column
  // so it stays visually close to the avatar (esp. when wrapping).
  alignItems: "flex-start",
  justifyContent: "center",
  gap: "4px",
  minWidth: 0
};
const exitButtonStyle = {
  ...import_styleConstants.ACTION_BUTTON_STYLE_BASE,
  color: "#b45309",
  border: "1px solid #b45309"
};
const expiryContainerStyle = {
  display: "flex",
  justifyContent: "center"
};
function ImpersonationSection({
  impersonatedUser,
  kibanaAccess,
  onFinishImpersonation,
  expiryInfo
}) {
  const { theme } = (0, import_themeProvider.useTheme)();
  const accessConfig = kibanaAccess ? import_styleConstants.ACCESS_LEVEL_CONFIG[kibanaAccess] : null;
  const displayName = impersonatedUser != null ? impersonatedUser : "Unknown";
  const avatarStyle = {
    ...import_styleConstants.AVATAR_STYLE_BASE,
    backgroundColor: theme.colors.codeBackground
  };
  const usernameStyle = {
    ...import_styleConstants.USER_SECTION_STYLES.username,
    color: theme.colors.textPrimary
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: import_styleConstants.USER_SECTION_STYLES.container, "data-testid": "impersonation-section", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: userRowStyle, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: avatarStyle, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiIcon, { type: "reporter", size: "m", color: theme.colors.textPrimary }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: userInfoStyle, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: usernameStyle, title: displayName, "data-testid": "identity-impersonating", children: displayName }),
        accessConfig && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: (0, import_styleConstants.accessBadgeStyle)(import_styleConstants.ACCESS_BADGE_COLORS.text, import_styleConstants.ACCESS_BADGE_COLORS.background), children: accessConfig.label })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
      "button",
      {
        type: "button",
        style: exitButtonStyle,
        onClick: onFinishImpersonation,
        onMouseEnter: (e) => {
          e.currentTarget.style.backgroundColor = import_styleConstants.ACTION_BUTTON_HOVER_COLORS.warning;
        },
        onMouseLeave: (e) => {
          e.currentTarget.style.backgroundColor = "transparent";
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiIcon, { type: "arrowLeft", size: "s" }),
          "Finish impersonation"
        ]
      }
    ),
    expiryInfo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: expiryContainerStyle, children: expiryInfo })
  ] });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ImpersonationSection
});
