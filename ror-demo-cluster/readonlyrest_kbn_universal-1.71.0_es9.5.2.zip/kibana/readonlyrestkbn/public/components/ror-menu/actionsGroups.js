"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var actionsGroups_exports = {};
__export(actionsGroups_exports, {
  default: () => actionsGroups_default
});
module.exports = __toCommonJS(actionsGroups_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_rorReservedHiddenAppsValues = require("../../../shared/constants/rorReservedHiddenAppsValues");
var import_hiddenAppsChecker = require("../../../shared/utils/hiddenAppsChecker");
var import_button = require("../common/button");
var import_spacer = require("../common/spacer");
var import_kibana_management = __toESM(require("../kibana-management"));
var import_group = __toESM(require("./group"));
function ActionsGroups({
  identity,
  closeRorMenu,
  isAccessUnrestricted,
  handleSettingsPageClick,
  kibanaVersion
}) {
  const showKibanaManagementButton = () => {
    var _a, _b;
    if ((_a = identity.kibanaHiddenApps) == null ? void 0 : _a.includes(import_rorReservedHiddenAppsValues.RorReservedHiddenAppsValue.ROR_MANAGE_KIBANA)) {
      return false;
    }
    return (_b = identity.kibanaHiddenApps) == null ? void 0 : _b.some(
      (hiddenApp) => (0, import_hiddenAppsChecker.hiddenAppsChecker)(hiddenApp, "Management|Stack Management", console) || (0, import_hiddenAppsChecker.hiddenAppsChecker)(hiddenApp, "Management|Management", console)
    );
  };
  const showSettingsButton = () => {
    var _a, _b;
    if (((_a = identity.kibanaHiddenApps) == null ? void 0 : _a.includes(import_rorReservedHiddenAppsValues.RorReservedHiddenAppsValue.READONLYREST_KBN)) || ((_b = identity.kibanaHiddenApps) == null ? void 0 : _b.includes(import_rorReservedHiddenAppsValues.RorReservedHiddenAppsValue.ROR_SECURITY_SETTINGS))) {
      return false;
    }
    return identity.kibanaAccess === void 0 || isAccessUnrestricted;
  };
  const showActionsGroup = showSettingsButton() || showKibanaManagementButton();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: showActionsGroup && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_group.default, { label: "Actions", children: [
      showSettingsButton() && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_button.Button, { onClick: () => handleSettingsPageClick("settings"), fullWidth: true, children: "Edit security settings" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_spacer.Spacer, { size: "m" }),
        showKibanaManagementButton() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_spacer.Spacer, { size: "m" })
      ] }),
      showKibanaManagementButton() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_kibana_management.default, { kibanaVersion, closeMainMenu: closeRorMenu })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_spacer.Spacer, {})
  ] }) });
}
var actionsGroups_default = ActionsGroups;
