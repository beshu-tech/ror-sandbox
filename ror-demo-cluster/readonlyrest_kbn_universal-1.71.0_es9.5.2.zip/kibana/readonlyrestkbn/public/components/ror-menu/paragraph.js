"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var paragraph_exports = {};
__export(paragraph_exports, {
  default: () => paragraph_default
});
module.exports = __toCommonJS(paragraph_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_styleConstants = require("../../utils/styleConstants");
var import_Marquee = __toESM(require("../common/Marquee"));
var import_text = require("../common/text");
const CHARS_PER_100PX = 12;
function Paragraph({ label, value, style, marquee, maxValueWidth = 200, ...props }) {
  const valueStr = typeof value === "string" ? value : "";
  const maxChars = Math.floor(maxValueWidth / 100 * CHARS_PER_100PX);
  const isOverflowing = marquee && valueStr.length > maxChars;
  const valueContainerStyle = {
    fontWeight: 600,
    display: "inline-block",
    maxWidth: `${maxValueWidth}px`,
    overflow: "hidden",
    verticalAlign: "bottom"
  };
  const renderValue = () => {
    if (!marquee) {
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { fontWeight: 600 }, children: value });
    }
    if (isOverflowing) {
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: valueContainerStyle, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_Marquee.default, { speed: import_styleConstants.MARQUEE_CONFIG.speed, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { paddingRight: import_styleConstants.MARQUEE_CONFIG.itemPadding }, children: value }) }) });
    }
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { ...import_styleConstants.ELLIPSIS_TEXT_STYLE, ...valueContainerStyle }, children: value });
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_text.Text, { size: "s", style, children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { ...props, style: { paddingBottom: "8px" }, children: [
    label,
    " ",
    renderValue()
  ] }) });
}
var paragraph_default = Paragraph;
