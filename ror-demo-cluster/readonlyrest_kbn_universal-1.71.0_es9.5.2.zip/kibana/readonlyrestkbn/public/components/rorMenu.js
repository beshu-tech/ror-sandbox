"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var rorMenu_exports = {};
__export(rorMenu_exports, {
  RorMenu: () => RorMenu
});
module.exports = __toCommonJS(rorMenu_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_eui = require("@elastic/eui");
var import_js_cookie = __toESM(require("js-cookie"));
var React = __toESM(require("react"));
var import_queryStringKeys = require("../../shared/constants/queryStringKeys");
var import_rorReservedHiddenAppsValues = require("../../shared/constants/rorReservedHiddenAppsValues");
var import_themeProvider = require("../providers/themeProvider");
var import_coreFunctions = __toESM(require("../utils/coreFunctions"));
var import_rorFetch = require("../utils/rorFetch");
var import_styleConstants = require("../utils/styleConstants");
var import_flexGroup = require("./common/flexGroup");
var import_flexItem = require("./common/flexItem");
var import_popoverTitle = __toESM(require("./common/popoverTitle"));
var import_spacer = require("./common/spacer");
var import_actionsGroups = __toESM(require("./ror-menu/actionsGroups"));
var import_expiryDate = __toESM(require("./ror-menu/expiry/expiryDate"));
var import_group = __toESM(require("./ror-menu/group"));
var import_IdentitySection = require("./ror-menu/IdentitySection");
var import_ImpersonationSection = require("./ror-menu/ImpersonationSection");
var import_licenseBadge = require("./ror-menu/licenseBadge");
var import_paragraph = __toESM(require("./ror-menu/paragraph"));
var import_rorPopover = require("./rorPopover");
var import_tenancy_select = __toESM(require("./tenancy-select"));
var import_TenantBadge = require("./TenantBadge");
const rorMenuScopedStyles = `
.ror-menu-root, .ror-menu-root * {
    box-sizing: border-box;
}

.ror-menu-trigger:focus-visible {
    outline: 2px solid var(--ror-border, #d3dae6);
    outline-offset: 2px;
}
`;
const _RorMenu = class _RorMenu extends React.Component {
  constructor(props) {
    super(props);
    __publicField(this, "isAccessUnrestricted", (identity) => {
      const { kibanaAccess } = identity;
      return kibanaAccess === "unrestricted" || kibanaAccess === "admin";
    });
    __publicField(this, "toggleRorMenu", () => {
      const { showRorMenu } = this.state;
      this.setState({
        showRorMenu: !showRorMenu
      });
    });
    __publicField(this, "closeRorMenu", () => {
      this.setState({
        showRorMenu: false
      });
    });
    __publicField(this, "onMouseEnter", () => {
      this.setState({ isHovered: true });
    });
    __publicField(this, "onMouseLeave", () => {
      this.setState({ isHovered: false });
    });
    __publicField(this, "onLogoutClick", (message) => {
      const { logoutRedirect } = this.props;
      const logoutUrl = new URL(window.location.origin + logoutRedirect);
      const rorUserSettingsCookie = import_js_cookie.default.get("rorUserSettings");
      let userSettings = {};
      if (rorUserSettingsCookie) {
        try {
          userSettings = JSON.parse(decodeURIComponent(rorUserSettingsCookie));
        } catch {
          userSettings = {};
        }
      }
      const rawNextUrlValue = window.location.pathname + window.location.search + window.location.hash;
      const nextUrlValue = userSettings["ror:rememberGroupAfterLogout"] === "true" ? rawNextUrlValue : this.removeTenancyFromNextUrl(rawNextUrlValue);
      window.sessionStorage.setItem(import_queryStringKeys.NEXT_URL, nextUrlValue);
      if (message) {
        logoutUrl.searchParams.set("message", message);
      }
      window.location.href = logoutUrl.href;
    });
    __publicField(this, "onFinishImpersonation", async () => {
      const { pkpBasePath } = this.props;
      try {
        const response = await (0, import_rorFetch.rorFetch)(`${pkpBasePath}/api/finish-impersonation`, {
          method: "POST"
        });
        const jsonResponse = await response.json();
        if (response.status !== 200) {
          throw new Error(jsonResponse.message);
        }
        sessionStorage.setItem("rorImpersonationFinished", "true");
        _RorMenu.refreshPage(jsonResponse.redirectUrl);
      } catch (e) {
        console.log("Error fetching finish impersonation ", e);
      }
    });
    __publicField(this, "onGoToSettingsPageClick", (initialTab = "settings") => {
      const { pkpBasePath } = this.props;
      const iframe = document.createElement("iframe");
      const tenancyId = new URLSearchParams(window.location.search).get(import_queryStringKeys.TENANCY_QUERY_STRING_KEY);
      const tenancyParam = tenancyId ? `&${import_queryStringKeys.TENANCY_QUERY_STRING_KEY}=${encodeURIComponent(tenancyId)}` : "";
      iframe.src = `${pkpBasePath}/web?basePath=${import_coreFunctions.default.serverBasePath}/&initialTab=${initialTab}&mode=${this.showSecuritySettings() ? "securitySettings" : "userSettings"}${tenancyParam}`;
      iframe.frameBorder = "0";
      iframe.id = "readonlyrestIframe";
      iframe.title = "readonlyrestIframe";
      iframe.style.position = "relative";
      iframe.style.zIndex = String(import_styleConstants.Z_INDEX.iframe);
      iframe.style.height = "100%";
      iframe.style.width = "100%";
      iframe.style.top = "0";
      iframe.style.backgroundColor = "white";
      iframe.style.border = "none";
      this.setState({
        settingsWindow: {
          iframe,
          previousOverflow: document.body.style.overflow
        }
      });
      document.body.prepend(iframe);
      document.body.style.overflow = "hidden";
      this.setState({
        showRorMenu: false
      });
    });
    __publicField(this, "onMessageFromIframe", (event) => {
      var _a;
      const { settingsWindow } = this.state;
      if (event.origin !== window.location.origin) return;
      const { data } = event;
      if (typeof data !== "object" || data === null) return;
      switch (data.type) {
        case "IFRAME_CLOSE": {
          this.onHideSettings();
          break;
        }
        case "IFRAME_REMOVE": {
          if (settingsWindow) {
            document.body.removeChild(settingsWindow.iframe);
            document.body.style.overflow = settingsWindow.previousOverflow;
            this.setState({ settingsWindow: void 0 });
          }
          break;
        }
        case "IFRAME_REFRESH_PAGE": {
          _RorMenu.refreshPage(data.redirectUrl);
          break;
        }
        case "APP_INIT_FINISHED": {
          const { theme, cssVariables } = this.context;
          const iframeElement = document.getElementById(
            "readonlyrestIframe"
          );
          (_a = iframeElement == null ? void 0 : iframeElement.contentWindow) == null ? void 0 : _a.postMessage({ type: "THEME", payload: { theme, cssVariables } }, "*");
          break;
        }
        default: {
          break;
        }
      }
    });
    __publicField(this, "onHideSettings", () => {
      var _a;
      const { settingsWindow } = this.state;
      if (settingsWindow) {
        const iframeElement = document.getElementById("readonlyrestIframe");
        (_a = iframeElement.contentWindow) == null ? void 0 : _a.postMessage({ settingsIframe: "CLOSE_EVENT_DISPATCHED" }, "*");
      }
    });
    __publicField(this, "getBadgeLabel", () => {
      var _a, _b;
      const { info } = this.props;
      const accessLevel = info.identity.kibanaAccess;
      return accessLevel ? (_b = (_a = import_styleConstants.ACCESS_LEVEL_CONFIG[accessLevel]) == null ? void 0 : _a.shortLabel) != null ? _b : "" : "";
    });
    __publicField(this, "onTenancyHop", (tenancyId) => {
      var _a, _b, _c;
      const { clearSessionOnEvents } = this.props;
      if (clearSessionOnEvents == null ? void 0 : clearSessionOnEvents.includes("tenancyHop")) {
        const recentTenants = (_a = window.localStorage) == null ? void 0 : _a.getItem("ror_recent_tenants");
        (_b = window.localStorage) == null ? void 0 : _b.clear();
        window.localStorage.setItem(
          `insecureClusterWarningVisibility${import_coreFunctions.default.serverBasePath}`,
          '{ "show": false}'
        );
        if (recentTenants) {
          window.localStorage.setItem("ror_recent_tenants", recentTenants);
        }
        (_c = window.sessionStorage) == null ? void 0 : _c.clear();
      }
      const redirectToUrl = new URL(decodeURIComponent(window.location.href));
      const finalUrl = `/switch-group?group=${encodeURIComponent(tenancyId)}&redirectTo=${encodeURIComponent(
        redirectToUrl.toString()
      )}`;
      window.location.href = import_coreFunctions.default.serverBasePathPrepend(finalUrl);
    });
    __publicField(this, "showSecuritySettings", () => {
      var _a, _b;
      const { info } = this.props;
      const identity = info.identity;
      return !(((_a = identity.kibanaHiddenApps) == null ? void 0 : _a.includes(import_rorReservedHiddenAppsValues.RorReservedHiddenAppsValue.READONLYREST_KBN)) || ((_b = identity.kibanaHiddenApps) == null ? void 0 : _b.includes(import_rorReservedHiddenAppsValues.RorReservedHiddenAppsValue.ROR_SECURITY_SETTINGS)));
    });
    this.state = {
      showRorMenu: false,
      isHovered: false
    };
  }
  componentDidMount() {
    var _a;
    this.handleTlExpiry();
    (_a = document.getElementById("kibana-body")) == null ? void 0 : _a.addEventListener("click", this.onHideSettings);
    window.addEventListener("popstate", this.onHideSettings);
    window.addEventListener("message", this.onMessageFromIframe, false);
    this.handleInitRedirect();
  }
  componentWillUnmount() {
    const kibanaBody = document.getElementById("kibana-body");
    if (kibanaBody) {
      kibanaBody.removeEventListener("click", this.onHideSettings);
    }
    window.removeEventListener("popstate", this.onHideSettings);
    window.removeEventListener("message", this.onMessageFromIframe, false);
  }
  handleInitRedirect() {
    if (sessionStorage.getItem("rorImpersonationFinished")) {
      this.onGoToSettingsPageClick("impersonate");
      sessionStorage.removeItem("rorImpersonationFinished");
    }
  }
  static refreshPage(url) {
    window.location.href = import_coreFunctions.default.serverBasePathPrepend(url);
  }
  handleTlExpiry() {
    const { info } = this.props;
    const validTo = localStorage.getItem("rorTtlValidTo");
    if (validTo && info.identity.impersonatedBy) {
      const expirationTime = new Date(validTo).getTime() - Date.now();
      const timeout = setTimeout(async () => {
        await this.onFinishImpersonation();
        clearTimeout(timeout);
      }, expirationTime);
    }
  }
  getVersionString() {
    var _a, _b;
    const { info } = this.props;
    const versionString = `${(_a = info.distribution) == null ? void 0 : _a.rorVersion}_es${(_b = info.distribution) == null ? void 0 : _b.kibanaVersion}`;
    return `${versionString} \u{1F984}`;
  }
  removeTenancyFromNextUrl(nextUrl) {
    const nextUrlURL = new URL(nextUrl, "http://example.com");
    nextUrlURL.searchParams.delete(import_queryStringKeys.TENANCY_QUERY_STRING_KEY);
    return nextUrlURL.pathname + nextUrlURL.search + nextUrlURL.hash;
  }
  render() {
    var _a, _b, _c, _d;
    const { info, pkpBasePath } = this.props;
    const { showRorMenu, isHovered } = this.state;
    const { theme } = this.context;
    const { identity, distribution } = info;
    const validTo = localStorage.getItem("rorTtlValidTo");
    const tenantName = (_a = identity.currentGroup) == null ? void 0 : _a.name;
    const hasTenant = !!tenantName;
    const badgeLabel = this.getBadgeLabel();
    const accessBadge = badgeLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiNotificationBadge, { style: { flexShrink: 0, textTransform: "uppercase" }, title: identity.kibanaAccess, children: badgeLabel }) : void 0;
    const rootStyle = {
      ...import_styleConstants.ROR_BASE_TYPOGRAPHY,
      display: "inline-flex",
      alignItems: "center",
      color: theme.colors.textPrimary
    };
    const triggerBaseStyle = {
      all: "unset",
      boxSizing: "border-box",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      minWidth: "48px",
      height: "48px",
      overflow: "visible",
      cursor: "pointer",
      borderRadius: "4px",
      padding: "0",
      backgroundColor: "transparent",
      color: theme.colors.textPrimary,
      fontFamily: "inherit",
      fontSize: "12px",
      lineHeight: "1",
      userSelect: "none"
    };
    const isExpanded = isHovered || showRorMenu;
    const triggerStyle = {
      ...triggerBaseStyle,
      ...isExpanded ? { backgroundColor: theme.colors.hover } : {}
    };
    const button = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "button",
      {
        type: "button",
        onClick: this.toggleRorMenu,
        onMouseEnter: this.onMouseEnter,
        onMouseLeave: this.onMouseLeave,
        "aria-label": hasTenant ? `Current tenant: ${tenantName}. Click to open ReadonlyREST menu.` : "Click to open ReadonlyREST menu.",
        className: "ror-menu-trigger",
        style: triggerStyle,
        children: hasTenant ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_TenantBadge.TenantBadge, { tenantName, isHovered: isExpanded, accessBadge }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "img",
          {
            alt: "ReadonlyREST",
            height: "24",
            src: `${pkpBasePath}/legacy/web/assets/rorSVG.svg`,
            style: { display: "block" }
          }
        )
      }
    );
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ror-menu-root", style: rootStyle, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: rorMenuScopedStyles }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
        import_rorPopover.RorPopover,
        {
          id: "rorMenuPopover",
          panelId: "rorMenuPanel",
          button,
          isOpen: showRorMenu,
          closePopover: this.closeRorMenu,
          anchorPosition: "downCenter",
          panelPaddingSize: "m",
          badgeLabel: isExpanded && hasTenant ? void 0 : badgeLabel,
          badgeTitle: isExpanded && hasTenant ? void 0 : identity.kibanaAccess,
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_popoverTitle.default, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_flexGroup.FlexGroup, { responsive: false, style: { alignItems: "center", justifyContent: "space-between" }, children: [
                /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
                  import_flexItem.FlexItem,
                  {
                    grow: false,
                    style: {
                      whiteSpace: "nowrap",
                      flexDirection: "row",
                      display: "flex",
                      alignItems: "center",
                      gap: "8px"
                    },
                    children: [
                      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                        "img",
                        {
                          alt: "",
                          height: "18",
                          src: `${pkpBasePath}/legacy/web/assets/rorSVG.svg`,
                          style: { flexShrink: 0 },
                          "aria-hidden": "true"
                        }
                      ),
                      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ReadonlyREST" }),
                      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                        import_licenseBadge.LicenseBadge,
                        {
                          info,
                          showSecuritySettings: this.showSecuritySettings,
                          openActivationKeyTab: () => this.onGoToSettingsPageClick("activation_keys")
                        }
                      )
                    ]
                  }
                ),
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_flexItem.FlexItem, { grow: false, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { display: "flex", alignItems: "center" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_eui.EuiToolTip, { content: "User settings", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                  import_eui.EuiIcon,
                  {
                    "data-testid": "user-settings-icon",
                    color: "inherit",
                    cursor: "pointer",
                    type: "advancedSettingsApp",
                    size: "m",
                    onClick: () => this.onGoToSettingsPageClick("user_Settings")
                  }
                ) }) }) })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_flexGroup.FlexGroup, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                import_flexItem.FlexItem,
                {
                  className: "chrHeaderHelpMenu__version",
                  style: {
                    fontWeight: 200,
                    fontSize: "85%",
                    whiteSpace: "nowrap",
                    marginBottom: "6px",
                    marginTop: "12px"
                  },
                  children: this.getVersionString()
                }
              ) })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              import_actionsGroups.default,
              {
                identity,
                closeRorMenu: this.closeRorMenu,
                isAccessUnrestricted: this.isAccessUnrestricted(identity),
                handleSettingsPageClick: (page) => this.onGoToSettingsPageClick(page),
                kibanaVersion: (distribution == null ? void 0 : distribution.kibanaVersion) || "??"
              }
            ),
            ((_b = identity.availableGroups) != null ? _b : []).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                import_tenancy_select.default,
                {
                  currentGroup: identity.currentGroup,
                  availableGroups: (_c = identity.availableGroups) != null ? _c : [],
                  handleChange: (group) => this.onTenancyHop(group.id),
                  closeMainMenu: this.closeRorMenu
                }
              ),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_spacer.Spacer, {})
            ] }),
            identity.impersonatedBy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_group.default, { label: "Impersonating", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              import_ImpersonationSection.ImpersonationSection,
              {
                impersonatedUser: identity.username,
                kibanaAccess: identity.kibanaAccess,
                onFinishImpersonation: this.onFinishImpersonation,
                expiryInfo: validTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
                  import_paragraph.default,
                  {
                    style: { margin: 0 },
                    "data-testid": "automatically-deactivate",
                    label: "Deactivated in:",
                    value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_expiryDate.default, { validTo })
                  }
                ) : void 0
              }
            ) }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_group.default, { label: "Identity", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              import_IdentitySection.IdentitySection,
              {
                username: (_d = identity.impersonatedBy) != null ? _d : identity.username,
                kibanaAccess: identity.impersonatedBy ? void 0 : identity.kibanaAccess,
                onLogout: () => this.onLogoutClick()
              }
            ) })
          ]
        }
      )
    ] });
  }
};
// eslint-disable-next-line react/static-property-placement
__publicField(_RorMenu, "contextType", (0, import_themeProvider.getThemeContext)());
let RorMenu = _RorMenu;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorMenu
});
