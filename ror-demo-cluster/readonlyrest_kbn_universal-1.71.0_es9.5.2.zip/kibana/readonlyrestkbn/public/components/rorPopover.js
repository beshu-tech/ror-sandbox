"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var rorPopover_exports = {};
__export(rorPopover_exports, {
  RorPopover: () => RorPopover
});
module.exports = __toCommonJS(rorPopover_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_eui = require("@elastic/eui");
var import_styleConstants = require("../utils/styleConstants");
var import_popover = require("./common/popover");
function RorPopover({
  id,
  panelId,
  closePopover,
  panelPaddingSize,
  badgeLabel,
  badgeTitle,
  anchorPosition,
  button,
  repositionOnScroll,
  isOpen,
  children
}) {
  let optionalBadge;
  if (badgeLabel) {
    optionalBadge = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      import_eui.EuiNotificationBadge,
      {
        style: {
          fontSize: "0.65rem",
          lineHeight: "1rem !important",
          padding: "0 !important",
          borderRadius: "3px",
          fontFamily: import_styleConstants.ROR_FONT_FAMILY,
          textTransform: "uppercase"
        },
        className: "ror-access-badge",
        title: badgeTitle,
        children: badgeLabel
      }
    );
  }
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_popover.Popover,
    {
      closePopover,
      anchorPosition,
      isOpen,
      id,
      panelPaddingSize,
      repositionOnScroll,
      hasArrow: true,
      button: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { position: "relative", display: "inline-block" }, children: [
        optionalBadge,
        button
      ] }),
      panelProps: { id: panelId },
      children
    }
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RorPopover
});
