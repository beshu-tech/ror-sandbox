"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var TenantInitialBadge_exports = {};
__export(TenantInitialBadge_exports, {
  TenantInitialBadge: () => TenantInitialBadge
});
module.exports = __toCommonJS(TenantInitialBadge_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_colorUtils = require("../../utils/colorUtils");
function TenantInitialBadge({ tenantName, size = 20 }) {
  const { initial, bgColor, textColor } = (0, import_colorUtils.getTenantAvatarProps)(tenantName);
  const style = {
    width: `${size}px`,
    height: `${size}px`,
    minWidth: `${size}px`,
    minHeight: `${size}px`,
    borderRadius: import_colorUtils.BADGE_STYLE_CONSTANTS.borderRadius,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: `${Math.round(size * 0.55)}px`,
    fontWeight: import_colorUtils.BADGE_STYLE_CONSTANTS.fontWeight,
    flexShrink: 0,
    backgroundColor: bgColor,
    color: textColor
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style, "aria-hidden": "true", children: initial });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TenantInitialBadge
});
