"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tenancy_select_exports = {};
__export(tenancy_select_exports, {
  default: () => tenancy_select_default
});
module.exports = __toCommonJS(tenancy_select_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_react = require("react");
var import_hooks = require("../../hooks");
var import_recentTenants = require("../../utils/recentTenants");
var import_menu = __toESM(require("../common/menu"));
var import_TenantMenuItem = require("./TenantMenuItem");
var import_TenantSelector = require("./TenantSelector");
const TENANT_SEARCH_THRESHOLD = 5;
const RECENT_SECTION_THRESHOLD = 3;
function TenancySelect({ currentGroup, availableGroups, handleChange, closeMainMenu }) {
  var _a;
  const { isOpen, toggle, close } = (0, import_hooks.useMenuState)();
  const [searchValue, setSearchValue] = (0, import_react.useState)("");
  (0, import_react.useEffect)(() => {
    if (currentGroup == null ? void 0 : currentGroup.id) {
      (0, import_recentTenants.addRecentTenant)(currentGroup.id);
    }
  }, [currentGroup == null ? void 0 : currentGroup.id]);
  const items = (0, import_react.useMemo)(() => {
    const recentIds = (0, import_recentTenants.getRecentTenantIds)();
    const searchLower = searchValue.toLowerCase();
    const filteredGroups = availableGroups.filter((group) => group.name.toLowerCase().includes(searchLower));
    const recentGroups = recentIds.map((id) => filteredGroups.find((g) => g.id === id)).filter((g) => g !== void 0 && g.id !== (currentGroup == null ? void 0 : currentGroup.id));
    const allTenantGroups = filteredGroups;
    const result = [];
    const showRecentSection = recentGroups.length > 0 && availableGroups.length > RECENT_SECTION_THRESHOLD;
    if (showRecentSection) {
      result.push({
        id: "header-recent",
        title: "Recent",
        isHeader: true
      });
      recentGroups.forEach((group) => {
        result.push({
          id: `recent-${group.id}`,
          title: group.name,
          action: () => handleChange(group)
        });
      });
    }
    if (showRecentSection && allTenantGroups.length > 0) {
      result.push({
        id: "header-all-tenants",
        title: "All Tenants",
        isHeader: true
      });
    }
    allTenantGroups.forEach((group) => {
      result.push({
        id: `all-${group.id}`,
        title: group.name,
        action: () => handleChange(group)
      });
    });
    return result;
  }, [availableGroups, handleChange, searchValue, currentGroup]);
  const currentTenantName = (_a = currentGroup == null ? void 0 : currentGroup.name) != null ? _a : "";
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    import_menu.default,
    {
      button: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_TenantSelector.TenantSelector, { tenantName: currentTenantName, onClick: toggle }),
      isOpen,
      items,
      selectedGroup: currentGroup,
      closeMainMenu,
      handleClose: close,
      renderItem: (item, isSelected) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_TenantMenuItem.TenantMenuItem, { tenantName: item.title, isSelected }),
      search: availableGroups.length > TENANT_SEARCH_THRESHOLD ? {
        placeholder: "Search for tenancy",
        isClearable: true,
        onChange: (e) => {
          setSearchValue(e.target.value);
        },
        value: searchValue
      } : void 0
    }
  );
}
var tenancy_select_default = TenancySelect;
