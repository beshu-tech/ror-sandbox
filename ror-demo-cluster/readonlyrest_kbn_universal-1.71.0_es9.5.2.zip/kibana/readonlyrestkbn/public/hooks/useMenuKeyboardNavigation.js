"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var useMenuKeyboardNavigation_exports = {};
__export(useMenuKeyboardNavigation_exports, {
  useMenuKeyboardNavigation: () => useMenuKeyboardNavigation
});
module.exports = __toCommonJS(useMenuKeyboardNavigation_exports);
var import_react = require("react");
function useMenuKeyboardNavigation({
  items,
  onSelect,
  onClose,
  selectedIndex = -1,
  resetTrigger
}) {
  const [focusedIndex, setFocusedIndex] = (0, import_react.useState)(-1);
  const selectableIndices = (0, import_react.useMemo)(
    () => items.map((item, i) => !item.isHeader ? i : -1).filter((i) => i !== -1),
    [items]
  );
  const computeInitialFocusIndex = (0, import_react.useCallback)(() => {
    var _a;
    if (selectedIndex >= 0 && selectableIndices.includes(selectedIndex)) {
      return selectedIndex;
    }
    return (_a = selectableIndices[0]) != null ? _a : -1;
  }, [selectedIndex, selectableIndices]);
  const resetFocus = (0, import_react.useCallback)(() => {
    setFocusedIndex(computeInitialFocusIndex());
  }, [computeInitialFocusIndex]);
  const navigateToItem = (0, import_react.useCallback)(
    (direction) => {
      if (selectableIndices.length === 0) return;
      const currentPos = selectableIndices.indexOf(focusedIndex);
      let nextPos;
      if (currentPos === -1) {
        nextPos = direction === "next" ? 0 : selectableIndices.length - 1;
      } else if (direction === "next") {
        nextPos = currentPos < selectableIndices.length - 1 ? currentPos + 1 : 0;
      } else {
        nextPos = currentPos > 0 ? currentPos - 1 : selectableIndices.length - 1;
      }
      setFocusedIndex(selectableIndices[nextPos]);
    },
    [focusedIndex, selectableIndices]
  );
  const handleKeyDown = (0, import_react.useCallback)(
    (e) => {
      switch (e.key) {
        case "ArrowDown":
          e.preventDefault();
          navigateToItem("next");
          break;
        case "ArrowUp":
          e.preventDefault();
          navigateToItem("prev");
          break;
        case "Enter":
          if (focusedIndex >= 0 && focusedIndex < items.length) {
            e.preventDefault();
            onSelect(focusedIndex, items[focusedIndex]);
          }
          break;
        case "Escape":
          e.preventDefault();
          onClose();
          break;
        case "Home":
          e.preventDefault();
          if (selectableIndices.length > 0) {
            setFocusedIndex(selectableIndices[0]);
          }
          break;
        case "End":
          e.preventDefault();
          if (selectableIndices.length > 0) {
            setFocusedIndex(selectableIndices[selectableIndices.length - 1]);
          }
          break;
        default:
          break;
      }
    },
    [focusedIndex, items, navigateToItem, onSelect, onClose, selectableIndices]
  );
  (0, import_react.useLayoutEffect)(() => {
    setFocusedIndex(computeInitialFocusIndex());
  }, [computeInitialFocusIndex]);
  (0, import_react.useEffect)(() => {
    if (resetTrigger !== void 0) {
      setFocusedIndex(computeInitialFocusIndex());
    }
  }, [resetTrigger, computeInitialFocusIndex]);
  (0, import_react.useEffect)(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);
  return {
    focusedIndex,
    setFocusedIndex,
    resetFocus
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  useMenuKeyboardNavigation
});
