"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var useMenuState_exports = {};
__export(useMenuState_exports, {
  useMenuState: () => useMenuState
});
module.exports = __toCommonJS(useMenuState_exports);
var import_react = require("react");
function useMenuState(initialOpen = false) {
  const [isOpen, setIsOpen] = (0, import_react.useState)(initialOpen);
  const toggle = (0, import_react.useCallback)(() => {
    setIsOpen((prev) => !prev);
  }, []);
  const close = (0, import_react.useCallback)(() => {
    setIsOpen(false);
  }, []);
  const open = (0, import_react.useCallback)(() => {
    setIsOpen(true);
  }, []);
  return {
    isOpen,
    toggle,
    close,
    open
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  useMenuState
});
