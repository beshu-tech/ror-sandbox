"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var public_exports = {};
__export(public_exports, {
  ReadonlyrestKbnPluginSetup: () => import_types.ReadonlyrestKbnPluginSetup,
  ReadonlyrestKbnPluginStart: () => import_types.ReadonlyrestKbnPluginStart,
  plugin: () => plugin
});
module.exports = __toCommonJS(public_exports);
var import_plugin = require("./plugin");
var import_types = require("./types");
function plugin(initializerContext) {
  return new import_plugin.ReadonlyrestKbnPlugin(initializerContext);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ReadonlyrestKbnPluginSetup,
  ReadonlyrestKbnPluginStart,
  plugin
});
