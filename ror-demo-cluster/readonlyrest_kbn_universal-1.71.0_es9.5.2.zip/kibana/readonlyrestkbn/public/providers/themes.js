"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var themes_exports = {};
__export(themes_exports, {
  dark9xTheme: () => dark9xTheme,
  darkTheme: () => darkTheme,
  lightTheme: () => lightTheme
});
module.exports = __toCommonJS(themes_exports);
const darkTheme = {
  colors: {
    bgDefault: "#07101f",
    bgPaper: "#1E1D24",
    hover: "#FFFFFF14",
    textPrimary: "#dfe5ef",
    textSecondary: "#8e9fbc",
    border: "#4d4c4c",
    popoverBorder: "inherit",
    codeBackground: "#25262E",
    backdropBackground: "#00000080"
  },
  variant: "dark"
};
const lightTheme = {
  colors: {
    bgDefault: "#f5f7fa",
    bgPaper: "#ffffff",
    hover: "#0000000a",
    textPrimary: "#1a1c21",
    textSecondary: "#69707d",
    border: "#d3dae6",
    popoverBorder: "#d3dae6",
    codeBackground: "#F5F7FA",
    backdropBackground: "#485975B3"
  },
  variant: "light"
};
const dark9xTheme = {
  colors: {
    bgDefault: "#07101f",
    bgPaper: "#0b1628",
    hover: "#FFFFFF14",
    textPrimary: "#FFFFFF",
    textSecondary: "#8e9fbc",
    border: "#2b394f",
    popoverBorder: "#2b394f",
    codeBackground: "#182335",
    backdropBackground: "#2B394FB3"
  },
  variant: "dark-9x"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  dark9xTheme,
  darkTheme,
  lightTheme
});
