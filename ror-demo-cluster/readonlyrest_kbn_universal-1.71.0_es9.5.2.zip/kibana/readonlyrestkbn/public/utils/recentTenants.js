"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var recentTenants_exports = {};
__export(recentTenants_exports, {
  addRecentTenant: () => addRecentTenant,
  getRecentTenantIds: () => getRecentTenantIds
});
module.exports = __toCommonJS(recentTenants_exports);
const STORAGE_KEY = "ror_recent_tenants";
const MAX_RECENT_TENANTS = 5;
const CURRENT_VERSION = 1;
function readStorage() {
  try {
    if (typeof window === "undefined" || !window.localStorage) {
      return null;
    }
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return null;
    }
    const data = JSON.parse(raw);
    if (data.version !== CURRENT_VERSION || !Array.isArray(data.tenantIds)) {
      return null;
    }
    return data;
  } catch {
    return null;
  }
}
function writeStorage(data) {
  try {
    if (typeof window === "undefined" || !window.localStorage) {
      return;
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
  }
}
function getRecentTenantIds() {
  var _a;
  const data = readStorage();
  return (_a = data == null ? void 0 : data.tenantIds) != null ? _a : [];
}
function addRecentTenant(tenantId) {
  if (!tenantId) {
    return;
  }
  const existing = getRecentTenantIds();
  const filtered = existing.filter((id) => id !== tenantId);
  const updated = [tenantId, ...filtered].slice(0, MAX_RECENT_TENANTS);
  writeStorage({
    version: CURRENT_VERSION,
    tenantIds: updated
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  addRecentTenant,
  getRecentTenantIds
});
