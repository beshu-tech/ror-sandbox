"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var rorFetch_exports = {};
__export(rorFetch_exports, {
  rorFetch: () => rorFetch
});
module.exports = __toCommonJS(rorFetch_exports);
var import_headers = require("../../shared/constants/headers");
var import_queryStringKeys = require("../../shared/constants/queryStringKeys");
function getTenancyFromUrl() {
  return new URLSearchParams(window.location.search).get(import_queryStringKeys.TENANCY_QUERY_STRING_KEY);
}
async function rorFetch(url, init) {
  const tenancyId = getTenancyFromUrl();
  const headers = new Headers(init == null ? void 0 : init.headers);
  if (tenancyId && !headers.has(import_headers.X_ROR_TENANCY)) {
    headers.set(import_headers.X_ROR_TENANCY, tenancyId);
  }
  return fetch(url, {
    ...init,
    headers
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  rorFetch
});
