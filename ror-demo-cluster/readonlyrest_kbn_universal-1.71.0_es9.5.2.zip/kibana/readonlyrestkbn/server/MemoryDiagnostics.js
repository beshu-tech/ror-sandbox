"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var MemoryDiagnostics_exports = {};
__export(MemoryDiagnostics_exports, {
  MemoryDiagnostics: () => MemoryDiagnostics
});
module.exports = __toCommonJS(MemoryDiagnostics_exports);
var import_http = __toESM(require("http"));
var import_https = __toESM(require("https"));
var import_rorLoggerFactory = require("../proxy/core/logging/rorLoggerFactory");
const _MemoryDiagnostics = class _MemoryDiagnostics {
  constructor() {
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "intervalHandle");
    __publicField(this, "previousMem");
    __publicField(this, "logMemoryUsage", () => {
      const mem = process.memoryUsage();
      const toMB = (bytes) => (bytes / 1024 / 1024).toFixed(2);
      const deltaMB = (current, previous) => {
        const delta = (current - previous) / 1024 / 1024;
        return `${delta >= 0 ? "+" : ""}${delta.toFixed(2)} MB`;
      };
      const deltaStr = this.previousMem ? ` | delta \u2014 heapUsed: ${deltaMB(mem.heapUsed, this.previousMem.heapUsed)}, rss: ${deltaMB(
        mem.rss,
        this.previousMem.rss
      )}, external: ${deltaMB(mem.external, this.previousMem.external)}, arrayBuffers: ${deltaMB(
        mem.arrayBuffers,
        this.previousMem.arrayBuffers
      )}` : "";
      const httpSockets = this.countSockets(import_http.default.globalAgent);
      const httpsSockets = this.countSockets(import_https.default.globalAgent);
      const handles = process._getActiveHandles();
      const requests = process._getActiveRequests();
      const handleCounts = handles.reduce((acc, h) => {
        var _a, _b, _c;
        const name = (_b = (_a = h == null ? void 0 : h.constructor) == null ? void 0 : _a.name) != null ? _b : "unknown";
        acc[name] = ((_c = acc[name]) != null ? _c : 0) + 1;
        return acc;
      }, {});
      this.logger.info(
        `[MemoryDiagnostics] heapUsed: ${toMB(mem.heapUsed)} MB, heapTotal: ${toMB(mem.heapTotal)} MB, rss: ${toMB(mem.rss)} MB, external: ${toMB(mem.external)} MB, arrayBuffers: ${toMB(mem.arrayBuffers)} MB${deltaStr}`
      );
      this.logger.info(
        `[MemoryDiagnostics] sockets \u2014 http active: ${httpSockets.active}, http free: ${httpSockets.free}, https active: ${httpsSockets.active}, https free: ${httpsSockets.free}`
      );
      this.logger.info(
        `[MemoryDiagnostics] handles: ${handles.length} total \u2014 ${JSON.stringify(handleCounts)}, pending requests: ${requests.length}`
      );
      this.previousMem = mem;
    });
  }
  static getInstance() {
    if (!_MemoryDiagnostics.instance) {
      _MemoryDiagnostics.instance = new _MemoryDiagnostics();
    }
    return _MemoryDiagnostics.instance;
  }
  start(options) {
    if (!(options == null ? void 0 : options.enabled)) {
      this.logger.debug("[MemoryDiagnostics] Disabled by configuration, skipping start");
      return;
    }
    if (this.intervalHandle) {
      this.logger.debug("[MemoryDiagnostics] Already running, skipping start");
      return;
    }
    this.logMemoryUsage();
    this.intervalHandle = setInterval(this.logMemoryUsage, options.intervalMs);
    this.logger.debug(`[MemoryDiagnostics] Started (intervalMs=${options.intervalMs})`);
  }
  stop() {
    if (this.intervalHandle) {
      clearInterval(this.intervalHandle);
      this.intervalHandle = void 0;
      this.logger.debug("[MemoryDiagnostics] Stopped");
    }
  }
  countSockets(agent) {
    const count = (pool) => Object.values(pool).reduce((sum, arr) => sum + arr.length, 0);
    return {
      free: count(agent.freeSockets),
      active: count(agent.sockets)
    };
  }
};
// eslint-disable-next-line no-use-before-define
__publicField(_MemoryDiagnostics, "instance");
let MemoryDiagnostics = _MemoryDiagnostics;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  MemoryDiagnostics
});
