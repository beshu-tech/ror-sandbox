"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var SessionCleanupTaskManager_exports = {};
__export(SessionCleanupTaskManager_exports, {
  SessionCleanupTaskManager: () => SessionCleanupTaskManager
});
module.exports = __toCommonJS(SessionCleanupTaskManager_exports);
var import_KibanaConfigManager = require("../kibana/config/KibanaConfigManager");
var import_rorLoggerFactory = require("../proxy/core/logging/rorLoggerFactory");
var import_buildSessionManagerSettings = require("../proxy/core/rorSettings/rorKbnSettingsBuilder/buildSessionManagerSettings");
class SessionCleanupTaskManager {
  constructor() {
    __publicField(this, "TASK_NAME", "ror_session_cleanup");
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "elasticsearchClient");
    __publicField(this, "taskManagerStart");
  }
  setup(taskManager) {
    this.registerTaskDefinitions(taskManager);
  }
  start(elasticsearchClient, taskManager) {
    this.taskManagerStart = taskManager;
    this.elasticsearchClient = elasticsearchClient;
    this.ensureScheduled(taskManager);
  }
  stop() {
    if (!this.taskManagerStart) {
      return;
    }
    this.taskManagerStart.remove(this.TASK_NAME).then(() => {
      this.logger.info(`Successfully removed session cleanup task: ${this.TASK_NAME}`);
    }).catch((e) => {
      var _a, _b;
      if (((_b = (_a = e == null ? void 0 : e.output) == null ? void 0 : _a.payload) == null ? void 0 : _b.error) === "Not Found") {
        this.logger.debug(`Task ${this.TASK_NAME} was not found during cleanup`);
        return;
      }
      this.logger.error({ message: `Failed to remove session cleanup task ${e.message}`, stack: e.stack });
    });
  }
  registerTaskDefinitions(taskManager) {
    const config = (0, import_KibanaConfigManager.getKibanaConfigManager)().getKibanaConfig();
    if (!config.readonlyrest_kbn) {
      return;
    }
    const { indexName, storeInIndex } = (0, import_buildSessionManagerSettings.buildSessionManagerSettings)(config.readonlyrest_kbn);
    if (!storeInIndex) {
      this.logger.debug("Session is not stored in index. Cleanup task is not registered");
      return;
    }
    taskManager.registerTaskDefinitions({
      [this.TASK_NAME]: {
        title: "Expired sessions cleanup",
        createTaskRunner: () => ({
          run: async () => {
            var _a;
            this.logger.info(`Session Cleanup task for ${indexName} is running`);
            await ((_a = this.elasticsearchClient) == null ? void 0 : _a.asInternalUser.deleteByQuery(
              {
                index: indexName,
                refresh: true,
                body: { query: { range: { expiresAt: { lte: Date.now() } } } }
              },
              { ignore: [409, 404] }
            ).then((data) => {
              var _a2;
              this.logger.debug(`Number of deleted stale Index sessions: ${(_a2 = data == null ? void 0 : data.deleted) != null ? _a2 : 0}`);
            }).catch((e) => {
              this.logger.error({ message: `Session Cleanup task error: ${e.message}`, stack: e.stack });
            }));
          }
        }),
        timeout: "5m"
      }
    });
  }
  ensureScheduled(taskManager) {
    const config = (0, import_KibanaConfigManager.getKibanaConfigManager)().getKibanaConfig();
    if (!config.readonlyrest_kbn) {
      return;
    }
    const { cleanupInterval, storeInIndex } = (0, import_buildSessionManagerSettings.buildSessionManagerSettings)(config.readonlyrest_kbn);
    if (!storeInIndex) {
      this.logger.debug("The session is not stored in the index. The cleanup task is not scheduled");
      return;
    }
    taskManager.get(this.TASK_NAME).then((data) => {
      this.logger.info("Task already registered:", data);
    }).catch((e) => {
      var _a, _b, _c;
      if (((_b = (_a = e == null ? void 0 : e.output) == null ? void 0 : _a.payload) == null ? void 0 : _b.error) === "Not Found") {
        this.logger.info(`${(_c = e == null ? void 0 : e.output) == null ? void 0 : _c.payload.message}, Task scheduled`);
        return taskManager.ensureScheduled({
          id: this.TASK_NAME,
          taskType: this.TASK_NAME,
          scope: [],
          schedule: { interval: cleanupInterval },
          params: {},
          state: {}
        });
      }
      this.logger.error({ message: `Task manager scheduling error ${e.message}`, stack: e.stack });
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SessionCleanupTaskManager
});
