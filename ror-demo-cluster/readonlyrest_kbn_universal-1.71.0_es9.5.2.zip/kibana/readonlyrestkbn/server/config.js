"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var config_exports = {};
__export(config_exports, {
  rorConfigSchema: () => rorConfigSchema
});
module.exports = __toCommonJS(config_exports);
var import_config_schema = require("@kbn/config-schema");
var import_ms = __toESM(require("ms"));
var import_types = require("../proxy/core/common/types");
var import_logLevel = require("../proxy/core/logging/logLevel");
var import_defaultValues = require("./defaultValues");
const rorConfigSchema = import_config_schema.schema.object({
  elasticsearch: import_config_schema.schema.object({
    username: import_config_schema.schema.maybe(import_config_schema.schema.string()),
    password: import_config_schema.schema.maybe(import_config_schema.schema.string())
  }),
  enabled: import_config_schema.schema.boolean({ defaultValue: true }),
  logLevel: import_config_schema.schema.string({
    defaultValue: "info",
    validate(v) {
      const acceptedLogLevelValues = (0, import_logLevel.getAcceptedLogLevelValues)();
      if (acceptedLogLevelValues.includes(v)) {
        return false;
      }
      return `must be one of ${acceptedLogLevelValues.join(" ,")}`;
    }
  }),
  cookiePass: import_config_schema.schema.string({ minLength: 32 }),
  cookieName: import_config_schema.schema.string({
    minLength: 5,
    defaultValue: import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.cookieName
  }),
  logPrettyPrintEnabled: import_config_schema.schema.boolean({ defaultValue: false }),
  store_sessions_in_index: import_config_schema.schema.maybe(import_config_schema.schema.boolean({ defaultValue: false })),
  sessions_index_name: import_config_schema.schema.maybe(
    import_config_schema.schema.string({ defaultValue: import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.sessions_index_name })
  ),
  sessions_refresh_after: import_config_schema.schema.maybe(
    import_config_schema.schema.number({ minValue: 1, defaultValue: import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.sessions_refresh_after })
  ),
  sessions_cleanup_interval: import_config_schema.schema.maybe(
    import_config_schema.schema.string({ defaultValue: import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.sessions_cleanup_interval })
  ),
  sessions_probe_interval_seconds: import_config_schema.schema.maybe(
    import_config_schema.schema.number({
      minValue: 10,
      defaultValue: import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.sessions_probe_interval_seconds
    })
  ),
  // "login", "tenancyHop", "never"
  clearSessionOnEvents: import_config_schema.schema.arrayOf(import_config_schema.schema.string(), { defaultValue: ["login", "tenancyHop"] }),
  session_timeout_minutes: import_config_schema.schema.number({
    defaultValue: import_defaultValues.DEFAULT_KIBANA_YAML_ROR_VALUES.session_timeout_minutes,
    minValue: 1
  }),
  // 3 days default
  proxy_auth_passthrough: import_config_schema.schema.boolean({ defaultValue: false }),
  custom_logout_link: import_config_schema.schema.maybe(import_config_schema.schema.string({ minLength: 6 })),
  custom_login_link: import_config_schema.schema.maybe(import_config_schema.schema.string({ minLength: 6 })),
  login_html_head_inject: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  login_custom_css_inject_file: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  login_custom_js_inject_file: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  custom_middleware_inject_file: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  custom_middleware_inject: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  login_custom_logo: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  login_subtitle: import_config_schema.schema.maybe(import_config_schema.schema.string({ unknowns: "allowed", defaultValue: "" })),
  login_title: import_config_schema.schema.maybe(import_config_schema.schema.string({ unknowns: "allowed", defaultValue: "" })),
  kibana_custom_css_inject: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  kibana_custom_css_inject_file: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  kibana_custom_js_inject: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  kibana_custom_js_inject_file: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  jwt_query_param: import_config_schema.schema.string({ defaultValue: "jwt" }),
  whitelistedPaths: import_config_schema.schema.maybe(import_config_schema.schema.arrayOf(import_config_schema.schema.string())),
  forward_auth_header: import_config_schema.schema.string({ defaultValue: import_types.X_FORWARDED_USER }),
  kibanaIndexTemplate: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  resetKibanaIndexToTemplate: import_config_schema.schema.boolean({ defaultValue: false }),
  // Kibana security token override (set it in dev mode)
  pkpKibanaToken: import_config_schema.schema.maybe(import_config_schema.schema.string()),
  license: import_config_schema.schema.maybe(
    import_config_schema.schema.object({
      activationKeyRefreshInterval: import_config_schema.schema.maybe(
        import_config_schema.schema.string({
          validate(v) {
            const activationKeyRefreshIntervalToMs = (0, import_ms.default)(v);
            const maximumTimeToMs = (0, import_ms.default)("1d");
            if (activationKeyRefreshIntervalToMs > maximumTimeToMs) {
              return `The activation key refresh interval cannot exceed ${(0, import_ms.default)(maximumTimeToMs, {
                long: true
              })}. Please provide a shorter duration.`;
            }
            return true;
          }
        })
      ),
      activationKeyRetrievalMode: import_config_schema.schema.maybe(import_config_schema.schema.string()),
      activationKeyFilePath: import_config_schema.schema.maybe(import_config_schema.schema.string({ defaultValue: "10m" }))
    })
  ),
  multiTenancyEnabled: import_config_schema.schema.maybe(import_config_schema.schema.boolean({ defaultValue: true })),
  cookies: import_config_schema.schema.maybe(
    import_config_schema.schema.object({
      sameSite: import_config_schema.schema.maybe(import_config_schema.schema.oneOf([import_config_schema.schema.literal("lax"), import_config_schema.schema.literal("strict"), import_config_schema.schema.literal("none")])),
      secure: import_config_schema.schema.maybe(import_config_schema.schema.boolean())
    })
  ),
  tenantIndex: import_config_schema.schema.maybe(
    import_config_schema.schema.object({
      number_of_shards: import_config_schema.schema.maybe(import_config_schema.schema.number({ minValue: 0 })),
      number_of_replicas: import_config_schema.schema.maybe(import_config_schema.schema.number({ minValue: 0 }))
    })
  ),
  diskThresholdVerificationEnabled: import_config_schema.schema.boolean({ defaultValue: true }),
  // Legacy:
  //         auth: Joi.object({
  //           signature_key: Joi.string().optional(),
  //
  //           //removeIf(no_saml)
  //           saml: Joi.object({
  //             enabled: Joi.boolean().default(true),
  //             type: Joi.string().optional(),
  //             protocol: Joi.string().default('http'),
  //             usernameParameter: Joi.string().default('nameID'),
  //             groupsParameter: Joi.string().default('memberOf'),
  //             kibanaExternalHost: Joi.string(),
  //             buttonName: Joi.string().optional(),
  //             logoutUrl: Joi.string().optional(),
  //             decryptionCert: Joi.string().optional(),
  //             entryPoint: Joi.string(),
  //             decryptionPvk: Joi.string().optional(),
  //             cert: Joi.string().optional(),
  //             privateCert: Joi.string().optional(),
  //             issuer: Joi.string().optional().default('ror'),
  //             authnContext: Joi.string().optional(),
  //             identifierFormat: Joi.string().optional(),
  //             acceptedClockSkewMs: Joi.number().optional(),
  //             signatureAlgorithm: Joi.string().optional(),
  //             disableRequestedAuthnContext: Joi.string().optional(),
  //           }).optional()
  //           //endRemoveIf(no_saml)
  //
  //         }).pattern(/./, Joi.any()).optional(),
  //
  // This is a poor workaround for legacy backward compatibility.
  // It requires an addition of custom validator or rewrite of schema to proper yaml standards (configurations as an array)
  auth: import_config_schema.schema.maybe(import_config_schema.schema.any()),
  memoryDiagnostics: import_config_schema.schema.maybe(
    import_config_schema.schema.object({
      enabled: import_config_schema.schema.maybe(import_config_schema.schema.boolean({ defaultValue: false })),
      interval: import_config_schema.schema.maybe(import_config_schema.schema.string({ defaultValue: "1d" }))
    })
  )
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  rorConfigSchema
});
