"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var defaultValues_exports = {};
__export(defaultValues_exports, {
  DEFAULT_KIBANA_YAML_ROR_VALUES: () => DEFAULT_KIBANA_YAML_ROR_VALUES
});
module.exports = __toCommonJS(defaultValues_exports);
var import_types = require("../proxy/core/common/types");
const DEFAULT_KIBANA_YAML_ROR_VALUES = {
  session_timeout_minutes: 4320,
  sessions_probe_interval_seconds: 30,
  sessions_index_name: ".readonlyrest_kbn_sessions",
  sessions_refresh_after: 2e3,
  sessions_cleanup_interval: "1d",
  whitelistedPaths: ["/status", "/api/status"],
  requestHeadersWhitelist: ["authorization", "cookie", import_types.X_ROR_CURRENT_GROUP],
  cookieName: "rorCookie"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DEFAULT_KIBANA_YAML_ROR_VALUES
});
