"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var server_exports = {};
__export(server_exports, {
  ReadonlyrestKbnPluginSetup: () => import_types.ReadonlyrestKbnPluginSetup,
  ReadonlyrestKbnPluginStart: () => import_types.ReadonlyrestKbnPluginStart,
  config: () => config,
  plugin: () => plugin
});
module.exports = __toCommonJS(server_exports);
var import_config_schema = require("@kbn/config-schema");
var import_KibanaConfigManager = require("../kibana/config/KibanaConfigManager");
var import_config = require("./config");
var import_plugin = require("./plugin");
var import_types = require("./types");
function plugin() {
  return new import_plugin.ReadonlyrestKbnPlugin();
}
const kibanaConfigManager = (0, import_KibanaConfigManager.getKibanaConfigManager)();
const kibanaConfig = kibanaConfigManager == null ? void 0 : kibanaConfigManager.getKibanaConfig();
const config = {
  schema: (kibanaConfig == null ? void 0 : kibanaConfig.readonlyrest_kbn) ? import_config.rorConfigSchema : import_config_schema.schema.nullable(import_config_schema.schema.any())
  // Validate readonlyrest_kbn config from kibana.yml when the configuration is present
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ReadonlyrestKbnPluginSetup,
  ReadonlyrestKbnPluginStart,
  config,
  plugin
});
