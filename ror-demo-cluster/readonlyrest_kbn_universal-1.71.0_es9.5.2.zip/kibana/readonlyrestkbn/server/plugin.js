"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var plugin_exports = {};
__export(plugin_exports, {
  ReadonlyrestKbnPlugin: () => ReadonlyrestKbnPlugin
});
module.exports = __toCommonJS(plugin_exports);
var import_ms = __toESM(require("ms"));
var import_RorKibanaBootstrapConfig = require("../kibana/config/RorKibanaBootstrapConfig");
var import_distributionInfoProvider = require("../kibana/patchers/distributionInfoProvider");
var import_kibanaPatcher = require("../kibana/patchers/kibanaPatcher");
var import_logLevel = require("../proxy/core/logging/logLevel");
var import_rorLoggerFactory = require("../proxy/core/logging/rorLoggerFactory");
var import_MemoryDiagnostics = require("./MemoryDiagnostics");
var import_SessionCleanupTaskManager = require("./SessionCleanupTaskManager");
class ReadonlyrestKbnPlugin {
  constructor() {
    __publicField(this, "logger", import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(__filename));
    __publicField(this, "sessionCleanupTaskManager");
    this.sessionCleanupTaskManager = new import_SessionCleanupTaskManager.SessionCleanupTaskManager();
  }
  async setup(_, { taskManager }) {
    this.logger.info(
      `Setting up ReadonlyREST plugin - build info: ${import_distributionInfoProvider.DistributionInfoProvider.getInstance().toString()}`
    );
    this.logger.debug("readonlyrest_kbn: Setup");
    this.sessionCleanupTaskManager.setup(taskManager);
    return {};
  }
  start(core, { taskManager }) {
    const settings = (0, import_RorKibanaBootstrapConfig.getRorKibanaBootstrapConfig)();
    this.sessionCleanupTaskManager.start(core.elasticsearch.client, taskManager);
    import_MemoryDiagnostics.MemoryDiagnostics.getInstance().start({
      intervalMs: Number((0, import_ms.default)(settings.memoryDiagnostics.interval)),
      enabled: settings.memoryDiagnostics.enabled
    });
    this.checkIfInstallationFinished();
    return {};
  }
  stop() {
    this.logger.debug("readonlyrest_kbn: Stopped");
    this.sessionCleanupTaskManager.stop();
    import_MemoryDiagnostics.MemoryDiagnostics.getInstance().stop();
  }
  checkIfInstallationFinished() {
    if ((0, import_kibanaPatcher.isPatchedAll)(
      (message, filename, level) => import_rorLoggerFactory.RorLoggerFactory.getLoggerForFile(filename)[(0, import_logLevel.toLoggerMethodName)(level != null ? level : import_logLevel.LogLevel.INFO)](message)
    )) {
      this.logger.debug("readonlyrest_kbn: Started");
    } else {
      console.log(
        `######################################################
#######    READONLYREST INSTALLATION ERROR    ########
######################################################`
      );
      this.logger.error({
        message: "ReadonlyREST plugin installation is not finished yet, an additional patching kibana step is required. Check documentation https://docs.readonlyrest.com/kibana#patching-kibana for more references"
      });
      process.exit();
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ReadonlyrestKbnPlugin
});
