"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var kibanaIndexDependentUrls_exports = {};
__export(kibanaIndexDependentUrls_exports, {
  KIBANA_SAVED_OBJECT_DEPENDENT_URL_SUBSTRINGS: () => KIBANA_SAVED_OBJECT_DEPENDENT_URL_SUBSTRINGS,
  isSavedObjectDependentUrl: () => isSavedObjectDependentUrl
});
module.exports = __toCommonJS(kibanaIndexDependentUrls_exports);
const KIBANA_SAVED_OBJECT_DEPENDENT_URL_SUBSTRINGS = [
  "/app/discover",
  // saved searches, data views
  "/app/dashboards",
  // dashboards
  "/app/lens",
  // lens visualizations
  "/app/visualize",
  // legacy visualizations
  "/app/maps",
  // saved maps
  "/app/canvas",
  // canvas workpads (deprecated in Kibana 9.x, still supported)
  "/app/r/s/",
  // Kibana short URL (hash-based, resolves to saved content)
  "/app/r?l=",
  // ALL Kibana locator URLs (Discover, Dashboard, Lens, Maps, …); the literal ? is safe because Express sets req.url from the raw HTTP request line where ? is always the query separator, never percent-encoded
  "/goto/"
  // Kibana goto redirect (resolves short URLs)
];
function isSavedObjectDependentUrl(url) {
  const pathname = new URL(url, "http://localhost").pathname;
  return KIBANA_SAVED_OBJECT_DEPENDENT_URL_SUBSTRINGS.some((s) => (s.includes("?") ? url : pathname).includes(s));
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KIBANA_SAVED_OBJECT_DEPENDENT_URL_SUBSTRINGS,
  isSavedObjectDependentUrl
});
