"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var rorReservedHiddenAppsValues_exports = {};
__export(rorReservedHiddenAppsValues_exports, {
  ALL_ROR_RESERVED_HIDDEN_APPS_VALUES: () => ALL_ROR_RESERVED_HIDDEN_APPS_VALUES,
  RorReservedHiddenAppsValue: () => RorReservedHiddenAppsValue
});
module.exports = __toCommonJS(rorReservedHiddenAppsValues_exports);
var RorReservedHiddenAppsValue = /* @__PURE__ */ ((RorReservedHiddenAppsValue2) => {
  RorReservedHiddenAppsValue2["ROR_MANAGE_KIBANA"] = "ROR Manage Kibana";
  RorReservedHiddenAppsValue2["READONLYREST_KBN"] = "readonlyrest_kbn";
  RorReservedHiddenAppsValue2["ROR_SECURITY_SETTINGS"] = "ROR Security Settings";
  return RorReservedHiddenAppsValue2;
})(RorReservedHiddenAppsValue || {});
const ALL_ROR_RESERVED_HIDDEN_APPS_VALUES = Object.values(RorReservedHiddenAppsValue);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ALL_ROR_RESERVED_HIDDEN_APPS_VALUES,
  RorReservedHiddenAppsValue
});
