"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ActivationKey_exports = {};
__export(ActivationKey_exports, {
  EDITIONS_ENUM: () => EDITIONS_ENUM,
  isEnterpriseLicense: () => isEnterpriseLicense,
  isFreeLicense: () => isFreeLicense,
  isPROLicense: () => isPROLicense
});
module.exports = __toCommonJS(ActivationKey_exports);
var EDITIONS_ENUM = /* @__PURE__ */ ((EDITIONS_ENUM2) => {
  EDITIONS_ENUM2["FREE"] = "kbn_free";
  EDITIONS_ENUM2["ENTERPRISE"] = "kbn_ent";
  EDITIONS_ENUM2["PRO"] = "kbn_pro";
  return EDITIONS_ENUM2;
})(EDITIONS_ENUM || {});
function isEnterpriseLicense(license) {
  return license.edition === "kbn_ent" /* ENTERPRISE */;
}
function isPROLicense(license) {
  return license.edition === "kbn_pro" /* PRO */;
}
function isFreeLicense(license) {
  return license.edition === "kbn_free" /* FREE */;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  EDITIONS_ENUM,
  isEnterpriseLicense,
  isFreeLicense,
  isPROLicense
});
