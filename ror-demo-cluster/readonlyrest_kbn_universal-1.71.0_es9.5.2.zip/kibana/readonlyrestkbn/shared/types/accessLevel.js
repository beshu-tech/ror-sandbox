"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var accessLevel_exports = {};
__export(accessLevel_exports, {
  AccessLevel: () => AccessLevel
});
module.exports = __toCommonJS(accessLevel_exports);
var AccessLevel = /* @__PURE__ */ ((AccessLevel2) => {
  AccessLevel2["RO_STRICT"] = "ro_strict";
  AccessLevel2["RO"] = "ro";
  AccessLevel2["RW"] = "rw";
  AccessLevel2["ADMIN"] = "admin";
  AccessLevel2["UNRESTRICTED"] = "unrestricted";
  AccessLevel2["API_ONLY"] = "api_only";
  return AccessLevel2;
})(AccessLevel || {});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AccessLevel
});
