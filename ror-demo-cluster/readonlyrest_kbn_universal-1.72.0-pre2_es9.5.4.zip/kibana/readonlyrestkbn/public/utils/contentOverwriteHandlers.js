"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var contentOverwriteHandlers_exports = {};
__export(contentOverwriteHandlers_exports, {
  ContentOverwriteDispatcher: () => ContentOverwriteDispatcher,
  EmbeddedDashboardFreeEditionHandler: () => EmbeddedDashboardFreeEditionHandler,
  ExternalAlertingLinkHandler: () => ExternalAlertingLinkHandler,
  buildOverwriteContext: () => buildOverwriteContext
});
module.exports = __toCommonJS(contentOverwriteHandlers_exports);
var import_jsx_runtime = require("react/jsx-runtime");
var import_react_dom = __toESM(require("react-dom"));
var semver = __toESM(require("semver"));
var import_ActivationKey = require("../../shared/types/ActivationKey");
var import_external_alerting_and_reporting_link = require("../components/external-alerting-and-reporting-link");
var import_pro_or_enterprise_feature_page = require("../components/pro-or-enterprise-feature-page");
function buildOverwriteContext(kibanaVersion, licenseEdition) {
  const kbnWrappers = document.querySelectorAll(".kbnAppWrapper");
  const lastKbnWrapper = kbnWrappers[kbnWrappers.length - 1];
  return {
    pathname: window.location.pathname,
    kibanaVersion,
    licenseEdition,
    jwtQueryParam: new URLSearchParams(window.location.search).get("jwt"),
    embedQueryParam: new URLSearchParams(window.location.hash.split("?")[1]).get("embed"),
    embedDashboardSelector: lastKbnWrapper || document.querySelector("#kibana-body"),
    existingAlertingLink: document.querySelector("#external-alerting-and-reporting-link"),
    existingProOrEnterpriseFeaturePage: document.getElementById(import_pro_or_enterprise_feature_page.PRO_OR_ENTERPRISE_FEATURE_PAGE_ID),
    pageBody: document.querySelector(".euiPageContentBody") || (lastKbnWrapper == null ? void 0 : lastKbnWrapper.querySelector("main")) || null
  };
}
class ContentOverwriteDispatcher {
  constructor() {
    __publicField(this, "handlers", []);
  }
  register(handler) {
    this.handlers.push(handler);
    return this;
  }
  dispatch(context) {
    for (const handler of this.handlers) {
      if (handler.handle(context)) return;
    }
  }
}
class EmbeddedDashboardFreeEditionHandler {
  handle({
    jwtQueryParam,
    embedQueryParam,
    embedDashboardSelector,
    licenseEdition,
    existingProOrEnterpriseFeaturePage
  }) {
    if (!jwtQueryParam || !embedQueryParam || !embedDashboardSelector || licenseEdition !== import_ActivationKey.EDITIONS_ENUM.FREE || existingProOrEnterpriseFeaturePage) {
      return false;
    }
    try {
      import_react_dom.default.unmountComponentAtNode(embedDashboardSelector);
    } catch {
    }
    import_react_dom.default.render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_pro_or_enterprise_feature_page.ProOrEnterpriseFeaturePage, {}), embedDashboardSelector);
    return true;
  }
}
class ExternalAlertingLinkHandler {
  constructor(kibanaVersion) {
    __publicField(this, "alertingUrls");
    this.alertingUrls = [
      "/app/management/insightsAndAlerting/triggersActions/logs",
      "/app/management/insightsAndAlerting/triggersActionsConnectors",
      "/app/management/insightsAndAlerting/triggersActionsConnectors/connectors",
      "/app/management/insightsAndAlerting/triggersActionsAlerts",
      "/app/management/insightsAndAlerting/triggersActions"
    ];
    if (semver.gte(kibanaVersion, "9.4.0")) {
      this.alertingUrls.push("/app/rules");
    } else {
      this.alertingUrls.push("/app/management/insightsAndAlerting/triggersActions/rules");
    }
  }
  handle({ pathname, kibanaVersion, existingAlertingLink, pageBody }) {
    if (!this.isAlertingUrl(pathname) || Boolean(existingAlertingLink) || !semver.gte(kibanaVersion, "8.6.0")) {
      return false;
    }
    if (pageBody) {
      try {
        import_react_dom.default.unmountComponentAtNode(pageBody);
      } catch {
      }
      import_react_dom.default.render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_external_alerting_and_reporting_link.ExternalAlertingAndReportingLink, {}), pageBody);
    }
    return true;
  }
  isAlertingUrl(pathname) {
    const appPathStart = pathname.indexOf("/app/");
    if (appPathStart === -1) return false;
    const appPath = pathname.slice(appPathStart).replace(/\/+$/, "");
    return this.alertingUrls.includes(appPath);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ContentOverwriteDispatcher,
  EmbeddedDashboardFreeEditionHandler,
  ExternalAlertingLinkHandler,
  buildOverwriteContext
});
