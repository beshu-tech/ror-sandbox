/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

// Let's have our own scope, so we don't leak variables and functions into global scope
(function hiddenAppsScope() {
  function isJsonString(str) {
    try {
      JSON.parse(str);
    } catch {
      return false;
    }
    return true;
  }

  function logWithContext(...params) {
    params.unshift('[ROR|hiddenApps] ');
    console.log(...params);
  }

  // The pages that the ROR menu "Manage Kibana" button opens when hidden_apps hides Stack Management.
  const manageKibanaButtonPages = [
    '/app/management/insightsAndAlerting/reporting',
    '/app/management/insightsAndAlerting/reporting/exports', // For Kibana 8.19.x
    '/app/management/kibana/indexPatterns',
    '/app/management/kibana/objects',
    '/app/management/kibana/dataViews'
  ];

  const APP_IDS_TO_BE_HIDDEN = ['Security'];
  const CAN_REPORT_APPS = '${canReportApps}' === 'true';
  const ALL_MENU_APPS = new Map();
  const FOUND_MENU_APPS_TO_BE_HIDDEN = [];

  // This selector is tested and works from 7.9.0 to 7.11.1 <--- #UPDATE_ME
  const DOM_MENU_ELEMENTS_SELECTOR = '[data-test-subj*="collapsibleNavGroup-"]';
  const DOM_SIDEBAR_TOGGLE_BUTTON_SELECTOR = "[aria-label*='Toggle primary navigation']";
  const DOM_NAV_APP_LINK_SELECTOR = '[data-test-subj="collapsibleNavAppLink"]';
  // On Kibana 8.0 and later, the title of some categories is a link to an app, for example Management.
  // A click on this link opens the app; other parts of the title open and close the category.
  const DOM_NAV_CATEGORY_TITLE_LINK_SELECTOR = '[data-test-subj="collapsibleNavAppLink-overview"]';
  const RECENT_ACTIONS_GROUP_NAME = 'recently';

  // A Kibana space id has lowercase letters, digits, '_' and '-'.
  // The space prefix is directly after the base path, so the regex runs on the path after the base path.
  const SPACES_PREFIX_REGEX = /^\/s\/[a-z0-9_-]+\//;

  // The page hides the apps only after the registry requests complete, so no request may wait forever.
  const REGISTRY_REQUEST_TIMEOUT_MILLIS = Number.parseInt('${registryRequestTimeoutMillis}', 10) || 65000;

  function getTenancyFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('tenancy');
  }

  // Each caller logs its own failure.
  function registryRequest(type, url, data) {
    const tenancy = getTenancyFromUrl();
    const headers = tenancy ? { 'X-ROR-TENANCY': tenancy } : {};
    return $.ajax({
      url,
      type,
      headers: data === undefined ? headers : { ...headers, 'Content-Type': 'application/json' },
      data,
      processData: false,
      dataType: 'json',
      timeout: REGISTRY_REQUEST_TIMEOUT_MILLIS
    });
  }

  function getAppsToHideFromRegistry() {
    return registryRequest('get', '${hiddenAppsRegistryPath}');
  }

  function getAllAppsFromRegistry() {
    return registryRequest('get', '${appRegistryPath}');
  }

  function setAppIdsToBeHidden(appIds) {
    APP_IDS_TO_BE_HIDDEN.push(...appIds);
    console.log('hiddenApps', APP_IDS_TO_BE_HIDDEN);
  }

  function hiddenAppsParser(hiddenApps) {
    return JSON.parse(hiddenApps.replace(/\\/g, '\\\\'));
  }

  setAppIdsToBeHidden(
    isJsonString('[${hiddenApps}]')
      ? (() => {
          // eslint-disable-next-line no-undef
          const hiddenAppsRaw = String.raw`[${hiddenApps}]`;
          return hiddenAppsParser(hiddenAppsRaw);
        })()
      : []
  );

  function buildAppMetadata(appElement, groupName) {
    const href = appElement.attr('href');
    return {
      id: `${groupName}|${appElement.text()}`,
      name: appElement.text(),
      groupName,
      href,
      path: withoutSpacePrefix(new URL(href).pathname)
    };
  }

  // jQuery rejects with the jqXHR object, which has no message.
  function describeRegistryFailure(error) {
    if (error && error.status > 0) {
      return `HTTP ${error.status}`;
    }
    // jQuery gives status 0 for a timeout or a network error, and names it in statusText.
    return error && error.statusText ? error.statusText : String(error);
  }

  async function printAllMenuApps() {
    logWithContext('=========== Apps ROR can hide =============');
    let allAppsFromRegistry;
    try {
      ({ allAppsFromRegistry } = await getAllAppsFromRegistry());
    } catch (error) {
      logWithContext(`Cannot print the apps ROR can hide: ${describeRegistryFailure(error)}`);
      return;
    }
    allAppsFromRegistry
      .sort((a, b) => a.id.localeCompare(b.id))
      .forEach(appMetadata => logWithContext(`${appMetadata.id} => ${appMetadata.path}`));
    logWithContext('===========================================');
    logWithContext('Apps array for kibanaAppRegistry.ts', ALL_MENU_APPS.entries());
  }

  function appendCSStoDOM(cssSelectorsArray, declarations = 'display: none;') {
    if (cssSelectorsArray.length === 0) {
      return;
    }
    const selectorsString = cssSelectorsArray.join(', ');
    logWithContext('Final CSS selector string:', cssSelectorsArray);
    // noinspection HtmlDeprecatedAttribute
    $(`
      <style type="text/css">
        ${selectorsString} {
          ${declarations}
        }
      </style>
    `).appendTo('head');
  }

  function expressionMatchesAppId(expression, appId) {
    function parseRegexpFromStringBasedRegexpValue() {
      const expressionWithoutRegexStartEndSymbols = expression.substr(1).slice(0, -1);
      const expressionWithEscapeValues = expressionWithoutRegexStartEndSymbols;
      return new RegExp(expressionWithEscapeValues);
    }

    function parseRegexpFromString() {
      const startWithRegex = new RegExp(`${expression.replace(/\|/g, '\\|')}.*`);
      return startWithRegex;
    }

    const isRegexExpression = expression.startsWith('/') && expression.endsWith('/');

    try {
      const regExp = isRegexExpression ? parseRegexpFromStringBasedRegexpValue() : parseRegexpFromString();
      return window.XRegExp.test(appId, regExp);
    } catch {
      logWithContext(`Invalid regular expression: ${expression} Ignoring!`);
      return false;
    }
  }

  function shouldHideApp(appId, appIdsToBeHidden) {
    return Boolean(appIdsToBeHidden.find(expression => expressionMatchesAppId(expression, appId)));
  }

  function computeEmptyGroupNames(survivorAppIds) {
    const groupNames = [...new Set([...ALL_MENU_APPS.values()].map(v => v.groupName))];
    logWithContext(`Groups found ${groupNames}`);

    const emptyOnes = groupNames.filter(groupName => !survivorAppIds.find(id => id.startsWith(groupName)));
    logWithContext(`Empty groups found ${emptyOnes}`);
    return emptyOnes;
  }

  function computeGroupHideSelector(groupName) {
    // Normal algorithm for transforming submenu (aka group) UI label names (as seen by the user) into CSS submenu selector
    let transformedName = groupName.replace(/ /g, '');
    transformedName = transformedName.charAt(0).toLowerCase() + transformedName.slice(1);

    // Some exceptions to be handled to the above, for some specific submenus. This is because the submenu selector follows the kibana plugin name (as seen in kibana.json), and the label may vary.
    if (transformedName === 'security') {
      transformedName = 'securitySolution';
    }
    if (transformedName === 'analytics') {
      transformedName = 'kibana';
    }

    if (transformedName === 'elasticsearch') {
      transformedName = 'enterpriseSearch';
    }

    return `[data-test-subj="collapsibleNavGroup-${cssString(transformedName)}"]`;
  }

  // A value for a quoted CSS attribute selector. CSS reads \r, \n and \f as a new line, which ends the
  // string. The escapes also keep the value from closing the <style> element.
  function cssString(value) {
    return String(value).replace(/[\\"<>\r\n\f]/g, char => `\\${char.charCodeAt(0).toString(16)} `);
  }

  // An app from the registry has only a path. The href of its navigation link has that path after
  // the base path and the space, followed by the end, the query or the hash.
  function computeHrefSelectors(linkSelector, path) {
    if (!path.includes('/app/')) {
      return [];
    }
    const hrefEnds = [`$="${cssString(path)}"`, `*="${cssString(`${path}?`)}"`, `*="${cssString(`${path}#`)}"`];
    return hrefEnds.map(hrefEnd => `${linkSelector}[href${hrefEnd}]`);
  }

  function computeNavLinkSelectors(path) {
    return [`li[url="${cssString(path)}"]`, ...computeHrefSelectors(DOM_NAV_APP_LINK_SELECTOR, path)];
  }

  // A hidden title would leave the category with an empty header. So the title stays, but a click on
  // it only opens or closes the category: the click goes to the parent element.
  function computeCategoryTitleLinkSelectors(appMetadata) {
    return appMetadata.id === 'Home'
      ? []
      : computeHrefSelectors(DOM_NAV_CATEGORY_TITLE_LINK_SELECTOR, appMetadata.path);
  }

  function computeAppHideSelector(appMetadata) {
    if (appMetadata.id === 'Home') {
      // Special case for "Home" app, which is not under a <li> but directly an <a>
      return `a[href*="${cssString(appMetadata.path)}"]`;
    }
    const navLinkSelectors = computeNavLinkSelectors(appMetadata.path);
    const selectors = appMetadata.href
      ? [`a[href="${cssString(appMetadata.href)}"]:not(${DOM_NAV_CATEGORY_TITLE_LINK_SELECTOR})`, ...navLinkSelectors]
      : navLinkSelectors;
    return selectors.join(', ');
  }

  function isValidRegistryApp(app) {
    return Boolean(app) && typeof app.id === 'string' && typeof app.path === 'string';
  }

  function shouldHideDashboardOrDashboardsApp(appIdsToBeHidden) {
    const isDashboardHiddenApps = shouldHideApp('Analytics|Dashboard', appIdsToBeHidden);
    const isDashboardsHiddenApps = shouldHideApp('Analytics|Dashboards', appIdsToBeHidden);

    // Case 1: Dashboard visible and Dashboards hidden
    if (!isDashboardHiddenApps && isDashboardsHiddenApps) {
      return false;
    }
    // Case 2: Dashboard hidden and Dashboards visible
    if (isDashboardHiddenApps && !isDashboardsHiddenApps) {
      return false;
    }
    // Case 3: Dashboard hidden and Dashboards hidden
    if (isDashboardHiddenApps && isDashboardsHiddenApps) {
      return true;
    }
    return false;
  }

  async function getHiddenAppsFromRegistry() {
    let hiddenApps = [];
    // A failed registry request must not stop the hiding of the apps that the page already knows.
    // The request fails when the session ends while the page loads, for example after a logout.
    try {
      ({ hiddenApps } = await getAppsToHideFromRegistry());
    } catch (error) {
      logWithContext(`Cannot get the hidden apps from the registry: ${describeRegistryFailure(error)}`);
    }
    const invalidRegistryApps = hiddenApps.filter(app => !isValidRegistryApp(app));
    if (invalidRegistryApps.length > 0) {
      logWithContext('Ignoring registry apps without a string id and path:', invalidRegistryApps);
    }
    return hiddenApps.filter(isValidRegistryApp);
  }

  function getCssSelectorsToHide(hiddenApps) {
    const survivorAppIds = [...ALL_MENU_APPS.keys()].filter(id => {
      if (id === 'Analytics|Dashboard' || id === 'Analytics|Dashboards') {
        /**
         * To keep backward compatibility with Kibana version below 8.14.0 during upgrade,
         * let user define Dashboard app both Analytics|Dashboard or Analytics|Dashboards
         * */
        return !shouldHideDashboardOrDashboardsApp(APP_IDS_TO_BE_HIDDEN);
      }

      return !shouldHideApp(id, APP_IDS_TO_BE_HIDDEN);
    });
    const emptyGroupsNames = computeEmptyGroupNames(survivorAppIds);

    let appsToHide = [...ALL_MENU_APPS.values()]
      .filter(appMetadata => !survivorAppIds.includes(appMetadata.id))
      .concat(hiddenApps);
    FOUND_MENU_APPS_TO_BE_HIDDEN.splice(0, FOUND_MENU_APPS_TO_BE_HIDDEN.length, ...appsToHide);

    const observabilityOverviewBasedCaps = [
      'Observability|Overview',
      'Observability|Alerts',
      'Observability|Cases',
      'Observability|SLOs',
      'Observability|Observability'
    ];
    const isRegexNegation = /\(\?!\(.*(Alerts|Overview|Cases|APM).*\)/;

    if (
      observabilityOverviewBasedCaps.some(observabilityOverviewBasedCap =>
        APP_IDS_TO_BE_HIDDEN.some(kibanaHiddenApp =>
          isRegexNegation.test(kibanaHiddenApp)
            ? false
            : expressionMatchesAppId(kibanaHiddenApp, observabilityOverviewBasedCap)
        )
      )
    ) {
      const observability = appsToHide.filter(app =>
        observabilityOverviewBasedCaps.some(observabilityOverviewBasedCap => observabilityOverviewBasedCap !== app.id)
      );

      appsToHide = appsToHide.concat(observability);
    } else {
      appsToHide = appsToHide.filter(
        app =>
          !observabilityOverviewBasedCaps.some(
            observabilityOverviewBasedCap => observabilityOverviewBasedCap === app.id
          )
      );
    }

    logWithContext(
      'Will hide apps:',
      appsToHide.map(_ => _.id)
    );

    const unusedExpressions = APP_IDS_TO_BE_HIDDEN.filter(
      expression =>
        expression !== 'readonlyrest_kbn' &&
        expression !== 'ROR Manage Kibana' &&
        expression !== 'ROR Security Settings' &&
        !appsToHide.find(appMetadata => expressionMatchesAppId(expression, appMetadata.id))
    );
    if (unusedExpressions && unusedExpressions.length) {
      logWithContext('Malformed expressions that did not match any app to hide:', unusedExpressions);
    }
    const groupsToHideSelectors = emptyGroupsNames.map(computeGroupHideSelector);
    const appToHideSelectors = appsToHide.map(computeAppHideSelector);
    return {
      selectorsToHide: groupsToHideSelectors.concat(appToHideSelectors),
      titleLinkSelectorsToBlock: appsToHide.flatMap(computeCategoryTitleLinkSelectors)
    };
  }

  function harvestAvailableAppsFromNav() {
    $(DOM_MENU_ELEMENTS_SELECTOR).each((_, menuGroup) => {
      if ($(menuGroup).text().toLowerCase().includes(RECENT_ACTIONS_GROUP_NAME)) {
        return;
      }
      const groupName = $(menuGroup).find('.euiTitle').text();
      $(menuGroup)
        .find('a')
        .map((_, app) => buildAppMetadata($(app), groupName))
        .each((_, appMetadata) => ALL_MENU_APPS.set(appMetadata.id, appMetadata));
    });
  }

  // Kibana 9.4.0 and later render the chrome with React createRoot. The toggle appears after the Kibana
  // spinner goes, and the nav groups after the click on the toggle returns. One time limit, from the
  // removal of the spinner, covers both waits. It stops the wait on a Kibana without them.
  const NAV_RENDER_TIMEOUT_MS = 3000;

  async function waitForElement(selector, timeLimit) {
    const isRendered = () => $(selector).length > 0;
    if (isRendered()) {
      return;
    }
    let observer;
    const rendered = new Promise(resolve => {
      observer = new MutationObserver(() => isRendered() && resolve());
      observer.observe(document.body, { childList: true, subtree: true });
    });
    await Promise.race([rendered, timeLimit]);
    observer.disconnect();
    if (!isRendered()) {
      logWithContext(`No ${selector} within ${NAV_RENDER_TIMEOUT_MS} ms after the Kibana spinner goes`);
    }
  }

  function ensureNavBarState(desiredState) {
    const navToggleButton = $(DOM_SIDEBAR_TOGGLE_BUTTON_SELECTOR);
    if (navToggleButton.length === 0) {
      return false;
    }
    const isOpen = navToggleButton.attr('aria-expanded') === 'true';
    const shouldToggle = desiredState !== isOpen;
    const stateForLogging = desiredState ? 'opened' : 'closed';
    if (shouldToggle) {
      navToggleButton.click();
      logWithContext(`Successfully ${stateForLogging} nav bar`);
    } else {
      logWithContext(`Nav bar was already ${stateForLogging}`);
    }
    return shouldToggle;
  }

  function executeWhenAppsListAvailable(callBack) {
    const kibanaLoaded = new Promise(resolve => {
      new MutationObserver((mutations, observer) => {
        for (const mutation of mutations) {
          for (const removedNode of mutation.removedNodes) {
            const kibanaSpinnerId = 'kbn_loading_message';
            if (removedNode.id === kibanaSpinnerId) {
              observer.disconnect();
              resolve();
              break;
            }
          }
        }
      }).observe(document.body, { childList: true });
    });

    kibanaLoaded.then(async () => {
      const timeLimit = new Promise(resolve => {
        setTimeout(resolve, NAV_RENDER_TIMEOUT_MS);
      });
      await waitForElement(DOM_SIDEBAR_TOGGLE_BUTTON_SELECTOR, timeLimit);
      // A nav that is open already can also render its groups in a later task.
      ensureNavBarState(true);
      await waitForElement(DOM_MENU_ELEMENTS_SELECTOR, timeLimit);
      harvestAvailableAppsFromNav();
      Promise.resolve(callBack()).catch(error => logWithContext('Cannot hide the apps:', error));
      ensureNavBarState(false);
    });
  }

  function withoutBasePath(path) {
    const basePath = '${basePath}';
    return basePath && path.startsWith(`${basePath}/`) ? path.slice(basePath.length) : path;
  }

  // Keeps the base path. A base path such as /s/kibana looks like a space prefix, so the regex runs only on the path after the base path.
  function withoutSpacePrefix(path) {
    const pathAfterBasePath = withoutBasePath(path);
    const basePathPart = path.slice(0, path.length - pathAfterBasePath.length);
    return `${basePathPart}${pathAfterBasePath.replace(SPACES_PREFIX_REGEX, '/')}`;
  }

  function isPathOf(pagePath, appPath) {
    return pagePath === appPath || pagePath.startsWith(`${appPath}/`);
  }

  // A copy of the server rule KibanaAppsRegistry.isOpenedByManageKibanaButton.
  function isOpenedByManageKibanaButton(pagePathWithoutBasePath, appMetadata) {
    const appPath = withoutBasePath(appMetadata.path);
    const isManageKibanaButtonHidden = APP_IDS_TO_BE_HIDDEN.includes('ROR Manage Kibana');
    if (isManageKibanaButtonHidden || !isManageKibanaButtonPageOfApp(pagePathWithoutBasePath, appPath)) {
      return false;
    }
    const isPageHiddenByName =
      manageKibanaButtonPages.includes(appPath) &&
      APP_IDS_TO_BE_HIDDEN.some(expression => namesAppDirectly(expression, appMetadata.id));
    return !isPageHiddenByName;
  }

  // The page is a button page or one of its sub-pages, and the app is that button page or a parent of it.
  function isManageKibanaButtonPageOfApp(pagePath, appPath) {
    return manageKibanaButtonPages.some(page => isPathOf(pagePath, page) && isPathOf(page, appPath));
  }

  // A value that matches Stack Management or a wider group does not name the app directly.
  function namesAppDirectly(expression, appId) {
    return (
      !expressionMatchesAppId(expression, 'Management|Stack Management') && expressionMatchesAppId(expression, appId)
    );
  }

  function prohibitNavigationIfNeeded() {
    const { pathname } = window.location;
    // The button pages have no base path. A registry path can have one, so the match removes it from both sides.
    const pagePath = withoutBasePath(withoutSpacePrefix(pathname));
    const spacePermissionsUrlRegexp = /app\/management\/kibana\/spaces\/edit\/([^/]+)\/roles/;

    if (spacePermissionsUrlRegexp.test(pagePath)) {
      window.location.replace('${basePath}/');
    }

    FOUND_MENU_APPS_TO_BE_HIDDEN.forEach(appMetadata => {
      if (
        isPathOf(pagePath, withoutBasePath(appMetadata.path)) &&
        !isOpenedByManageKibanaButton(pagePath, appMetadata)
      ) {
        logWithContext(`Cannot navigate to ${pathname} because ${appMetadata.name} app is hidden`);
        window.location.replace('${basePath}/');
      }
    });
  }

  // Kibana changes the route in the page through window.history, without a page load.
  function prohibitNavigationOnRouteChange() {
    ['pushState', 'replaceState'].forEach(method => {
      const original = window.history[method];
      window.history[method] = function guardedHistoryMethod(...args) {
        const result = original.apply(this, args);
        prohibitNavigationIfNeeded();
        return result;
      };
    });
    window.addEventListener('popstate', prohibitNavigationIfNeeded);
  }

  function sendAppsToRegistry(appsArray) {
    return registryRequest('post', '${appRegistryPath}', JSON.stringify(appsArray));
  }

  function hideApps(hiddenApps) {
    const { selectorsToHide, titleLinkSelectorsToBlock } = getCssSelectorsToHide(hiddenApps);
    appendCSStoDOM(selectorsToHide);
    appendCSStoDOM(titleLinkSelectorsToBlock, 'pointer-events: none; cursor: default;');
    prohibitNavigationIfNeeded();
  }

  // The registry apps need no nav harvest, and the harvest can wait for the nav. So ROR hides the
  // registry apps at once, and all the apps after the harvest.
  const hiddenAppsFromRegistryPromise = getHiddenAppsFromRegistry();
  const registryAppsHidden = (async () => {
    try {
      const hiddenAppsFromRegistry = await hiddenAppsFromRegistryPromise;
      logWithContext('Hiding the registry apps before the nav harvest');
      hideApps(hiddenAppsFromRegistry);
    } catch (error) {
      logWithContext('Cannot hide the registry apps:', error);
    }
  })();

  executeWhenAppsListAvailable(async () => {
    // In parallel with the registry requests, the report can add a second session document (RORDEV-2357).
    // The server lets only these users report the apps and read the whole registry.
    if (CAN_REPORT_APPS) {
      try {
        await sendAppsToRegistry(Array.from(ALL_MENU_APPS.values()));
      } catch (error) {
        logWithContext(`Cannot report the menu apps: ${describeRegistryFailure(error)}`);
      }
      await printAllMenuApps();
    }
    const hiddenAppsFromRegistry = await hiddenAppsFromRegistryPromise;
    // The route guard uses the apps of the last pass, so the pass with the nav apps runs last.
    await registryAppsHidden;
    hideApps(hiddenAppsFromRegistry);
  });

  function hideSecuritySolutionViewOption() {
    if (!shouldHideApp('Security', APP_IDS_TO_BE_HIDDEN)) {
      return;
    }
    appendCSStoDOM(['[data-test-subj="solutionViewSecurityOption"]']);
  }

  hideSecuritySolutionViewOption();
  prohibitNavigationOnRouteChange();

  // For testing hidden app functionality purpose
  if (typeof module !== 'undefined' && Object.prototype.hasOwnProperty.call(module, 'exports')) {
    module.exports = {
      FOUND_MENU_APPS_TO_BE_HIDDEN,
      APP_IDS_TO_BE_HIDDEN,
      NAV_RENDER_TIMEOUT_MS,
      shouldHideApp,
      prohibitNavigationIfNeeded,
      setAppIdsToBeHidden,
      hiddenAppsParser,
      hideSecuritySolutionViewOption
    };
  }
})();
