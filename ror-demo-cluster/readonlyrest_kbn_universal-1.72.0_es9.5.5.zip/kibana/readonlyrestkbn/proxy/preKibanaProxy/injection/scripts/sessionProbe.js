/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

// Every Kibana tab runs this script, but only one tab of the browser at a time sends the session
// probe: the tab that holds the lease in localStorage.
function init() {
  const PROBE_INTERVAL_MILLIS = Number.parseInt('${intervalMillis}', 10);
  const SESSION_PROBE_PATH = '${sessionProbeUrl}';
  const BASE_LOGOUT_PATH = '${baseLogoutUrl}';
  const NEXT_URL_PARAM = 'nextUrl';
  const PREFIX = '${sessionProbePrefix}';
  const LOGGING_ENABLED = '${enableLogging}' === 'true';
  const SESSION_PROBE_COOKIE_NAME = `${PREFIX}-SP`;
  // Tabs of ReadonlyREST 1.71.0 and earlier use the same key, so the old name stays.
  const LEASE_KEY = `${PREFIX}-MUTEX`;
  const BACKOFF_KEY = `${PREFIX}-BACKOFF`;
  const TAB_ID_KEY = `${PREFIX}-TAB`;
  const LOGOUT_EVENT = `${PREFIX}-LOGOUT`;
  const RELOAD_EVENT = `${PREFIX}-RELOAD`;
  const CHECK_INTERVAL_MILLIS = 10000;
  const LEASE_CHECK_DELAY_MILLIS = 150;
  const MAX_ATTEMPTS = 3;
  // The server calculates the timeout from its elasticsearch.requestTimeout. A file without the server
  // values (the source file itself) gets the timeout for the default of 30 s.
  const PROBE_TIMEOUT_MILLIS = Number.parseInt('${probeTimeoutMillis}', 10) || 65000;
  // The holder renews the lease when it sends a request, so the lease covers one request: up to the
  // timeout, plus the delay of the timers of a hidden tab, the jQuery timeout timer too (Chrome
  // intensive throttling), plus a margin.
  const HIDDEN_TAB_TIMER_DELAY_MILLIS = 60000;
  const LEASE_MARGIN_MILLIS = 25000;
  const LEASE_MILLIS = PROBE_TIMEOUT_MILLIS + HIDDEN_TAB_TIMER_DELAY_MILLIS + LEASE_MARGIN_MILLIS;
  // Kibana nodes can have different elasticsearch.requestTimeout values, so a tab of another node can
  // write a longer lease than this tab.
  const MAX_LEASE_MILLIS = Math.max(LEASE_MILLIS, 10 * 60 * 1000);
  const MAX_BACKOFF_MILLIS = 120000;
  // A frozen tab runs its queued storage events when it wakes up. An older LOGOUT can come from a
  // session that ended before the user logged in again, so the next probe of the tab decides instead.
  const STALE_LOGOUT_MILLIS = 2 * CHECK_INTERVAL_MILLIS;
  const TAB_ID = `${performance.now() || 0}:${Math.random() * 1000000000 || 0}`;
  const TAB_CREATED_AT = Date.now();

  let currentProbeIntervalMillis = PROBE_INTERVAL_MILLIS;
  let failedAttempts = 0;
  let probeSentAt = null;
  let tabReloadStarted = false;

  function logAsSessionProbe(message) {
    if (LOGGING_ENABLED) {
      console.log(`[ROR|sessionProbe] ${message}`);
    }
  }

  const eventBus = {
    subscribe: (topic, onMessage) =>
      window.addEventListener('storage', event => {
        if (event.key === topic && event.newValue != null) {
          onMessage(event.newValue);
        }
      }),
    // A storage event fires only when the stored value changes, so each message is unique.
    // A full localStorage must not stop the logout or the reload of this tab.
    publish: topic => {
      try {
        localStorage.setItem(topic, JSON.stringify({ at: Date.now(), from: TAB_ID }));
      } catch (error) {
        logAsSessionProbe(`Cannot send ${topic} to the other tabs: ${error}`);
      }
    }
  };

  function redirectToLogout() {
    const nextUrl = window.location.pathname + window.location.search + window.location.hash;
    const encodedNextUrl = encodeURIComponent(nextUrl);
    logAsSessionProbe(`Setting nextUrl param to: ${nextUrl}`);
    const redirectUri = `${BASE_LOGOUT_PATH}?${NEXT_URL_PARAM}=${encodedNextUrl}`;
    logAsSessionProbe(`Redirecting to: ${encodedNextUrl}`);
    window.location.href = redirectUri;
  }

  function reload() {
    logAsSessionProbe(`Reloading the page`);
    window.location.reload(false);
  }

  function parseJson(value) {
    try {
      return JSON.parse(value);
    } catch (_error) {
      return null;
    }
  }

  // Tabs of ReadonlyREST 1.71.0 and earlier send an empty string, with no time. Such a message is
  // never stale, so a logout from an old tab still logs out this tab.
  function isStaleMessage(value) {
    const message = parseJson(value);
    return message !== null && Number.isFinite(message.at) && Date.now() - message.at > STALE_LOGOUT_MILLIS;
  }

  function onLogoutMessage(value) {
    if (isStaleMessage(value)) {
      logAsSessionProbe(`Ignoring an old ${LOGOUT_EVENT} message`);
      return;
    }
    redirectToLogout();
  }

  function parseLease(value) {
    const lease = parseJson(value);
    if (lease !== null && typeof lease.tabId === 'string' && Number.isFinite(lease.until)) {
      return lease;
    }
    return null;
  }

  // Tabs that still run an older version of this script use the same key, with a plain tab id and no
  // end time. Such a lease ends LEASE_MILLIS after this tab first reads it. Remove in 1.73.0
  // (RORDEV-2272).
  let legacyLease = null;

  function readLease() {
    const value = localStorage.getItem(LEASE_KEY);
    if (value === null) {
      legacyLease = null;
      return null;
    }
    const lease = parseLease(value);
    if (lease !== null) {
      return lease;
    }
    if (legacyLease === null || legacyLease.value !== value) {
      legacyLease = { value, until: Date.now() + LEASE_MILLIS };
    }
    return { tabId: value, until: legacyLease.until };
  }

  // A lease never lasts longer than MAX_LEASE_MILLIS from now. A later end comes from a clock that
  // moved back, or from a bad value.
  function isLeaseValid(lease) {
    const remainingMillis = lease.until - Date.now();
    return remainingMillis > 0 && remainingMillis <= MAX_LEASE_MILLIS;
  }

  function writeLease() {
    localStorage.setItem(LEASE_KEY, JSON.stringify({ tabId: TAB_ID, until: Date.now() + LEASE_MILLIS }));
  }

  function holdsValidLease() {
    const lease = readLease();
    return lease !== null && lease.tabId === TAB_ID && isLeaseValid(lease);
  }

  // Removes the lease only when it holds this tab id.
  function releaseLease(tabId) {
    const lease = readLease();
    if (lease !== null && lease.tabId === tabId) {
      localStorage.removeItem(LEASE_KEY);
    }
  }

  function readBackoff() {
    const backoff = parseJson(localStorage.getItem(BACKOFF_KEY));
    if (backoff !== null && Number.isFinite(backoff.failedRounds) && Number.isFinite(backoff.notBefore)) {
      return backoff;
    }
    return null;
  }

  function isBackingOff() {
    const backoff = readBackoff();
    if (backoff === null) {
      return false;
    }
    const remainingMillis = backoff.notBefore - Date.now();
    return remainingMillis > 0 && remainingMillis <= MAX_BACKOFF_MILLIS;
  }

  // After a failed round, no tab probes for a while, so that the tabs do not send more requests to a
  // Kibana or Elasticsearch that does not answer.
  function recordFailedRound() {
    const previous = readBackoff();
    const failedRounds = previous === null ? 1 : previous.failedRounds + 1;
    const waitMillis = Math.min(CHECK_INTERVAL_MILLIS * 2 ** (failedRounds - 1), MAX_BACKOFF_MILLIS);
    logAsSessionProbe(`Next session probe in ${waitMillis} ms at the earliest`);
    localStorage.setItem(BACKOFF_KEY, JSON.stringify({ failedRounds, notBefore: Date.now() + waitMillis }));
  }

  function clearBackoff() {
    localStorage.removeItem(BACKOFF_KEY);
  }

  function readProbeCookie() {
    const cookie = Cookies.get(SESSION_PROBE_COOKIE_NAME);
    if (cookie == null) {
      return null;
    }
    const cookieValue = parseJson(cookie);
    if (
      cookieValue !== null &&
      Number.isFinite(cookieValue.createdAtMillis) &&
      Number.isFinite(cookieValue.intervalMillis)
    ) {
      return cookieValue;
    }
    logAsSessionProbe(`Found an unreadable session probe cookie`);
    return null;
  }

  function isValidSessionProbeCookiePresent() {
    const cookieValue = readProbeCookie();
    if (cookieValue === null) {
      logAsSessionProbe(`No valid session probe cookie found`);
      return false;
    }
    if (cookieValue.intervalMillis !== currentProbeIntervalMillis && cookieValue.createdAtMillis > TAB_CREATED_AT) {
      logAsSessionProbe(
        `Found session probe cookie with different interval set. Current = ${currentProbeIntervalMillis}. New = ${cookieValue.intervalMillis}`
      );
      currentProbeIntervalMillis = cookieValue.intervalMillis;
    }
    if (Date.now() < cookieValue.createdAtMillis + currentProbeIntervalMillis) {
      logAsSessionProbe(`Session probe cookie valid`);
      return true;
    }
    logAsSessionProbe(`Found invalid session probe cookie`);
    return false;
  }

  function isSessionProbeCurrentlyBeingChecked() {
    const lease = readLease();
    if (lease === null) {
      logAsSessionProbe(`Session probe not currently being checked`);
      return false;
    }
    // This includes the expired lease of this tab.
    if (!isLeaseValid(lease)) {
      logAsSessionProbe(`Session probe lease of tabId ${lease.tabId} expired`);
      return false;
    }
    logAsSessionProbe(`Session probe currently being checked by tabId: ${lease.tabId}`);
    return true;
  }

  // A tab sends one probe request at a time, also when its lease disappears during the request (another
  // tab cleared localStorage, for example). The time limit covers an answer that never reaches the page.
  function isProbeInFlight() {
    return probeSentAt !== null && Date.now() - probeSentAt < LEASE_MILLIS;
  }

  function shouldCheckSession() {
    if (isValidSessionProbeCookiePresent()) {
      // The last round ended, so a plain tab id read from now on belongs to a new round.
      legacyLease = null;
      return false;
    }
    return !isProbeInFlight() && !isSessionProbeCurrentlyBeingChecked() && !isBackingOff();
  }

  function storeProbeCookie() {
    const now = Date.now();
    const beforeNextIntervalTick = new Date(now + currentProbeIntervalMillis - 1);
    const cookieValue = JSON.stringify({
      createdAtMillis: now,
      intervalMillis: currentProbeIntervalMillis
    });
    Cookies.set(SESSION_PROBE_COOKIE_NAME, cookieValue, { expires: beforeNextIntervalTick });
  }

  function finishRound() {
    failedAttempts = 0;
    releaseLease(TAB_ID);
  }

  function finishImpersonation() {
    sessionStorage.setItem('rorImpersonationFinished', 'true');
    window.location.reload();
  }

  function onSessionProbeSuccess(data) {
    probeSentAt = null;
    logAsSessionProbe(`Session probe successful: ${JSON.stringify(data)}`);
    const answer = data !== null && typeof data === 'object' ? data : {};
    if (Number.isFinite(answer.intervalMillis) && answer.intervalMillis > 0) {
      currentProbeIntervalMillis = answer.intervalMillis;
    }
    clearBackoff();
    storeProbeCookie();
    finishRound();
    if (answer.reload) {
      eventBus.publish(RELOAD_EVENT);
      reload();
    } else if (answer.reloadThisPageWithoutTenancy) {
      reloadWithoutTenancy();
    }
  }

  // The probe sends the tenancy of the URL, so a reload of the same URL sends it again. The tab loads its URL
  // without that tenancy, and only once per page: a navigation that the user stops (a beforeunload prompt) does
  // not start again at each probe. A URL without a tenancy does not load again: the tenancy then comes from another
  // source, which a load does not change.
  function reloadWithoutTenancy() {
    if (tabReloadStarted) {
      logAsSessionProbe(`This page already started to load without its tenancy`);
      return;
    }
    // The full URL keeps the origin of the page: a path that starts with // would name another host.
    const url = new URL(window.location.href);
    if (!url.searchParams.has('tenancy')) {
      logAsSessionProbe(`The URL of this page has no tenancy, so a load of the page does not change the tenancy`);
      return;
    }
    tabReloadStarted = true;
    url.searchParams.delete('tenancy');
    logAsSessionProbe(`Loading the page without the tenancy that the session does not have`);
    window.location.replace(url.href);
  }

  function getTenancyFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('tenancy');
  }

  function getSessionProbe() {
    // An expired own lease ends the round: the next check takes the lease again, with the 150 ms re-check.
    if (!holdsValidLease()) {
      logAsSessionProbe(`This tab holds no valid session probe lease`);
      failedAttempts = 0;
      return;
    }
    writeLease();
    probeSentAt = Date.now();
    logAsSessionProbe(`Getting session probe ${new Date()}`);
    const tenancy = getTenancyFromUrl();
    $.ajax({
      url: SESSION_PROBE_PATH,
      type: 'get',
      timeout: PROBE_TIMEOUT_MILLIS,
      headers: tenancy ? { 'X-ROR-TENANCY': tenancy } : undefined,
      success: onSessionProbeSuccess,
      // eslint-disable-next-line no-use-before-define
      error: onSessionProbeFail
    });
  }

  function onSessionProbeFail(err, textStatus) {
    probeSentAt = null;
    failedAttempts += 1;
    const status = err ? err.status : undefined;
    // jQuery sets responseJSON only for a JSON body. A proxy in front of Kibana can answer 401 with HTML.
    const body = err ? err.responseJSON : undefined;
    const message = body !== null && typeof body === 'object' ? body.message : undefined;
    logAsSessionProbe(`Session probe failed: ${status} ${textStatus}. Attempt ${failedAttempts}/${MAX_ATTEMPTS}`);

    if (status === 401 && message === 'Ttl is reached') {
      clearBackoff();
      finishRound();
      finishImpersonation();
      return;
    }

    if (status === 401) {
      clearBackoff();
      finishRound();
      eventBus.publish(LOGOUT_EVENT);
      Cookies.remove(SESSION_PROBE_COOKIE_NAME);
      redirectToLogout();
      return;
    }

    // A request that timed out is not sent again at once: the server is too slow, or it does not answer.
    if (textStatus === 'timeout' || failedAttempts >= MAX_ATTEMPTS) {
      logAsSessionProbe(`Session probe temporarily unavailable; keeping the current session`);
      try {
        recordFailedRound();
      } finally {
        finishRound();
      }
      return;
    }

    getSessionProbe();
  }

  function checkSessionValidity() {
    try {
      if (shouldCheckSession()) {
        writeLease();
        // Two tabs can write the lease at the same time. Only the tab whose write stays probes.
        setTimeout(getSessionProbe, LEASE_CHECK_DELAY_MILLIS);
      }
    } finally {
      setTimeout(checkSessionValidity, CHECK_INTERVAL_MILLIS);
    }
  }

  // sessionStorage belongs to the browser tab, so a page finds there the id of the page that ran in
  // the tab before it. After a reload, or after the browser restores a crashed tab, that page is gone
  // and its lease is free. A page that copies or shares the sessionStorage of a live page (a
  // duplicated tab, a frame of the same origin) can free the lease of that page: at most one more
  // probe runs, because every tab compares ids before it renews or removes a lease.
  function releaseLeaseOfPreviousPage() {
    try {
      const previousTabId = sessionStorage.getItem(TAB_ID_KEY);
      if (previousTabId !== null) {
        releaseLease(previousTabId);
      }
      sessionStorage.setItem(TAB_ID_KEY, TAB_ID);
    } catch (error) {
      logAsSessionProbe(`Cannot release the lease of the previous page: ${error}`);
    }
  }

  eventBus.subscribe(LOGOUT_EVENT, onLogoutMessage);
  eventBus.subscribe(RELOAD_EVENT, reload);
  // A close, a reload or a navigation frees the lease at once. After a crash, the next page in the tab
  // frees it, or it ends at `until`.
  window.addEventListener('pagehide', () => releaseLease(TAB_ID));
  releaseLeaseOfPreviousPage();
  setTimeout(checkSessionValidity, CHECK_INTERVAL_MILLIS);
}

init();
