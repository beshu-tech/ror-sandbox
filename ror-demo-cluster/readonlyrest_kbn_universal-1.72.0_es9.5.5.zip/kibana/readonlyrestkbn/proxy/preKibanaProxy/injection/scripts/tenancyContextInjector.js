"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

  // proxy/preKibanaProxy/injection/scripts/requestHeaders/RequestHeadersInterceptor.ts
  var RequestHeadersInterceptor = class {
    constructor(headersToAdd) {
      this.headersToAdd = headersToAdd;
      __publicField(this, "originalFetch");
      this.originalFetch = window.fetch.bind(window);
    }
    overrideAllKibanaApiCalls() {
      this.overrideFetchMethod();
      this.overrideXhrMethod();
    }
    overrideFetchMethod() {
      const originalFetch = this.originalFetch;
      window.fetch = ((input, init = {}) => {
        const url = input instanceof Request ? input.url : input.toString();
        if (this.isExternalRequest(url)) {
          return originalFetch(input, init);
        }
        const headers = new Headers(input instanceof Request ? input.headers : init.headers);
        for (const [name, value] of Object.entries(this.headersToAdd())) {
          headers.set(name, value);
        }
        return originalFetch(
          input instanceof Request ? new Request(input, { headers }) : new Request(input.toString(), __spreadProps(__spreadValues({}, init), { headers }))
        );
      });
    }
    overrideXhrMethod() {
      const headersToAdd = this.headersToAdd;
      const isExternalRequest = this.isExternalRequest.bind(this);
      const proto = XMLHttpRequest.prototype;
      const originalOpen = proto.open;
      const originalSend = proto.send;
      const originalSetRequestHeader = proto.setRequestHeader;
      proto.open = function(method, url, async = true, user, password) {
        this.isExternal = isExternalRequest(typeof url === "string" ? url : url.toString());
        originalOpen.call(this, method, url, async, user, password);
      };
      proto.send = function(...args) {
        if (!this.isExternal) {
          for (const [name, value] of Object.entries(headersToAdd())) {
            originalSetRequestHeader.call(this, name, value);
          }
        }
        originalSend.apply(this, args);
      };
    }
    isExternalRequest(url) {
      try {
        return new URL(url, window.location.origin).origin !== window.location.origin;
      } catch (e) {
        return false;
      }
    }
  };

  // shared/constants/queryStringKeys.ts
  var TENANCY_QUERY_STRING_KEY = "tenancy";

  // proxy/preKibanaProxy/injection/scripts/tenancyContext/ClipboardInterception.ts
  var _ClipboardInterception = class _ClipboardInterception {
    constructor(tenancyUrlService2, tenancyContextApplier2) {
      this.tenancyUrlService = tenancyUrlService2;
      this.tenancyContextApplier = tenancyContextApplier2;
    }
    setupClipboardInterception() {
      document.addEventListener("copy", (event) => {
        var _a;
        const selectedText = (_a = document.getSelection()) == null ? void 0 : _a.toString();
        if (!selectedText) {
          return;
        }
        if (selectedText.includes("<iframe")) {
          this.interceptEmbedDashboardCopyLink(selectedText, event);
          return;
        }
        if (_ClipboardInterception.INTERCEPTED_PATHS.some((path) => selectedText.includes(path))) {
          this.interceptUrlCopyLink(selectedText, event);
        }
      });
    }
    interceptEmbedDashboardCopyLink(copiedText, event) {
      var _a;
      const currentTenancyId = this.tenancyUrlService.getCurrentTenancy();
      const copiedUrl = this.tenancyContextApplier.addTenancyToIframeString(copiedText, currentTenancyId);
      (_a = event.clipboardData) == null ? void 0 : _a.setData("text/plain", copiedUrl.toString());
      event.preventDefault();
    }
    interceptUrlCopyLink(copiedText, event) {
      var _a;
      const copiedUrl = new URL(copiedText);
      const currentTenancyId = this.tenancyUrlService.getCurrentTenancy();
      copiedUrl.searchParams.set(TENANCY_QUERY_STRING_KEY, currentTenancyId);
      (_a = event.clipboardData) == null ? void 0 : _a.setData("text/plain", copiedUrl.toString());
      event.preventDefault();
    }
  };
  __publicField(_ClipboardInterception, "SHARED_SPACE_PATH", "/app/r/s/");
  __publicField(_ClipboardInterception, "GOTO_PATH", "/goto/");
  __publicField(_ClipboardInterception, "LOCATOR_PATH", "/app/r?l=");
  __publicField(_ClipboardInterception, "INTERCEPTED_PATHS", [
    _ClipboardInterception.GOTO_PATH,
    _ClipboardInterception.SHARED_SPACE_PATH,
    _ClipboardInterception.LOCATOR_PATH
  ]);
  var ClipboardInterception = _ClipboardInterception;

  // proxy/preKibanaProxy/injection/scripts/tenancyContext/HistoryApiPatcher.ts
  var HistoryApiPatcher = class {
    constructor(tenancyUrlService2, defaultTenancyId) {
      this.tenancyUrlService = tenancyUrlService2;
      this.defaultTenancyId = defaultTenancyId;
      __publicField(this, "lastTenancyId", null);
    }
    patchHistoryMethods() {
      ["pushState", "replaceState"].forEach((method) => {
        const original = window.history[method];
        window.history[method] = (state, title, url) => {
          if (url) {
            const newUrl = new URL(url.toString(), window.location.origin);
            this.ensureTenantInUrlParam(newUrl);
            return original.call(window.history, state, title, newUrl.toString());
          }
          return original.call(window.history, state, title, url);
        };
      });
    }
    ensureTenancyInUrl() {
      const currentUrl = this.tenancyUrlService.getCurrentUrl();
      if (!currentUrl.searchParams.has(TENANCY_QUERY_STRING_KEY)) {
        this.tenancyUrlService.setTenancyId(this.defaultTenancyId);
        window.history.replaceState(window.history.state, "", currentUrl.toString());
      }
      this.lastTenancyId = currentUrl.searchParams.get(TENANCY_QUERY_STRING_KEY);
    }
    ensureTenantInUrlParam(newUrl) {
      if (!newUrl.searchParams.has(TENANCY_QUERY_STRING_KEY)) {
        newUrl.searchParams.set(TENANCY_QUERY_STRING_KEY, this.lastTenancyId || this.defaultTenancyId);
      }
      this.lastTenancyId = this.tenancyUrlService.getCurrentTenancy();
    }
  };

  // proxy/preKibanaProxy/injection/scripts/tenancyContext/kibanaLinksRewriter.ts
  var _KibanaLinksRewriter = class _KibanaLinksRewriter {
    constructor(tenancyUrlService2) {
      this.tenancyUrlService = tenancyUrlService2;
    }
    rewriteAllLinks() {
      document.querySelectorAll("a[href]").forEach((link) => this.rewriteLinkHref(link));
    }
    rewriteLinkHref(link) {
      if (link.dataset[_KibanaLinksRewriter.TENANT_APPLIED_MARKER]) {
        return;
      }
      const tenancyId = this.tenancyUrlService.getCurrentTenancy();
      link.dataset[_KibanaLinksRewriter.TENANT_APPLIED_MARKER] = "true";
      const hrefUrl = new URL(link.href, window.location.origin);
      hrefUrl.searchParams.set(TENANCY_QUERY_STRING_KEY, tenancyId);
      link.href = hrefUrl.toString();
    }
  };
  __publicField(_KibanaLinksRewriter, "TENANT_APPLIED_MARKER", "tenantApplied");
  var KibanaLinksRewriter = _KibanaLinksRewriter;

  // proxy/preKibanaProxy/injection/scripts/tenancyContext/KibanaLinksObserver.ts
  var KibanaLinksObserver = class {
    constructor(tenancyUrlService2, kibanaLinksRewriter2, tenancyInfoApplier) {
      this.tenancyUrlService = tenancyUrlService2;
      this.kibanaLinksRewriter = kibanaLinksRewriter2;
      this.tenancyInfoApplier = tenancyInfoApplier;
      __publicField(this, "mutationObserver");
      this.mutationObserver = this.createMutationObserver();
    }
    observeAndRewriteDynamicLinks() {
      this.mutationObserver.observe(document.body, {
        attributes: true,
        childList: true,
        subtree: true
      });
    }
    createMutationObserver() {
      return new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          if (mutation.type === "attributes") {
            if (mutation.attributeName === "data-share-url") {
              this.rewriteIframeLink(mutation.target);
            }
          }
          mutation.addedNodes.forEach((node) => {
            var _a, _b;
            if (node.nodeType !== Node.ELEMENT_NODE) return;
            const element = node;
            if ((_a = element.matches) == null ? void 0 : _a.call(element, "a[href]")) {
              this.kibanaLinksRewriter.rewriteLinkHref(element);
            }
            (_b = element.querySelectorAll) == null ? void 0 : _b.call(element, "a[href]").forEach((link) => {
              this.kibanaLinksRewriter.rewriteLinkHref(link);
            });
          });
        });
      });
    }
    rewriteIframeLink(link) {
      if ((link == null ? void 0 : link.dataset) && link.dataset[KibanaLinksRewriter.TENANT_APPLIED_MARKER]) {
        return;
      }
      const shareUrl = link.dataset.shareUrl;
      const tenancyId = this.tenancyUrlService.getCurrentTenancy();
      if (!shareUrl) {
        console.log("Share URL not found on the iframe link element.");
        return;
      }
      link.dataset[KibanaLinksRewriter.TENANT_APPLIED_MARKER] = "true";
      link.dataset.shareUrl = this.tenancyInfoApplier.addTenancyToIframeString(shareUrl, tenancyId);
    }
  };

  // shared/constants/headers.ts
  var X_ROR_TENANCY = "x-ror-tenancy";

  // proxy/preKibanaProxy/injection/scripts/tenancyContext/TenancyContextApplier.ts
  var TenancyContextApplier = class {
    constructor(tenancyUrlService2) {
      this.tenancyUrlService = tenancyUrlService2;
    }
    addTenancyToIframeString(iframeString, tenancyId) {
      const parser = new DOMParser();
      const doc = parser.parseFromString(iframeString, "text/html");
      const iframe = doc.querySelector("iframe");
      if (!iframe || !iframe.src) return iframeString;
      const url = new URL(iframe.src);
      url.searchParams.set(TENANCY_QUERY_STRING_KEY, tenancyId);
      iframe.src = url.toString();
      return iframe.outerHTML;
    }
    extendHeadersWithTenancy(headers) {
      headers[X_ROR_TENANCY] = this.tenancyUrlService.getCurrentTenancy();
      return headers;
    }
  };

  // proxy/constants/errors.ts
  var errors_default = {
    wrongTypeOfIndicesSource: "Wrong type of indices source",
    notSufficientLicenseToUseFeature: (feature, licenseType = "Enterprise") => "You need a ReadonlyREST ".concat(licenseType, " license to use the ").concat(feature),
    cannotSaveClusterWideSettingsOnFreeLicense: "Cannot save cluster-wide settings on Free license",
    updateSettingsViaApiEnterpriseOnly: "You need a ReadonlyREST Enterprise license to save cluster-wide settings via ReadonlyREST API",
    unsupportedMediaType: "We are unable to process your request because the provided media type is not supported. Please ensure you are using a compatible content type.",
    internalServerError: "Internal server error",
    fileExtensionOnlyYmlSupported: "The file extension is not supported. Please upload a file with the correct yml or yaml extension.",
    fileIsRequiredField: "The file is a required field.",
    fileSizeExceeds: (maxSize) => "The file size exceeds the maximum ".concat(maxSize, " allowed limit. Please upload a smaller file."),
    cannotReloadNewSettings: "Cannot reload new settings",
    forbidByBlockWithForbidTypeMatch: 'Request was FORBIDDEN by matching a block with "forbid" type',
    testSettingsAreNotConfigured: "Request was FORBIDDEN because test settings are not configured",
    impersonationNotAllowed: "Request was FORBIDDEN because impersonation is not allowed",
    impersonationNotSupported: "Request was FORBIDDEN because impersonation is not supported",
    noAclBlockWasMatched: "No ACL block was matched",
    readonlyRestWasNotStarted: "ReadonlyREST was not started yet",
    readonlyRestFailedToStart: "ReadonlyREST failed to start",
    operationNotAllowed: "Operation not allowed",
    activationKey: {
      cantBeVerified: "This activation key can't be verified",
      licenseKeyExpired: "The License key token provided has expired.",
      invalidJwt: "Invalid JWT. The header or payload could not be parsed.",
      licenseKeyMalformed: "License key malformed. The token does not have three components (delimited by a .).",
      invalidJtwSignature: "The provided JWT token has an incorrect or tampered signature, indicating a potential unauthorized modification of the token contents.",
      noLicenseKeyProvided: "There is no activation key provided.",
      unmodified: "License token already exists is not modified. If you want to overwrite your license key use overwrite=true query string parameter."
    },
    inSufficientPermissions: "You don't have sufficient permissions to perform this operation.",
    defaultForbiddenMessage: "Forbidden by ReadonlyREST",
    cannotAuthenticate: "Cannot authenticate. Please try again later.",
    insufficientPermissions: (configPath) => "Insufficient permissions to write to Kibana config file. Please run the following commands to fix permissions: chown kibana:kibana ".concat(configPath, " && chmod 664 ").concat(configPath),
    configFileNotFound: (configPath) => "Config file not found at ".concat(configPath),
    configFileUnchanged: (configPath) => "Config file located at ".concat(configPath, " unchanged. No update needed."),
    yamlValidationError: (yamlData) => "The provided Yaml data: ".concat(JSON.stringify(yamlData), " cannot be processed. Verify the format of the Yaml data"),
    rorSettingsManager: {
      alreadyInitialized: "RorSettingsManager is already initialized",
      notInitialized: "RorSettingsManager is not initialized. Call initialize() first.",
      errorDuringSettingsAutoRefresh: "Error during configuration auto-refresh:",
      cannotReadSettingsFile: (file, reason) => "Cannot read ".concat(file, ": ").concat(reason),
      invalidSettingsInFile: (file, error) => "Invalid ReadonlyREST settings in ".concat(file, ": ").concat(error),
      invalidSettingsInIndex: (error) => "Invalid ReadonlyREST settings in the ReadonlyREST settings index: ".concat(error),
      invalidSettingsInIndexKept: (invalidSettingsInIndexError) => "".concat(invalidSettingsInIndexError, ". ReadonlyREST keeps the last valid settings from the ReadonlyREST settings index."),
      settingsInIndexValidAgain: "The ReadonlyREST settings in the ReadonlyREST settings index are valid again.",
      invalidSettingsSourceSkipped: (invalidSettingsSourceError, usedSource) => {
        const settingsSourceLabels = {
          index: "the ReadonlyREST settings index",
          file: "readonlyrest.yml",
          "kibana.yml": "kibana.yml"
        };
        const indexPriorityNote = usedSource === "index" ? " The settings in the ReadonlyREST settings index have priority. ReadonlyREST ignores this file also when the file is valid." : "";
        return "".concat(invalidSettingsSourceError, ". ReadonlyREST uses the settings from ").concat(settingsSourceLabels[usedSource], ".").concat(indexPriorityNote);
      },
      settingsNotSet: (from) => from ? "ReadonlyREST settings are not set in ".concat(from) : "ReadonlyREST settings are not set",
      settingsAreMalformed: (from) => "ReadonlyREST settings from ".concat(from, " are malformed"),
      settingsRefreshFailed: "Failed to refresh ReadonlyREST settings",
      defaultSettingsNotAvailable: (readonlyrestYmlFilenamePath) => "ReadonlyREST settings from ".concat(readonlyrestYmlFilenamePath, " are not available"),
      emptyRorIndex: "ReadonlyREST settings index exists but is empty",
      errorFetchingFromRorIndex: "Error fetching settings from ReadonlyREST settings index",
      failedToFetchingFromRorIndex: "Failed to fetch settings from ReadonlyREST settings index",
      rorKbnSectionNotFoundInIndex: "readonlyrest_kbn section not found in ReadonlyREST settings index.",
      rorKbnSectionRequiredForIndexSource: "The settings must contain the readonlyrest_kbn section, because ReadonlyREST Kibana uses the settings from the ReadonlyREST settings index.",
      noValidSourceAvailable: "No valid ROR settings source available",
      deprecatedSettingsWarnings: {
        kibanaYmlDeprecated: "You are using the deprecated ReadonlyREST configuration in kibana.yml. Migrate to the new format in readonlyrest.yml. The support for ReadonlyREST configuration in a kibana.yml will be removed in the future.",
        kibanaYmlAndIndexConflict: "You have ReadonlyREST settings in both kibana.yml and .readonlyrest index. The settings from .readonlyrest index will be used.",
        kibanaYmlAndFileConflict: "You have ReadonlyREST settings in both kibana.yml and readonlyrest.yml. The settings from readonlyrest.yml will be used.",
        readonlyrest_kbnSettingsNotAvailableInAPostRequest: (pathname) => "You are using deprecated ReadonlyREST settings in the ".concat(pathname, " request without readonlyrest_kbn section defined.")
      },
      policyValidationFailed: (policyValidationError) => "Validation failed for settings, keeping previous settings: ".concat(policyValidationError)
    },
    notAuthorizedToPerformOperation: "You are not authorized to perform this operation",
    userRequestIdentityNotAvailable: "User request identity is not available",
    groupNotDefinedInUrl: "group is not defined in URL",
    tenancy: {
      notFoundInUrl: "Tenancy not found in the current URL.",
      switchError: "Switch tenancy error",
      selectedTenancyNotAvailableForTheUser: (tenancyName) => "Selected tenancy ".concat(tenancyName, " not available for the user")
    },
    session: {
      invalidJSON: "Saved session is not a valid JSON",
      fetchSessionFailed: "Failed to fetch session from index",
      fetchSessionsFailed: "Failed to fetch sessions from index"
    }
  };

  // proxy/preKibanaProxy/injection/scripts/tenancyContext/TenancyUrlService.ts
  var TenancyUrlService = class {
    constructor(defaultTenancyId) {
      this.defaultTenancyId = defaultTenancyId;
      __publicField(this, "currentUrl");
      this.currentUrl = new URL(window.location.href);
    }
    getCurrentUrl() {
      return this.currentUrl;
    }
    getCurrentTenancy() {
      const tenancyId = this.currentUrl.searchParams.get(TENANCY_QUERY_STRING_KEY);
      if (!tenancyId) {
        console.log(errors_default.tenancy.notFoundInUrl);
        return this.defaultTenancyId;
      }
      return tenancyId;
    }
    setTenancyId(tenancyId) {
      this.currentUrl.searchParams.set(TENANCY_QUERY_STRING_KEY, tenancyId);
    }
  };

  // proxy/preKibanaProxy/injection/scripts/tenancyContext/windowOpenInterceptor.ts
  var WindowOpenInterceptor = class {
    constructor(tenancyUrlService2) {
      this.tenancyUrlService = tenancyUrlService2;
    }
    intercept() {
      const originalOpen = window.open;
      window.open = (url, target, features) => {
        const interceptedUrls = ["/api/reporting/jobs/download/"];
        if (typeof url === "string" && interceptedUrls.some((interceptedUrl) => url.includes(interceptedUrl))) {
          const originURL = new URL(url, window.location.origin);
          if (!originURL.searchParams.has(TENANCY_QUERY_STRING_KEY)) {
            originURL.searchParams.set(TENANCY_QUERY_STRING_KEY, this.tenancyUrlService.getCurrentTenancy());
          }
          return originalOpen.call(window, originURL.toString(), target, features);
        }
        return originalOpen.call(window, url, target, features);
      };
    }
  };

  // proxy/preKibanaProxy/injection/scripts/tenancyContextInjector.ts
  var DEFAULT_ENCRYPTED_TENANCY_CONTEXT = "${defaultEncryptedTenancyContext}";
  var TenancyContextInjector = class {
    constructor(kibanaLinksObserver2, kibanaLinksRewriter2, clipboardInterception2, fetchApiInterceptor, historyApiPatcher2, windowOpenInterceptor2) {
      this.kibanaLinksObserver = kibanaLinksObserver2;
      this.kibanaLinksRewriter = kibanaLinksRewriter2;
      this.clipboardInterception = clipboardInterception2;
      this.fetchApiInterceptor = fetchApiInterceptor;
      this.historyApiPatcher = historyApiPatcher2;
      this.windowOpenInterceptor = windowOpenInterceptor2;
    }
    initialize() {
      this.historyApiPatcher.ensureTenancyInUrl();
      this.historyApiPatcher.patchHistoryMethods();
      this.kibanaLinksRewriter.rewriteAllLinks();
      this.kibanaLinksObserver.observeAndRewriteDynamicLinks();
      this.fetchApiInterceptor.overrideAllKibanaApiCalls();
      this.clipboardInterception.setupClipboardInterception();
      this.windowOpenInterceptor.intercept();
    }
  };
  var tenancyUrlService = new TenancyUrlService(DEFAULT_ENCRYPTED_TENANCY_CONTEXT);
  var tenancyContextApplier = new TenancyContextApplier(tenancyUrlService);
  var kibanaLinksRewriter = new KibanaLinksRewriter(tenancyUrlService);
  var kibanaLinksObserver = new KibanaLinksObserver(tenancyUrlService, kibanaLinksRewriter, tenancyContextApplier);
  var clipboardInterception = new ClipboardInterception(tenancyUrlService, tenancyContextApplier);
  var requestInterceptor = new RequestHeadersInterceptor(() => tenancyContextApplier.extendHeadersWithTenancy({}));
  var historyApiPatcher = new HistoryApiPatcher(tenancyUrlService, DEFAULT_ENCRYPTED_TENANCY_CONTEXT);
  var windowOpenInterceptor = new WindowOpenInterceptor(tenancyUrlService);
  new TenancyContextInjector(
    kibanaLinksObserver,
    kibanaLinksRewriter,
    clipboardInterception,
    requestInterceptor,
    historyApiPatcher,
    windowOpenInterceptor
  ).initialize();
})();
