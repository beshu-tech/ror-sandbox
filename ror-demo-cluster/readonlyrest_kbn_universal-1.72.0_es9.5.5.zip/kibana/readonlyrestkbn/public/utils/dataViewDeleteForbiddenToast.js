"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var dataViewDeleteForbiddenToast_exports = {};
__export(dataViewDeleteForbiddenToast_exports, {
  interceptDataViewDeleteForbidden: () => interceptDataViewDeleteForbidden
});
module.exports = __toCommonJS(dataViewDeleteForbiddenToast_exports);
const CONTENT_MANAGEMENT_DELETE_URL_PATTERN = /\/api\/content_management\/rpc\/delete$/;
const SAVED_OBJECTS_DATA_VIEW_DELETE_URL_PATTERN = /\/api\/saved_objects\/index-pattern\/[^/?]+(\?.*)?$/;
const DATA_VIEW_CONTENT_TYPE_ID = "index-pattern";
const isDataViewDeleteRequestBody = (body) => {
  if (typeof body !== "string") return false;
  try {
    const parsed = JSON.parse(body);
    return typeof parsed === "object" && parsed !== null && parsed.contentTypeId === DATA_VIEW_CONTENT_TYPE_ID;
  } catch {
    return false;
  }
};
const isDataViewDeleteRequest = (httpErrorResponse) => {
  var _a, _b, _c, _d, _e;
  const method = (_b = (_a = httpErrorResponse.request) == null ? void 0 : _a.method) == null ? void 0 : _b.toUpperCase();
  const url = (_d = (_c = httpErrorResponse.request) == null ? void 0 : _c.url) != null ? _d : "";
  if (method === "DELETE") return SAVED_OBJECTS_DATA_VIEW_DELETE_URL_PATTERN.test(url);
  if (method === "POST" && CONTENT_MANAGEMENT_DELETE_URL_PATTERN.test(url)) {
    return isDataViewDeleteRequestBody((_e = httpErrorResponse.fetchOptions) == null ? void 0 : _e.body);
  }
  return false;
};
const interceptDataViewDeleteForbidden = (http, toasts) => http.intercept({
  responseError: (httpErrorResponse) => {
    var _a, _b;
    if (((_a = httpErrorResponse.response) == null ? void 0 : _a.status) !== 403) return;
    if (!isDataViewDeleteRequest(httpErrorResponse)) return;
    const message = (_b = httpErrorResponse.body) == null ? void 0 : _b.message;
    toasts.addDanger({
      title: "Data view could not be deleted",
      text: typeof message === "string" ? message : "You do not have permission to delete this data view."
    });
  }
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  interceptDataViewDeleteForbidden
});
