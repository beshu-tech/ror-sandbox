"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var wireForbiddenResponseHandlers_exports = {};
__export(wireForbiddenResponseHandlers_exports, {
  wireForbiddenResponseHandlers: () => wireForbiddenResponseHandlers
});
module.exports = __toCommonJS(wireForbiddenResponseHandlers_exports);
var semver = __toESM(require("semver"));
var import_bulkDeleteFailureToast = require("./bulkDeleteFailureToast");
var import_dangerToastErrorPatch = require("./dangerToastErrorPatch");
var import_dataViewDeleteForbiddenToast = require("./dataViewDeleteForbiddenToast");
var import_kibana7xSavedObjectDeleteForbiddenPatch = require("./kibana7xSavedObjectDeleteForbiddenPatch");
var import_tagAssignForbiddenToast = require("./tagAssignForbiddenToast");
var import_tagDeleteForbiddenToast = require("./tagDeleteForbiddenToast");
const wireForbiddenResponseHandlers = (core, kibanaVersion) => {
  (0, import_dangerToastErrorPatch.patchDangerToastForErrors)(core.notifications.toasts);
  (0, import_bulkDeleteFailureToast.interceptBulkDeleteFailures)(core.http, core.notifications.toasts);
  (0, import_tagDeleteForbiddenToast.interceptTagDeleteForbidden)(core.http, core.notifications.toasts);
  (0, import_tagAssignForbiddenToast.interceptTagAssignForbidden)(core.http, core.notifications.toasts);
  (0, import_kibana7xSavedObjectDeleteForbiddenPatch.interceptKibana7xSavedObjectCountsForbidden)(core.http);
  if (semver.lt(kibanaVersion, "8.7.0")) {
    (0, import_kibana7xSavedObjectDeleteForbiddenPatch.patchKibana7xSavedObjectDeleteForbidden)(core.savedObjects.client, core.notifications.toasts);
  } else if (semver.lt(kibanaVersion, "9.2.0")) {
    (0, import_dataViewDeleteForbiddenToast.interceptDataViewDeleteForbidden)(core.http, core.notifications.toasts);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  wireForbiddenResponseHandlers
});
