"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var queryStringKeys_exports = {};
__export(queryStringKeys_exports, {
  KIBANA_NEXT_URL: () => KIBANA_NEXT_URL,
  NEXT_URL: () => NEXT_URL,
  NOT_FOUND_QUERY_STRING_KEY: () => NOT_FOUND_QUERY_STRING_KEY,
  TENANCY_QUERY_STRING_KEY: () => TENANCY_QUERY_STRING_KEY
});
module.exports = __toCommonJS(queryStringKeys_exports);
const NOT_FOUND_QUERY_STRING_KEY = "not-found-url";
const TENANCY_QUERY_STRING_KEY = "tenancy";
const NEXT_URL = "nextUrl";
const KIBANA_NEXT_URL = "next";
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  KIBANA_NEXT_URL,
  NEXT_URL,
  NOT_FOUND_QUERY_STRING_KEY,
  TENANCY_QUERY_STRING_KEY
});
