/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const POPUP_THRESHOLD_IN_DAYS = 33;
const KEY_EXPIRATION_DATE = Number.parseInt('${expirationDateEpoch}', 10);
const IS_TRIAL = 'true' === '${isTrial}';

// a function that takes epoch seconds and returns the number of days until now
function daysUntilNow(epochSeconds) {
  const A_DAY_IN_MILLISECONDS = 1000 * 60 * 60 * 24;
  const now = new Date();
  const then = new Date(0);
  then.setUTCSeconds(epochSeconds);
  const diff = then - now;
  return Math.ceil(diff / A_DAY_IN_MILLISECONDS);
}

const DAYS_UNTIL_KEY_EXPIRATION = daysUntilNow(KEY_EXPIRATION_DATE);

/**
 * We need to add sessionStorage ignoreKeyExpirationInfo for automatic tests purposes as a workaround of https://github.com/cypress-io/cypress/issues/4158
 * When we reload a page, for example on tenancy change, cypress is not able to close alert automatically and, we cannot do it programmatically
 * since the window browser object changed, and we are not able to subscribe to specific onAlert event. The result is, that tests hung, and we need to close the alert manually
 * What is not the best option in case of automatic tests
 */
const manuallyIgnoreAlert = sessionStorage.getItem('ror:ignoreKeyExpirationInfo') !== 'true';
const showExpirationAlert = DAYS_UNTIL_KEY_EXPIRATION < POPUP_THRESHOLD_IN_DAYS && manuallyIgnoreAlert;
const message = IS_TRIAL
  ? `ReadonlyREST plugins for Kibana are non-free. This is a time-limited but full-featured trial build for your evaluation. Visit https://readonlyrest.com for more information.`
  : `ReadonlyREST Activation Key is about to expire. Visit https://readonlyrest.com/customer to get a new Activation Key.`;
if (showExpirationAlert) {
  window.alert(`ReadonlyREST universal build (${DAYS_UNTIL_KEY_EXPIRATION} ${
    DAYS_UNTIL_KEY_EXPIRATION > 1 ? 'days' : 'day'
  } left).\n
\n${message}\n\n
If you are already a subscriber and your payment has been received, obtain an Activation Key from https://readonlyrest.com/customer and follow the instructions to activate this software. This is a universal build, No need to reinstall a different plugin to upgrade licenses.\n`);
}
