"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.InfoApiResponse = exports.toDate = exports.isExpired = exports.LicenseInfo = exports.Licensor = exports.Licensee = exports.License = exports.Distribution = exports.Identity = void 0;
class Identity {
    username;
    kibanaHiddenApps;
    kibanaAccess;
    impersonatedBy;
    currentGroup;
    availableGroups;
    constructor(username, kibanaHiddenApps, kibanaAccess, impersonatedBy, currentGroup, availableGroups) {
        this.username = username;
        this.kibanaHiddenApps = kibanaHiddenApps;
        this.kibanaAccess = kibanaAccess;
        this.impersonatedBy = impersonatedBy;
        this.currentGroup = currentGroup;
        this.availableGroups = availableGroups;
    }
}
exports.Identity = Identity;
class Distribution {
    versionString;
    kibanaVersion;
    rorEdition;
    rorVersion;
    isProduction;
    isEnterprise;
    isPro;
    isFree;
    isBuildExpired;
    constructor(versionString, kibanaVersion, rorEdition, rorVersion, isProduction, isEnterprise, isPro, isFree, isBuildExpired) {
        this.versionString = versionString;
        this.kibanaVersion = kibanaVersion;
        this.rorEdition = rorEdition;
        this.rorVersion = rorVersion;
        this.isProduction = isProduction;
        this.isEnterprise = isEnterprise;
        this.isPro = isPro;
        this.isFree = isFree;
        this.isBuildExpired = isBuildExpired;
    }
}
exports.Distribution = Distribution;
class License {
    edition;
    edition_name;
    constructor(edition, edition_name) {
        this.edition = edition;
        this.edition_name = edition_name;
    }
}
exports.License = License;
class Licensee {
    name;
    buying_for;
    constructor(name, buying_for) {
        this.name = name;
        this.buying_for = buying_for;
    }
}
exports.Licensee = Licensee;
class Licensor {
    name;
    contact;
    constructor(name, contact) {
        this.name = name;
        this.contact = contact;
    }
}
exports.Licensor = Licensor;
class LicenseInfo {
    license;
    licensee;
    licensor;
    exp;
    iat;
    jti;
    constructor(license, licensee, licensor, exp, iat, jti) {
        this.license = license;
        this.licensee = licensee;
        this.licensor = licensor;
        this.exp = exp;
        this.iat = iat;
        this.jti = jti;
    }
}
exports.LicenseInfo = LicenseInfo;
function isExpired(li) {
    return li.exp < Date.now() / 1000;
}
exports.isExpired = isExpired;
function toDate(n) {
    return new Date(n * 1000);
}
exports.toDate = toDate;
class InfoApiResponse {
    identity;
    licenseInfo;
    distribution;
    cluster_uuid;
    constructor(identity, licenseInfo, distribution, cluster_uuid) {
        this.identity = identity;
        this.licenseInfo = licenseInfo;
        this.distribution = distribution;
        this.cluster_uuid = cluster_uuid;
    }
}
exports.InfoApiResponse = InfoApiResponse;
