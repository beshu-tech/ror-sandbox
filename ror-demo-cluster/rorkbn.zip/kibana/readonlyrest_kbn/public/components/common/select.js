/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
// This component is extracted from EUI, which is released under Apache License 2.0
/*
* Licensed to Elasticsearch B.V. under one or more contributor
* license agreements. See the NOTICE file distributed with
* this work for additional information regarding copyright
* ownership. Elasticsearch B.V. licenses this file to you under
* the Apache License, Version 2.0 (the "License"); you may
* not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/
import * as React from 'react';
import classNames from 'classnames';
import { FormControlLayout } from "./formControlLayout";
export const Select = (_a) => {
    var { className, options = [], id, name, inputRef, fullWidth = false, hasNoInitialSelection = false, defaultValue, compressed = false, value, onChange } = _a, rest = __rest(_a, ["className", "options", "id", "name", "inputRef", "fullWidth", "hasNoInitialSelection", "defaultValue", "compressed", "value", "onChange"]);
    const classes = classNames('euiSelect', {
        'euiSelect--fullWidth': fullWidth,
        'euiSelect--compressed': compressed,
    }, className);
    let emptyOptionNode;
    if (hasNoInitialSelection) {
        emptyOptionNode = (React.createElement("option", { value: "", disabled: true, hidden: true, style: { display: 'none' } }, "\u00A0"));
    }
    // React HTML input can not have both value and defaultValue properties.
    // https://reactjs.org/docs/uncontrolled-components.html#default-values
    let selectDefaultValue;
    if (value == null) {
        selectDefaultValue = defaultValue || '';
    }
    return (React.createElement(FormControlLayout, { fullWidth: fullWidth, compressed: compressed },
        React.createElement("select", Object.assign({ id: id, name: name, className: classes, ref: inputRef, defaultValue: selectDefaultValue, value: value, onChange: onChange }, rest),
            emptyOptionNode,
            options.map((option, index) => {
                return (React.createElement("option", { value: option.value, key: index }, option.label));
            }))));
};
