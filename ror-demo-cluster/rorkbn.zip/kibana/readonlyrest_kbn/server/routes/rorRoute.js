/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

"use strict";

import settingsHandler from "./lib/settings_handler";
import injectMirror from "./lib/inject_mirror";
import initAuth from "./lib/auth.js";
import constants from './lib/constants'

export default async function (kibana, server) {

  eval(atob('aWYoZXZhbChhdG9iKCJNVFk1TkRNMU56WTJOalUwT1NBK0lEQWdKaVlnY0dGeWMyVkpiblFvWVhSdllpZ2lUVlJCZWsxNlVYbE9la1Y1VGtSck0wMXFSVDBpS1NrZ1BDQW9ibVYzSUVSaGRHVW9LU2t1WjJWMFZHbHRaU2dwIikpKXt0aHJvdyBuZXcgRXJyb3IoYXRvYigiVW1WaFpHOXViSGxTUlZOVUlHWnZjaUJMYVdKaGJtRWdhR0ZzZEdWa0lHSmxZMkYxYzJVZ2VXOTFjaUIwY21saGJDQm9ZWE1nWlhod2FYSmxaQ3dnYjNJZ2RHaHBjeUJpZFdsc1pDQnBjeUIzWVhrZ2RHOXZJRzlzWkM0Z1IyVjBJSFJvWlNCc1lYUmxjM1FnWW5WcGJHUXNJRzl5SUdkbGRDQmhjM05wYzNSaGJtTmxJR0YwSUdGMElHaDBkSEJ6T2k4dmNtVmhaRzl1YkhseVpYTjBMbU52YlE9PSIpKX0='))
  const logger = constants.getLogger('readonlyrest_kbn:rorRoute')

  // Routes in the end

  const additionalRoutes = [
    {
      path: '/api/readonlyrest_kbn/settings',
      method: 'GET',
      handler: function (request, h) {
        return settingsHandler(server, request, h)
      }
    },
    {
      path: '/api/ror/injectMirror',
      method: 'GET',
      handler: function (request, h) {
        return injectMirror(server, request, h)
      }
    },
    {
      path: '/api/readonlyrest_kbn/settings/file',
      method: 'GET',
      handler: function (request, h) {
        return settingsHandler(server, request, h)
      }
    },
    {
      path: '/api/readonlyrest_kbn/settings',
      method: 'POST',
      handler: function (request, h) {
        return settingsHandler(server, request, h)
      }
    }]


  // Initialize cookie-based local auth
  await initAuth(kibana, server, additionalRoutes)
}
