"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const button_1 = require("./button");
const arrowLeftIcon_1 = require("../icons/arrowLeftIcon");
function MenuButton({ handleClick, text, className }) {
    return ((0, jsx_runtime_1.jsxs)(button_1.Button, { onClick: handleClick, className: `ror_menu_button ${className}`, fullWidth: true, textProps: { style: { display: 'flex', justifyContent: 'space-between' } }, children: [(0, jsx_runtime_1.jsx)(arrowLeftIcon_1.ArrowLeftIcon, { fill: "#006BB4" }), (0, jsx_runtime_1.jsx)("div", { style: { flex: 1, marginRight: '24px' }, children: text })] }));
}
exports.default = MenuButton;
