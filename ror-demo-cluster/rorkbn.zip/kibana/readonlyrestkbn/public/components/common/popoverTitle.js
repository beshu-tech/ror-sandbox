"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function PopoverTitle({ children }) {
    const theme = sessionStorage.getItem('rorTheme');
    const borderColor = theme === 'dark' ? '#4d4c4c' : '#d3dae6';
    return ((0, jsx_runtime_1.jsx)(eui_1.EuiPopoverTitle, { style: { color: 'inherit', borderBottom: `1px solid ${borderColor}` }, children: children }));
}
exports.default = PopoverTitle;
