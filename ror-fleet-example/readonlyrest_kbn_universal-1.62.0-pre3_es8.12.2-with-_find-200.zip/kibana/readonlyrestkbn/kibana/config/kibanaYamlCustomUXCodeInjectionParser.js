"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseCustomUxCodeInjection = exports.parseJsFile = exports.parseCssFile = void 0;
const fs_1 = __importDefault(require("fs"));
const rorLoggerFactory_1 = require("../../proxy/core/logging/rorLoggerFactory");
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
function isCustomCodeInjectionConfigPresent(rorObject) {
    return (rorObject.kibana_custom_css_inject != null ||
        rorObject.kibana_custom_css_inject_file != null ||
        rorObject.kibana_custom_js_inject != null ||
        rorObject.kibana_custom_js_inject_file != null);
}
function parseCssFile(customUserCssFilePath) {
    let customUserCssFileContent;
    try {
        logger.trace(`Reading css file from file ${customUserCssFilePath}`);
        customUserCssFileContent = fs_1.default.readFileSync(customUserCssFilePath).toString();
    }
    catch (error) {
        if (error.code === 'ENOENT') {
            logger.error(`Custom CSS file not found in the path ${customUserCssFilePath}!`);
        }
        throw error;
    }
    return customUserCssFileContent;
}
exports.parseCssFile = parseCssFile;
function parseJsFile(customUserJsFilePath) {
    let customUserJSFileContent;
    try {
        logger.trace(`Reading js file from file ${customUserJsFilePath}`);
        customUserJSFileContent = fs_1.default.readFileSync(customUserJsFilePath).toString();
    }
    catch (error) {
        if (error.code === 'ENOENT') {
            logger.error(`Custom JS file not found in the path ${customUserJsFilePath}!`);
        }
        throw error;
    }
    return customUserJSFileContent;
}
exports.parseJsFile = parseJsFile;
function parseCustomUxCodeInjection(rorObject) {
    if (rorObject == null || !isCustomCodeInjectionConfigPresent(rorObject)) {
        return undefined;
    }
    const customUserCssFileContent = rorObject.kibana_custom_css_inject_file
        ? parseCssFile(rorObject.kibana_custom_css_inject_file)
        : undefined;
    const customUserJsFileContent = rorObject.kibana_custom_js_inject_file
        ? parseJsFile(rorObject.kibana_custom_js_inject_file)
        : undefined;
    return {
        css: rorObject.kibana_custom_css_inject,
        cssFileContent: customUserCssFileContent,
        js: rorObject.kibana_custom_js_inject,
        jsFileContent: customUserJsFileContent
    };
}
exports.parseCustomUxCodeInjection = parseCustomUxCodeInjection;
