"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.rorInitialization = exports.verifyCompliance = exports.verifyKibanaConfigProperties = void 0;
const cookieManager_1 = require("../../proxy/core/cookieManager");
const esSSLConnectionProvider_1 = require("../../proxy/core/esSSLConnectionProvider");
const esHostBalancer_1 = require("../../proxy/core/esHostBalancer");
const esClient_1 = require("../../proxy/core/esClient");
const sessionManagerFactory_1 = require("../../proxy/core/sessionManager/sessionManagerFactory");
const rorRequestAppender_1 = require("../../proxy/core/rorRequestAppender");
const LicenseService_1 = require("../../proxy/core/license/LicenseService");
const preKibanaProxy_1 = require("../../proxy/preKibanaProxy/preKibanaProxy");
const preElasticsearchProxy_1 = require("../../proxy/preElasticsearchProxy/preElasticsearchProxy");
const kibanaYamlRorConfigParser_1 = require("./kibanaYamlRorConfigParser");
const rorStoreInitializer_1 = require("./rorStoreInitializer");
const authorizationHeadersValidation_1 = require("../../proxy/core/authorization/authorizationHeadersValidation");
const authorizationHeadersCollector_1 = require("../../proxy/core/authorization/authorizationHeadersCollector");
const rorLoggerFactory_1 = require("../../proxy/core/logging/rorLoggerFactory");
const ActivationKey_1 = require("../../proxy/core/license/ActivationKey");
const configUtils_1 = require("./configUtils");
const kibanaYamlKibanaConfigParser_1 = require("./kibanaYamlKibanaConfigParser");
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
function verifyKibanaConfigProperties(kibanaConfigForPkp, rorConfig, license) {
    if (kibanaConfigForPkp.kibanaIndex !== kibanaYamlKibanaConfigParser_1.DEFAULT_KIBANA_INDEX &&
        (0, ActivationKey_1.isEnterpriseLicense)(license) &&
        rorConfig.multiTenancyEnabled) {
        (0, configUtils_1.exitInOneSecond)();
        throw new Error('A custom `kibana.index` value is not allowed when `readonlyrest_kbn.multiTenancyEnabled` is set to true (default: true)! This is to prevent inconsistent behaviour. Disable multi-tenancy if you really need a non standard `kibana index`. Questions? Please use the Forum https://forum.readonlyrest.com.');
    }
    return true;
}
exports.verifyKibanaConfigProperties = verifyKibanaConfigProperties;
function initializeSharedServices(elasticsearchConfig, kibanaConfigForPkp, kibanaConfigForPep, rorConfig, licenseService) {
    const esSSLConnectionProvider = new esSSLConnectionProvider_1.EsSSLConnectionProvider(elasticsearchConfig.sslConfig);
    const esHostBalancer = new esHostBalancer_1.EsHostBalancer(elasticsearchConfig.elasticsearchHosts, kibanaConfigForPep.networkParameters, elasticsearchConfig.kibanaTechUserEsAuthToken, esSSLConnectionProvider);
    const esClient = new esClient_1.EsClient(elasticsearchConfig.kibanaTechUserEsAuthToken, esHostBalancer, esSSLConnectionProvider, rorConfig.multiTenancyEnabled, elasticsearchConfig.customHeaders, kibanaConfigForPkp.kibanaIndex);
    const sessionManager = sessionManagerFactory_1.SessionManagerFactory.build(esClient, rorConfig.sessionManagerConfig, rorConfig.sessionConfig, licenseService, kibanaConfigForPkp.reportingQueueTimeout);
    const cookieManager = new cookieManager_1.CookieManager(rorConfig.cookieConfig);
    const rorRequestAppender = new rorRequestAppender_1.RorRequestAppender(sessionManager, cookieManager);
    const authorizationHeadersCollector = new authorizationHeadersCollector_1.AuthorizationHeadersCollector(rorConfig.proxyAuthConfig, rorConfig.jwtQueryParam, rorConfig?.authConfig?.signatureKey);
    const authorizationHeadersValidation = new authorizationHeadersValidation_1.AuthorizationHeadersValidation(authorizationHeadersCollector, elasticsearchConfig.requestHeadersWhitelist, esClient);
    return {
        cookieManager,
        esSSLConnectionProvider,
        esHostBalancer,
        esClient,
        sessionManager,
        rorRequestAppender,
        licenseService,
        authorizationHeadersCollector,
        authorizationHeadersValidation
    };
}
function initializePkp(kibanaConfigForPkp, rorConfig, sharedServices, elasticsearchConfig) {
    const preKibanaProxyParams = {
        pkpHostAndPort: kibanaConfigForPkp.pkpHostAndPort,
        kibanaUrl: kibanaConfigForPkp.kibanaUrl,
        kibanaIndex: kibanaConfigForPkp.kibanaIndex,
        kibanaTemplateIndex: rorConfig.kibanaTemplateIndex,
        resetKibanaIndexToTemplate: rorConfig.resetKibanaIndexToTemplate,
        kibanaBasePath: kibanaConfigForPkp.kibanaBasePath,
        rewriteBasePath: kibanaConfigForPkp.rewriteBasePath,
        pkpKibanaToken: rorConfig.pkpKibanaToken,
        auth: rorConfig.authConfig,
        sessionConfig: rorConfig.sessionConfig,
        kibanaSSLConfig: kibanaConfigForPkp.kibanaSslConfig,
        customUXCodeInjection: rorConfig.customUXCodeInjection,
        customLogoutLink: rorConfig.customLogoutLink,
        customLoginLink: rorConfig.customLoginLink,
        proxyAuth: rorConfig.proxyAuthConfig,
        jwtQueryParam: rorConfig.jwtQueryParam,
        whitelistedPaths: rorConfig.whitelistedPaths,
        requestHeadersWhitelist: elasticsearchConfig.requestHeadersWhitelist,
        loginPageCustomizations: rorConfig.loginPageCustomizations,
        cookieConfig: rorConfig.cookieConfig,
        clearSessionOnEvents: rorConfig.clearSessionOnEvents,
        licenseService: sharedServices.licenseService,
        spacesEnabled: rorConfig.spacesEnabled,
        multiTenancyEnabled: rorConfig.multiTenancyEnabled,
        customMiddlewareInjectFile: rorConfig.customMiddlewareInjectFile,
        customMiddlewareInject: rorConfig.customMiddlewareInject,
        reportingQueueTimeout: kibanaConfigForPkp.reportingQueueTimeout,
        tenantIndex: rorConfig.tenantIndex
    };
    try {
        new preKibanaProxy_1.PreKibanaProxy(sharedServices.sessionManager, sharedServices.cookieManager, sharedServices.rorRequestAppender, sharedServices.esClient, sharedServices.authorizationHeadersCollector, sharedServices.authorizationHeadersValidation, preKibanaProxyParams);
    }
    catch (e) {
        logger.error('Error initialising PKP', e);
    }
}
// TODO: kibana.index and xpack.reporting.index should be randomized, so we have a string like .kibana_<uuid> to be able to recognise it
// if the user places an unrecognisable string like "kibana.index: a" in kibana.yml
function initializePep(kibanaConfigForPep, rorConfig, sharedServices) {
    const preElasticsearchProxyParams = {
        port: kibanaConfigForPep.pepPort,
        networkParameters: kibanaConfigForPep.networkParameters,
        kibanaIndex: kibanaConfigForPep.kibanaIndex,
        reportingIndex: kibanaConfigForPep.reportingIndex,
        kibanaTechUserEsAuthToken: kibanaConfigForPep.kibanaTechUserEsAuthToken,
        requestHeadersWhitelist: kibanaConfigForPep.requestHeadersWhitelist,
        multiTenancyEnabled: rorConfig.multiTenancyEnabled
    };
    return new preElasticsearchProxy_1.PreElasticsearchProxy(sharedServices.sessionManager, sharedServices.rorRequestAppender, sharedServices.esHostBalancer, sharedServices.esSSLConnectionProvider, preElasticsearchProxyParams, sharedServices.authorizationHeadersValidation, sharedServices.licenseService);
}
function verifyCompliance(licenseService, rorConfig) {
    licenseService.getCompliance().verify([
        { message: 'SAML authentication', value: rorConfig.authConfig?.samlConfigurations },
        { message: 'OIDC authentication', value: rorConfig.authConfig?.oidcConfigurations },
        { message: 'Tenancy Templating', value: rorConfig.kibanaTemplateIndex },
        { message: 'Custom CSS/JS Injections', value: rorConfig.customUXCodeInjection },
        {
            message: 'Custom middleware',
            value: rorConfig.customMiddlewareInject || rorConfig.customMiddlewareInjectFile
        }
    ], [{ message: 'Login page customizations', value: rorConfig.loginPageCustomizations }]);
}
exports.verifyCompliance = verifyCompliance;
/*
 * We need to mutate and return the deepObject back to Kibana SYNCHRONOUSLY,
 * otherwise Kibana gets started on port 5601, where PKP should bind instead.
 *
 * There is no way to initialize async ROR components while
 * synchronoulsy waiting for them, and then returning deepObject back to Kibana.
 *
 * I tried 'desync', but it's implemented in C++ and it's not portable.
 *
 * 1. Keep the bulk of ROR initialization synchronous
 * 2. When you initialize something asynchronously (like licenseService),
 * be aware you won't have it initialised during ROR init, at all.
 */
function rorInitialization(deepObject, elasticsearchConfig, kibanaConfigForPkp, kibanaConfigForPep) {
    const rorConfig = (0, kibanaYamlRorConfigParser_1.parseRorConfig)(deepObject);
    const decode = (token) => Buffer.from(token, 'base64').toString('binary');
    const tokenPubKey = decode('LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlHYk1CQUdCeXFHU000OUFnRUdCU3VCQkFBakE0R0dBQVFCZW9UZTF1UDhCaFRSdFdDR2hNTThJWUFwSElKRgppTWJXcEJFa0M2ZHJoMlpXSzVkSTFxL25' +
        'ENzltU1laVjBzWlFjTTROclVZQ0J3YkpDWlZLTHlIWlh0Y0E4Vld0CmlqN05NWlkrUEJDemtvQVJDbUlKZHprQkI5a1RxRFB6U29aZkRqQW54ZzF5OGxoUVR1dFJ2Z09jTUhKRDgrd3kKV3hLYlU2L1JCVFU2' +
        'd2pJZE5pND0KLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0t');
    const licenseService = new LicenseService_1.LicenseService(rorConfig.cookieConfig.password, tokenPubKey, rorConfig.licenseConfiguration);
    const sharedServices = initializeSharedServices(elasticsearchConfig, kibanaConfigForPkp, kibanaConfigForPep, rorConfig, licenseService);
    initializePep(kibanaConfigForPep, rorConfig, sharedServices);
    sharedServices.esClient.waitForES().then(() => {
        sharedServices.sessionManager.init();
        // We can't wait on this async task to complete, unfortunately.
        licenseService
            .init(sharedServices.esClient)
            .catch(e => {
            logger.error('Error initializing license service', e);
        })
            .then(() => {
            logger.debug('license service initialized');
            verifyKibanaConfigProperties(kibanaConfigForPkp, rorConfig, licenseService.getActivationKey().license);
            verifyCompliance(licenseService, rorConfig);
            (0, rorStoreInitializer_1.initializeRorStore)(kibanaConfigForPkp, rorConfig);
            initializePkp(kibanaConfigForPkp, rorConfig, sharedServices, elasticsearchConfig);
        });
    });
}
exports.rorInitialization = rorInitialization;
