"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    wrongTypeOfIndicesSource: 'Wrong type of indices source',
    notSufficientLicenseToUseImpersonateFeature: 'You need a ReadonlyREST Enterprise license to use the impersonate feature',
    cannotSaveClusterWideSettingsOnFreeLicense: 'Cannot save cluster-wide settings on Free license',
    updateSettingsViaApiEnterpriseOnly: 'You need a ReadonlyREST Enterprise license to save cluster-wide settings via ReadonlyREST API',
    unsupportedMediaType: 'We are unable to process your request because the provided media type is not supported. Please ensure you are using a compatible content type.',
    internalServerError: 'Internal server error',
    fileExtensionOnlyYmlSupported: 'The file extension is not supported. Please upload a file with the correct yml or yaml extension.',
    fileIsRequiredField: 'The file is a required field.',
    fileSizeExceeds: (maxSize) => `The file size exceeds the maximum ${maxSize} allowed limit. Please upload a smaller file.`,
    cannotReloadNewSettings: 'Cannot reload new settings',
    forbidByBlockWithForbidTypeMatch: 'Request was FORBIDDEN by matching a block with "forbid" type',
    noAclBlockWasMatched: 'No ACL block was matched',
    readonlyRestWasNotStarted: 'ReadonlyREST was not started yet',
    readonlyRestFailedToStart: 'ReadonlyREST failed to start',
    operationNotAllowed: `Operation not allowed`,
    activationKey: {
        cantBeVerified: "This activation key can't be verified",
        licenseKeyExpired: 'The License key token provided has expired.',
        invalidJwt: 'Invalid JWT. The header or payload could not be parsed.',
        licenseKeyMalformed: 'License key malformed. The token does not have three components (delimited by a .).',
        invalidJtwSignature: 'The provided JWT token has an incorrect or tampered signature, indicating a potential unauthorized modification of the token contents.',
        noLicenseKeyProvided: 'There is no activation key provided.',
        unmodified: 'License token already exists is not modified. If you want to overwrite your license key use overwrite=true query string parameter.'
    },
    inSufficientPermissions: "You don't have sufficient permissions to perform this operation."
};
