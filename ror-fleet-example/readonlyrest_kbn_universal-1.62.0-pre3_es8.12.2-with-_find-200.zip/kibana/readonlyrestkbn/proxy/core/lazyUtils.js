"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeWithInterval = void 0;
const rorLoggerFactory_1 = require("./logging/rorLoggerFactory");
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
const sleep = (time) => new Promise(resolve => {
    setTimeout(resolve, time);
});
const executeWithInterval = async (fn, interval) => {
    try {
        await fn();
    }
    catch (e) {
        logger.error(`Caught an error in executeWithInterval`, e);
    }
    finally {
        await sleep(interval);
        await (0, exports.executeWithInterval)(fn, interval);
    }
};
exports.executeWithInterval = executeWithInterval;
