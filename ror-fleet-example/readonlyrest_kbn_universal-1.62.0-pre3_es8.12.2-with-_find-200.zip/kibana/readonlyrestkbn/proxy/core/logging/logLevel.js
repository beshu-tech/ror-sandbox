"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLogFormattedTime = exports.getLogLevelDescription = exports.getAcceptedLogLevelValues = exports.LogLevel = void 0;
var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["ERROR"] = 0] = "ERROR";
    LogLevel[LogLevel["WARN"] = 1] = "WARN";
    LogLevel[LogLevel["INFO"] = 2] = "INFO";
    LogLevel[LogLevel["DEBUG"] = 3] = "DEBUG";
    LogLevel[LogLevel["TRACE"] = 4] = "TRACE";
})(LogLevel = exports.LogLevel || (exports.LogLevel = {}));
function getAcceptedLogLevelValues() {
    return Object.keys(LogLevel)
        .filter(key => !Number.isNaN(Number(LogLevel[key])))
        .map(key => key.toString().toLowerCase());
}
exports.getAcceptedLogLevelValues = getAcceptedLogLevelValues;
function getLogLevelDescription(logLevel) {
    switch (logLevel) {
        case LogLevel.WARN:
            return 'warning';
        default:
            return LogLevel[logLevel].toString().toLowerCase();
    }
}
exports.getLogLevelDescription = getLogLevelDescription;
const leftPad = (valueToPad, length, char = '0') => String(valueToPad).length >= length ? `${valueToPad}` : (String(char).repeat(length) + valueToPad).slice(-length);
function getLogFormattedTime() {
    const date = new Date();
    return [
        leftPad(date.getHours(), 2),
        leftPad(date.getMinutes(), 2),
        leftPad(date.getSeconds(), 2),
        leftPad(date.getMilliseconds(), 3)
    ].join(':');
}
exports.getLogFormattedTime = getLogFormattedTime;
