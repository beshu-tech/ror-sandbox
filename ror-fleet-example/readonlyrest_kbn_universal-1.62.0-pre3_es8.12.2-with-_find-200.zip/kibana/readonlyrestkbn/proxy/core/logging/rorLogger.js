"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RorLogger = void 0;
const logLevel_1 = require("./logLevel");
class RorLogger {
    static impersonating;
    static correlationId;
    logAppenders;
    constructor(logAppenders) {
        this.logAppenders = logAppenders;
    }
    static clearImpersonatingInfo() {
        RorLogger.impersonating = undefined;
    }
    static clearCorrelationId() {
        RorLogger.correlationId = undefined;
    }
    static appendImpersonatingInfo(impersonating) {
        RorLogger.impersonating = impersonating;
    }
    static appendCorrelationId(correlationId) {
        RorLogger.correlationId = correlationId;
    }
    error(message, ...optionalParams) {
        this.logAppenders.forEach(logAppender => {
            logAppender.log(logLevel_1.LogLevel.ERROR, message, RorLogger.impersonating, RorLogger.correlationId, ...optionalParams);
        });
    }
    warn(message, ...optionalParams) {
        this.logAppenders.forEach(logAppender => {
            logAppender.log(logLevel_1.LogLevel.WARN, message, RorLogger.impersonating, RorLogger.correlationId, ...optionalParams);
        });
    }
    info(message, ...optionalParams) {
        this.logAppenders.forEach(logAppender => {
            logAppender.log(logLevel_1.LogLevel.INFO, message, RorLogger.impersonating, RorLogger.correlationId, ...optionalParams);
        });
    }
    debug(message, ...optionalParams) {
        this.logAppenders.forEach(logAppender => {
            logAppender.log(logLevel_1.LogLevel.DEBUG, message, RorLogger.impersonating, RorLogger.correlationId, ...optionalParams);
        });
    }
    trace(message, ...optionalParams) {
        this.logAppenders.forEach(logAppender => {
            logAppender.log(logLevel_1.LogLevel.TRACE, message, RorLogger.impersonating, RorLogger.correlationId, ...optionalParams);
        });
    }
}
exports.RorLogger = RorLogger;
