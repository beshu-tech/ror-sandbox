"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionManager = void 0;
const uuid_1 = require("uuid");
const ActivationKey_1 = require("../license/ActivationKey");
const accessLevel_1 = require("../common/accessLevel");
const rorLoggerFactory_1 = require("../logging/rorLoggerFactory");
const EXCLUDED_SESSION_TIMEOUT_REFRESH_PATHS = ['/api/ui_counters/_report', '/api/licensing/info'];
const logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
class SessionManager {
    cleanAfterGet(licenseService, session) {
        const metadata = session;
        const license = licenseService.getActivationKey().license;
        const isEnt = (0, ActivationKey_1.isEnterpriseLicense)(license);
        const isFree = (0, ActivationKey_1.isFreeLicense)(license);
        const identity = {
            username: metadata.username,
            kibanaHiddenApps: isFree ? [] : metadata.kibanaHiddenApps,
            kibanaAccess: metadata.kibanaAccess || accessLevel_1.AccessLevel.UNRESTRICTED,
            currentGroup: isEnt ? metadata.currentGroup : undefined,
            availableGroups: isEnt ? metadata.availableGroups : [],
            authorizationHeaders: metadata.authorizationHeaders,
            expiresAt: metadata.expiresAt,
            lastSessionActivityDate: metadata.lastSessionActivityDate,
            origin: metadata.origin,
            impersonatedBy: isEnt ? metadata.impersonatedBy : undefined,
            correlationId: metadata.correlationId,
            kibanaIndex: metadata.kibanaIndex,
            kibanaTemplateIndex: metadata.kibanaTemplateIndex,
            customMetadata: metadata.customMetadata
        };
        return identity;
    }
    mostRecentlyAccessed = null;
    createNewSessionExpirationDate = () => new Date(Date.now() + this.sessionTimeoutMillis);
    getMostRecentlyAccessed = () => this.mostRecentlyAccessed;
    clearMostRecentlyAccessed = () => {
        this.mostRecentlyAccessed = undefined;
    };
    async exists(sid) {
        return (await this.get(sid)) != null;
    }
    async isSessionExpired(sid) {
        const session = await this.get(sid);
        if (!session?.expiresAt) {
            return true;
        }
        return session.expiresAt.getTime() < Date.now();
    }
    refreshSession = async (sid, currentUrl, nextRefreshAfterInSeconds = 2) => {
        const oldSession = await this.get(sid);
        const correlationId = oldSession?.correlationId;
        if (!oldSession) {
            throw new Error('The previous session cannot be accessed.');
        }
        if (!correlationId) {
            logger.trace('The previous correlationId cannot be retrieved.');
        }
        const lastSessionActivityDate = this.refreshLastSessionActivityDate(oldSession, sid, currentUrl);
        const oldSessionLastActivityDate = oldSession.lastSessionActivityDate;
        const differenceInSeconds = !lastSessionActivityDate || !oldSessionLastActivityDate
            ? undefined
            : (lastSessionActivityDate.getTime() - oldSessionLastActivityDate.getTime()) / 1000;
        if (differenceInSeconds && differenceInSeconds <= nextRefreshAfterInSeconds) {
            logger.trace(`The time since the last activity is ${differenceInSeconds} second, which is less than the required ${nextRefreshAfterInSeconds} seconds for the next refresh. Returning the old session.”`);
            return oldSession;
        }
        const newSession = {
            expiresAt: this.createNewSessionExpirationDate(),
            lastSessionActivityDate,
            authorizationHeaders: new Map([...Array.from(oldSession.authorizationHeaders.entries())]),
            username: oldSession.username,
            currentGroup: oldSession.currentGroup,
            availableGroups: oldSession.availableGroups ? [...oldSession.availableGroups] : [],
            kibanaHiddenApps: oldSession.kibanaHiddenApps ? [...oldSession.kibanaHiddenApps] : [],
            kibanaAccess: oldSession.kibanaAccess,
            kibanaIndex: oldSession.kibanaIndex,
            kibanaTemplateIndex: oldSession.kibanaTemplateIndex,
            origin: oldSession.origin,
            impersonatedBy: oldSession.impersonatedBy,
            allowedApiPaths: oldSession.allowedApiPaths,
            correlationId: correlationId || (0, uuid_1.v4)(),
            customMetadata: oldSession.customMetadata
        };
        await this.set(sid, newSession);
        logger.trace(`Session refreshed successfully after ${differenceInSeconds} seconds.`);
        return newSession;
    };
    refreshLastSessionActivityDate(session, sid, currentUrl) {
        if (EXCLUDED_SESSION_TIMEOUT_REFRESH_PATHS.includes(currentUrl)) {
            return session.lastSessionActivityDate;
        }
        return new Date();
    }
    async lastSessionActivityDate(sid) {
        const session = await this.get(sid);
        if (!session) {
            return;
        }
        return session.lastSessionActivityDate;
    }
    async isSessionTimeout(sid) {
        const currentTimeInMillis = new Date().getTime();
        const lastSessionActivityDate = await this.lastSessionActivityDate(sid);
        if (!lastSessionActivityDate) {
            return true;
        }
        const lastSessionActivityTimeInMillis = currentTimeInMillis - lastSessionActivityDate.getTime();
        return this.sessionTimeoutMillis < lastSessionActivityTimeInMillis;
    }
}
exports.SessionManager = SessionManager;
