"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OidcRouterConfigFactory = exports.OidcRouterConfig = void 0;
const rorLoggerFactory_1 = require("../../../core/logging/rorLoggerFactory");
const SSO_PREFIX = 'ror_kbn_';
const ROUTES = {
    LOGIN: '/login-ep',
    LOGOUT: '/logout-ep',
    LOGIN_CALLBACK: '/callback',
    LOGOUT_CALLBACK: '/logout-callback'
};
class OidcRouterConfig {
    connectorName;
    buttonName;
    routerPath;
    scope;
    issuer;
    usernameParameter;
    groupsParameter;
    clientId;
    clientSecret;
    oidcTokenURL;
    oidcAuthorizationURL;
    oidcUserInfoURL;
    oidcLogoutUrl;
    loginPath;
    logoutPath;
    loginCallbackPath;
    logoutCallbackPath;
    loginCallbackURL;
    logoutCallbackUrl;
    jwksURL;
    kibanaExternalHost;
    proxyURL;
    tokenEndpointAuthMethod;
    cookieConfig;
    constructor(basePath, config, cookieConfig) {
        this.connectorName = config.name;
        this.buttonName = config.buttonName;
        this.routerPath = `${basePath}/${SSO_PREFIX}${config.name}`;
        this.scope = config.scope;
        this.issuer = config.issuer;
        this.usernameParameter = config.usernameParameter;
        this.groupsParameter = config.groupsParameter;
        this.clientId = config.clientId;
        this.clientSecret = config.clientSecret;
        this.oidcTokenURL = config.tokenURL;
        this.oidcAuthorizationURL = config.authorizationURL;
        this.oidcUserInfoURL = config.userInfoURL;
        this.oidcLogoutUrl = config.logoutUrl;
        this.loginPath = ROUTES.LOGIN;
        this.logoutPath = ROUTES.LOGOUT;
        this.loginCallbackPath = ROUTES.LOGIN_CALLBACK;
        this.logoutCallbackPath = ROUTES.LOGOUT_CALLBACK;
        this.loginCallbackURL = `${config.protocol}://${config.kibanaExternalHost + this.routerPath + ROUTES.LOGIN_CALLBACK}`;
        this.logoutCallbackUrl = `${config.protocol}://${config.kibanaExternalHost + this.routerPath + ROUTES.LOGOUT_CALLBACK}`;
        this.cookieConfig = {
            name: `${cookieConfig.name}_${config.name}`,
            password: cookieConfig.password
        };
        this.jwksURL = config.jwksURL;
        this.kibanaExternalHost = config.kibanaExternalHost;
        this.proxyURL = config.proxyURL;
        this.tokenEndpointAuthMethod = config.tokenEndpointAuthMethod;
    }
    loginPathRelativeToRoot() {
        return `${this.routerPath}${this.loginPath}`;
    }
    logoutPathRelativeToRoot() {
        return `${this.routerPath}${this.logoutPath}`;
    }
    toLegacySsoButtonProps() {
        return {
            name: this.connectorName,
            type: 'oidc',
            buttonName: this.buttonName,
            loginUrl: this.loginPathRelativeToRoot()
        };
    }
}
exports.OidcRouterConfig = OidcRouterConfig;
class OidcRouterConfigFactory {
    basePath;
    cookieConfig;
    logger = rorLoggerFactory_1.RorLoggerFactory.getLoggerForFile(__filename);
    constructor(basePath, cookieConfig) {
        this.basePath = basePath;
        this.cookieConfig = cookieConfig;
    }
    constructFrom(auth) {
        if (!auth) {
            return [];
        }
        if (!OidcRouterConfigFactory.signatureKeyExists(auth)) {
            this.logger.info('No auth.signature_key set');
            return [];
        }
        if (!OidcRouterConfigFactory.oidcConfigurationsExist(auth)) {
            this.logger.info('No OIDC configurations found');
            return [];
        }
        const configs = auth.oidcConfigurations.filter(config => config.enabled);
        if (configs.length === 0) {
            this.logger.info('No enabled OIDC configurations found');
            return [];
        }
        return configs.map(config => new OidcRouterConfig(this.basePath, config, this.cookieConfig));
    }
    static signatureKeyExists(auth) {
        return Boolean(auth.signatureKey);
    }
    static oidcConfigurationsExist(auth) {
        return auth.oidcConfigurations?.length !== 0;
    }
}
exports.OidcRouterConfigFactory = OidcRouterConfigFactory;
