"use strict";
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_KIBANA_YAML_ROR_VALUES = void 0;
const types_1 = require("../proxy/core/common/types");
exports.DEFAULT_KIBANA_YAML_ROR_VALUES = {
    session_timeout_minutes: 4320,
    sessions_probe_interval_seconds: 30,
    whitelistedPaths: ['/status', '/api/status'],
    requestHeadersWhitelist: ['authorization', 'cookie', types_1.X_ROR_CURRENT_GROUP],
    cookieName: 'rorCookie'
};
